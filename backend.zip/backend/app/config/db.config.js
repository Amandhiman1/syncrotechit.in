module.exports = {
  url: process.env.MONGODB_URL
};
