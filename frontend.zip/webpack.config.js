module.exports = {
    optimization: {
        portableRecords: true,
    },
};