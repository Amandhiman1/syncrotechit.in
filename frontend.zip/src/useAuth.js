import { useState, useEffect } from 'react';
import AxiosJWT from './components/Dashboard/Common/AxiosJWT';

const useAuth = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const checkAuthStatus = async () => {
      try {
        const response = await AxiosJWT.get('https://flight-backend-ro3e.onrender.com/api/auth/check');
        if (response.status === 200) {
          setIsLoggedIn(true);
        } else {
          setIsLoggedIn(false);
        }
      } catch (error) {
        if (error.response && error.response.status === 403) {
          setIsLoggedIn(false);
        } else {
          console.error('An error occurred while checking authentication status:', error);
        }
      } finally {
        setLoading(false);
      }
    };

    checkAuthStatus();
  }, []);

  return { isLoggedIn, loading };
};

export default useAuth;
