import React from 'react'
import Header from './Include/Header'
import Footer from './Include/Footer'
import t_c  from './Assets/term&con.png'
import { Link } from 'react-router-dom'
import { useEffect } from 'react'
import HomeSearch from './HomeSearch'
import SearchComponent from './SearchComponent'


export default function TermAndConditions() {
  useEffect( ()=>{
    window.scrollTo({
      top : 0
    })
  },[] )



  let tc_link = [
    {
      id:"1",
      link_name: "Who are we?",
      link_url: "/",
    },
    {
      id:"2",
      link_name: "Some terms that we use in this Privacy Policy",
      link_url: "/",
    },
    {
      id:"3",
      link_name: "What Personal Data do we collect?",
      link_url: "/",
    },
    {
      id:"4",
      link_name: "For what purposes do we use your Personal Data?",
      link_url: "/",
    },
    {
      id:"5",
      link_name: "Who do we share your Personal Data with and why?",
      link_url: "/",
    },
    {
      id:"6",
      link_name: "How long do we store your Personal Data?",
      link_url: "/",
    },
    {
      id:"7",
      link_name: "How to access and control your Personal Data?",
      link_url: "/",
    },
    {
      id:"8",
      link_name: "Cookies & Similar technology",
      link_url: "/",
    },
    {
      id:"9",
      link_name: "Transferring your data outside of the European Economic Area",
      link_url: "/",
    },
    {
      id:"10",
      link_name: "Who do we share your Personal Data with and why?",
      link_url: "/",
    },
    {
      id:"11",
      link_name: "Complaint with the supervisory authority",
      link_url: "/",
    },
    {
      id:"12",
      link_name: "Contacting us and exercising your rights",
      link_url: "/",
    },
    {
      id:"13",
      link_name: "Data Protection Officer",
      link_url: "/",
    },
    {
      id:"14",
      link_name: "Changes to this Privacy Policy",
      link_url: "/",
    },

]
  return (
    <>
{/* header */}
    <Header/>
{/* end header  */}

{/* one section */}
<section className='tnc_section'>
  <div className='container'>
    <div className='row'>
      <div className='col-md-12'>
        <h2 className='meta_title_tac'>Term and conditions</h2>
      </div>
    </div>
    {/* <SearchComponent /> */}
  </div>
</section>
{/* end one section */}
 
{/* two section */}
<section className='tnc_two_section'>
  <div className='container'>
    <div className='row'>
      <div className='col-md-12'>
        <p className='Regulation-Policy'>We at vmaans.com take your privacy very seriously. Currently, we comply with the Regulation No. *******, the General Data Protection Regulation, also known as GDPR, which sets the highest privacy and data protection standard in the world. In this Privacy Policy we explain what data we collect from you, why we collect it, how we use it and with whom we might share it. It also explains what rights you as a data subject have and how you can fulfill them.
<br></br>This Privacy Policy applies to any data processing done by us in connection to the use of our services, both through our website vmaans.com
</p>
      </div>
    </div>
  </div>
</section>
{/* end two section */}


{/* three section */}
<section className='tnc_three_section'>
  <div className='container'>
    <div className='row'>
      <div className='col-md-6 d-flex'>
      <ul className='tc_list' >

      {
        tc_link.map((li_link => 

<li key={li_link.id}><Link to={li_link.link_url}>{li_link.link_name}</Link></li>

))
      }


    
</ul>
      </div>
      <div className='col-md-6'>
           <img  src={t_c} className='w-100' alt='' title='' />
      </div>
    </div>
  </div>
</section>
{/* end three section */}


{/* four section */}
<section className='tnc_four_section'>
  <div className='container'>
    <div className='row'>
      <div className='col-md-12'>
         <h2 className='heading_tc'>Who are we?</h2>
         <p className="dec_tc">We, as the Date Controller are the company vmaans.com s.r.o., ID No. *************, with a registered office at Calle Fuerteventura,70 4º3ª, Sabadell, Barcelona , 08205, the Spain, registered in the Commercial Register maintained by the Regional Court in Sabadell, file No. C 12247, Tax ID No. xxxxxxxxxx </p>
      </div>
    </div>
  </div>
</section>
{/* end four section */}

{/* five section */}
<section className='tnc_five_section'>
  <div className='container'>
    <div className='row'>
      <div className='col-md-12'>
         <h2 className='heading_tc'>Some terms that we use in this Privacy Policy</h2>
         <p className="dec_tc">Personal Data: any information relating to a directly or indirectly identified or identifiable natural person. That means that if we possess means to identify either you or even the device you're using, any information that we can connect to you will be treated as Personal Data. Data Controller: someone that determines the purposes and means of processing Personal Data. For example, we are a Data Controller when we process your Personal Data for the purposes stated in this Privacy Policy.If you choose to book a ticket through our website or app, we will be sending your Personal Data to another Data Controller – the carrier or the provider of other services – who will again use your Personal Data for its own purposes. Each Data Controller should have a Privacy Policy such as this one where you can learn about how your Personal Data is processed. You can see the overview of Data Controllers with whom we might share the data below. Data Processor: a third party that only helps to achieve the purposes determined by the Data Controller. For example, we as a Data Controller use many third-party services to which we outsource some parts of our activities that we don’t do ourselves for various reasons such as cost-efficiency. A Data Processor is only allowed to process your Personal Data according to our documented instructions. Third Countries: countries in which the GDPR regime is not applicable. Currently, by Third Countries, we mean all countries that lie outside of the European Economic Area.</p>
        
      </div>
    </div>
  </div>
</section>
{/* end five section */}

{/* six section */}
<section className='tnc_six_section'>
  <div className='container'>
    <div className='row'>
      <div className='col-md-12'>
         <h2 className='heading_tc'>What Personal Data do we collect?</h2>
         <p className="dec_tc">We collect your Personal Data directly from you, either when you provide us your Personal Data or gather them by ourselves when you use our services or you are in touch with us. Depending on the processing purpose, we may process the following categories of Personal Data:</p>
        <h5 className="head_tc">CATEGORY OF PERSONAL DATA</h5>
        <p className="dec_tc"><b>Identification information:</b> Information used to identify you as a natural person, such as your name, surname, gender, nationality, billing address, and date of birth, and artificial online identifier created by us, such as vmaans.com ID.</p>
        <p className="dec_tc"><b>Contact information:</b>	Information used to contact you, such as your email address and telephone number.</p>
        <p className="dec_tc"><b>Your online behavior while interacting with us:</b>	Your behavior on our website and in our app, i.e. what you visited, how long you stayed, what you clicked on, etc. We also track your interactions with the emails and notifications that we send you, such as if you open the email or if you click on any of the links that it contains.</p>
      </div>
    </div>
  </div>
</section>
{/* end six section */}

{/* header */}
    <Footer/>
{/* end header  */}


    </>
  )
}
