import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom"; // Import useParams
import axios from "axios";
import "./Include/css/style.css";
import Footer from "./Include/Footer";
import Header from "./Include/Header";
import { useSelector } from "react-redux";
import { useHistory } from "react-router-dom/cjs/react-router-dom";
import { Button, Form } from "react-bootstrap";
import PhoneInput from "react-phone-input-2";
import { format } from "date-fns";
import SearchComponent from "./SearchComponent";

const OfferDetails = () => {
  const { id } = useParams(); // Get the offer ID from URL parameters
  const [offer, setOffer] = useState(null);
  const [openForm, setOpenForm] = useState(false);
  const [formValue, setFormValue] = useState({
    name: "",
    email: "",
    phone: "",
    offerId: "",
  });
  const selectedLanguage = useSelector((state) => state.reducer.language);
  const history = useHistory();

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      document.querySelector("button.close").click();
      setOpenForm(false);
      console.log(process.env.REACT_APP_API_URL);
      // Make the first API call
      await axios.post("https://flight-backend-ro3e.onrender.com/api/inquiry", formValue, {
        headers: {
          "Content-Type": "application/json",
        },
      });
      // Handle success
      history.push("/thank-you");
    } catch (error) {
      // Handle errors
      console.error(error);
      alert(error);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormValue((prevFormValue) => ({
      ...prevFormValue,
      [name]: value,
    }));
  };

  useEffect(() => {
    // Fetch offer details based on the offer ID
    const fetchOfferDetails = async () => {
      try {
        const response = await axios.get(
          `https://flight-backend-ro3e.onrender.com/api/offers/${id}`
        );
        setOffer(response.data);
      } catch (error) {
        console.error("Error fetching offer details:", error);
      }
    };

    fetchOfferDetails();
  }, [id]); // Re-run the effect if the ID changes

  if (!offer) {
    return <div>Loading...</div>; // Show loading message while data is being fetched
  }

  return (
    <>
      {/* header */}
      <Header />
      {/* end header */}

      <div className="main-box-banner">
        <h1>{offer.to}</h1>
      <div className="container mb-5 common-padding">
        <SearchComponent />
      </div>
      </div>

      {/* <div className="flight-details">
  <div className="flight-card container">
    <div className="flight-info">
      <h2 className="flight-title">Offer Description</h2>
      <div className="flight-fields">
        <div className="flight-field">
          <span className="field-label">
            From:<img src="../icons/plane-departure-svgrepo-com (1).svg" />
          </span>
          <span className="field-value">{offer.from}</span>
        </div>
        <div className="flight-field">
          <span className="field-label">
            To:<img src="../icons/plane-arrival-svgrepo-com.svg" />
          </span>
          <span className="field-value">{offer.to}</span>
        </div>
        <div className="flight-field">
          <span className="field-label">
            Price:<img src="../icons/currency-dollar-circle-svgrepo-com.svg" />
          </span>
          <span className="field-value">${offer.price}</span>
        </div>
        <div className="flight-field">
          <span className="field-label">
            Airline:<img src="../icons/SpiceJet-Logo.svg" />
          </span>
          <span className="field-value">{offer.airline}</span>
        </div>
        <div className="flight-field">
          <span className="field-label">
            Travel Date:<img src="../icons/calender-svgrepo-com.svg" />
          </span>
          <span className="field-value">
            {format(new Date(offer.travelDate), "EEE dd MMM yyyy")}
          </span>
        </div>
        <div className="flight-field">
          <span className="field-label">
            Sales Valid:<img src="../icons/calender-svgrepo-com (1).svg" />
          </span>
          <span className="field-value">
            {format(new Date(offer.salesValid), "EEE dd MMM yyyy")}
          </span>
        </div>
        <div className="flight-field">
          <span className="field-label">
            Bag Allotment:<img src="../icons/bag-svgrepo-com.svg" />
          </span>
          <span className="field-value">{offer.bagAllot}</span>
        </div>
        <div className="flight-field">
          <span className="field-label">
            Cabin:<img src="../icons/cabin-617-svgrepo-com.svg" />
          </span>
          <span className="field-value">{offer.cabin}</span>
        </div>
      </div>
      <div className="flight-policy">
        <h2 className="policy-title">Offer Policy</h2>
        <h5>Policy Discription</h5>
        <div class="policy-box-main">
        <div className="flight-field policy-full-width">
          <span className="field-label">Cancel Fees:</span>
          <span className="field-value">{offer.cancelFees}%</span>
        </div>
        <div className="flight-field policy-full-width">
          <span className="field-label">Change Fees:</span>
          <span className="field-value">{offer.changeFees}%</span>
        </div>
        </div> */}
<div class="offer-ab-description">
    <h2>Offer Description</h2>
    <p class="description-ab">{offer.desc[selectedLanguage]}</p>
</div>

<div class="offer-ab-details-section">
    <h3>Offer Details</h3>
    <div class="card-ab-container">
        <div class="row">
            <div class="card-ab">
                <div class="icon">✈️</div>
                <div class="details-ab">
                    <h3>From:</h3>
                    <p>{offer.from}</p>
                </div>
            </div>
            <div class="card-ab">
                <div class="icon">🛬</div>
                <div class="details-ab">
                    <h3>To:</h3>
                    <p>{offer.to}</p>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="card-ab">
                <div class="icon">💲</div>
                <div class="details-ab">
                    <h3>Price:</h3>
                    <p>${offer.price}</p>
                </div>
            </div>
            <div class="card-ab">
                <div class="icon">✈️</div>
                <div class="details-ab">
                    <h3>Airline:</h3>
                    <p>{offer.airline}</p>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="card-ab">
                <div class="icon">📅</div>
                <div class="details-ab">
                    <h3>Travel Date:</h3>
                    <p>{format(new Date(offer.travelDate), "EEE dd MMM yyyy")}</p>
                </div>
            </div>
            <div class="card-ab">
                <div class="icon">📅</div>
                <div class="details-ab">
                    <h3>Sales Valid:</h3>
                    <p>{format(new Date(offer.salesValid), "EEE dd MMM yyyy")}</p>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="card-ab">
                <div class="icon">👜</div>
                <div class="details-ab">
                    <h3>Bag Allotment:</h3>
                    <p>{offer.bagAllot}</p>
                </div>
            </div>
            <div class="card-ab">
                <div class="icon">🚉</div>
                <div class="details-ab">
                    <h3>Cabin:</h3>
                    <p>{offer.cabin}</p>
                </div>
            </div>
        </div>
    </div>
</div>

<div>
  <h2 class="pilicy-head">Offer Policy</h2>
<div class="policy-ab-offer-section">
    <h3>Policy Discription</h3>
    <div class="card-ab-container">
        <div class="row">
            <div class="card-ab">
                {/* <div class="icon">🔒</div> */}
                <div class="details-ab">
                    <h3>Cancel Fees:</h3>
                    <p>{offer.cancelFees}%</p>
                </div>
            </div>
            <div class="card-ab">
                {/* <div class="icon">💼</div> */}
                <div class="details-ab">
                    <h3>Change Fees:</h3>
                    <p>{offer.changeFees}%</p>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
        {/* <div className="flight-field policy-full-width">
          <span
            className="field-value"
            dangerouslySetInnerHTML={{
              __html: offer.policy[selectedLanguage],
            }}
          />
        </div> */}
      {/* </div>
    </div> */}
    {/* <div className="flight-info-image">
      <img
        src={`https://flight-backend-ro3e.onrender.com/images/${offer.image}`}
        alt="Flight Image"
      />
    </div> */}
  {/* // </div> */}
  <div className="flight-buy-now">
    <button
      className="buy-now-button"
      onClick={() => {
        setOpenForm(true);
        setFormValue((prevFormValue) => ({
          ...prevFormValue,
          offerId: offer._id,
        }));
      }}
    >
      Get This Offer
    </button>
  </div>
{/* </div> */}


      {openForm && (
        <div id="up-sec1">
          <div
            class="modal fade sec-up show"
            id="exampleModal"
            tabindex="-1"
            aria-labelledby="exampleModalLabel"
            aria-modal="true"
            role="dialog"
            style={{ display: "block" }}
          >
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header form-background">
                  <div class="modal-header-inner">
                    <img
                      src={`${process.env.PUBLIC_URL}/image/airplane-form.png`}
                      alt="Example"
                    />
                  </div>
                  <div class="modal-heading">
                    <h5 class="modal-title" id="exampleModalLabel">
                      {/* {" "} */}
                      Please Fill The <span>Details Below</span>
                    </h5>
                    <p>
                      Founded by grandsons of the founders, created to make
                      flying easy and affordable
                    </p>
                  </div>
                  <button
                    type="button"
                    class="close"
                    data-dismiss="modal"
                    aria-label="Close"
                    fdprocessedid="n4qy62"
                    onClick={() => setOpenForm(false)}
                  >
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body form-background">
                  <div className="overlay-body">
                    <Form onSubmit={handleSubmit}>
                      <Form.Group className="mb-3" controlId="name">
                        <Form.Label>Name</Form.Label>
                        <Form.Control
                          type="text"
                          placeholder="Enter Name"
                          name="name"
                          value={formValue.name}
                          className="my-form"
                          onChange={handleInputChange}
                          required
                        />
                      </Form.Group>
                      <Form.Group className="mb-3" controlId="formBasicEmail">
                        <Form.Label>Email</Form.Label>
                        <Form.Control
                          type="email"
                          placeholder="Email"
                          name="email"
                          className="my-form"
                          value={formValue.email}
                          onChange={handleInputChange}
                          required
                        />
                      </Form.Group>
                      <Form.Group className="mb-3" controlId="number">
                        <Form.Label>Phone Number</Form.Label>
                        <PhoneInput
                          placeholder="Enter phone number"
                          value={formValue.phone}
                          onChange={(value) =>
                            setFormValue({ ...formValue, phone: value })
                          }
                          country={"in"}
                          className="my-form"
                          required
                        />
                      </Form.Group>
                      <Form.Group controlId="termsCheckbox" className="mb-3">
                        <Form.Check
                          type="checkbox"
                          label="I accept the terms and conditions"
                          name="termsAccepted"
                          checked={formValue.termsAccepted}
                          onChange={handleInputChange}
                          required
                        />
                      </Form.Group>
                      <div className="form-btn">
                        <Button
                          variant="primary"
                          type="submit"
                          className="sub-btn-form"
                        >
                          Submit
                        </Button>
                      </div>
                    </Form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* footer */}
      <Footer />
      {/* end footer */}
    </>
  );
};

export default OfferDetails;
