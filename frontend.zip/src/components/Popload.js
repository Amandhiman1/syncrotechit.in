import React, { useState, useEffect } from 'react';
import Contact from './Contact'

const Popload = () => {
    const [percent, setPercent] = useState(0);
    const [animationComplete, setAnimationComplete] = useState(false);
    const [dataLoading, setDataLoading] = useState(true);
    const [openForm, setOpenForm] = useState(false);

    useEffect(() => {
        const animate = () => {
            if (percent < 100) {
                setPercent(prevPercent => prevPercent + 1);
            } else {
                setAnimationComplete(true);
            }
        };

        const animationInterval = setInterval(animate, 40);

        // Cleanup function to clear interval when component unmounts
        return () => clearInterval(animationInterval);
    }, [percent]); // Re-run effect when percent changes

    useEffect(() => {
        if (animationComplete) {
            alert("Flight not found!");
            setDataLoading(false);
            setOpenForm(true);
        }
    }, [animationComplete]);

    return (
        <div className="PoploadContainer">
            <div className="Popload">
                <div className="progress" style={{ width: `${percent}%` }}></div>
                <div className="counter">{percent}% </div>
                {dataLoading && <span>Loading...</span>}
                {openForm && <Contact />}
            </div>
        </div>
    );
};

export default Popload;