import React, { useState, useEffect } from "react";
import { useDispatch } from 'react-redux';
import { Button, Modal, Row } from 'react-bootstrap';
import axios from 'axios';
import { setLanguage } from '../redux/Action';
import cross from './Common/img/crossmodal.svg';

// Import images
import lanuageimg from './Common/img/lan_cun_dp.svg';
import Currencyimg from './Common/img/Currency_dp.svg';
import rightarrow from './Common/img/right_arrow.svg';
import leftarrow from './Common/img/left_arrow.svg';
import lanuagebtn from './Common/img/language.svg';
import earth from './Common/img/globe-menu.svg'

export default function SignupPop() {
  const [showlancun, setlancunShow] = useState(false);
  const [showCurrency, setShowCurrency] = useState(false);
  const [showLanguage, setShowLanguage] = useState(false);
  const [langs, setLangs] = useState([]);
  const [selectedLanguage, setSelectedLanguage] = useState(localStorage.getItem('language') || 'en');
  const [selectedCurrency, setSelectedCurrency] = useState(JSON.parse(localStorage.getItem('selectedCurrency')) || { id: "1", title: "Euro", value: "euro" });

  const dispatch = useDispatch();

  // Fetch languages from the API
  useEffect(() => {
    axios.get('https://flight-backend-ro3e.onrender.com/api/languages')
      .then(({ data }) => {
        if (data.length) setLangs(data);
      })
      .catch(error => console.error("Error fetching languages:", error));
  }, []);

  // Handle language change
  const handleLanguageChange = (e) => {
    const languageCode = e.target.value;
    setSelectedLanguage(languageCode);
    dispatch(setLanguage(languageCode));
    localStorage.setItem('language', languageCode);
  };

  // Handle currency change
  const handleCurrencyChange = (currency) => {
    setSelectedCurrency(currency);
    localStorage.setItem('selectedCurrency', JSON.stringify(currency));
  };

  // Handle Continue button click
  const handleContinue = () => {
    setlancunShow(false);
    console.log('Language changed to:', selectedLanguage);
    console.log('Currency changed to:', selectedCurrency);
  };

  // Currency options
  const currencies = [
    { id: "1", title: "Euro", value: "EUR" },
    { id: "2", title: "US Dollar", value: "USD" },
    { id: "3", title: "British Pound", value: "GBP" },
    { id: "4", title: "Japanese Yen", value: "JPY" },
    { id: "5", title: "Indian Rupees", value: "INR" },
    { id: "6", title: "Chinese Yuan", value: "CNY" },
    { id: "7", title: "Australian Dollar", value: "AUD" },
  ];

  // Modal content for Language and Currency
  const renderLanguageModal = () => (
    <Modal show={showLanguage} onHide={() => setShowLanguage(false)} animation={false} className="loginwithdp curn_dp">
     <Modal.Header>
          <img src={cross} alt="Close modal" onClick={() => {setShowLanguage(false); setlancunShow(true);}} />
        </Modal.Header>
      <Modal.Body>
        <div className="details_dp curn_dp">
          <h3 className="title pt-5">Select Language</h3>
          <p>Choose your preferred language. You can always change it in the top menu.</p>
        </div>
        <ul className="poplist-dp langu-dp">
          {langs.length > 0 ? langs.map((lang) => (
            <li
              key={lang.code}
              onClick={() => handleLanguageChange({ target: { value: lang.code } })}
              className={selectedLanguage === lang.code ? 'active' : ''}
            >
              <div style={{ display: 'flex', alignItems: 'center' }} className="listmain_dp">
                <img src={lanuagebtn} alt={lang.name} style={{ width: 40, marginRight: 8 }} />
                <p className="m-0 list_dp">{lang.name}</p>
              </div>
            </li>
          )) : (
            <li>Loading...</li>
          )}
        </ul>
      </Modal.Body>
      <Modal.Footer>
        <div className="btn_dp">
          <div className="left_btn_dp">
            <img src={leftarrow} alt="left arrow" width={40} height={40} className="img-fluid mx-auto" />
            <Button className="cancel_btn" onClick={() => {setShowLanguage(false); setlancunShow(true);}}>Cancel</Button>
          </div>
          <div className="right_btn_dp">
            <Button className="done_btn" onClick={() => {setShowLanguage(false); setlancunShow(true);}}>Done</Button>
            <img src={rightarrow} alt="right arrow" width={40} height={40} className="img-fluid mx-auto" />
          </div>
        </div>
      </Modal.Footer>
    </Modal>
  );

  const renderCurrencyModal = () => (
    <Modal show={showCurrency} onHide={() => setShowCurrency(false)} animation={false} className="loginwithdp curn_dp">
    <Modal.Header>
          <img src={cross} alt="Close modal" onClick={() => {setShowCurrency(false); setlancunShow(true)}} />
        </Modal.Header>
      <Modal.Body>
        <div className="details_dp curn_dp">
          <h3 className="title pt-5">Select Currency</h3>
          <p>Choose your preferred currency. You can always change it in the top menu.</p>
        </div>
        <ul className="poplist-dp">
          {currencies.map((currency) => (
            <li
              key={currency.id}
              onClick={() => handleCurrencyChange(currency)}
              className={selectedCurrency.value === currency.value ? 'active' : ''}
            >
              <div style={{ display: 'flex', alignItems: 'center' }} className="listmain_dp">
                <img src={Currencyimg} alt={currency.title} style={{ width: 40, marginRight: 8 }} />
                <p className="m-0 list_dp">
                  {currency.title} <p>(<span>{currency.value}</span>)</p>
                </p>
              </div>
            </li>
          ))}
        </ul>
      </Modal.Body>
      <Modal.Footer>
        <div className="btn_dp">
          <div className="left_btn_dp">
            <img src={leftarrow} alt="left arrow" width={40} height={40} className="img-fluid mx-auto" />
            <Button className="cancel_btn" onClick={() => {setShowCurrency(false); setlancunShow(true)}}>Cancel</Button>
          </div>
          <div className="right_btn_dp">
            <Button className="done_btn" onClick={() => {setShowCurrency(false); setlancunShow(true)}}>Done</Button>
            <img src={rightarrow} alt="right arrow" width={40} height={40} className="img-fluid mx-auto" />
          </div>
        </div>
      </Modal.Footer>
    </Modal>
  );

  return (
    <>
      <Modal
        show={showlancun}
        onHide={() => setlancunShow(false)}
        backdrop="static"
        keyboard={false}
        className="loginwithdp curn_dp"
      >
      <Modal.Header>
          <img src={cross} alt="Close modal" onClick={handleContinue} />
        </Modal.Header>
        <Modal.Body>
          <Row className="pop_box_dp">
            <div className="image_dp mx-auto">
              <img src={lanuageimg} className="img-fluid" alt="language_img" />
            </div>
            <div className="details_dp">
              <h3 className="title">Select language and currency</h3>
              <p>Choose your preferred language and currency. You can always change them in the top menu.</p>
            </div>
            {/* Language Dropdown */}
            <div className="drop_dp pt-0">
              <h5>Language</h5>
              <Button className="drop_btn_dp" onClick={() => { setShowLanguage(true); setlancunShow(false); }}>
                <img src={lanuagebtn} alt="language button" />
                {langs.length > 0 ? langs.find(lang => lang.code === selectedLanguage)?.name || 'Select Language' : 'Loading...'}
              </Button>
            </div>
            {/* Currency Dropdown */}
            <div className="drop_dp">
              <h5>Currency</h5>
              <Button className="drop_btn_dp" onClick={() => { setShowCurrency(true); setlancunShow(false); }}>
                <img src={Currencyimg} alt="Currency button" />
                {selectedCurrency.title}
              </Button>
            </div>
          </Row>
        </Modal.Body>
        <Modal.Footer>
          <div className="pop_btn_dp">
            <Button className="Continue_btn" onClick={handleContinue}>Continue</Button>
            <img src={rightarrow} alt="right arrow" width={40} height={40} className="img-fluid mx-auto" />
          </div>
        </Modal.Footer>
      </Modal>

      {/* Language and Currency Buttons */}
      <div className="menu_icon_dp">
      <img src={earth} width={15} height={15}/>
      <h6 className="navlistbtn" onClick={() => setlancunShow(true)}>
        {langs.length > 0 ? langs.find(lang => lang.code === selectedLanguage)?.name || 'Select Language' : 'Loading...'}
      </h6>
      </div>
      <div className="menu_icon_dp">
      <img src={earth} width={15} height={15}/>
      <h6 className="navlistbtn" onClick={() => setlancunShow(true)}>{selectedCurrency.value}</h6>
      </div>
      {/* Render Modals */}
      {renderCurrencyModal()}
      {renderLanguageModal()}
    </>
  );
}
 