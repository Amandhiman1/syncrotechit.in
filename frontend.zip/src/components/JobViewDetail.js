import React, { useEffect, useState } from "react";
import Header from "./Include/Header";
import Footer from "./Include/Footer";
import jvd_arrow from "./Assets/jvd-arrow.png";
import HomeSearch from "./HomeSearch";
import SearchComponent from "./SearchComponent";
import { useSelector } from "react-redux";
import { useParams } from "react-router-dom";
import { Button, Form, Spinner } from "react-bootstrap";
import PhoneInput from "react-phone-input-2";

export default function JobViewDetail() {
  const [job, setJob] = useState([]);
  const [loading, setLoading] = useState(true);
  const [formLoading, setFormLoading] = useState(false);
  const [openForm, setOpenForm] = useState(false);
  const [formValue, setFormValue] = useState({
    name: "",
    email: "",
    phone: "",
    cv: null,
    termsAccepted: false,
  });
  const [errors, setErrors] = useState({});
  const selectedLanguage = useSelector((state) => state.reducer.language);
  const { slug } = useParams();

  useEffect(() => {
    window.scrollTo({
      top: 0,
    });

    // Fetch jobs from API
    const fetchJobs = async () => {
      try {
        const response = await fetch(`https://flight-backend-ro3e.onrender.com/api/job/${slug}`);
        const data = await response.json();
        console.log(data);
        
        setJob(data);
      } catch (error) {
        console.error("Error fetching jobs:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchJobs();
  }, [slug]);

  const validateForm = () => {
    const newErrors = {};
    const { name, email, phone, cv, termsAccepted } = formValue;

    if (!name) newErrors.name = "Name is required.";
    if (!email) newErrors.email = "Email is required.";
    else if (!/\S+@\S+\.\S+/.test(email)) newErrors.email = "Email is invalid.";
    if (!phone) newErrors.phone = "Phone number is required.";
    if (!cv) newErrors.cv = "CV is required.";
    else if (cv && cv.type !== "application/pdf") newErrors.cv = "CV must be a PDF file.";
    if (!termsAccepted) newErrors.termsAccepted = "You must accept the terms and conditions.";

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
  
    if (name === "name") {
      // Allow only alphabets and spaces for the name field
      if (/^[A-Za-z\s]*$/.test(value)) {
        setFormValue({ ...formValue, [name]: value });
        setErrors({ ...errors, [name]: "" }); // Clear error if valid
      } else {
        setErrors({ ...errors, [name]: "Name can only contain alphabets and spaces." });
      }
    } else {
      setFormValue({ ...formValue, [name]: value });
    }
  };

  const handleFileChange = (e) => {
    setFormValue({ ...formValue, cv: e.target.files[0] });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!validateForm()) return;

    setFormLoading(true);

    const formData = new FormData();
    formData.append("name", formValue.name);
    formData.append("email", formValue.email);
    formData.append("phone", formValue.phone);
    formData.append("cv", formValue.cv);

    try {
      const response = await fetch(
        `https://flight-backend-ro3e.onrender.com/api/jobs/${job._id}/apply`,
        {
          method: "POST",
          body: formData,
        }
      );

      if (!response.ok) {
        const errorData = await response.json();
        console.error(errorData);
        alert(errorData.message);
        return;
      }

      alert("Application submitted successfully!");
      setOpenForm(false);
    } catch (error) {
      console.error("Error submitting application:", error);
    } finally {
      setFormLoading(false);
    }
  };

  return (
    <>
      {/* header */}
      <Header />
      {/* end header  */}

      <section className="jvd_section">
        <div className="container">
          <div className="row">
            <div className="col-md-12">
              <h2 className="meta_title_tac">
                <span>Job </span>{" "}
                <img src={jvd_arrow} className="" alt="" title="" />
                {loading ? (
                  <Spinner animation="border" variant="primary" />
                ) : (
                  job.jobTitle[selectedLanguage]
                )}
              </h2>
            </div>
          </div>
        </div>
      </section>

      <div className="main_jdc">
        <section className="job_detil_sec">
          <div className="container">
            <div className="row">
              <div className="col-lg-9 col-md-8 col-sm-12">
                {loading ? (
                  <Spinner animation="border" variant="primary" />
                ) : (
                  <div
                    dangerouslySetInnerHTML={{
                      __html: job.jobDesc[selectedLanguage],
                    }}
                  />
                )}
              </div>
              <div className="col-lg-3 col-md-4 col-sm-12">
                <div className="jvd_leftside">
                  <dl className="list_right">
                    <dt>Department</dt>
                    <dd>
                      {loading ? (
                        <Spinner animation="border" variant="primary" />
                      ) : (
                        job.department
                      )}
                    </dd>
                    <dt>Location</dt>
                    <dd>
                      {loading ? (
                        <Spinner animation="border" variant="primary" />
                      ) : (
                        job.location
                      )}
                    </dd>
                  </dl>
                  <button
                    className="fasstbooking_btn"
                    onClick={() => setOpenForm(true)}
                  >
                    Apply
                  </button>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="jvd_three_section">
          <div className="container">
            <p className="jvd_para">
              For certain positions we can help with relocation from anywhere in
              the world, please let us know in your applications and we will
              assess whether this is possible. English is the official language
              at the office. Please submit your resume in English if you choose
              to apply. At XYZ we believe that diversity adds incredible value
              to our teams, our products, and our culture. We don’t just accept
              differences—we celebrate it, we support it, and we thrive on it
              for the benefit of our employees, our products, and our community.
              As an equal opportunity employer, we stay true to our mission by
              ensuring that our place can be anyone’s place regardless of race,
              religion, gender, sexual orientation, national origin, disability
              or age.
            </p>
          </div>
        </section>

        {openForm && (
          <div id="up-sec1">
            <div
              className="modal fade sec-up show"
              id="exampleModal"
              tabIndex="-1"
              aria-labelledby="exampleModalLabel"
              aria-modal="true"
              role="dialog"
              style={{ display: "block" }}
            >
              <div className="modal-dialog">
                <div className="modal-content">
                  <div className="modal-header form-background">
                    <div className="modal-heading">
                      <h5 className="modal-title" id="exampleModalLabel">
                        Please Fill The <span>Details Below</span>
                      </h5>
                      <p>
                        Founded by grandsons of the founders, created to make
                        flying easy and affordable
                      </p>
                    </div>
                    <button
                      type="button"
                      className="close"
                      data-dismiss="modal"
                      aria-label="Close"
                      onClick={() => setOpenForm(false)}
                    >
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div className="modal-body form-background">
                    <div className="overlay-body">
                      <Form onSubmit={handleSubmit}>
                        <Form.Group className="mb-3" controlId="name">
                          <Form.Label>Name*</Form.Label>
                          <Form.Control
                            type="text"
                            placeholder="Enter Name"
                            name="name"
                            value={formValue.name}
                            className="my-form"
                            onChange={handleInputChange}
                            required
                          />
                          {errors.name && <Form.Text className="text-danger">{errors.name}</Form.Text>}
                        </Form.Group>
                        <Form.Group className="mb-3" controlId="formBasicEmail">
                          <Form.Label>Email*</Form.Label>
                          <Form.Control
                            type="email"
                            placeholder="Email"
                            name="email"
                            className="my-form"
                            value={formValue.email}
                            onChange={handleInputChange}
                            required
                          />
                          {errors.email && <Form.Text className="text-danger">{errors.email}</Form.Text>}
                        </Form.Group>
                        <Form.Group className="mb-3" controlId="number">
                          <Form.Label>Phone Number*</Form.Label>
                          <PhoneInput
                            placeholder="Enter phone number"
                            value={formValue.phone}
                            onChange={(value) =>
                              setFormValue({ ...formValue, phone: value })
                            }
                            country={"in"}
                            className="my-form"
                            required
                          />
                          {errors.phone && <Form.Text className="text-danger">{errors.phone}</Form.Text>}
                        </Form.Group>
                        <Form.Group className="mb-3" controlId="cv">
                          <Form.Label>Upload CV (PDF only)*</Form.Label>
                          <Form.Control
                            type="file"
                            name="cv"
                            accept=".pdf"
                            onChange={handleFileChange}
                            required
                          />
                          {errors.cv && <Form.Text className="text-danger">{errors.cv}</Form.Text>}
                        </Form.Group>
                        <Form.Group controlId="termsCheckbox" className="mb-3">
                          <Form.Check
                            type="checkbox"
                            label="I accept the terms and conditions"
                            name="termsAccepted"
                            checked={formValue.termsAccepted}
                            onChange={(e) =>
                              setFormValue({
                                ...formValue,
                                termsAccepted: e.target.checked,
                              })
                            }
                            required
                          />
                          {errors.termsAccepted && <Form.Text className="text-danger">{errors.termsAccepted}</Form.Text>}
                        </Form.Group>
                        <div className="form-btn">
                          <Button
                            variant="primary"
                            type="submit"
                            className="sub-btn-form"
                            disabled={formLoading}
                          >
                            {formLoading ? (
                              <Spinner animation="border" size="sm" />
                            ) : (
                              "Submit"
                            )}
                          </Button>
                        </div>
                      </Form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* footer */}
      <Footer />
      {/* end footer  */}
    </>
  );
}
