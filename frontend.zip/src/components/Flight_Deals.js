import React, { useState } from "react";
import "./Include/css/style.css";
import Footer from "./Include/Footer";
import Header from "./Include/Header";
import flightd from "./Assets/FlightDealsfirst.svg";
import { Link } from "react-router-dom";
import { useEffect } from "react";
import singapur from "./Assets/25400 1.png";
import africa from "./Assets/216 1.png";
import newzeland from "./Assets/Flights to New Zealand 3.png";
import mexico from "./Assets/Flights to Mexico 3.png";
import HomeSearch from "./HomeSearch";
import SearchComponent from "./SearchComponent";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faArrowsAltH } from "@fortawesome/free-solid-svg-icons";
import axios from "axios";
import { Button, Form } from "react-bootstrap";
import PhoneInput from "react-phone-input-2";
import { useHistory } from "react-router-dom/cjs/react-router-dom";

export default function FlightDeals() {
  const [offerData, setOfferData] = useState([]);

  const getOffers = async () => {
    await axios
      .get("https://flight-backend-ro3e.onrender.com/api/offers")
      .then((response) => {
        setOfferData(response.data);
      })
      .catch((error) => {
        console.error("There was an error fetching the offers!", error);
      });
  };

  useEffect(() => {
    window.scrollTo({
      top: 0,
    });
    getOffers();
  }, []);

  return (
    <>
      {/* header */}
      <Header />
      {/* end header  */}
      <div className="main-box-banner">
      <div className="container mb-5 common-padding">
        <SearchComponent />
      </div>
      </div>

      {/* two section */}
      <section className="flight_two_section pt-5 pb-1">
        <div className="container">
          <div className="row">
            {/* {origin.map(pricebox =>(
          <div className='col-lg-4 col-md-6 col-sm-6 col-xs-12' key={pricebox.id}>
              <Link to="#">
                <div className='flight' >
                    <img src={pricebox.imgs} alt='' className='fly_price_image' />
                    <div className='flight_price'>
                      <span className='fly-c-name'>{pricebox.c_name}</span>
                      <span className='fly-c-price'>{pricebox.c_price}</span>
                    </div>
                </div>
              </Link>
            </div>
        ))} */}

            <div className="col-lg-12">
              <div className="col-lg-12 row-set mb-3">
                {offerData.map((offer) => (
                  <div className="col-lg-4 bottom-gap">
                    <Link to={`/offer/${offer._id}`}>
                      <div class="small-image-container">
                        <img
                          src={`https://flight-backend-ro3e.onrender.com/images/${offer.image}`}
                          alt="Example"
                        />
                        <div class="content main12">
                          <div class="main-content">
                            <h2>{offer.to}</h2>
                            <p>
                              Ticket From<b>{offer.price}$</b>
                            </p>
                          </div>
                          <div class="hover-content">
                            <p>
                              {offer.from}{" "}
                              <FontAwesomeIcon
                                icon={faArrowsAltH}
                                className="icon-color"
                              />
                            </p>
                            <h2>{offer.to}</h2>
                            <p>
                              Ticket From <b>{offer.price}$</b>
                            </p>
                          </div>
                        </div>
                      </div>
                    </Link>
                  </div>
                ))}
                {/* <div className="col-lg-4 bottom-gap ">
                  <Link href="#">
                    <div class="small-image-container">
                      <img
                        src={`${process.env.PUBLIC_URL}/image/canada.png`}
                        alt="Example"
                      />
                      <div class="content main12">
                        <div class="main-content">
                          <h2>Canada</h2>
                          <p>
                            Ticket From<b>52$</b>
                          </p>
                        </div>
                        <div class="hover-content">
                          <p>
                            Chandigarh{" "}
                            <FontAwesomeIcon
                              icon={faArrowsAltH}
                              className="icon-color"
                            />
                          </p>
                          <h2>Canada</h2>
                          <p>
                            Ticket From<b>52$</b>
                          </p>
                        </div>
                      </div>
                    </div>
                  </Link>
                </div>
                <div className="col-lg-4 bottom-gap">
                  <Link href="#">
                    <div class="small-image-container">
                      <img
                        src={`${process.env.PUBLIC_URL}/image/paris.png`}
                        alt="Example"
                      />
                      <div class="content main12">
                        <div class="main-content">
                          <h2>Paris</h2>
                          <p>
                            Ticket From<b>52$</b>
                          </p>
                        </div>
                        <div class="hover-content">
                          <p>
                            Chandigarh{" "}
                            <FontAwesomeIcon
                              icon={faArrowsAltH}
                              className="icon-color"
                            />
                          </p>
                          <h2>Paris</h2>
                          <p>
                            Ticket From<b>52$</b>
                          </p>
                        </div>
                      </div>
                    </div>
                  </Link>
                </div> */}
              </div>
              {/* <div className="col-lg-12 row-set mb-3">
                <div className="col-lg-4 bottom-gap">
                  <Link href="#">
                    <div class="small-image-container">
                      <img
                        src={`${process.env.PUBLIC_URL}/image/england.png`}
                        alt="Example"
                      />
                      <div class="content main12">
                        <div class="main-content">
                          <h2>England</h2>
                          <p>
                            Ticket From<b>52$</b>
                          </p>
                        </div>
                        <div class="hover-content">
                          <p>
                            Chandigarh{" "}
                            <FontAwesomeIcon
                              icon={faArrowsAltH}
                              className="icon-color"
                            />
                          </p>
                          <h2>England</h2>
                          <p>
                            Ticket From<b>52$</b>
                          </p>
                        </div>
                      </div>
                    </div>
                  </Link>
                </div>
                <div className="col-lg-4 bottom-gap">
                  <Link href="#">
                    <div class="small-image-container">
                      <img
                        src={`${process.env.PUBLIC_URL}/image/france.png`}
                        alt="Example"
                      />
                      <div class="content main12">
                        <div class="main-content">
                          <h2>France</h2>
                          <p>
                            Ticket From<b>52$</b>
                          </p>
                        </div>
                        <div class="hover-content">
                          <p>
                            Chandigarh{" "}
                            <FontAwesomeIcon
                              icon={faArrowsAltH}
                              className="icon-color"
                            />
                          </p>
                          <h2>France</h2>
                          <p>
                            Ticket From<b>52$</b>
                          </p>
                        </div>
                      </div>
                    </div>
                  </Link>
                </div>
                <div className="col-lg-4 bottom-gap">
                  <Link href="#">
                    <div class="small-image-container">
                      <img
                        src={`${process.env.PUBLIC_URL}/image/spain.png`}
                        alt="Example"
                      />
                      <div class="content main12">
                        <div class="main-content">
                          <h2>Spain</h2>
                          <p>
                            Ticket From<b>85$</b>
                          </p>
                        </div>
                        <div class="hover-content">
                          <p>
                            Chandigarh{" "}
                            <FontAwesomeIcon
                              icon={faArrowsAltH}
                              className="icon-color"
                            />
                          </p>
                          <h2>Spain</h2>
                          <p>
                            Ticket From<b>85$</b>
                          </p>
                        </div>
                      </div>
                    </div>
                  </Link>
                </div>
              </div>
              <div className="col-lg-12 row-set mb-3">
                <div className="col-lg-4 bottom-gap ">
                  <Link href="#">
                    <div class="small-image-container">
                      <img
                        src={`${process.env.PUBLIC_URL}/image/germany.png`}
                        alt="Example"
                      />
                      <div class="content main12">
                        <div class="main-content">
                          <h2>Germany</h2>
                          <p>
                            Ticket From<b>65$</b>
                          </p>
                        </div>
                        <div class="hover-content">
                          <p>
                            Chandigarh{" "}
                            <FontAwesomeIcon
                              icon={faArrowsAltH}
                              className="icon-color"
                            />
                          </p>
                          <h2>Germany</h2>
                          <p>
                            Ticket From<b>65$</b>
                          </p>
                        </div>
                      </div>
                    </div>
                  </Link>
                </div>
                <div className="col-lg-4 bottom-gap">
                  <Link href="#">
                    <div class="small-image-container">
                      <img
                        src={`${process.env.PUBLIC_URL}/image/japan.png`}
                        alt="Example"
                      />
                      <div class="content main12">
                        <div class="main-content">
                          <h2>Japan</h2>
                          <p>
                            Ticket From<b>552$</b>
                          </p>
                        </div>
                        <div class="hover-content">
                          <p>
                            Chandigarh{" "}
                            <FontAwesomeIcon
                              icon={faArrowsAltH}
                              className="icon-color"
                            />
                          </p>
                          <h2>Japan</h2>
                          <p>
                            Ticket From<b>552$</b>
                          </p>
                        </div>
                      </div>
                    </div>
                  </Link>
                </div>
                <div className="col-lg-4 bottom-gap">
                  <Link href="#">
                    <div class="small-image-container">
                      <img
                        src={`${process.env.PUBLIC_URL}/image/thailand.png`}
                        alt="Example"
                      />
                      <div class="content main12">
                        <div class="main-content">
                          <h2>Thailand</h2>
                          <p>
                            Ticket From<b>524$</b>
                          </p>
                        </div>
                        <div class="hover-content">
                          <p>
                            Chandigarh{" "}
                            <FontAwesomeIcon
                              icon={faArrowsAltH}
                              className="icon-color"
                            />
                          </p>
                          <h2>Thailand</h2>
                          <p>
                            Ticket From<b>524$</b>
                          </p>
                        </div>
                      </div>
                    </div>
                  </Link>
                </div>
              </div>
              <div className="col-lg-12 row-set mb-3">
                <div className="col-lg-4 bottom-gap">
                  <Link href="#">
                    <div class="small-image-container">
                      <img
                        src={`${process.env.PUBLIC_URL}/image/maxico.png`}
                        alt="Example"
                      />
                      <div class="content main12">
                        <div class="main-content">
                          <h2>Mexico</h2>
                          <p>
                            Ticket From<b>452$</b>
                          </p>
                        </div>
                        <div class="hover-content">
                          <p>
                            Chandigarh{" "}
                            <FontAwesomeIcon
                              icon={faArrowsAltH}
                              className="icon-color"
                            />
                          </p>
                          <h2>Mexico</h2>
                          <p>
                            Ticket From<b>452$</b>
                          </p>
                        </div>
                      </div>
                    </div>
                  </Link>
                </div>
                <div className="col-lg-4 bottom-gap">
                  <Link href="#">
                    <div class="small-image-container">
                      <img
                        src={`${process.env.PUBLIC_URL}/image/russia.png`}
                        alt="Example"
                      />
                      <div class="content main12">
                        <div class="main-content">
                          <h2>Russia</h2>
                          <p>
                            Ticket From<b>522$</b>
                          </p>
                        </div>
                        <div class="hover-content">
                          <p>
                            Chandigarh{" "}
                            <FontAwesomeIcon
                              icon={faArrowsAltH}
                              className="icon-color"
                            />
                          </p>
                          <h2>Russia</h2>
                          <p>
                            Ticket From<b>522$</b>
                          </p>
                        </div>
                      </div>
                    </div>
                  </Link>
                </div>
                <div className="col-lg-4 bottom-gap">
                  <Link href="#">
                    <div class="small-image-container">
                      <img
                        src={`${process.env.PUBLIC_URL}/image/italy.png`}
                        alt="Example"
                      />
                      <div class="content main12">
                        <div class="main-content">
                          <h2>Italy</h2>
                          <p>
                            Ticket From<b>852$</b>
                          </p>
                        </div>
                        <div class="hover-content">
                          <p>
                            Chandigarh{" "}
                            <FontAwesomeIcon
                              icon={faArrowsAltH}
                              className="icon-color"
                            />
                          </p>
                          <h2>Italy</h2>
                          <p>
                            Ticket From<b>852$</b>
                          </p>
                        </div>
                      </div>
                    </div>
                  </Link>
                </div>
              </div> */}
            </div>
          </div>
          {/* <div className="row d-flex align-items-center justify-content-center">
            <button className="opnedeals mb-5">Lead More </button>
          </div> */}
        </div>
      </section>
      {/* one section */}
      <section className="flight_one_section my-flight-section">
        <div className="container">
          <div className="row">
            <div className="col-lg-6 d-flex align-items-center">
              <div className=" ">
                <h6 className="about-prime-text">Flight sale now on!</h6>
                <p className="about-lowest-prices">
                  We think you might love these deals from Barcelona (Spain).
                  Deals, routes, and exclusive offers from xyz.com. Search,
                  book, and save money.
                </p>
              </div>
            </div>

            <div className="col-lg-6">
              {/* <div className='flight_viwe'>
                <img src={flightd} alt='' className='img-fluid w-100 rounded'/>
                 <div className='flight_price'>
                      <span className='fly-c-name'>Africa</span>
                      <span className='fly-c-price'>320 $</span>
                    </div>
            </div> */}

              <Link href="#">
                <div class="large-image-container">
                  <img
                    src={`${process.env.PUBLIC_URL}/image/dubai.png`}
                    alt="Example"
                  />
                  <div class="content">
                    <div class="main-content">
                      <h2>Dubai</h2>
                      <p>
                        Ticket From<b>35$</b>
                      </p>
                    </div>
                    <div class="hover-content">
                      <p>
                        Chandigarh{" "}
                        <FontAwesomeIcon
                          icon={faArrowsAltH}
                          className="icon-color"
                        />
                      </p>
                      <h2>Dubai United Arab Emirates</h2>
                      <p>
                        Ticket From<b>35$</b>
                      </p>
                    </div>
                  </div>
                </div>
              </Link>
            </div>
          </div>
        </div>
      </section>
      {/* end one section */}
      {/* end seven section */}

      {/* header */}
      <Footer />
      {/* end header  */}
    </>
  );
}
