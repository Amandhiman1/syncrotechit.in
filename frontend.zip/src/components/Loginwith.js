import React, { useState } from 'react';
import { Button, Modal, Form } from 'react-bootstrap';
import Account from './Common/img/your_account.svg';
import google from './Common/img/google-plus.svg';
import facebook from './Common/img/facebook.svg';
import email from './Common/img/email.svg';
import cross from './Common/img/crossmodal.svg';
import envelope from './Common/img/envelope.svg'
import leftarrow from './Common/img/left_arrow.svg';
import rightarrow from './Common/img/right_arrow.svg';

export default function Loginwith() {
  const [show, setShow] = useState(false);
  const [showEmailModal, setShowEmailModal] = useState(false);
  const [showEmailCodeModal, setShowEmailCodeModal] = useState(false);

  const handleCloseLoginModal = () => setShow(false);
  const handleShowLoginModal = () => setShow(true);

  const handleCloseEmailModal = () => setShowEmailModal(false);
  const handleShowEmailModal = () => setShowEmailModal(true);

  
  const handleCloseEmailCodeModal = () => setShowEmailCodeModal(false);
  const handleShowEmailCodeModal = () => setShowEmailCodeModal(true);

  return (
    <>
      {/* Login Modal */}
      <Button variant="primary" className='sign_in_btn' onClick={handleShowLoginModal}>
        Signup
      </Button>

      <Modal show={show} onHide={handleCloseLoginModal} className='loginwithdp'>
        <Modal.Header>
          <img src={cross} alt="Close modal" onClick={handleCloseLoginModal} />
        </Modal.Header>
        <Modal.Body className='pop_box_dp'>
          <div className="image_dp mx-auto">
            <img src={Account} className='img-fluid' alt="Account" />
          </div>

          <div className="details_dp">
            <h3 className="title pt-3">Continue to your account</h3>
            <p className='pt-4 top_para_dp'>Track prices, make trip planning easier and enjoy faster booking.</p>
          </div>

          <div className='loginstep pt-5'>
            {/* Email Login Button */}
            <div className='btn_box'>
              <img src={email} className="img-fluid logo_img" alt="Email" />
              <Button className='loginbtn' onClick={() => { handleShowEmailModal(); handleCloseLoginModal(); }}>Continue with email</Button>
            </div>

            {/* Google Login Button */}
            <div className='btn_box'>
              <img src={google} className="img-fluid logo_img" alt="Google" />
              <Button className='loginbtn'>Google</Button>
            </div>

            {/* Facebook Login Button */}
            <div className='btn_box'>
              <img src={facebook} className="img-fluid logo_img" alt="Facebook" />
              <Button className='loginbtn'>Facebook</Button>
            </div>
          </div>

          <p className='pt-5 para_dp'>Booked with an incorrect email address?</p>
        </Modal.Body>
        <Modal.Footer>
          <p>The use of your account is governed by these <span>Terms of Use</span>. Your Personal Data will be processed according to our <span>Privacy Policy</span>.</p>
        </Modal.Footer>
      </Modal>

      {/* Login with Email Modal */}
      <Modal show={showEmailModal} onHide={handleCloseEmailModal} className="loginwithdp">
        <Modal.Header>
        <img src={cross} alt="Close modal" onClick={handleCloseEmailModal} />
        </Modal.Header>
        <Modal.Body className='pop_box_dp'>
          <div className="image_dp mx-auto">
            <img src={Account} className='img-fluid' alt="Account" />
          </div>
          <div className="details_dp">
            <h3 className="title pt-5">Contine to your account</h3>
            {/* <p>We sent a code to <span>your@email.com</span> please add it below to verify</p> */}
          </div>
          <Form className='pt-3'>
            <Form.Group className="mb-3" controlId="emailInput">
             
              <div className='email_dp'>

                <img src={envelope} className='img-fluid' alt="Account"/>
                <div className='email_text'>
                <Form.Label>Sign in or register yout email</Form.Label>
                <Form.Control type="email" placeholder="e.g. your@email.com" required/>
                </div>
                
              </div>
              {/* <p>Resend Code</p> */}
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
        

        <div className='btn_dp'>
                        <div className='left_btn_dp'>
                                <img src={leftarrow} width={40} height={40} className='img-fluid mx-auto'/>
                                    <Button className="cancel_btn"  onClick={handleCloseEmailCodeModal}> Cancel</Button>
                                </div>
                                <div className='right_btn_dp'>
                                
                                     <Button className="done_btn" onClick={() => { handleShowEmailCodeModal(); handleCloseEmailModal(); }}> Continue</Button>
                                     <img src={rightarrow} width={40} height={40} className='img-fluid mx-auto'/>
                                </div>
        </div>
        </Modal.Footer>
      </Modal>



      {/* verify Email Code  Modal */}
      <Modal show={showEmailCodeModal} onHide={handleCloseEmailCodeModal} className="loginwithdp">
        <Modal.Header>
        <img src={cross} alt="Close modal" onClick={handleCloseEmailCodeModal} />
        </Modal.Header>
        <Modal.Body className='pop_box_dp'>
          <div className="image_dp mx-auto">
            <img src={Account} className='img-fluid' alt="Account" />
          </div>
          <div className="details_dp">
            <h3 className="title pt-5">Verify your email account </h3>
            <p>We sent a code to <span>your@email.com</span> please add it below to verify</p>
          </div>
          <Form className='pt-3'>
            <Form.Group className="mb-3" controlId="emailInput">
            <Form.Label className='codelabel'>Enter 8 character code</Form.Label>
              <div className='email_dp'>
              
                <img src={envelope} className='img-fluid' alt="Account"/>
                <div className='email_text'>
                
                <Form.Control type="email" placeholder="e.g. your@email.com" required/>
                </div>
                
              </div>
              <a className='codesend pt-3'>Resend Code</a>
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
        

        <div className='btn_dp'>
                                <div className='left_btn_dp'>
                                <img src={leftarrow} width={40} height={40} className='img-fluid mx-auto'/>
                                    <Button className="cancel_btn"  onClick={handleCloseEmailCodeModal}> Cancel</Button>
                                </div>
                                <div className='right_btn_dp'>
                                
                                     <Button className="done_btn" onClick={handleCloseEmailCodeModal}> Continue</Button>
                                     <img src={rightarrow} width={40} height={40} className='img-fluid mx-auto'/>
                                </div>
                            </div>
        </Modal.Footer>
      </Modal>




    </>
  );
}
