import React from 'react';
import './Common/css/style.css'; 
import Sidebar from './Common/Sidebar';
import DashboardHeader from './Common/DashboardHeader';


export default function DashboardOfferpage() {
  return (
    <>
 
  
<section className="admin-pages">
    <div className="container-fluid p-0">
        <div className="row p-0 m-0">
            <div className="col-md-2 bg-light">
                <Sidebar/>
            </div>

            <div className="col-md-10">
                <header><DashboardHeader/></header>
                <h2>Coming Soon Offer Page</h2>
    hello
            </div>
        </div>
    </div>   
</section> 


    </>
  )
}

