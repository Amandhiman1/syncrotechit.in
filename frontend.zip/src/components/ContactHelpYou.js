import React, { useState } from "react";
import "./Include/css/style.css";
import Header from "./Include/Header";
import Footer from "./Include/Footer";
import contactmaps from "./Assets/026-map 1.svg";
import Accordion from "react-bootstrap/Accordion";
import like_img from "./Assets/like.svg";
import dislike_img from "./Assets/dislike.svg";
import { useEffect } from "react";
import { Link } from "react-router-dom";
import HomeSearch from "./HomeSearch";
import SearchComponent from "./SearchComponent";
import axios from "axios";
import { useSelector } from "react-redux";

export default function ContactHelpYou() {

  const [categories, setCategories] = useState([]);

  const selectedLanguage = useSelector((state) => state.reducer.language);

  const getCategories = async () => {
    const res = await axios.get("https://flight-backend-ro3e.onrender.com/api/faqCategory");
    console.log(res.data);
    setCategories(res.data);
  };

  useEffect(() => {
    window.scrollTo({
      top: 0,
    });
    getCategories();
  }, []);

  // let contacttab = [
  //   {
  //     id: "0",
  //     title: "Ticket cancellation",
  //     text: "At vmaans.com. is tremendously growing travel search site, a favourite place for millions of hearts to plan and book at the best prices. We are honest travel company, which means people can trust our extensive variety of flights and Holidays options.",
  //   },
  //   {
  //     id: "1",
  //     title: "Ticket change",
  //     text: "At vmaans.com. is tremendously growing travel search site, a favourite place for millions of hearts to plan and book at the best prices. We are honest travel company, which means people can trust our extensive variety of flights and Holidays options.",
  //   },
  //   {
  //     id: "2",
  //     title: "Ticket refund",
  //     text: "At vmaans.com. is tremendously growing travel search site, a favourite place for millions of hearts to plan and book at the best prices. We are honest travel company, which means people can trust our extensive variety of flights and Holidays options.",
  //   },
  //   {
  //     id: "3",
  //     title: "Luggage policies",
  //     text: "At vmaans.com. is tremendously growing travel search site, a favourite place for millions of hearts to plan and book at the best prices. We are honest travel company, which means people can trust our extensive variety of flights and Holidays options.",
  //   },
  //   {
  //     id: "4",
  //     title: "Discount cards",
  //     text: "At vmaans.com. is tremendously growing travel search site, a favourite place for millions of hearts to plan and book at the best prices. We are honest travel company, which means people can trust our extensive variety of flights and Holidays options.",
  //   },
  // ];

  return (
    <>
      {/* header */}
      <Header />
      {/* end header  */}

      {/* one section */}
      <section className="contact_one_section">
        <div className="container">
          <div className="row  m-0 p-0">
            <h6 className="headdingneed"> Need help?</h6>
          </div>
          {/* <SearchComponent /> */}
          <div className="row ">
            <div className="col-md-8">
              <div className="contact-tabs">
                <Accordion defaultActiveKey="0">
                  {categories.map((category) => (
                    <Accordion.Item eventKey={category._id}>
                      <Accordion.Header className="m-0">
                        {category.title[selectedLanguage].name}
                      </Accordion.Header>
                      <Accordion.Body>
                        {category.questions.map((question) => (
                          <div>
                            <Link to={`question/${question.slug}`}>{question.title[selectedLanguage].name}</Link>
                          </div>
                        ))}

                        <hr className="hr-tab" />

                        <h6 className="like-conts">
                          Did this article help you?
                        </h6>
                        <div className="like-dislike">
                          <button>
                            <img src={like_img} alt="" /> Yes
                          </button>
                          <button>
                            <img src={dislike_img} alt="" /> No
                          </button>
                        </div>
                      </Accordion.Body>
                    </Accordion.Item>
                  ))}
                </Accordion>
              </div>
            </div>

            <div className="col-md-4">
              <div className="map-cont">
                <img src={contactmaps} alt="" className="img-fluid w-100" />
                <h6 className="cont-domain">XYZ.COM</h6>
                <p className="Fuerteventura">
                  Calle Fuerteventura,70 4º3ª Sabadell, Barcelona , 08205 Spain{" "}
                </p>
              </div>
            </div>
          </div>
          <div className="row m-0 p-0">
            <div className="still-need d-flex align-items-center pt-5">
              <h6 className="need-help m-0 pr-4">Still need help?</h6>
              <Link to="/contact-us">
                <button>Contact Us</button>
              </Link>
            </div>
          </div>
        </div>
      </section>
      {/* end one section */}

      {/* header */}
      <Footer />
      {/* end header  */}
    </>
  );
}
