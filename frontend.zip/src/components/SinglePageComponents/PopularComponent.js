import React from "react";
import { Link } from "react-router-dom/cjs/react-router-dom";
import airoplane from "../Assets/cloud-with-airoplane.svg";

const PopularComponent = ({ flight }) => {
  return (
    <section className="Populer_Routes_section">
      <div className="container">
        <div className="row">
          <div className="col-md-12 pt-5 pb-2">
            <h2 className="Populer_Routes ">{flight.heading}</h2>
          </div>
        </div>
        <div className="row bg-white">
          {flight.flights.map((flight_dtl) => (
            <div className="col-md-6">
              <div className="flightbox d-flex align-items-center justify-content-between">
                <h6 className="from">{flight_dtl.Origin.AirportName}</h6>
                <img src={airoplane} alt="" />
                <h6 className="fromto">{flight_dtl.Destination.AirportName}</h6>
              </div>
            </div>
          ))}
        </div>
        <div className="row justify-content-center pt-4 pb-5">
          {flight.slug && (
            <Link to={`/page/${flight.slug.toLowerCase()}.html`}>
              <button className="mint_flights">
                Show more flights
              </button>
            </Link>
          )}
        </div>
      </div>
    </section>
  );
};

export default PopularComponent;
