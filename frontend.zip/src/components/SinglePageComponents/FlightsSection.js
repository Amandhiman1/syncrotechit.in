import React from "react";
import brush_img from "../Assets/Brussels_Airlines_SN 2.png";
import airoplane from "../Assets/cloud-with-airoplane.svg";
import clender_str from "../Assets/calendar-1 3.png";
import { Link } from "react-router-dom";

const FlightsSection = ({ flight, handleFlightClick, moreFlightOnclick }) => {
  return (
    <div>
      <section className="cheap_flight_three_section">
        <div className="container">
          <div className="row">
            <div className="col-md-12 pt-5">
              <h2 className="last_minute_flights">{flight.heading}</h2>
              <p className="flights_tickets">{flight.slogan}</p>
            </div>
          </div>

          <div className="row">
            {flight.flights.map((flight_dtl) => (
              <div className="col-md-6">
                <div onClick={() => handleFlightClick(flight_dtl)}>
                  <div className="Economy_box">
                    <div className="uper_box">
                      <div className="imgs_flight_logo d-flex align-items-center">
                        <img src={brush_img} alt="" />
                      </div>
                      <div className="fligth_vips">
                        <span className="economy_tag">Economy</span>
                      </div>
                    </div>
                    <div className="middle_box">
                      <div className="Spicejet">
                        <div className="airoplane_text">
                          <p className="m-0">
                            {flight_dtl.Origin.AirportName}{" "}
                            <span className="del_city">
                              {" "}
                              {flight_dtl.Origin.AirportCode}
                            </span>{" "}
                          </p>
                          <span className="flight_time">
                            {flight_dtl.Origin.DateTime}
                          </span>
                        </div>
                        <img src={airoplane} alt="" />
                        <div className="airoplane_text">
                          <p className="m-0">
                            {" "}
                            {flight_dtl.Destination.AirportName}{" "}
                            <span className="mum_city">
                              {" "}
                              {flight_dtl.Destination.AirportCode}
                            </span>
                          </p>
                          <span className="flight_time">
                            {flight_dtl.Destination.DateTime}
                          </span>
                        </div>
                      </div>
                    </div>
                    <hr />
                    <div className="bottom_box">
                      <div className="imgs_flight_logo d-flex align-items-center">
                        <div className="m-0 from_direct">
                          {flight_dtl.Flight.Price.TotalDisplayFare}{" "}
                          {flight_dtl.Flight.Price.Currency}{" "}
                          <span>
                            {flight_dtl.StopsNumber == 0
                              ? "Directly"
                              : `${flight_dtl.StopsNumber} Stop(s)`}
                          </span>
                        </div>
                      </div>
                      <div className="fligth_Depart">
                        <div className="main_cnt_box d-flex">
                          <div className="img_span">
                            <img src={clender_str} alt="" />
                          </div>
                          <div className="box_cont_img_cont">
                            <small>Depart</small>
                            <span>{flight_dtl.Origin.DateTime}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div className="row justify-content-center pt-4 pb-5">
            {flight.slug && (
              <Link to={`/page/${flight.slug.toLowerCase()}.html`}>
                <button className="mint_flights">
                  Show more flights
                </button>
              </Link>
            )}
          </div>
        </div>
      </section>
    </div>
  );
};

export default FlightsSection;
