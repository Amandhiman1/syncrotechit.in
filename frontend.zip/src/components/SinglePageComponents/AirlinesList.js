import React from "react";
import brush_img from "../Assets/Brussels_Airlines_SN 2.png";
import airoplane from "../Assets/cloud-with-airoplane.svg";
import { Link } from "react-router-dom";

const AirlinesList = ({ flight, handleFlightClick }) => {
  return (
    <div>
      <section className="cheap_flight_airlinesearch_section">
        <div className="container">
          <div className="row">
            <div className="col-md-12 pt-5 pb-4">
              <h2 className="last_minute_flights">{flight.heading}</h2>
            </div>
          </div>

          {flight.flights.map((fly_dtl) => (
            <div className="row airline_details_cheapest mb-4">
              <div className="col-md-5">
                <div className="search_first">
                  <img src={brush_img} alt="" />
                  <h6 className="Airline_name m-0">{fly_dtl.Airline}</h6>
                  <p className="btn_stops m-0">{fly_dtl.StopsNumber}</p>
                  <div className="date_time_city">
                    <span className="flight_time">
                      {fly_dtl.Origin.DateTime}
                    </span>
                    <p className="m-0">
                      {" "}
                      {fly_dtl.Origin.AirportName}{" "}
                      <span className="del_city">
                        {" "}
                        {fly_dtl.Origin.AirportCode}
                      </span>
                    </p>
                  </div>
                </div>
              </div>
              <div className="col-md-2 d-flex justify-content-center ">
                <img src={airoplane} alt="" />
              </div>
              <div className="col-md-5">
                <div className="search_second">
                  <div className="date_time_city">
                    <span className="flight_time">
                      {fly_dtl.Destination.DateTime}
                    </span>
                    <p className="m-0">
                      {fly_dtl.Destination.AirportName}{" "}
                      <span className="mum_city">
                        {" "}
                        {fly_dtl.Destination.AirportCode}
                      </span>
                    </p>
                  </div>
                  <div className="m-0 from_direct">
                    {fly_dtl.Flight.Price.TotalDisplayFare}{" "}
                  </div>
                  <button
                    className="airline-searchs_btn"
                    onClick={() => handleFlightClick(fly_dtl)}
                  >
                    Search
                  </button>
                </div>
              </div>
            </div>
          ))}
          <div className="row justify-content-center pt-5 pb-5">
            {flight.slug && (
              <Link to={`/page/${flight.slug.toLowerCase()}.html`}>
                <button className="mint_flights">
                  Show more last minute flights
                </button>
              </Link>
            )}
          </div>
        </div>
      </section>
    </div>
  );
};

export default AirlinesList;
