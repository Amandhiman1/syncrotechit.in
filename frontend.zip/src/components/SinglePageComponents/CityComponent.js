import React from "react";
import beachs from '../Assets/beach.png'
import { Link } from "react-router-dom";

const CityComponent = ({flight, handleFlightClick}) => {
  return (
    <div>
      <section className="cheap_flight_airlinesearch_section pb-3">
        <div className="container">
          <div className="row">
            <div className="col-md-12 pt-5 pb-4">
              <h2 className="last_minute_flights">{flight.heading}</h2>
            </div>
          </div>
          <div className="row ">
            {flight.flights.map((flight_dtl) => (
              <div className="col-lg-3 col-md-6 col-sm-6 col-xs-12 p-0 m-0 chep_img_box" onClick={() => handleFlightClick(flight_dtl)}>
                <div className="beach_detls_imgs">
                  <img src={beachs} alt="" className="plane_beach" />
                  <div className="bech_text_ups">
                    <p className="bech_names">
                      {flight_dtl.Origin.AirportName}
                    </p>
                    <p className="bech__price">
                      {flight_dtl.Flight.Price.TotalDisplayFare}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div className="row justify-content-center pt-4 pb-5">
            {flight.slug && (
              <Link to={`/page/${flight.slug.toLowerCase()}.html`}>
                <button className="mint_flights">
                  Show more flights
                </button>
              </Link>
            )}
          </div>
        </div>
      </section>
    </div>
  );
};

export default CityComponent;
