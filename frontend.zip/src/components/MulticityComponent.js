import React, { useState } from 'react'
import SearchableDropdown from './SearchableDropdown'
import ReactDatePicker from 'react-datepicker';

import clendr_from from './Dashboard/Common/img/calendar-1 1.svg';
import user from './Dashboard/Common/img/user.svg';
import seat from './Dashboard/Common/img/032-seat 1.svg';
import increment from './Common/img/increment.svg';
import decrement from './Common/img/decrement.svg';
import child from './Common/img/child.svg';
import adult from './Common/img/adults.svg';
import infant from './Common/img/infarant.svg';
import CabinBaggage from './Common/img/Cabin_Baggage.svg';
import CheckedBaggage from './Common/img/Checked_Baggage.svg';
import leftarrow from './Common/img/left_arrow.svg';
import rightarrow from './Common/img/right_arrow.svg';
import { Alert, Button, Form, Image } from "react-bootstrap";




const MulticityComponent = ({ airports, loading, forms, setForms, adultCount, childCount, infantCount, setAdultCount, setChildCount, setInfantCount, setCabin , cabin }) => {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);

//  setAdultCount usestate condition for value Increment & Decrement  dharampreet //
const handleDecrement = () => {
    setAdultCount(prevCount => Math.max(1, prevCount - 1));
  };

  const handleIncrement = () => {
    setAdultCount(prevCount => Math.min(9, prevCount + 1));
  };

  //  setChildCount usestate condition for value Increment & Decrement dharampreet //
  const chlildhandleDecrement = () => {
    setChildCount(prevCount => Math.max(0, prevCount - 1));
  };

  const childhandleIncrement = () => {
    setChildCount(prevCount => Math.min(9, prevCount + 1));
  };


 //  setChildCount usestate condition for value Increment & Decrement dharampreet //
 const InfanthandleDecrement = () => {
  setInfantCount(prevCount => Math.max(0, prevCount - 1));
};

const InfanthandleIncrement = () => {
  setInfantCount(prevCount => Math.min(9, prevCount + 1));
};



    const [isDetailOpen, setIsDetailOpen] = useState(false);

    const addForm = (event) => {
        event.preventDefault();
        setForms((prevForms) => [
            ...prevForms,
            {
                fromAirport: prevForms[prevForms.length - 1].toAirport,
                toAirport: null,
                departureDate: new Date(prevForms[prevForms.length - 1].departureDate),
                travelers: 2,
                cabin: 'Economy',
            },
        ]);

        setForms((prevForms) => {
            const newForms = [...prevForms];
            newForms[newForms.length - 1].departureDate.setDate(newForms[newForms.length - 1].departureDate.getDate() +
             1);
            return newForms;
        });
    };

    const handleInputChange = (index, field, value) => {
        setForms((prevForms) => {
            const newForms = [...prevForms];
            newForms[index][field] = value;
            if(field == 'toAirport' && newForms[index + 1]) {
                newForms[index + 1]['fromAirport'] = value;
            }
            return newForms;
        });
        console.log(forms);
    };

    const formatDate = (date) => {
        const options = { day: 'numeric', month: 'short', year: '2-digit' };
        return new Intl.DateTimeFormat('en-US', options).format(date);
    };

    return (
        <div className="multicity-comp">
            {forms.map((form, index) => (
                <div key={index} className='plan_loc_from_to'>
                    <div className="secd_linsform">
                        <div className='from-to d-flex flight_details_dp'>
                            <SearchableDropdown
                                options={airports}
                                loading={loading}
                                type="from"
                                selectedOption={form.fromAirport}
                                setSelectedOption={(value) => handleInputChange(index, 'fromAirport', value)}
                            />

                            <SearchableDropdown
                                options={airports}
                                loading={loading}
                                type="to"
                                selectedOption={form.toAirport}
                                setSelectedOption={(value) => handleInputChange(index, 'toAirport', value)}
                            />
                        </div>
                        <div className='depart-retun d-flex' >
                            <div className="main_cnt_box d-flex" onClick={() => document.getElementById('departdatepicker').click()}>
                                <div className='img_span'>
                                    <img src={clendr_from} alt="" />
                                </div>
                                <div className='box_cont_img_cont'>
                                    <small><label>Depart</label></small>
                                    <span>{formatDate(form.departureDate)}</span>
                                </div>
                            </div>


                            <ReactDatePicker
                                id='departdatepicker'
                                selected={form.departureDate}
                                onChange={(date) => handleInputChange(index, 'departureDate', date)}
                                dateFormat="dd MMM ''yy"
                                popperClassName="datepicker-popper"
                                minDate={tomorrow}
                                monthsShown={2}
                                className="custom-datepicker"
                            />
                        </div>
                        {index == 0 && (
                            <div className='trable-cabin d-flex' onClick={() => setIsDetailOpen(!isDetailOpen)}>
                                <div className="main_cnt_box d-flex">
                                    <div className='img_span'>
                                        <img src={user} alt="" />
                                    </div>
                                    <div className='box_cont_img_cont'>
                                        <small><label>Traveler’s</label></small>
                                        <span>{+adultCount + +childCount + +infantCount} Traveler’s</span>
                                    </div>
                                </div>
                                <div className="main_cnt_box d-flex">
                                    <div className='img_span'>
                                        <img src={seat} alt="" />
                                    </div>
                                    <div className='box_cont_img_cont'>
                                        <small><label>Cabin</label></small>
                                        <span>{cabin}</span>
                                    </div>
                                </div>
                            </div>
                        )}
                    </div>
                </div>
            ))}
            {isDetailOpen && (
                <div className="adults_ls">
                <h2 className="travel_box_title">Passangers</h2>
                   <div className="row">
                    <div className="col-lg-12">
                       

                        <div className="travel_del_dp">
                          <div className="left_side_dp">
                            <div className="image_dp">
                              <img src={adult} width={40} height={40} className='img-fluid mx-auto'/>
                            </div>
                            <div className="travel_lis_dp">
                              <p className="top-head">
                                <b>ADULTS</b>
                              </p>
                              <p className="num_count">Over 11</p>
                            </div>
                          </div>
                          <div className="right_side_dp">
                            <div className="quantity">
                              <img src={decrement} width={40} height={40} className='img-fluid mx-auto' onClick={handleDecrement}/>
                              <input className="w3-input" type="number" min="1" max="9" value={adultCount} onChange={(e) => { const value = parseInt(e.target.value); if (value >= 1 && value <= 9) { setAdultCount(value); } }} />
                              <img src={increment} width={40} height={40} className='img-fluid mx-auto' onClick={handleIncrement}/>
                            </div>
                          </div>
                      </div>

{/* 
                        <div class="w3-bar">
                            <a onClick={() => {
                                setAdultCount('1')
                                setIsDetailOpen(false)
                            }} class="w3-button">1</a>
                            <a onClick={() => {
                                setAdultCount('2')
                                setIsDetailOpen(false)
                            }} class="w3-button">2</a>
                            <a onClick={() => {
                                setAdultCount('3')
                                setIsDetailOpen(false)
                            }} class="w3-button">3</a>
                            <a onClick={() => {
                                setAdultCount('4')
                                setIsDetailOpen(false)
                            }} class="w3-button">4</a>
                            <a onClick={() => {
                                setAdultCount('5')
                                setIsDetailOpen(false)
                            }} class="w3-button">5</a>
                        </div> */}
                    </div>
                    <div className='col-lg-12'>
                    <div className="travel_del_dp">
                                <div className="left_side_dp">
                                    <div className="image_dp">
                                      <img src={child} width={40} height={40} className='img-fluid mx-auto'/>
                                    </div>
                                    <div className="travel_lis_dp">
                                      <p className="top-head">
                                          <b>Child</b>
                                      </p>
                                      <p className="num_count">2 - 11</p>
                                    </div>
                                </div>
                                <div className="right_side_dp">
                                    <div className="quantity">
                                          <img src={decrement} width={40} height={40} className='img-fluid mx-auto' onClick={chlildhandleDecrement}/>
                                          <input className="w3-input" type="number" min="1" max="9" value={childCount} onChange={(e) => { const value = parseInt(e.target.value); if (value >= 1 && value <= 9) { setChildCount(value); } }} />
                                          <img src={increment} width={40} height={40} className='img-fluid mx-auto' onClick={childhandleIncrement}/>
                                    </div>
                                </div>
                            </div>
                    </div>
                    <div className='col-lg-12'>
                    <div className="travel_del_dp">
                              <div className="left_side_dp">
                                  <div className="image_dp">
                                      <img src={infant} width={40} height={40} className='img-fluid mx-auto'/>
                                  </div>
                                  <div className="travel_lis_dp">
                                      <p className="top_head">
                                        <b>Infant</b>
                                      </p>
                                      <p className="num_count">Under 2</p>
                                  </div>
                              </div>
                              <div className="right_side_dp">
                                 <div className="quantity">
                                    <img src={decrement} width={40} height={40} className='img-fluid mx-auto' onClick={InfanthandleDecrement}/>
                                    <input className="w3-input" type="number" min="1" max="9" value={infantCount} onChange={(e) => { const value = parseInt(e.target.value); if (value >= 1 && value <= 9) { setInfantCount(value);} }} />
                                    <img src={increment} width={40} height={40} className='img-fluid mx-auto' onClick={InfanthandleIncrement}/>
                                  </div>
                              </div>
                            </div>
                    </div>
                </div>

                    
                        {/* <div className="col-lg-6">
                            <p><b>CHILDREN (2y - 12y)</b></p>
                            <p>on the day of travel</p>
                            <div class="w3-bar">
                                <a onClick={() => {
                                    setChildCount('1')
                                    setIsDetailOpen(false)
                                }} class="w3-button">1</a>
                                <a onClick={() => {
                                    setChildCount('2')
                                    setIsDetailOpen(false)
                                }} class="w3-button">2</a>
                                <a onClick={() => {
                                    setChildCount('3')
                                    setIsDetailOpen(false)
                                }} class="w3-button">3</a>
                                <a onClick={() => {
                                    setChildCount('4')
                                    setIsDetailOpen(false)
                                }} class="w3-button">4</a>
                                <a onClick={() => {
                                    setChildCount('5')
                                    setIsDetailOpen(false)
                                }} class="w3-button">5</a>
                            </div>
                        </div> */}
                        {/* <div className="col-lg-6">
                            <p><b>INFANTS (below 2y)
                            </b></p>
                            <p>on the day of travel


                            </p>
                            <div class="w3-bar">
                                <a onClick={() => {
                                    setInfantCount('1')
                                    setIsDetailOpen(false)
                                }} class="w3-button">1</a>
                                <a onClick={() => {
                                    setInfantCount('2')
                                    setIsDetailOpen(false)
                                }} class="w3-button">2</a>
                                <a onClick={() => {
                                    setInfantCount('3')
                                    setIsDetailOpen(false)
                                }} class="w3-button">3</a>
                                <a onClick={() => {
                                    setInfantCount('4')
                                    setIsDetailOpen(false)
                                }} class="w3-button">4</a>
                                <a onClick={() => {
                                    setInfantCount('5')
                                    setIsDetailOpen(false)
                                }} class="w3-button">5</a>
                            </div>
                        </div> */}



                        <h2 className="travel_box_title">Bags</h2>
                        <div className="row">
                      <div className="col-lg-12">
                        <div className="travel_del_dp">
                            <div className="left_side_dp">
                              <div className="image_dp">
                                <img src={CabinBaggage} width={40} height={40} className='img-fluid mx-auto'/>
                              </div>
                              <div className="travel_lis_dp">
                                <p className="top-head">
                                  <b>Cabin Baggage</b>
                                </p>
                              </div>
                            </div>
                            <div className="right_side_dp">
                              <div className="quantity">
                                <img src={decrement} width={40} height={40} className='img-fluid mx-auto' onClick={handleDecrement}/>
                                <input className="w3-input" type="number" min="1" max="9" value={adultCount} onChange={(e) => { const value = parseInt(e.target.value); if (value >= 1 && value <= 9) { setAdultCount(value); } }} />
                                <img src={increment} width={40} height={40} className='img-fluid mx-auto' onClick={handleIncrement}/>
                              </div>
                            </div>
                        </div>  
                      </div>

                      <div className="col-lg-12">
                        <div className="travel_del_dp">
                            <div className="left_side_dp">
                              <div className="image_dp">
                                <img src={CheckedBaggage} width={40} height={40} className='img-fluid mx-auto'/>
                              </div>
                              <div className="travel_lis_dp">
                                <p className="top-head">
                                  <b>Checked Baggage</b>
                                </p>
                              </div>
                            </div>
                            <div className="right_side_dp">
                              <div className="quantity">
                                <img src={decrement} width={40} height={40} className='img-fluid mx-auto' onClick={handleDecrement}/>
                                <input className="w3-input" type="number" min="1" max="9" value={adultCount} onChange={(e) => { const value = parseInt(e.target.value); if (value >= 1 && value <= 9) { setAdultCount(value); } }} />
                                <img src={increment} width={40} height={40} className='img-fluid mx-auto' onClick={handleIncrement}/>
                              </div>
                            </div>
                        </div>  
                      </div>
                      </div>

{/* <div className="row cabin_dp">
    <div className="col-lg-12">
        <div className=" p-0">
          <p><b>Cabin</b>
          <Button
            className="close-button1"
            onClick={() => setIsCabinDetailOpen(false)}
          > X </Button>
        </p>
        <div className="cabin_list_dp">
        {["Economy", "PremiumEconomy", "Business"].map((classType) => (
          <label key={classType} className={cabin === classType ? 'active' : ''}>
            <input
              type="radio"
              name="cabinClass"
              value={classType}
              checked={cabin === classType}
              onChange={() => {
                setCabin(classType);
                setIsCabinDetailOpen(false);
              }}
            />
            {classType === "PremiumEconomy" ? "Premium Economy" : classType}
          </label>
        ))}
        </div>
      </div>
  </div>
</div> */}
                    
                      


                  <div className='row cabin_dp'>
                    <div className="col-lg-12">
                    <div className=" p-0">
          <p><b>Cabin</b></p>
          </div>
                        {/* <p>on the day of travel</p> */}

                        <div class="cabin_list_dp">
  <label className={`w3-button ${cabin === 'Economy' ? 'active' : ''}`}>
    <input
      type="radio"
      name="cabin"
      value="Economy"
      checked={cabin === 'Economy'}
      onChange={() => {
        setCabin('Economy');
        setIsDetailOpen(false);
      }}
    />
    <span>Economy</span>
  </label>
  <label className={`w3-button ${cabin === 'PremiumEconomy' ? 'active' : ''}`}>
    <input
      type="radio"
      name="cabin"
      value="PremiumEconomy"
      checked={cabin === 'PremiumEconomy'}
      onChange={() => {
        setCabin('PremiumEconomy');
        setIsDetailOpen(false);
      }}
    />
    <span>Premium Economy</span>
  </label>
  <label className={`w3-button ${cabin === 'Business' ? 'active' : ''}`}>
    <input
      type="radio"
      name="cabin"
      value="Business"
      checked={cabin === 'Business'}
      onChange={() => {
        setCabin('Business');
        setIsDetailOpen(false);
      }}
    />
    <span>Business</span>
  </label>
</div>




                        {/* <div class="w3-bar">
                            <a onClick={() => {
                                setCabin('Economy')
                                setIsDetailOpen(false)
                            }} class="w3-button">Economy</a>
                            <a onClick={() => {
                                setCabin('PremiumEconomy')
                                setIsDetailOpen(false)
                            }} class="w3-button">Premium Economy</a>
                            <a onClick={() => {
                                setCabin('Business')
                                setIsDetailOpen(false)
                            }} class="w3-button">Business</a>
                        </div> */}
                    </div>

</div>




<div className="row">
 
  

    <div className='btn_dp'>
                                <div className='left_btn_dp'>
                                <img src={leftarrow} width={40} height={40} className='img-fluid mx-auto'/>
                                    <Button className="cancel_btn"> Cancel</Button>
                                </div>
                                <div className='right_btn_dp'>
                                
                                     <Button className="done_btn"> Done</Button>
                                     <img src={rightarrow} width={40} height={40} className='img-fluid mx-auto'/>
                                </div>
                            </div>
                         
                     




                     
 
</div>


                </div>

                
            )}
            <button className='btn btn-primary' onClick={(event) => addForm(event)}>Add More</button>
        </div>
    )
}

export default MulticityComponent
