import React from 'react'
import "./Include/css/style.css"
import Footer from './Include/Footer'
import Header from './Include/Header'
import job1 from './Assets/jobs1.svg'
import job2 from './Assets/job2.png'
import job3 from './Assets/job3.png'
import { useEffect } from 'react'
import { Link } from 'react-router-dom'
import HomeSearch from './HomeSearch'
import SearchComponent from './SearchComponent'




export default function Jobs() {
  useEffect( ()=>{
    window.scrollTo({
      top : 0
    })
  },[] )



  return (
    <>
    {/* header */}
    <Header/>
    {/* end header  */}
    
  {/* <div className='container marg-bt common-padding'>
  <SearchComponent />
  </div> */}
    
    {/* one section */}
    <section className='about_one_section job-section'>
      <div className='container job1-cont'>
        <div className='row'>
          <div className='col-md-6 d-flex align-items-center'>
              <div className='job-section'>
                <h6 className='about-prime-text'>Be part of the future of travel</h6>
                <Link to="/job-career-oportunity">
                    <button className='job_btn fasstbooking_btn'>Load More </button>
                </Link>
              </div>
          </div>
    
          <div className='col-md-6 image-cont-job'>
                <img src={job1} alt='' className='img-fluid w-100'/>
          </div>
        </div>
    
      </div>
    </section>
    {/* end one section */}
    
  {/* two section */}
<section className='job_two_section '>
  <div className='container'>
    <div className='row'>
      <div className='col-md-12'>
        <div className='faster-booking '>
            <div className='row'>
              <div className='securty_text text-center'>
              From flights to hotels and car hire, XYZ works side-by-side  in travel to bring over thousand monthly users all the options they need to plan and book their perfect trip.
    We’re already a market leader and we’re just getting started.
    Join us for the adventure of a lifetime. Together we can change how the world travels.
              </div>
            </div>
        </div>
      </div>
    </div>
  </div>
</section>
{/* end two section */}



    {/* three section */}
<section className='job_three_section '>
  <div className='container'>
    <div className='row'>
      <div className='col-md-12'>
        <div className='faster-booking '>
            <div className='row  d-flex align-items-center'>
              <div className='col-md-5'>
                <img src={job2} alt='' className='w-100 img-fluid'/>
              </div>
              <div className='col-md-7 p-3 pl-5 d-flex align-items-center'>
                <div className='fasstbooking '>
                    <h3 className='signfastbook'>It’s a journey</h3>
                    <p>Being part of XYZ means joining a team hell bent on building the world’s most innovative, and helpful travel experiences possible. We’re hugely ambitious and believe we have the chance to genuinely challenge and disrupt the industry.
                       <br/><br/> As a company we never stand still. That’s why you’ll always find new opportunities to learn and develop, whether that's through our  mentorship, coaching or industry talks.</p>
                </div>
              </div>
            </div>
        </div>
      </div>
    </div>
  </div>
</section>
{/* end three section */}


{/* four section */}

<section className='job_four_section'>
      <div className='container'>
        <div className='row'>
          <div className='col-md-6 d-flex align-items-center'>
              <div className=' '>
                <h6 className='about-prime-text'>We’re on a mission</h6>
                <p className='about-lowest-prices'>For the last 10 years we’ve been on a mission to empower every traveller with innovative tools, insights and experiences that help people get to where they’re going, so they can spend more time out exploring the world . Our traveller-first approach drives everything we do and it’s never been more important than it is today.</p>
              </div>
          </div>
    
          <div className='col-md-6'>
            <img src={job3} alt='' className='img-fluid w-100'/>
          </div>
        </div>
    
      </div>
    </section>

{/* end four section */} 
    
    
    {/* header */}
    <Footer/>
    {/* end header  */}
    
        </>
  )
}
