import React, { useState } from 'react'
import "./Include/css/style.css"
import Header from './Include/Header';
import Footer from './Include/Footer';
import logoImg from './Assets/circular-arrows 2.svg';
import refundimg from './Assets/refund (2) 1.svg';
import firstimg from './Assets/Frame 936.png';
import missoion from './Assets/our-mission.png';
import flightsft from './Assets/cloud-with-airoplane.svg';
import singapur from './Assets/25400 1.png';
import africa from './Assets/216 1.png';
import newzeland from './Assets/Flights to New Zealand 3.png';
import mexico from './Assets/Flights to Mexico 3.png';

import nightlight from './Assets/Frame 939.png';
import flower_sky from './Assets/Frame 937.png';
import river_view from './Assets/Frame 943.png';
import dubai_sea from './Assets/Frame 941.png';
import house_road from './Assets/Frame 940.png';
import pull_house from './Assets/Frame 942.png';

import blog1 from './Assets/552 2.png';
import blog2 from './Assets/Water Sports 1.png';
import blog3 from './Assets/Road Trip 3.png';

import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faArrowsAltH } from '@fortawesome/free-solid-svg-icons';
import primeimg from './Common/img/prime_img.svg'
import ourmission from './Common/img/our_mission.svg'
import Loginwith from './Loginwith';

import { Link } from 'react-router-dom';

// slider

// import {useState} from 'react'
import Slider from 'react-slick'


import 'slick-carousel/slick/slick.css'
import 'slick-carousel/slick/slick-theme.css'

import { useEffect } from 'react';
import HomeSearch from './HomeSearch';
import axios from 'axios';
import { useSelector } from 'react-redux';

export default function Index() {
  const [blogs, setBlogs] = useState([]);

  const selectedLanguage = useSelector((state) => state.reducer.language);

  const getBlogs = async () => {
    const url = "https://flight-backend-ro3e.onrender.com/api/blog";
    await axios
      .get(url)
      .then((res) => {
        setBlogs(res.data);
      })
      .catch((err) => {
        console.error(err);
      });
  };

  useEffect(() => {
    window.scrollTo({
      top: 0
    })
    getBlogs();
  }, [])

  // const [sliderRef, setSliderRef] = useState(null)
  const sliderSettings = {

    arrows: true,
    slidesToShow: 4,
    slidesToScroll: 1,
    infinite: true,
    // speed: 500, // ms
    // autoplay: true,
    // autoplaySpeed: 2000,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 2,
        }
      },
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 1,
        }
      }
    ]
  }

  let famoustrip = [
    {
      id: '1',
      img_src: firstimg,
    },
    {
      id: '2',
      img_src: nightlight,
    },
    {
      id: '3',
      img_src: flower_sky,
    },
    {
      id: '4',
      img_src: river_view,
    },
    {
      id: '5',
      img_src: dubai_sea,
    },
    {
      id: '6',
      img_src: house_road,
    },
    {
      id: '7',
      img_src: pull_house,
    },

  ]


  let cheapflight = [
    {
      id: "1",
      from: "Amsterdam",
      to: "Istanbul",
      img: flightsft,
    },
    {
      id: "2",
      from: "Boston",
      to: "Thiruvananthapuram",
      img: flightsft,
    },
    {
      id: "3",
      from: "Toronto",
      to: "Delhi",
      img: flightsft,
    },
    {
      id: "4",
      from: "London",
      to: "Delhi",
      img: flightsft,
    },
    {
      id: "5",
      from: "Copenhegon",
      to: "Malaga",
      img: flightsft,
    },
    {
      id: "6",
      from: "Berlin",
      to: "Bongkok",
      img: flightsft,
    },
    {
      id: "7",
      from: "Madrid",
      to: "Quito",
      img: flightsft,
    },
    {
      id: "8",
      from: "Lisbon",
      to: "Sao Paulo",
      img: flightsft,
    },
    {
      id: "9",
      from: "Brussel",
      to: "New york",
      img: flightsft,
    },
    {
      id: "10",
      from: "Dubai",
      to: "Mumbai",
      img: flightsft,
    },
    {
      id: "11",
      from: "Frankfurt",
      to: "Copenhegon",
      img: flightsft,
    },
    {
      id: "12",
      from: "Barcelona",
      to: "Cancun",
      img: flightsft,
    },

  ]

  let origin = [
    {
      id: "1",
      imgs: singapur,
      c_name: "Singapore",
      c_price: "500 $",
    },
    {
      id: "2",
      imgs: africa,
      c_name: "Africa",
      c_price: "320 $",
    },
    {
      id: "3",
      imgs: newzeland,
      c_name: "New Zealand",
      c_price: "560 $",
    },
    {
      id: "4",
      imgs: mexico,
      c_name: "Mexico",
      c_price: "400 $",
    },
    {
      id: "5",
      imgs: africa,
      c_name: "Africa",
      c_price: "320 $",
    },


  ]

  let blogs_data = [
    {
      id: "1",
      imgs: blog1,
      name: "10 Best destination for summer holidays",
    },
    {
      id: "2",
      imgs: blog2,
      name: "10 Best destination for summer holidays",
    },
    {
      id: "3",
      imgs: blog3,
      name: "10 Best destination for summer holidays",
    },



  ]

  return (
    <>
      {/* header */}
      <Header />
      {/* end header  */}



      {/* first section */}
        <HomeSearch />
      {/* end first section */}



      {/* second section */}
      <section className='second_section'>
        <div className='container'>
          <div className='row easy_refund_row_dp'>
            <div className='col-md-6'>
              <div className='Change-anytime margin_remove_dp'>
                <div className='row'>
                  <div className='col-md-3 '>
                    <div className='anytimeimages img_bg_remove_dp'>
                      <img src={logoImg} tittle="" alt="" />
                    </div>
                  </div>
                  <div className='col-md-8 d-flex align-items-center'>
                    <div className=''>
                      <h6 className='text-center'>Change your trip anytime</h6>
                      <p className='text-center'>Change your flight bookinh anytime anywhere our team 24*7 excited to help you or change online .</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className='col-md-6'>
              <div className='Easy-Refund margin_remove_dp'>
                <div className='row'>
                  <div className='col-md-3'>
                    <div className='anytimeimages img_bg_remove_dp'>
                      <img src={refundimg} tittle="" alt="" />
                    </div>
                  </div>
                  <div className='col-md-8 d-flex align-items-center '>
                    <div className=''>
                      <h6 className='text-center'>Easy  Refund</h6>
                      <p className='text-center'>Easy to chancel your flight ticket and get fast refund from your flying carrier .</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

        </div>
      </section>
      {/* end second section */}




      {/* three section */}
      <section className='three_section'>
        <div className='container'>
          <div className='row'>
            <div className='col-md-6'>
              <div className='prime_box'>
                <div className='col-md-12 d-flex align-items-center prime_img_dp'>
                  <div className='img_dp'>
                    <img src={primeimg} />
                  </div>
                  <div className='prime-flight'>
                    <h6 className='prime-text text-center'><b>PRIME</b></h6>
                    <h6 className='prime-text text-center'>FLIGHT DEALS</h6>
                    <p className='lowest-prices mt-3 text-center mt-0'>Our lowest prices on trips</p>
                  </div>
                </div>

              </div>
            </div>

            <div className='col-md-6 select-cols'>
            <div class="select-wrapper prime_box_dp">
        <label for="country">Where From?</label>
        <select id="country">
            <option value="AF">Afghanistan</option>
            <option value="AL">Albania</option>
            <option value="DZ">Algeria</option>
            
        </select>
    </div>

    <div class="select-wrapper1 prime_box_dp">
        <label for="country">Travelers</label>
        <select id="country">
            <option value="AF">Bracelona</option>
            <option value="AL">Albania</option>
            <option value="DZ">Algeria</option>
            
        </select>
    </div>

            </div>
          </div>

        </div>
      </section>
      {/* end three section */}




      {/* four section */}
      <section className='four_section'>
        <div className='container'>
          <div className='row'>
            <div className='col-md-12'>
              <div className='Famous-places'>
                {/* <div className='img-count'>
                  {
                    famoustrip.map(imgs => (
                      <img className='blg_imgs' key={imgs.id} src={imgs.img_src} alt='' />
                    ))
                  }
                </div> */}

                {/* <div className='row-main'>
                  <div class="container12">
                  <img
                          src={`${process.env.PUBLIC_URL}/image/dubai.png`}
                          alt="Example"
                        />
                    <div class="content">
                      <div class="initial-content">
                        <div><p>Dubai</p>
                        <small>Tickets from <b>$36</b></small></div>
                      </div>
                      <div class="hover-content">
                        <div><small>Chandighar <FontAwesomeIcon icon={faArrowsAltH} className="icon-color"/></small>
                        <p>Dubai</p>
                       <small>Tickets from <b>$36</b></small></div>
                      </div>
                    </div>
                  </div>
                  <div class="container12">
                  <img
                          src={`${process.env.PUBLIC_URL}/image/delhi.png`}
                          alt="Example"
                        />
                    <div class="content">
                      <div class="initial-content">
                        <div><p>New Delhi</p>
                        <small>Tickets from <b>$46</b></small></div>
                      </div>
                      <div class="hover-content">
                        <div><small>Chandighar <FontAwesomeIcon icon={faArrowsAltH} className="icon-color"/></small>
                        <p>New Delhi</p>
                       <small>Tickets from <b>$46</b></small></div>
                      </div>
                    </div>
                  </div>
                  <div class="container12">
                  <img
                          src={`${process.env.PUBLIC_URL}/image/canada.png`}
                          alt="Example"
                        />
                    <div class="content">
                      <div class="initial-content">
                        <div><p>Canada</p>
                        <small>Tickets from <b>$306</b></small></div>
                      </div>
                      <div class="hover-content">
                        <div><small>Chandighar <FontAwesomeIcon icon={faArrowsAltH} className="icon-color"/></small>
                        <p>Canada</p>
                       <small>Tickets from <b>$306</b></small></div>
                      </div>
                    </div>
                  </div>
                  <div class="container12">
                  <img
                          src={`${process.env.PUBLIC_URL}/image/london.png`}
                          alt="Example"
                        />
                    <div class="content">
                      <div class="initial-content">
                        <div><p>London</p>
                        <small>Tickets from <b>$356</b></small></div>
                      </div>
                      <div class="hover-content">
                        <div><small>Chandighar <FontAwesomeIcon icon={faArrowsAltH} className="icon-color"/></small>
                        <p>London</p>
                       <small>Tickets from <b>$356</b></small></div>
                      </div>
                    </div>
                  </div>
                </div> */}

{/* <div class="custom-container">
        <div class="row">
           
            <div class="column large-column">
                <div class="large-image-container">
                <img
                          src={`${process.env.PUBLIC_URL}/image/first1.png`}
                          alt="Example"
                        />
                    <div class="content">
                        <div class="main-content">
                            <h2>Dubai</h2>
                            <p>Ticket From<b>35$</b></p>
                        </div>
                        <div class="hover-content">
                            <p>Chandigarh <FontAwesomeIcon icon={faArrowsAltH} className="icon-color"/></p>
                            <h2>Dubai United Arab Emirates</h2>
                            <p>Ticket From<b>35$</b></p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="column large-column">
                <div class="row  padd-row">
           
                    <div class="column small-column">
                        <div class="small-image-container">
                        <img
                          src={`${process.env.PUBLIC_URL}/image/london.png`}
                          alt="Example"
                        />
                            <div class="content main12">
                                <div class="main-content">
                                    <h2>London</h2>
                                    <p>Ticket From<b>85$</b></p>
                                </div>
                                <div class="hover-content">
                                    <p>Chandigarh <FontAwesomeIcon icon={faArrowsAltH} className="icon-color"/></p>
                                    <h2>London</h2>
                                    <p>Ticket From<b>35$</b></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="column small-column">
                        <div class="small-image-container">
                        <img
                          src={`${process.env.PUBLIC_URL}/image/paris.png`}
                          alt="Example"
                        />
                            <div class="content main12">
                                <div class="main-content">
                                    <h2>Paris</h2>
                                    <p>Ticket From<b>45$</b></p>
                                </div>
                                <div class="hover-content">
                                    <p>Chandigarh <FontAwesomeIcon icon={faArrowsAltH} className="icon-color"/></p>
                                    <h2>Paris</h2>
                                    <p>Ticket From<b>45$</b></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                
                    <div class="column small-column">
                        <div class="small-image-container">
                        <img
                          src={`${process.env.PUBLIC_URL}/image/canada.png`}
                          alt="Example"
                        />
                            <div class="content main12">
                                <div class="main-content">
                                    <h2>Canada</h2>
                                    <p>Ticket From<b>96$</b></p>
                                </div>
                                <div class="hover-content">
                                    <p>Chandigarh <FontAwesomeIcon icon={faArrowsAltH} className="icon-color"/></p>
                                    <h2>Canada</h2>
                                    <p>Ticket From<b>96$</b></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="column small-column">
                        <div class="small-image-container">
                        <img
                          src={`${process.env.PUBLIC_URL}/image/delhi.png`}
                          alt="Example"
                        />
                            <div class="content main12">
                                <div class="main-content">
                                    <h2>New Delhi</h2>
                                    <p>Ticket From<b>52$</b></p>
                                </div>
                                <div class="hover-content">
                                    <p>Chandigarh <FontAwesomeIcon icon={faArrowsAltH} className="icon-color"/></p>
                                    <h2>New Delhi</h2>
                                    <p>Ticket From<b>52$</b></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> */}



<div class="container">
        <div class="row">
            <div class="col-md-12 p-0">
               <div class="col-lg-12 mb-3">
                   <div class="row responcive-gap">
                       <div class="col-lg-6 padd-0">
                       <div class="large-image-container box_animation_dp">
                <img
                          src={`${process.env.PUBLIC_URL}/image/first1.png`}
                          alt="Example"
                        />
                    <div class="content">
                        <div class="main-content">
                            <h2>Dubai</h2>
                            <p>Ticket From<b>35$</b></p>
                        </div>
                        <div class="hover-content">
                            <p>Chandigarh <FontAwesomeIcon icon={faArrowsAltH} className="icon-color"/></p>
                            <h2>Dubai United Arab Emirates</h2>
                            <p>Ticket From<b>35$</b></p>
                        </div>
                    </div>
                       </div>
                       </div>
                       <div class="col-lg-3 padd-0">
                       <div class="small-image-container box_animation_dp">
                        <img
                          src={`${process.env.PUBLIC_URL}/image/delhi.png`}
                          alt="Example"
                        />
                            <div class="content main12">
                                <div class="main-content">
                                    <h2>New Delhi</h2>
                                    <p>Ticket From<b>52$</b></p>
                                </div>
                                <div class="hover-content">
                                    <p>Chandigarh <FontAwesomeIcon icon={faArrowsAltH} className="icon-color"/></p>
                                    <h2>New Delhi</h2>
                                    <p>Ticket From<b>52$</b></p>
                                </div>
                            </div>
                       </div>
                       </div>
                       <div class="col-lg-3 padd-0">
                        <div class="small-image-container box_animation_dp">
                        <img
                          src={`${process.env.PUBLIC_URL}/image/london.png`}
                          alt="Example"
                        />
                            <div class="content main12">
                                <div class="main-content">
                                    <h2>London</h2>
                                    <p>Ticket From<b>52$</b></p>
                                </div>
                                <div class="hover-content">
                                    <p>Chandigarh <FontAwesomeIcon icon={faArrowsAltH} className="icon-color"/></p>
                                    <h2>London</h2>
                                    <p>Ticket From<b>52$</b></p>
                                </div>
                            </div>
                       </div>
                       </div>
                   </div>
               </div>
                <div class="col-lg-12">
                     <div class="row responcive-gap">
                       <div class="col-lg-3 padd-0">
                       <div class="small-image-container box_animation_dp">
                        <img
                          src={`${process.env.PUBLIC_URL}/image/canada.png`}
                          alt="Example"
                        />
                            <div class="content main12">
                                <div class="main-content">
                                    <h2>Canada</h2>
                                    <p>Ticket From<b>52$</b></p>
                                </div>
                                <div class="hover-content">
                                    <p>Chandigarh <FontAwesomeIcon icon={faArrowsAltH} className="icon-color"/></p>
                                    <h2>Canada</h2>
                                    <p>Ticket From<b>52$</b></p>
                                </div>
                            </div>
                       </div>
                       </div>
                       <div class="col-lg-3 padd-0">
                       <div class="small-image-container box_animation_dp">
                        <img
                          src={`${process.env.PUBLIC_URL}/image/paris.png`}
                          alt="Example"
                        />
                            <div class="content main12">
                                <div class="main-content">
                                    <h2>Paris</h2>
                                    <p>Ticket From<b>52$</b></p>
                                </div>
                                <div class="hover-content">
                                    <p>Chandigarh <FontAwesomeIcon icon={faArrowsAltH} className="icon-color"/></p>
                                    <h2>Paris</h2>
                                    <p>Ticket From<b>52$</b></p>
                                </div>
                            </div>
                       </div>
                       </div>
                       <div class="col-lg-3 padd-0">
                       <div class="small-image-container box_animation_dp">
                        <img
                          src={`${process.env.PUBLIC_URL}/image/england.png`}
                          alt="Example"
                        />
                            <div class="content main12">
                                <div class="main-content">
                                    <h2>England</h2>
                                    <p>Ticket From<b>52$</b></p>
                                </div>
                                <div class="hover-content">
                                    <p>Chandigarh <FontAwesomeIcon icon={faArrowsAltH} className="icon-color"/></p>
                                    <h2>England</h2>
                                    <p>Ticket From<b>52$</b></p>
                                </div>
                            </div>
                       </div>
                       </div>
                       <div class="col-lg-3 padd-0">
                       <div class="small-image-container box_animation_dp">
                        <img
                          src={`${process.env.PUBLIC_URL}/image/france.png`}
                          alt="Example"
                        />
                            <div class="content main12">
                                <div class="main-content">
                                    <h2>France</h2>
                                    <p>Ticket From<b>52$</b></p>
                                </div>
                                <div class="hover-content">
                                    <p>Chandigarh <FontAwesomeIcon icon={faArrowsAltH} className="icon-color"/></p>
                                    <h2>France</h2>
                                    <p>Ticket From<b>52$</b></p>
                                </div>
                            </div>
                       </div>
                       </div>
                </div>
                </div>
            </div>
        </div>
    </div>



                <button className='opnedeals'>Open more deals </button>
              </div>
            </div>
          </div>
        </div>
      </section>
      {/* end four section */}



      {/* five section */}
      <section className='five_section'>
        <div className='container'>
          <div className='row'>
            <div className='col-md-12'>
              <div className='faster-booking '>
                <div className='row fast_booking_box'>
                  <div className='col-md-4 set-img-5'>
                  <img
                          src={ourmission}
                          alt="Example" 
                        />
                  </div>
                  <div className='col-md-8 align-items-center'>
                    <div className='fasstbooking'>
                    <div className='content_dp'>
                      <h3 className='signfastbook'>Sign in for better deals and faster booking  </h3>
                      <p className='travel'>Save you travel details securely and best price for your favorite destination . </p>
                      </div>
                      <div className='fastbtn_dp'>
                      {/* <button className='fasstbooking_btn'>Sign in</button> */}
                      <Loginwith/>
                      </div>
                    </div>
                    <div className='fasstbooking pad_top_dp'>
                    <div className='content_dp'>
                      <h3 className='signfastbook org_col'>Did you not found what you are looking for ? 
                      no worries </h3>
                      <p className='travel'>Share your contact details  and get  callback from our  team</p>
                      </div>
                      <div className='fastbtn_dp'>
                      <button className='fasstbooking_btn green_bg_dp'>Get Callback</button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      {/* end five section */}

      {/* six section */}


      {/* <section className='six_section'>
        <div className='container'>
          <div className='row'>
            <div className='col-md-8'>
              <div className='found-looking'>
                <h3>Did you not found what you are looking for ?</h3>
                <p>Share your contact details and get callback from our team</p>
              </div>
            </div>
            <div className='col-md-4 d-flex align-items-center justify-content-end'>
              <button className='fasstbooking_btn2'>Get Callback</button>
            </div>
          </div>
        </div>
      </section> */}


      {/* end six section */}



      {/* seven section */}
      <section className='seven_section'>
        <div className='container'>
          <div className='row d-flex align-items-center'>
            <div className='cheap-flight'>
              <h3>Find out your next destination</h3>
              <p>Top flights routes from your origin  </p>
            </div>
          </div>
          <div className='row d-flex align-items-center slider_dp'>

            <Slider {...sliderSettings}>
              {

                origin.map(pricebox => (
                  <Link to="#">
                    <div className='origin' key={pricebox.id}>
                      <img src={pricebox.imgs} alt='' className='c_price_image' />
                      <div className='origin_price'>
                        <span className='c-name'>{pricebox.c_name}</span>
                        <span className='c-price'>{pricebox.c_price}</span>
                      </div>
                    </div>
                  </Link>
                ))
              }

            </Slider>
          </div>


        {/* <div className='colored-image'>
                  <div class="image-container906">
        <img src={`${process.env.PUBLIC_URL}/image/new90.png`} alt="Example" className='faster-img'
                                />
                <div class="use-content">
                    <p>Singapore</p>
                    <p>$345</p>
                </div>
            </div>

            <div class="image-container906">
        <img src={`${process.env.PUBLIC_URL}/image/new901.png`} alt="Example" className='faster-img'
                                />
                <div class="use-content">
                    <p>Africa</p>
                    <p>$345</p>
                </div>
            </div>

            <div class="image-container906">
        <img src={`${process.env.PUBLIC_URL}/image/new902.png`} alt="Example" className='faster-img'
                                />
                <div class="use-content">
                    <p>New Zealand</p>
                    <p>$345</p>
                </div>
            </div>

            <div class="image-container906">
        <img src={`${process.env.PUBLIC_URL}/image/new903.png`} alt="Example" className='faster-img'
                                />
                <div class="use-content">
                    <p>Mexico</p>
                    <p>$345</p>
                </div>
            </div>
            </div> */}



        </div>
      </section>
      {/* end seven section */}



      {/* eight section */}
      <section className='eight_section'>
        <div className='container'>
          <div className='row d-flex align-items-center'>
            <div className='cheap-flight'>
              <h3>Popular cheap flight tickets routes</h3>
              <p>Most peoples looking for these destinations  </p>
            </div>
          </div>



          <div className='row mt-lg-3'>

            {
              
              cheapflight.map(flight => (
               
                <div className='col-md-4'>
                   <Link to="#">
                  <div className='flightbox d-flex align-items-center justify-content-between'>
                    <h6 className='from'>{flight.from}</h6>
                    <img src={flight.img} alt='' />
                    <h6 className='fromto'>{flight.to}</h6>
                  
                  </div>
                  </Link>
                </div>
               
              )
              )
             
            }

          </div>
          <div className='row d-flex align-items-center justify-content-center'>
            <button className='opnedeals'>Open more deals </button>
          </div>
        </div>
      </section>
      {/* end eight section */}




      {/* nine section */}
      <section className='nine_section'>
        <div className='container'>
          <div className='row'>
            <div className='col-md-12'>
              <div className='faster-booking '>
                <div className='row fast_booking_box'>
                  <div className='col-md-4 set-img-5'>
                  {/* <img
                          src={`${process.env.PUBLIC_URL}/image/img2nd.png`}
                          alt="Example" className='faster-img'
                        /> */}
                  <img
                          src={ourmission}
                          alt="Example" 
                        />
                  </div>
                  <div className='col-md-8 align-items-center'>
                    <div className='fasstbooking our_mission_dp'>
                    <div className='content_dp'>
                      <h3 className='signfastbook'>Our  Mission  make sure your travel is carbon negitive</h3>
                      
                      </div>
                      <div className='fastbtn_dp'>
                      <p className='travel'>We care about this planet  and we want make our contribtutions  in ensuring ..</p>
                      {/* <button className='fasstbooking_btn'>Sign in</button> */}
                      <Loginwith/>
                      </div>
                    </div>
                  </div>
                </div>
              </div>



              {/* 
            <div className='faster-booking '>
                    <div className='row d-flex align-items-center'>
                      <div className='col-md-3'>
                        <img src={missoion} alt='' className='w-100' />
                      </div>

                      <div className='col-md-9 p-3'>
                        <div className='row '>
                          <div className='col-md-12 text-center'>
                            <h3 className='carbon-negitive w-100 pb-4'>Our  Mission  make sure your travel is carbon negitive </h3>
                          </div>
                          <div className='col-md-12'>
                            <div className='fasstbooking d-flex align-items-center justify-content-between '>
                              <p className='contribtutions m-0'>We care about this planet  and we want make our contribtutions  in ensuring .. </p>
                              <button className='contribtutions_signin_btn'>Sign in</button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
            </div> */}
            </div>
          </div>
        </div>
      </section>
      {/* end nine section */}




      {/* ten section */}
      <section className='ten_section'>
        <div className='container'>
          <div className='row d-flex align-items-center blog_row_dp'>
            <div className='cheap-flight'>
              <h3>Get The Best Out Of Your Next Getaway to</h3>
              <p> inspire your next getaway </p>
            </div>
          </div>
          <div className='row mt-5'>

            {
              blogs.reverse().slice(0, 3).map(blog => (

                <div className='col-md-4'>
                  <Link to="#">
                    <div className='blog_data_cont ' key={blog.id}>
                      <img src={`https://flight-backend-ro3e.onrender.com/images/${blog.imageUrl}`} alt='' />
                      <div className='blog_conts'>
                        <h6 className='blog_heading'>{blog.titles[selectedLanguage]}</h6>
                        <Link to={`/blog-view/${blog.slug}`} className='blog_btn_readmore1'>Read More</Link>
                        {/* <button className='blog_btn_readmore'>Read more</button> */}
                      </div>
                    </div>
                  </Link>
                </div>

              )
              )
            }



        {/* <div className="blog-div">

            <div class="image-container">
            <img
                          src={`${process.env.PUBLIC_URL}/image/new1.png`}
                          alt="Example" className='image12'
                        />
            <div class="button-container">
              <button class="read-more-button">Read More</button>
            </div>
          </div>


          <div class="image-container">
            <img
                          src={`${process.env.PUBLIC_URL}/image/new2.png`}
                          alt="Example" className='image12'
                        />
            <div class="button-container">
              <button class="read-more-button">Read More</button>
            </div>
          </div>

          <div class="image-container">
            <img
                          src={`${process.env.PUBLIC_URL}/image/new3.png`}
                          alt="Example" className='image12'
                        />
            <div class="button-container">
              <button class="read-more-button">Read More</button>
            </div>
          </div>
        </div> */}




          </div>
          <div className='row d-flex align-items-center justify-content-center'>
            <Link to="/blog"><button className='opnedeals'>Read more</button></Link>
          </div>
        </div>
      </section>
      {/* end ten section */}

















      {/* footer */}
      <Footer />
      {/* end header */}
    </>

  )
}
