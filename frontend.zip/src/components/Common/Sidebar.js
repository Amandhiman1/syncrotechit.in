import React from 'react';
import './css/style.css'; 
import  logoImg  from './img/air-freight 2.svg';
import  dashboardImg  from './img/ic_round-dashboard.svg';
import  visitersImg  from './img/Visiters.svg';
import  callBackImg  from './img/call back.svg';
import  offerPageImg  from './img/offer.svg';
import  messagesImg  from './img/Messages.svg';
import  blogImg  from './img/blog.svg';
import  newsletterImg  from './img/newsletter.svg';
import  webgageImg  from './img/webpage.svg';
import  jobImg  from './img/jobs.svg';
import  lanImg  from './img/lang.svg';
import  faImg  from './img/faq.svg';
import  peoplesImg  from './img/user.svg';
import  reportsImg  from './img/reports.svg';
import  currencyImg  from './img/currency.svg';
import  managedomainImg  from './img/044-webpage 1.svg';
import { NavLink } from 'react-router-dom';


// start hover images  //
import  hovdash  from './img/hover-image/ic_round-dashboard.svg';
import  hovvisiters  from './img/hover-image/031-question-mark 3.svg';
import  hovcallBack  from './img/hover-image/call-back 1.svg';
import  hovofferPage  from './img/hover-image/offerhover4.svg';
import  hovmessages  from './img/hover-image/050-message 2.svg';
import  hovblog  from './img/hover-image/Group.svg';
import  hovnewsletter  from './img/hover-image/047-agreement 1.svg';
import  hovwebgage  from './img/hover-image/043-webpage 1.svg';
import  hovjob  from './img/hover-image/039-job-hunting 1.svg';
import  hovlan  from './img/hover-image/044-webpage 1.svg';
import  hovfa  from './img/hover-image/046-question 2.svg';

// End hover images //

export default function Sidebar() {

    
    let menu=[
            {
            id: "1",
            title: "Dashboard",
            url: "/dashboard",
            imgs:  dashboardImg ,
            hovimgs:  hovdash ,
        },
        {
            id: "2",
            title: "Visiters",
            url: "/visiters",
            imgs:  visitersImg ,
            hovimgs:  hovvisiters ,
        },
        {
            id: "3",
            title: "Call Back",
            url: "/call-back",
            imgs:  callBackImg ,
            hovimgs:  hovcallBack ,
        },
        {
            id: "4",
            title: "Messages",
            url: "/message",
            imgs:  messagesImg ,
            hovimgs:  hovmessages ,
        },
        {
            id: "5",
            title: "Offer Page",
            url: "/offer",
            imgs:  offerPageImg ,
            hovimgs:  hovofferPage ,
        },
        {
            id: "6",
            title: "Blog",
            url: "/j",
            imgs:  blogImg ,
            hovimgs:  hovblog ,
        },

        {
            id: "7",
            title: "Newsletter",
            url: "/i",
            imgs:  newsletterImg ,
            hovimgs:  hovnewsletter ,
        },
        {
            id: "8",
            title: "Web Page",
            url: "/h",
            imgs:  webgageImg ,
            hovimgs:  hovwebgage ,
        },
        {
            id: "9",
            title: "Jobs",
            url: "/g",
            imgs:  jobImg ,
            hovimgs:  hovjob ,
        },
        {
            id: "10",
            title: "Manage Domains",
            url: "/f",
            imgs:  managedomainImg ,
            hovimgs:  hovlan ,
        },
        {
            id: "11",
            title: "Frequently Asked",
            url: "/e",
            imgs:  faImg ,
            hovimgs:  hovfa ,
        },
        {
            id: "12",
            title: "Peoples",
            url: "/d",
            imgs:  peoplesImg ,
            hovimgs:  hovdash ,
        },
        {
            id: "13",
            title: "Reports",
            url: "/c",
            imgs:  reportsImg ,
            hovimgs:  hovdash ,
        },
        {
            id: "14",
            
            title: "Currency",
            url: "/b",
            imgs:  currencyImg ,
            hovimgs:  hovdash ,
        },

        {
            id: "15",
            title: "Language",
            url: "/a",
            imgs:  lanImg ,
            hovimgs:  hovdash ,
        },

    ]



  return (
    <>


    <div id="page-top">
        <div id="wrapper" >
            <ul className="navbar-nav sidebar sidebar-dark accordion sidebar_dashboard" id="accordionSidebar" >

                <NavLink className="sidebar-brand d-flex align-items-center " to="/">
                    <div className="sidebar-brand-icon">
                        <img src={ logoImg } tittle="" alt="" />
                        
                    </div>
                </NavLink>

                {  menu.map(
                    menus=>( 
                        <li className="nav-item">
                            <NavLink className="nav-link" to={menus.url}>
                                <img className='simple-image' src={menus.imgs} tittle={menus.title} alt="" />
                                <img className="hover-image" src={menus.hovimgs} tittle={menus.title} alt="" />
                                <span>{menus.title}</span>
                            </NavLink>
                        </li>
                    )   
                )  }
            </ul>
           
        </div>
</div> 
            
    </>
   
  )
}
