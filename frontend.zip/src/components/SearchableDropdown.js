import React, { useEffect, useRef, useState } from 'react';
import { MdFlightTakeoff, MdFlightLand } from "react-icons/md";
import { useSelector } from 'react-redux';

import plane_to from './Dashboard/Common/img/plane (15) 1.svg';
import plane_from from './Dashboard/Common/img/plane (14) 1.svg';
import airport from "./Common/img/airport-srach.svg"
import { Button } from 'react-bootstrap';
import leftarrow from './Common/img/left_arrow.svg'
import rightarrow from './Common/img/right_arrow.svg'
import seacrhplane from './Common/img/search_plane.svg'



const SearchableDropdown = ({ options, loading, type, selectedOption, setSelectedOption }) => {

    const countryCode = useSelector((state) => state.reducer.countryCode);

    const [isDropdownOpen, setIsDropdownOpen] = useState(false);
    const [searchQuery, setSearchQuery] = useState('');
    const [loadingOptions, setLoadingOptions] = useState(false);
    const [filteredOptions, setFilteredOptions] = useState([]);

    const defaultOptionsRef = useRef([]);

    const dropdownRef = useRef(null);

    const handleOptionSelect = (option) => {
        setIsDropdownOpen(false);
        setSelectedOption(option); // Notify parent component about the selected option
    };

    const handleClickOutside = (event) => {
        if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
            setIsDropdownOpen(false);
        }
    };

    function removeDuplicates(array) {
        const uniqueObjects = [];
        const encounteredIds = new Set();

        for (const obj of array) {
            if (!encounteredIds.has(obj.id)) {
                uniqueObjects.push(obj);
                encounteredIds.add(obj.id);
            }
        }

        return uniqueObjects;
    }

    const uniqueOptions = removeDuplicates(options);

    useEffect(() => {
        window.addEventListener('click', handleClickOutside);
    
        return () => {
            window.removeEventListener('click', handleClickOutside);
        };
    }, []);
    
    useEffect(() => {
        // Update the default options only when uniqueOptions changes
        defaultOptionsRef.current = uniqueOptions;
        if (searchQuery === '') {
            setFilteredOptions(defaultOptionsRef.current);
        }
    }, [uniqueOptions]);

    useEffect(() => {
        const fetchFilteredOptions = async () => {
            try {
                setLoadingOptions(true);
                const response = await fetch(`https://flight-backend-ro3e.onrender.com/api/airports/search?query=${searchQuery}&origincountry=${countryCode}`);
                const data = await response.json();
                console.log('data ==>', data);
                setFilteredOptions(data);
            } catch (error) {
                console.error('Error fetching filtered options:', error);
            } finally {
                setLoadingOptions(false);
            }
        };

        if (searchQuery) {
            fetchFilteredOptions();
        } else {
            // If search query is empty, set filteredOptions to the default list
            setFilteredOptions(defaultOptionsRef.current);
        }
    }, [searchQuery]);

    return (
        <>
            {loading ? ('loading') :
                <div ref={dropdownRef} className='main-search-box'>
                    <div className="main_cnt_box d-flex" onClick={() => setIsDropdownOpen(!isDropdownOpen)}>
                        <div className='img_span'>
                            <img src={type === "from" ? plane_to : plane_from} alt="" />
                        </div>
                        <div className='box_cont_img_cont'>
                            <small><label>{type === "from" ? "From" : "To"}</label></small>
                            <span className={`d-flex ${type === "from" ? 'from-name' : 'from-tos'}`}>
                                {selectedOption ? selectedOption.english : 'Select Airport'} <p>{selectedOption && selectedOption.code}</p>
                            </span>
                        </div>
                    </div>
                    {isDropdownOpen && (
                        <div className="dropdown py-3">

                        <div className='drop_search_dp'>
                        <div className='img_dp'>
                            <img src={seacrhplane} />
                        </div>
                        <div className='seach_del'>
                            <p>{type === "from" ? "From" : "To"}</p>
                            <input
                                type="text"
                                className='mb-3'
                                value={searchQuery}
                                onChange={(e) => setSearchQuery(e.target.value)}
                                placeholder="Search..."
                            />
                        </div>
                    
                        </div>
                         

                            <ul className='pl-0' style={{ paddingLeft: "0px" }}>
                                {loadingOptions ? <p>Loading results...</p> :
                                    filteredOptions.length === 0 ? <p>No matching results found.</p> :
                                        filteredOptions.map((option, index) => (
                                            <li key={index} onClick={() => handleOptionSelect(option)}>
                                                <div className='d-flex justify-content-between flights-hov'>
                                                    <div className='aeroport'>
                                                        <div className='d-flex p-2 left_side'>
                                                            <span className='pr-1'>
                                                                {type === "from" ? (<img src={airport} width={35} height={35} className='img-fluid mx-auto'/>) : (<MdFlightLand />)}
                                                            </span>
                                                           <span className='sel_airport'>
                                                           <p className='city_name'>{option.english}</p>
                                                           <p className='mb-0 d-flex align-items-start green_short'>{option.code}</p>
                                                           </span>
                                                           
                                                        </div>
                                                        
                                                    </div>
                                                    <p className='mb-0 px-2 city_airport'>{option.airport_name}</p>
                                                   
                                                </div>
                                            </li>
                                        ))
                                }
                            </ul>

                            <div className='btn_dp'>
                                <div className='left_btn_dp'>
                                <img src={leftarrow} width={40} height={40} className='img-fluid mx-auto'/>
                                    <Button className="cancel_btn" onClick={() => setIsDropdownOpen(!isDropdownOpen)}> Cancel</Button>
                                </div>
                                <div className='right_btn_dp'>
                                
                                     <Button className="done_btn" onClick={() => setIsDropdownOpen(!isDropdownOpen)}> Done</Button>
                                     <img src={rightarrow} width={40} height={40} className='img-fluid mx-auto'/>
                                </div>
                            </div>

                        </div>
                    )}
                </div>
            }
        </>
    );
};

export default SearchableDropdown;
