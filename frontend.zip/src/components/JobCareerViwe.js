import React from 'react'
import Header from './Include/Header'
import Footer from './Include/Footer'

import img_serch from './Assets/blog_search.svg'
import { useEffect } from 'react'
import { Link } from 'react-router-dom'
import HomeSearch from './HomeSearch'
import SearchComponent from './SearchComponent'

export default function JobCareerViwe() {
    useEffect( ()=>{
        window.scrollTo({
          top : 0
        })
      },[] )
    
    
    
      return (
        <>
        {/* header */}
            <Header/>
        {/* end header  */}
            
        {/* <div className='container'>
        <SearchComponent />
        </div> */}

        {/* one section */}
        <section className='pp_section job_pp_section'>
          <div className='container'>
            <div className='row'>
              <div className='col-md-12'>
                <h2 className='meta_title_tac mb-4'>Choose your next career oportunity</h2>
    <form>
    
        <div className='jco_form'>
            <div className='row align-items-end'>
                <div className='col-md-5'>
                    <div class=" form-group m-0">
                        <label>By location:</label>
                        <input type="text" className='form-control' placeholder="All Location"/>
                    </div>
                </div>
                <div className='col-md-5'>
                    <div class=" form-group m-0">
                        <label >By title, description:</label>
                        <div className='search_blog_box'>
                            <img src={img_serch} alt='' />
                            <input type="search" placeholder="e.g. engineering manager" className="me-2" aria-label="Search" />
                        </div>
                    </div>
                </div>
                <div className='col-md-2'>
               
                    <button type="submit" class="btn btn-primary jco_form_btn">Submit</button>
               
                </div>
            </div>
    
         
        
              
        </div>
    
    </form>
    
    
    
            
              </div>
            </div>
          </div>
        </section>
        {/* end one section */}
        
        {/* two section */}
        <section className='jco_two_section'>
          <div className='container'>
            <div className='row'>
                <div className='location_description'>
                    <div className='by_location'>
                        <span className='by_lable_ld'>By location:</span>
                        <h3 className='by_heading_ld' >Barcelona <span>Spain</span> </h3>
                    </div>
                    <div className='by_description'>
                        <span  className='by_lable_ld'>By title, description:</span>
                        <h3 className='by_heading_ld' >Barcelona <span>Spain</span> </h3>

                    </div>
                    <div className='by_description_viwe_btn'>
                            <Link to="/job-view-detail">
                                <button>View Details</button>
                            </Link>

                    </div>

                </div>
            </div>
          </div>
        </section>
        {/* end two section */}
        
        
        
        {/* header */}
            <Footer/>
        {/* end header  */}
        
        
            </>
      )
}
