import React, { useState, useEffect } from "react";
import "./Include/css/style.css";
import Footer from "./Include/Footer";
import Header from "./Include/Header";
import blog1 from "./Assets/blog1.png";
import img_serch from "./Assets/blog_search.svg";
import Nav from "react-bootstrap/Nav";
import { Link, NavLink, useParams } from "react-router-dom";
import axios from "axios";
import { useSelector } from "react-redux";

export default function Blog() {
  const [blogs, setBlogs] = useState([]);
  const [categories, setCategories] = useState([]);
  const [currentCategoryName, setCurrentCategoryName] = useState("");
  const selectedLanguage = useSelector((state) => state.reducer.language);

  const { categorySlug } = useParams();

  const getBlogs = async (categorySlug = null) => {
    const url = categorySlug
      ? `https://flight-backend-ro3e.onrender.com/api/blog/category/${categorySlug}`
      : "https://flight-backend-ro3e.onrender.com/api/blog";
    await axios
      .get(url)
      .then((res) => {
        setBlogs(res.data);
      })
      .catch((err) => {
        console.error(err);
      });
  };

  const getCategories = async () => {
    await axios
      .get("https://flight-backend-ro3e.onrender.com/api/blogcat")
      .then((res) => {
        setCategories(res.data);
      })
      .catch((err) => {
        console.error(err);
      });
  };

  useEffect(() => {
    window.scrollTo({
      top: 0,
    });
    getBlogs(categorySlug);
    getCategories();
  }, [categorySlug]);

  useEffect(() => {
    if (categorySlug && categories.length > 0) {
      const category = categories.find(
        (category) => category.slug === categorySlug
      );
      if (category) {
        setCurrentCategoryName(category.title[selectedLanguage]);
      }
    } else {
      setCurrentCategoryName("");
    }
  }, [categorySlug, categories, selectedLanguage]);

  return (
    <>
      {/* header */}
      <Header />
      {/* end header  */}

      {/* one section */}
      <section className="blog_two_section">
        <div className="container">
          <div className="row">
            <div className="col-md-8">
              <div className="blog_cat">
                <h1 className="thistopweek">
                  {currentCategoryName ? currentCategoryName : "ALL BLOGS"}
                </h1>

                {blogs
                  .slice(0)
                  .reverse()
                  .map((blog) => (
                    <Link key={blog.slug} to={`/blog-view/${blog.slug}`}>
                      <div className="blog_cat_viwe">
                        <div className="blogs_cts">
                          <img
                            src={`https://flight-backend-ro3e.onrender.com/images/${blog.imageUrl}`}
                            alt={blog.imageAlt[selectedLanguage]}
                            className="blog_viwe_img"
                          />
                          <div className="blog_cont">
                            <p className="beach_cat">
                              {blog.category[selectedLanguage]}
                            </p>
                            <h6 className="visited_beaches">
                              {blog.titles[selectedLanguage]}
                            </h6>
                            <div class="post-info">
                              <div class="author-info">
                                <img
                                  src="../icons/user-svgrepo-com.svg"
                                  alt="User Icon"
                                  class="icon-blog"
                                />{" "}
                                Posted by{" "}
                                <span class="author-name">John Doe</span>
                              </div>
                              <div class="divider">|</div>
                              <div class="date-info">📅 12th August 2024</div>
                              <div class="divider">|</div>
                              <div class="likes-dislikes">
                                <span class="likes">
                                  <img
                                    src="../icons/new-like.svg"
                                    alt="Thumbs Up"
                                    class="icon-blog"
                                  />{" "}
                                  10
                                </span>
                                <span class="dislikes">
                                  <img
                                    src="../icons/new-dislike.svg"
                                    alt="Thumbs Down"
                                    class="icon-blog"
                                  />{" "}
                                  2
                                </span>
                              </div>
                            </div>

                            <p className="miami_discover">
                              {blog.shortDesc[selectedLanguage]}
                            </p>

                            <div className="auther_details d-flex align-items-center ">
                              <img src={blog.author_img} alt="" />
                              <div className=" ">
                                <h6 className="autherby">{blog.author_by}</h6>

                                <p className="autherdate">{blog.author_date}</p>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </Link>
                  ))}
              </div>
            </div>

            <div className="col-md-4">
              <div className="sidebar_sticky">
                <div className="sidebar_blog">
                  <div className="search_blog_box">
                    <img src={img_serch} alt="" />
                    <input
                      type="search"
                      placeholder="Search"
                      className="me-2"
                      aria-label="Search"
                    />
                  </div>
                  <div className="cat_blog_box">
                    <h6 className="cat_blogstext">Categories</h6>
                    <Nav as="ul" className="blog_ul">
                      <Nav.Item as="li" className="blog_li">
                        <NavLink to="/blog">All</NavLink>
                      </Nav.Item>
                      {categories.map((category) => (
                        <Nav.Item
                          as="li"
                          className="blog_li"
                          key={category.slug}
                        >
                          <NavLink to={`/blog/category/${category.slug}`}>
                            {category.title[selectedLanguage]}
                          </NavLink>
                        </Nav.Item>
                      ))}
                    </Nav>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      {/* end one section */}

      {/* one section */}
      <section className="about_one_section blog-section-one">
        <div className="container">
          <div className="row">
            <div className="col-md-6 d-flex align-items-center">
              <div className=" ">
                <h6 className="about-prime-text">Where Are You Headed Next?</h6>
                <p className="about-lowest-prices">
                  Explore Destinations & Get Inspired For Your Next Getaway
                </p>
              </div>
            </div>

            <div className="col-md-6">
              <img src={blog1} alt="" className="img-fluid w-100" />
            </div>
          </div>
        </div>
      </section>
      {/* end one section */}

      <Footer />
    </>
  );
}
