import React from 'react'
import "./Include/css/style.css"
import Footer from './Include/Footer'
import Header from './Include/Header'

import abot_img from './Assets/about-us.svg'
import abot_img_process from './Assets/image_processing20200905-13926-zqyeog 1.svg'
import missoion from './Assets/our-mission.png';

import card1 from './Assets/image_processing20200827-9589-1ccpkx0 1.png'
import card2 from './Assets/3cb2d0bd58ca76bd1a69ccf568507837 1.png'
import card3 from './Assets/image 1.png'

import Card from 'react-bootstrap/Card';
import { useEffect } from 'react'
import HomeSearch from './HomeSearch'
import SearchComponent from './SearchComponent'






export default function About() {
  useEffect(() => {
    window.scrollTo({
      top: 0
    })
  }, [])


  let aboutcard = [
    {
      id: "1",
      Title: "Travel With Ease",
      discription: "We worked out all the complicated bit so you don't have to . no – Hassle , no – fuss trip planning .",
      img: card1,
    },
    {
      id: "2",
      Title: "See All Your Options",
      discription: "A single search provides all the airlines options available to personal needs to travel.",
      img: card2,
    },
    {
      id: "3",
      Title: "Search Across Globe",
      discription: "Start and end your journey in thousands of cities across the globe. The choice is yours.",
      img: card3,
    },

  ]
  let aboutuls = [
    {
      id: "1",
      year: "2014",
      disc: "The travel industry changes forever after three friends meet up and start to think about creating an easy way to book and manage trips. XYZ is born!.They Quite their Job and start together in house travel agency to serve traveller fair and transparent exactly what they deserve. ",
    },
    {
      id: "2",
      year: "2017",
      disc: "After server more than Thousands customers in last 3 years  with a offline travel agency. we decide to be a online travel agency as well to server million of coustumers.",
    },
    {
      id: "3",
      year: "2019",
      disc: "We relocated from Delhi to Barcelona ",
    },
    {
      id: "4",
      year: "2022",
      disc: "Our popular ‘Search Everywhere’ feature launches, created to show travellers the cheapest destinations they can fly to.",
    },

  ]

  return (
    <>
      {/* header */}
      <Header />
      {/* end header  */}

      {/* one section */}
      <section className='about_one_section blog1-section'>
        <div className='container'>
          <div className='row'>
            <div className='col-md-6 d-flex align-items-center'>
              <div className=' '>
                <h6 className='about-prime-text'>About us</h6>
                <p className='about-lowest-prices'>Explore Destinations & Get Inspired For Your Next Getaway</p>
              </div>
            </div>

            <div className='col-md-6'>
              <img src={abot_img} alt='' className='img-fluid w-100' />
            </div>
          </div>

        </div>
      </section>
      {/* end one section */}
{/* 
     <div className='container common-padding'>
     <SearchComponent />
     </div> */}

      {/* two section */}
      <section className='about_two_section'>
        <div className='container'>
          <div className='row'>
            <div className='col-md-6'>
              <img src={abot_img_process} alt='' className='img-fluid w-100' />
            </div>

            <div className='col-md-6 d-flex align-items-center'>
              <div className=' '>
                <h6 className='about-prime-text'>Who We Are</h6>
                <p className='about-lowest-prices'>At vmaans.com. is tremendously growing travel search site, a favourite place for millions of hearts to plan and book at the best prices. We are honest travel company, which means people can trust our extensive variety of flights and Holidays options.</p>
              </div>
            </div>


          </div>

        </div>
      </section>
      {/* end two section */}



      {/* three section */}
      <section className='about_three_section '>
        <div className='container'>
          <div className='row'>
            <div className='col-md-12 d-flex align-items-center'>
              <div className='text-center '>
                <h6 className='about-prime-text'>Who We Are</h6>
                <p className='about-lowest-prices'>At vmaans.com. is tremendously growing travel search site, a favourite place for millions of hearts to plan and book at the best prices. We are honest travel company, which means people can trust our extensive variety of flights and Holidays options.</p>
              </div>
            </div>
          </div>

          <div className='row pt-5'>
            <div className='col-md-12'>
              <div className='card_about'>

                {
                  aboutcard.map(aboutcards => (
                    <Card>
                      <Card.Img variant="top" src={aboutcards.img} className='img-fluid w-100' />
                      <Card.Body>
                        <Card.Title>{aboutcards.Title}</Card.Title>
                        <Card.Text>
                          {aboutcards.discription}
                        </Card.Text>
                      </Card.Body>
                    </Card>
                  ))}
              </div>
            </div>
          </div>

        </div>
      </section>
      {/* end three section */}



      {/* four section */}
      <section className='about_four_section'>
        <div className='container'>
          <div className='row'>
            <div className='col-md-12'>
              <h6 className='about-prime-text text-center pb-4'>Our journey so far</h6>
            </div>

          </div>
          <div className='row'>
            <div className='col-md-12'>
              <ul className='line_degn'>
                {
                  aboutuls.map(aboutul => (

                    <li>
                      <h5 className='line_h5'>{aboutul.year}</h5>
                      <p className='line_p'>{aboutul.disc}</p>
                    </li>

                  )
                  )
                }
              </ul>
            </div>


          </div>

        </div>
      </section>
      {/* end four section */}



      {/* five section */}
      <section className='five_section'>
        <div className='container'>
          <div className='row'>
            <div className='col-md-12'>
              <div className='faster-booking '>
                <div className='row'>
                  <div className='col-md-5'>
                    <img src={missoion} alt='' className='w-100 img-fluid' />
                  </div>
                  <div className='col-md-7 p-3 pl-5 d-flex align-items-center'>
                    <div className='fasstbooking'>
                      <h3 className='signfastbook'>Sign in for better deals and faster booking  </h3>
                      <p className='travel'>Save you travel details securely and best price for your favorite destination . </p>
                      <button className='fasstbooking_btn'>Sign in</button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      {/* end five section */}











      {/* header */}
      <Footer />
      {/* end header  */}

    </>
  )
}
