import React from 'react';
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, LabelList } from 'recharts';

const data = [
  { name: 'Mon 15 Apr', value: 18 },
  { name: 'Fri 25 May', value: 15 },
  { name: 'Tue 18 Jun', value: 20 },
  { name: 'Sat 06 Jul', value: 25 },
  { name: 'Fri 15 Aug', value: 15 },
  { name: 'Mon 19 Sep', value: 20 },
  { name: 'Fri 27 Oct', value: 15 },
  { name: 'Tue 30 Nov', value: 15},
  { name: 'Sun 15 Dec', value: 15},
  { name: 'Wed 27 Jan', value: 30 },
  { name: 'Fri 15 Feb', value: 15 },
  { name: 'Thu 18 Apr', value: 15 }
];

const MyVerticalBarChart = () => {
  return (
    <ResponsiveContainer width="100%" height={400}>
      <BarChart
        data={data}
        margin={{ top: 20, right: 65, left: 0, bottom: 0 }}
      >
        <XAxis 
          dataKey="none" 
          axisLine={false} 
          tickLine={false} 
          interval={0} 
        />
        <YAxis 
          axisLine={false} 
          tickLine={false} 
          tick={false} 
        />
        <Bar 
          dataKey="value" 
          fill="#DFE8FD" 
          radius={[0, 0, 0, 0]} 
          barSize={60} 
          tick={{ angle: 0, textAnchor: 'end', fontSize: 15 }} 
        >
          <LabelList dataKey="name" position="inside"   angle={0} />
          <LabelList dataKey="value" position="top" />
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}

export default MyVerticalBarChart;
