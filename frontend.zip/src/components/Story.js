import React from 'react'
import "./Include/css/style.css"
import Footer from './Include/Footer'
import Header from './Include/Header'
import story_img from './Assets/story1.svg'
import story_logos from './Assets/story2.png'
import story_video from './Assets/story3.png'

import { useEffect } from 'react'
import HomeSearch from './HomeSearch'
import SearchComponent from './SearchComponent'
import { Link } from 'react-router-dom';


export default function Story() {
  
    useEffect( ()=>{
        window.scrollTo({
          top : 0
        })
      },[] )
    
    
let story=[

    {
        id:"1",
        name:"Logos",
        img:story_logos,
        desc:"A collection of the vmaans logo in various formats, colours and orientations.",
    },
    {
        id:"2",
        name:"Videos",
        img:story_video,
        desc:"The vmaans story, brought to life in through engaging videos.",
    },
    {
        id:"3",
        name:"Photography",
        img:story_logos,
        desc:"Images that capture the beauty and diversity of travel, the essence of XYZ and the principals for which we stand.",
    },
    {
        id:"4",
        name:"Product Screenshots",
        img:story_logos,
        desc:"Our website work helping travellers around the world find their perfect trips.",
    },
]




      return (
        <>
        {/* header */}
          <Header/>
        {/* end header  */}
        
        {/* <div className='container common-padding'>
        <SearchComponent />
        </div> */}
        
        {/* one section */}
        <section className='story_one_section'>
          <div className='container'>
            <div className='row'>
              <div className='col-md-6 d-flex align-items-center'>
                  <div className=' '>
                    <h6 className='about-prime-text'>Telling the vmaans story</h6>
                    <p className='about-lowest-prices'>On this page you’ll find links to a variety of vmaans brand assets for use by media and partners, including logos, videos, photography and more.</p>
                  </div>
              </div>
        
              <div className='col-md-6'>
                  <img src={story_img} alt='' className='img-fluid w-100'/>
              </div>
            </div>
        
          </div>
        </section>
        {/* end one section */}
        
      {/* two section */}
    <section className='security_two_section'>
      <div className='container'>
        <div className='row'>
          <div className='col-md-12'>
            <div className='faster-booking '>
                <div className='row'>
                  <div className='securty_text text-center'>
                  By downloading any of these assets, you acknowledge and agree that all assets are for editorial use only, and all commercial and personal use is prohibited. Unless agreed with XYZ in writing, you are also prohibited from using these assets in a way which suggests sponsorship or endorsement by XYZ. If you want to know more about us and our brand you can read our brand story, visit our media centre or contact us if you have any questions.
                  </div>
                </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    {/* end two section */}
    


      {/* two section */}
    <section className='story_three_section'>
      <div className='container'>
        <div className='row'>
            {
            story.map(( story_dtl => 
              
                <div className='col-md-6'>
                  <Link href="#">
                    <div className='story_view_cat'>
                        <img src={ story_dtl.img } alt=''/>
                            <h3>{ story_dtl.name }</h3>
                            <p>{ story_dtl.desc }</p>

                    </div>
                    </Link>
                </div>
                
            ))}
        </div>
      </div>
    </section>
    {/* end two section */}
    
    
    
   
        {/* header */}
    
          <Footer/>
    
        {/* end header  */}
        
            </>
      )
}
