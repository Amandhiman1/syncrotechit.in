import React, { useState } from 'react'
import Footer from './Include/Footer'
import Header from './Include/Header'
import { Link } from 'react-router-dom';
import { useEffect } from 'react';
import { useSelector } from 'react-redux';
import HomeSearch from './HomeSearch';
import SearchComponent from './SearchComponent';



export default function Pages() {

  const language = useSelector((state) => state.reducer.language);

    const [cityPages, setCityPages] = useState({});
    const [countryPages, setCountryPages] = useState({});
    const [airlinePages, setAirlinePages] = useState({});
    const [airportPages, setAirportPages] = useState({});

    useEffect(() => {
      get_citypages()
      get_countrypages()
      get_airlinepages()
      get_airportpages()
    }, [language])

    const get_citypages = () => {
      try {
          let post_data = {
              method: 'POST',
              //credentials: 'same-origin',
              //mode: 'same-origin',
              // body: JSON.stringify({'category':'cities','lang':localStorage.getItem('language')?localStorage.getItem('language'):'en'}),
              body: JSON.stringify({'category':'cities','lang':language}),
              headers: {
                  'Accept':       'application/json',
                  'Content-Type': 'application/json',
                  //'X-CSRFToken':  cookie.load('csrftoken')
              }
          }
          fetch(process.env.REACT_APP_API_URL+'webpages/filter',post_data)
          .then(response => response.json())
          .then(data => {
                      console.log('city data ==> '+data);
                      //setOrders(data)
                      setCityPages(data)
                  }, (error) => {
                  if (error) {
                      console.log(error)
                  }
          });
      }catch(e){
          //snotify()
      }
  }

  const get_countrypages = () => {
    try {
        let post_data = {
            method: 'POST',
            //credentials: 'same-origin',
            //mode: 'same-origin',
            body: JSON.stringify({'category':'countries','lang':language}),
            headers: {
                'Accept':       'application/json',
                'Content-Type': 'application/json',
                //'X-CSRFToken':  cookie.load('csrftoken')
            }
        }
        fetch(process.env.REACT_APP_API_URL+'webpages/filter',post_data)
        .then(response => response.json())
        .then(data => {
                    console.log(data)
                    //setOrders(data)
                    setCountryPages(data)
                }, (error) => {
                if (error) {
                    console.log(error)
                }
        });
    }catch(e){
        //snotify()
    }
}

const get_airlinepages = () => {
  try {
      let post_data = {
          method: 'POST',
          //credentials: 'same-origin',
          //mode: 'same-origin',
          body: JSON.stringify({'category':'airlines','lang':language}),
          headers: {
              'Accept':       'application/json',
              'Content-Type': 'application/json',
              //'X-CSRFToken':  cookie.load('csrftoken')
          }
      }
      fetch(process.env.REACT_APP_API_URL+'webpages/filter',post_data)
      .then(response => response.json())
      .then(data => {
                  console.log(data)
                  //setOrders(data)
                  setAirlinePages(data)
              }, (error) => {
              if (error) {
                  console.log(error)
              }
      });
  }catch(e){
      //snotify()
  }
}

const get_airportpages = () => {
  try {
      let post_data = {
          method: 'POST',
          //credentials: 'same-origin',
          //mode: 'same-origin',
          body: JSON.stringify({'category':'airports','lang':language}),
          headers: {
              'Accept':       'application/json',
              'Content-Type': 'application/json',
              //'X-CSRFToken':  cookie.load('csrftoken')
          }
      }
      fetch(process.env.REACT_APP_API_URL+'webpages/filter',post_data)
      .then(response => response.json())
      .then(data => {
                  console.log(data)
                  //setOrders(data)
                  setAirportPages(data)
              }, (error) => {
              if (error) {
                  console.log(error)
              }
      });
  }catch(e){
      //snotify()
  }
}

    useEffect( ()=>{
    window.scrollTo({
      top : 0
    })
  },[] )

  return (
    <>
    {/* header */}
        <Header/>
    {/* end header  */}
    {/* one section */}
    <section className='tou_section'>
      <div className='container'>
        <div className='row'>
          <div className='col-md-12'>
            <h2 className='meta_title_tac'>Web Pages List</h2>
          </div>
          <SearchComponent />
        </div>
      </div>
    </section>
    {/* end one section */}
    
    {/* two section */}
    <section className='tou_two_section'>
      <div className='container'>
        <div className='row'>
          <div className='col-md-4'>
              <h2 className='toc_top_head'>City Pages</h2>
              <ul className="tou_list">  
                {/* <li> Article 1. <a href='/' className='toc_link_tab'>Our website</a></li>
                <li> Article 2. <a href='/' className='toc_link_tab'>Access to and use of the Website</a></li>
                <li> Article 3. <a href='/' className='toc_link_tab'>Website functionalities and XYZ.com Account</a></li>
                <li> Article 4. <a href='/' className='toc_link_tab'>Our intellectual property</a></li>
                <li> Article 5. <a href='/' className='toc_link_tab'>Trademarks, logos, and service marks of third parties</a></li>
                <li> Article 6. <a href='/' className='toc_link_tab'>Final provisions</a></li> */}

                {
                  cityPages.length>0?cityPages.map((li_link =>

                    <li key={li_link.id}><Link to={`/page/${li_link.slug}`}>{li_link.title}</Link></li>

                  )):'No data found!!'
                }


              </ul>
          </div>

          <div className='col-md-4'>
              <h2 className='toc_top_head'>Country Pages</h2>
              <ul className="tou_list">  
                {/* <li> Article 1. <a href='/' className='toc_link_tab'>Our website</a></li>
                <li> Article 2. <a href='/' className='toc_link_tab'>Access to and use of the Website</a></li>
                <li> Article 3. <a href='/' className='toc_link_tab'>Website functionalities and XYZ.com Account</a></li>
                <li> Article 4. <a href='/' className='toc_link_tab'>Our intellectual property</a></li>
                <li> Article 5. <a href='/' className='toc_link_tab'>Trademarks, logos, and service marks of third parties</a></li>
                <li> Article 6. <a href='/' className='toc_link_tab'>Final provisions</a></li> */}

                {
                  countryPages.length>0?countryPages.map((li_link =>

                    <li key={li_link.id}><Link to={`/page/${li_link.slug}`}> {li_link.title}</Link></li>

                  )):'No data found!!'
                }


              </ul>
          </div>

          <div className='col-md-4'>
              <h2 className='toc_top_head'>Airline Pages</h2>
              <ul className="tou_list">  
                {/* <li> Article 1. <a href='/' className='toc_link_tab'>Our website</a></li>
                <li> Article 2. <a href='/' className='toc_link_tab'>Access to and use of the Website</a></li>
                <li> Article 3. <a href='/' className='toc_link_tab'>Website functionalities and XYZ.com Account</a></li>
                <li> Article 4. <a href='/' className='toc_link_tab'>Our intellectual property</a></li>
                <li> Article 5. <a href='/' className='toc_link_tab'>Trademarks, logos, and service marks of third parties</a></li>
                <li> Article 6. <a href='/' className='toc_link_tab'>Final provisions</a></li> */}

                {
                  airlinePages.length>0?airlinePages.map((li_link =>

                    <li key={li_link.id}><Link to={`/page/${li_link.slug}`}> {li_link.title}</Link></li>

                  )):'No data found!!'
                }


              </ul>
          </div>

          <div className='col-md-4'>
              <h2 className='toc_top_head'>Airport Pages</h2>
              <ul className="tou_list">
                {
                  airportPages.length>0?airportPages.map((li_link =>

                    <li key={li_link.id}><Link to={`/page/${li_link.slug}`}> {li_link.title}</Link></li>

                  )):'No data found!!'
                }
              </ul>
          </div>

        </div>
      </div>
    </section>
    {/* end two section */}

    
    {/* header */}
        <Footer/>
    {/* end header  */}
    
    
        </>
  )
}
