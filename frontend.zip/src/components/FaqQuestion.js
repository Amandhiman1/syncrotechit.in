import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import Header from "./Include/Header";
import Footer from "./Include/Footer";
import axios from "axios";
import { Link } from "react-router-dom";
import { useSelector } from "react-redux";

const FaqQuestion = () => {
  const { questionSlug } = useParams();
  const [question, setQuestion] = useState({});
  const [loading, setLoading] = useState(true);

  const selectedLanguage = useSelector((state) => state.reducer.language);

  const getQuestionData = async () => {
    await axios
      .get(`https://flight-backend-ro3e.onrender.com/api/faqQuestion/${questionSlug}`)
      .then((res) => {
        console.log(res.data);
        setQuestion(res.data);
        setLoading(false);
        console.log(question);
      })
      .catch((err) => {
        console.error(err);
        setLoading(false);
      });
  };

  useEffect(() => {
    getQuestionData();
  }, [questionSlug]);
  return (
    <>
      <Header />
      {loading ? (
        <div>Loading...</div>
      ) : (
        <section>
          <div class="container max-w-4xl mx-auto px-4 py-8">
            <h1 class="text-3xl font-bold mb-6">{question.name[selectedLanguage].name}</h1>
            <div class="space-y-4">
              {question.faqArticles.map((article) => (
                <Link to={`/article/${article.slug}`}>
                  <div class="bg-white shadow-sm rounded-lg p-2">
                    <h2 class="text-xl font-semibold">
                      {article.title[selectedLanguage].title}
                    </h2>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}
      <Footer />
    </>
  );
};

export default FaqQuestion;
