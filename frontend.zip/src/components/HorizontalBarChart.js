import React from 'react';
import { BarChart, Bar, XAxis, YAxis, Legend, ResponsiveContainer } from 'recharts';

const data = [
  { name: '< 7 Days', Return: 9000, Oneway: 9000 },
  { name: '7 to 14 Days', Return: 7000, Oneway: 7000 },
  { name: '14 to 30 Days', Return: 6000, Oneway: 6000 },
  { name: '30 to 60 Days', Return: 2000, Oneway: 2000 }
];

const MyHorizontalBarChart = () => {
  return (
    <ResponsiveContainer width="100%" height={400}>
      <BarChart
        width={500}
        height={300}
        data={data}
        layout="vertical"
        margin={{
          top: 20, right: 30, left: 20, bottom: 0,
        }}
      >
        <XAxis type="number" axisLine={false} tick={false} />
        <YAxis type="category" dataKey="name" axisLine={false} tickLine={false} />
        <Legend layout="horizontal" verticalAlign="top" align="left" />
        <Bar dataKey="Return" fill="#2864f0" />
        <Bar dataKey="Oneway" fill="#0daa96" />
      </BarChart>
    </ResponsiveContainer>
  );
}

export default MyHorizontalBarChart;
