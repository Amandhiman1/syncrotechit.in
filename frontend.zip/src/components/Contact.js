import React, { useEffect, useState } from "react";
import Footer from "./Include/Footer";
import Header from "./Include/Header";
import mail_img from "./Assets/mail.svg";
import PhoneInput from "react-phone-input-2";
import "react-phone-input-2/lib/style.css";
import axios from "axios";
import { useHistory } from "react-router-dom";
import HomeSearch from "./HomeSearch";
import SearchComponent from "./SearchComponent";

export default function Contact() {
  useEffect(() => {
    window.scrollTo({
      top: 0,
    });
  }, []);
  const [value, setValue] = useState();
  const [data, setData] = useState({
    email: "",
    subject: "",
    description: "",
    file_attachments: null,
  });
  const [emailError, setEmailError] = useState(false);
  const [descriptionError, setDescriptionError] = useState(false);

  const history = useHistory();

  const validateEmail = () => {
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    const isValid = emailRegex.test(data.email);
    setEmailError(!isValid);
    return isValid;
  };

  const validateDescription = () => {
    const isValid = data.description.length > 0;
    setDescriptionError(!isValid);
    return isValid;
  };
  const handleOnChange = (e) => {
    if (e.target.name === "file_attachments") {
      setData({
        ...data,
        [e.target.name]: e.target.files[0],
      });
    } else {
      setData({
        ...data,
        [e.target.name]: e.target.value,
      });
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (validateEmail() && validateDescription()) {
        const formData = {
          ...data,
          number: value,
        };
        const res = await axios.post(
          "https://flight-backend-ro3e.onrender.com/api/contact-help-you",
          formData
        );

        setData({
          email: "",
          subject: "",
          description: "",
          file_attachments: null,
        });
        setValue("");
        history.push('/thank-you');
      }
    } catch (error) {
      console.log(error);
    }
  };
  return (
    <>
      {/* header */}
      <Header />
      {/* end header  */}

      {/* one section */}
      <section className="chy_section">
        <div className="container">
          <div className="row">
            <div className="col-md-12">
              <h2 className="title_cheap_flight">How we can Help you?</h2>
              <p className="Idigo_text">
                Explore Destinations & Get Inspired For Your Next Getaway
              </p>
            </div>
            <SearchComponent />
          </div>
        </div>
      </section>
      {/* end one section */}

      {/* one section */}
      <section className="chy_two_section">
        <div className="container">
          <div className="row">
            <div className="col-md-5 contact-img-cont">
            <img
                          src={`${process.env.PUBLIC_URL}/image/contact-us.png`}
                          alt="Example"
                        />
            </div>
            <div className="col-md-7">
              <div className="chy_form">
                <h3 className="chy_talk_heading">Talk To Us</h3>
                <p className="send_message">
                  Send us a message <img src={mail_img} alt="" />
                </p>

                <form onSubmit={handleSubmit} encType="multipart/form-data">
                  <div className="form-group">
                    <label htmlFor="">Your email address*</label>
                    <input
                      type="email"
                      className="form-control"
                      placeholder=""
                      value={data.email}
                      name="email"
                      onChange={handleOnChange}
                    />
                    {emailError && <p>Email is required</p>}
                  </div>

                  <div className="form-group">
                    <label htmlFor="">Subject</label>
                    <input
                      type="text"
                      className="form-control"
                      placeholder="Subject"
                      value={data.subject}
                      name="subject"
                      onChange={handleOnChange}
                    />
                  </div>
                  <div className="form-group">
                    <label htmlFor="">Description *</label>
                    <textarea
                      className="form-control"
                      rows="3"
                      name="description"
                      onChange={handleOnChange}
                      value={data.description}
                    ></textarea>
                    {descriptionError && <p>Description is required</p>}
                  </div>

                  <div className="form-group">
                    <label htmlFor="">
                      Telephone Number (with country code)
                    </label>
                    {/* <input type="tel" class="form-control"  placeholder="Telephone Number" required /> */}
                    <PhoneInput
                      // placeholder="Telephone Number"
                      country={"in"}
                      value={value}
                      onChange={(phone) => setValue(phone)}
                    />
                  </div>

                  <div className="form-group">
                    <label htmlFor="">Attachments</label>
                    <img
                          src={`${process.env.PUBLIC_URL}/image/aerrow.png`}
                          alt="Example"
                          className="file-img"
                        />
                    <input
                    
                      type="file"
                      className="form-control file-main"
                      name="file_attachments"
                      onChange={handleOnChange}
                    />
                  </div>

                  <div className="form-group text-center mt-4 mb-5">
                    <button
                      type="submit"
                      className="btn btn-primary cont_sub_btn"
                    >
                      Submit
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </section>
      {/* end one section */}

      {/* header */}
      <Footer />
      {/* end header  */}
    </>
  );
}