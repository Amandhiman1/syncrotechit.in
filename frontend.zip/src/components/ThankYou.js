import React from 'react'
import Header from './Include/Header'
import Footer from './Include/Footer'

const ThankYou = () => {
    return (
        <>
            <Header/>
            <section className='chy_section'>
                <div className='container'>
                    <div className='row'>
                        <div className='col-md-12'>
                            <h2 className='title_cheap_flight'>Thank You</h2>
                        </div>
                    </div>
                </div>
            </section>
            <Footer />
        </>
    )
}

export default ThankYou
