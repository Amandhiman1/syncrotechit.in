import React, { useEffect } from "react";
import "./Common/css/admin_style.css";
import Sidemanu from "./Common/Sidebar_menu";
import DashboardHeader from "./Common/DashboardHeader";
import { useState } from "react";
import DatePicker from "react-datepicker";
import Calendarimgs from "./Common/img/calender.svg";
import "react-datepicker/dist/react-datepicker.css";
import celendr from "./Common/img/calendar2.svg";
import blog_img from "./Common/img/blog.svg";
import edit_btn from "./Common/img/edit_button.svg";
import del_btn from "./Common/img/delt_button.svg";
import { Link } from "react-router-dom";
import { Form, Tab, Tabs } from "react-bootstrap";
import axios from "axios";
import AxiosJWT from './Common/AxiosJWT'
import { toast } from "react-toastify";
import { format } from "date-fns";
import visitor from './Common/img/visitors.svg';
import greendot from './Common/img/greendot.svg'

export default function DashboardBlog() {
  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(null);
  const [languages, setLangs] = useState([]);
  const [blogs, setBlogs] = useState([]);
  const [formData, setFormData] = useState({
    createdBy: '668eb1acaa30efee73843082',
    title: languages.reduce((acc, lang) => {
      acc[lang.code] = "";
      return acc;
    }, {}),
  });

  const getBlogs = async () => {
    try {
      await axios.get("https://flight-backend-ro3e.onrender.com/api/blog")
        .then(
          (data) => {
            console.log(data.data);
            if (data.data.length > 0) setBlogs(data.data);
          },
          (error) => {
            if (error) {
              console.log(error);
            }
          }
        );
    } catch (e) {
      console.log(e);
    }
  };

  const handleDelete = async (blogId) => {
    if (window.confirm("Are you sure you want to delete this blog?")) {
      try {
        await AxiosJWT.delete(`https://flight-backend-ro3e.onrender.com/api/blog/${blogId}`); // Make sure the endpoint is correct
        getBlogs(); // Refresh the blog list after deletion
      } catch (error) {
        console.error("There was an error deleting the blog!", error);
      }
    }
  };

  const getLanguages = () => {
    try {
      fetch(process.env.REACT_APP_API_URL + "languages")
        .then((response) => response.json())
        .then(
          (data) => {
            console.log(data);
            if (data.length > 0) setLangs(data);
          },
          (error) => {
            if (error) {
              console.log(error);
            }
          }
        );
    } catch (e) {
      console.log(e);
    }
  };

  const handleTopicFormChange = (e, langCode) => {
    const { value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      title: {
        ...prevData.title,
        [langCode]: value,
      },
    }));
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await AxiosJWT.post(
        "https://flight-backend-ro3e.onrender.com/api/blogcat",
        formData
      );
      console.log("Form submitted:", formData);
      console.log("Response:", response.data);
      toast.success("New category created");
      setFormData({
        title: languages.reduce((acc, lang) => {
          acc[lang.code] = "";
          return acc;
        }, {}),
      });
    } catch (error) {
      console.error("Error submitting form:", error);
    }
  };

  useEffect(() => {
    getBlogs();
    getLanguages();
  }, []);

  return (
    <>
      <section className="admin-pages blog_page">
        <div className="container-fluid p-0">
          <div className="row p-0 m-0">
            <div className="col-lg-2 col-md-12 bg-light">
              <Sidemanu />
            </div>

            <div className="col-lg-10 col-md-12">
              <header>
                <DashboardHeader />
              </header>

              {/* content */}
              <div className="col-md-12 mt-4">
                <div className="row top_dash_box">
                  <div className="col-md-3">
                    <div className="green_section offer new_visi">
                      <div className="left_side_dash">
                        <span className="visi">Total Blogs</span>
                        <span className="texts new_text">40</span>
                      </div>
                    </div>
                  </div>
                  <div className="col-md-3">
                    <div className="blue_section new_visi">
                      <div className="left_side_dash">
                        <span className="visi">Draft Blogs</span>
                        <span className="texts new_text">12</span>
                      </div>
                    </div>
                  </div>
                  <div className="col-md-3">
                    <div className="orang_section new_visi">
                      <div className="left_side_dash">
                        <span className="visi">Published Blogs</span>
                        <span className="texts new_text">28</span>
                      </div>
                    </div>
                  </div>
                  <div className="col-md-3 d-flex align-items-center justify-content-center">
                    <div className="create_button">
                      <div className="left_side_dash">
                        <button
                          type="button"
                          class="create_btn btn-main"
                          data-toggle="modal"
                          data-target="#myModal3"
                        >
                          Add new category
                        </button>
                        <Link to="/admin/add-blog">
                          <button className="create_btn">Post new</button>
                        </Link>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="row m-0 mt-4 p-3  bg-light">
                <div className="col-md-5">
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Search"
                  />
                </div>
                <div className="col-md-4 d-flex gap-div">
                  {/* <div className="mr-3 d-flex clender_str">
                    <img src={Calendarimgs} alt="" />

                    <DatePicker
                      className="form-control date_picker"
                      selected={startDate}
                      onChange={(date) => setStartDate(date)}
                      placeholderText="From"
                    />
                  </div>
                  <div className="d-flex clender_str ">
                    <img src={Calendarimgs} alt="" />
                    <DatePicker
                      className="form-control date_picker"
                      selected={endDate}
                      onChange={(date) => setEndDate(date)}
                      placeholderText="To"
                    />
                  </div> */}
                  <div class="date-input">
      <span class="icon-container">
      <img src={Calendarimgs} alt="" />
      </span>
      <input type="text" placeholder="From"/>
  </div>
  <div class="date-input">
      <span class="icon-container img-2">
      <img src={Calendarimgs} alt="" />
      </span>
      <input type="text" placeholder="To"/>
  </div>
                </div>
                <div className="col-md-1 pl-2">
                  <select
                    className="custom_select form-control"
                    id="inputGroupSelect03"
                  >
                    <option>Type</option>
                    <option value="1">One</option>
                    <option value="2">Two</option>
                  </select>
                </div>
                <div className="col-md-2">
                  <input
                    type="submit"
                    name="shortby"
                    value="Short by"
                    className="form-control short-by"
                  />
                </div>
              </div>

              {/* first call request */}
              {blogs.map((blog) => (
                <div className="call_req_id">
                  <div className="row ">
                    <div className="col-md-12">
                      {/* first row */}
                      <div className="row">
                        <div className="col-md-6 ">
                          <div className="main_cnt_box d-flex w-100">
                            <div className="img_span">
                              <img src={blog_img} alt="" />
                            </div>
                            <div className="box_cont_img_cont">
                              <small>Blog ID No.</small>
                              <span>{blog._id}</span>
                            </div>
                          </div>
                        </div>

                        <div className="col-md-6 ">
                          <div className="main_cnt_box d-flex w-100 justify-content-end">
                            <div className="img_span">
                              <img src={celendr} alt="" />
                            </div>
                            <div className="box_cont_img_cont">
                              <small>Blog Post Date</small>
                              <span>
                                {format(
                                  new Date(blog.createdAt),
                                  "EEE dd MMM yyyy HH:mm"
                                )}
                              </span>
                            </div>
                          </div>
                        </div>

                        {/* add edit delt start */}


                        {/* add edit delt end */}
                      </div>

                      {/* end first row */}

                      <hr className="hr_dashbord" />

                      {/* start second row*/}

                      <div className="row blog_box_des_dp">

                      <div className="col-lg-2 col-md-3 col-sm-12 secd_lins box_border">
                          <div className="main_cnt_box d-flex">
                            <div className="box_cont_img_cont">
                              <small>Category</small>
                              <span>{blog.category.en}</span>
                            </div>
                          </div>

                          <div className="main_cnt_box d-flex">
                            <div className="box_cont_img_cont">
                              <small>Language</small>
                              <span>English</span>
                            </div>
                          </div>

                          <div className="main_cnt_box d-flex">
                          <div className="img">
                            <img src={visitor} />
                          </div>
                            <div className="box_cont_img_cont">
                              <small>No. of Visitors</small>
                              <span>400</span>
                            </div>
                          </div>
{/* 
                          <div className="main_cnt_box d-flex">
                            <div className="box_cont_img_cont">
                              <small>No. of repeat</small>
                              <span>400</span>
                            </div>
                          </div>
                          <div className="main_cnt_box d-flex">
                            <div className="box_cont_img_cont">
                              <small>No. of Images</small>
                              <span>400</span>
                            </div>
                          </div> */}
                        </div>

                        <div className="col-lg-8 col-md-3 col-sm-12 blog_del_dp">
                          <div className="main_cnt_box d-flex w-100">
                            <p className="desinatinaton_visit">
                              {" "}
                              {blog.titles.en}{" "}
                            </p>

                           


                          </div>

                          <div className="d-flex status_opn">
                                    <div className="img_dp">
                                      <img src={greendot} />
                                    </div>
                                    <div className="box_cont_img_cont">
                                      <small className="org_text">Status</small>
                                      <span>Active</span>
                                    </div>
                                  </div>

                                  <div className="d-flex status_opn pt-3">
                                    <div className="box_cont_img_cont">
                                      <small>Name</small>
                                      <span><b>Top 10 desinatinaton to visit in this summer</b></span>
                                    </div>
                                  </div>
                        </div>

                        <div className="col-lg-2 col-md-3 col-sm-12 edit_del_dp">
                          
                          <div className="d-flex add_edit_dlt">
                            {/* <Link className=" d-flex" to="#">
                              <div className="img_span">
                                <img src={active_btn} alt="" />
                              </div>
                              <div className="box_cont_img_cont">
                                <small>Status</small>
                                <span>Published</span>
                              </div>
                            </Link> */}

                            <Link className=" d-flex" to={`/admin/edit-blog/${blog.slug}`}>
                              <div className="img_span">
                                <img src={edit_btn} alt="" />
                              </div>
                              <div className="box_cont_img_cont pl-2">
                                {/* <small>Call request date</small> */}
                                <span>Edit</span>
                              </div>
                            </Link>
                            <div className="d-flex" onClick={() => handleDelete(blog._id)}>
                              <div className="img_span">
                                <img src={del_btn} alt="" />
                              </div>
                              <div className="box_cont_img_cont">
                                {/* <small>Call request date</small> */}
                                <span>Delete</span>
                              </div>
                            </div>
                          </div>
                       
                        </div>

                 
                      </div>
                      {/* end second row */}
                    </div>
                  </div>
                </div>
              ))}
              {/* content end */}
            </div>
          </div>

          <div
            className="modal right fade"
            id="myModal3"
            tabindex="-1"
            role="dialog"
            aria-labelledby="myModalLabel3"
          >
            <div className="modal-dialog main" role="document">
              <div className="modal-content main">
                <div className="modal-header">
                  <button
                    type="button"
                    className="close"
                    data-dismiss="modal"
                    aria-label="Close"
                  >
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>

                <div className="modal-body modal-main sidebar_popup">
                  <Form
                    onSubmit={handleSubmit}
                    id="topicForm"
                    className="common-form common-form-border login-signup-form"
                    autoComplete="off"
                  >
                    <div className="row mb-5">
                      <div className="col-lg-12">
                        <Tabs
                          defaultActiveKey="en"
                          id="uncontrolled-tab-example"
                          className="mb-3"
                        >
                          {languages.length > 0 &&
                            languages.map((lang) => (
                              <Tab
                                key={lang.code}
                                eventKey={lang.code}
                                title={lang.name}
                              >
                                <Form.Group
                                  className="mb-3 f-left w-100"
                                  controlId={`form-control-${lang.code}`}
                                >
                                  <Form.Label>Topic Name</Form.Label>
                                  <Form.Control
                                    type="text"
                                    name="name"
                                    value={formData.title[lang.code]}
                                    onChange={(e) =>
                                      handleTopicFormChange(e, lang.code)
                                    }
                                  />
                                </Form.Group>
                              </Tab>
                            ))}
                        </Tabs>
                        <button
                          variant="primary"
                          className="create_btn form_submit text-center shrink-border sub-btn"
                          type="submit"
                        >
                          Submit
                        </button>
                      </div>
                    </div>
                  </Form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
