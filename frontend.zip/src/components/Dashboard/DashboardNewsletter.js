import React, { useEffect, useRef } from "react";
import "./Common/css/admin_style.css";
import Sidemenu from "./Common/Sidebar_menu";
import DashboardHeader from "./Common/DashboardHeader";
import { useState } from "react";
import DatePicker from "react-datepicker";
import Calendarimgs from "./Common/img/calender.svg";
import "react-datepicker/dist/react-datepicker.css";
import webpage from "./Common/img/pexels-mateusz.svg";
import blog_img from "./Common/img/calendar2.svg";
import news from "./Common/img/offer.svg";
import active_btn from "./Common/img/active_icon.svg";
import del_btn from "./Common/img/delt_button.svg";
import { Link } from "react-router-dom";
import { useHistory } from "react-router-dom/cjs/react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { checkAdminLogin } from "../../redux/Action";
import { Form } from "react-bootstrap";
import axios from "axios";
import SunEditor from "suneditor-react";
import Swal from "sweetalert2";
import { format } from "date-fns";
import AxiosJWT from './Common/AxiosJWT';
import greendot from './Common/img/greendot.svg'

export default function DashboardNewsletter() {
  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(null);
  const [languages, setLangs] = useState([]);
  const [formData, setFormData] = useState({
    language: "",
    subject: "",
    body: "",
  });
  const [templates, setTemplates] = useState([]);

  const isAdmin = useSelector((state) => state.reducer.isAdmin);
  const dispatch = useDispatch();
  const history = useHistory();
  const editorRef = useRef(null);

  const showalert = (heading) => {
    Swal.fire({
      title: heading,
      icon: "question",
      customClass: {
        popup: "my-popup",
        confirmButton: "my-confirm-button",
        cancelButton: "my-cancel-button",
      },
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const res = await AxiosJWT.post(
        "https://flight-backend-ro3e.onrender.com/api/emailTemplate",
        formData
      );
      console.log(res.data);
      showalert(res.data);
      setFormData({ language: "", subject: "", body: "" }); // Reset form data

      // Clear SunEditor content
      if (editorRef.current) {
        editorRef.current.setContents(""); // Reset the editor content
      }

      getTemplates();
    } catch (err) {
      console.error(err);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleEditorChange = (content) => {
    setFormData((prevData) => ({
      ...prevData,
      body: content,
    }));
  };

  const handleDelete = async (id) => {
    await AxiosJWT
      .delete(`https://flight-backend-ro3e.onrender.com/api/emailTemplate/${id}`)
      .then((res) => {
        console.log(res.data);
        showalert(res.data);
        getTemplates();
      })
      .catch((err) => {
        showalert(err);
      });
  };

  const getTemplates = async () => {
    await AxiosJWT
      .get("https://flight-backend-ro3e.onrender.com/api/emailTemplate")
      .then((res) => {
        setTemplates(res.data);
      })
      .catch((err) => {
        console.error(err);
      });
  };

  const sendEmail = async (templateId) => {
    await AxiosJWT
      .post("https://flight-backend-ro3e.onrender.com/api/emailTemplate/send-email", {
        templateId,
      })
      .then((res) => {
        console.log(res.data);
        showalert(res.data);
        getTemplates();
      })
      .catch((err) => {
        console.error(err);
      });
  };

  const get_langauages = () => {
    try {
      AxiosJWT.get("https://flight-backend-ro3e.onrender.com/api/languages").then(
        (data) => {
          console.log(data.data);
          //setOrders(data)
          if (data.data.length > 0) setLangs(data.data);
        },
        (error) => {
          if (error) {
            console.log(error);
          }
        }
      );
    } catch (e) {
      //snotify()
      console.error(e);
    }
  };

  const convertDate = (isoDate) => {
    const date = new Date(isoDate);
    return format(date, "EEE dd MMM yyyy HH:mm");
  };

  // const handleInputChange = (field, value) => {
  //   setFormData((prevData) => ({
  //     ...prevData,
  //     [field]: value,
  //   }));
  // };

  useEffect(() => {
    dispatch(checkAdminLogin()); // Dispatch the action to check login status
  }, [dispatch]);

  useEffect(() => {
    get_langauages();
    getTemplates();
  }, []);

  useEffect(() => {
    // If not authenticated, redirect to the login page
    if (isAdmin === false) {
      history.push("/admin/login");
    }
  }, [isAdmin, history]);

  return (
    <>
      <section className="admin-pages news_letter">
        <div className="container-fluid p-0">
          <div className="row p-0 m-0">
            <div className="col-lg-2 col-md-12 bg-light">
              <Sidemenu />
            </div>

            <div className="col-lg-10 col-md-12">
              <header>
                <DashboardHeader />
              </header>

              {/* content  */}
              <div className="col-md-12 mt-4">
                <div className="row top_dash_box">
                  <div className="col-md-3">
                    <div className="green_section offer new_visi">
                      <div className="left_side_dash">
                        <span className="visi">Total Newsletters</span>
                        <span className="texts new_text">40</span>
                      </div>
                    </div>
                  </div>
                  <div className="col-md-3">
                    <div className="blue_section new_visi">
                      <div className="left_side_dash">
                        <span className="visi">Draft</span>
                        <span className="texts new_text">12</span>
                      </div>
                    </div>
                  </div>
                  <div className="col-md-3">
                    <div className="orang_section new_visi">
                      <div className="left_side_dash">
                        <span className="visi">Sent</span>
                        <span className="texts new_text">28</span>
                      </div>
                    </div>
                  </div>
                  <div className="col-md-3 d-flex align-items-center justify-content-center">
                    <div className="create_button">
                      <div className="left_side_dash">
                        <button
                          class="create_btn"
                          data-toggle="modal"
                          data-target="#myModal3"
                        >
                          Post new
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="row m-0 mt-4 p-3  bg-light">
                <div className="col-md-5">
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Search"
                  />
                </div>
                <div className="col-md-4 d-flex gap-div">
                  {/* <div className="mr-3 d-flex clender_str">
                    <img src={Calendarimgs} alt="" />
                    <DatePicker
                      className="form-control date_picker"
                      selected={startDate}
                      onChange={(date) => setStartDate(date)}
                      placeholderText="From"
                    />
                  </div>
                  <div className="d-flex clender_str ">
                    <img src={Calendarimgs} alt="" />
                    <DatePicker
                      className="form-control date_picker"
                      selected={endDate}
                      onChange={(date) => setEndDate(date)}
                      placeholderText="To"
                    />
                  </div> */}
                  <div class="date-input">
      <span class="icon-container">
      <img src={Calendarimgs} alt="" />
      </span>
      <input type="text" placeholder="From"/>
  </div>
  <div class="date-input">
      <span class="icon-container img-2">
      <img src={Calendarimgs} alt="" />
      </span>
      <input type="text" placeholder="To"/>
  </div>
                </div>
                <div className="col-md-1 pl-2">
                  <select
                    className="custom_select form-control"
                    id="inputGroupSelect03"
                  >
                    <option>Type</option>
                    <option value="1">One</option>
                    <option value="2">Two</option>
                  </select>
                </div>
                <div className="col-md-2">
                  <input
                    type="submit"
                    className="form-control"
                    Name="shortby"
                    value="Short by"
                    class="form-control short-by"
                  />
                </div>
              </div>

              {/* first call request  */}
              <div className="call_req_id">
                <div className="row ">
                  {templates != 0 ? (
                    templates
                      .slice()
                      .reverse()
                      .map((template) => (
                        <div className="col-md-12">
                          {/* first row  */}
                          <div className="row  justify-content-between">
                            <div className="col-lg-6 ">
                              <div className="main_cnt_box d-flex w-100">
                                <div className="img_span">
                                  <img src={blog_img} alt="" />
                                </div>
                                <div className="box_cont_img_cont">
                                  <small>Blog Post Date</small>
                                  {/* <span>Thu 22 Apr 2022 18:30</span> */}
                                  <span>{convertDate(template.createdAt)}</span>
                                </div>
                              </div>
                            </div>

                            <div className="col-lg-6 justify-content-center">
                              <div className="main_cnt_box d-flex w-100 justify-content-end">
                                <div className="img_span">
                                  <img src={news} alt="" />
                                </div>
                                <div className="box_cont_img_cont">
                                  <small>Blog ID No.</small>
                                  <span>{template._id}</span>
                                </div>
                              </div>
                            </div>

                            {/* add edit delt start  */}

                        

                            {/* add edit delt end  */}
                          </div>

                          {/* end first row  */}

                          <hr className="hr_dashbord" />

                          {/* start second row  */}

                          <div className="row align-items-center">

                            <div className="col-lg-2 col-md-2 col-sm-12 blog_box_des_dp">
                            <div className="secd_lins box_border">
                                <div className="main_cnt_box d-flex">
                                  <div className="box_cont_img_cont">
                                    <small>Category</small>
                                    <span>Flight</span>
                                  </div>
                                </div>
                                <div className="main_cnt_box d-flex">
                                  <div className="box_cont_img_cont">
                                    <small>Language</small>
                                    <span>{template.language}</span>
                                  </div>
                                </div>
                                <div className="">
                                  <div className="box_cont_img_cont">
                                    {template.status !== "Sent" && (
                                      <button
                                        class="create_btn"
                                        onClick={() => sendEmail(template._id)}
                                      >
                                        Send Email
                                      </button>
                                    )}
                                  </div>
                                </div>
                              </div>
                            </div>

                            <div className="col-lg-8 col-md-8 col-sm-12">
                            <div className="image_disc">
                                <h5>{template.subject}</h5>
                                {/* <div
                                  dangerouslySetInnerHTML={{
                                    __html: template.body,
                                  }}
                                /> */}
                              </div>
                            <div className="news_imgs_main">
                                <img src={webpage} alt="" width={100} height={100} />
                              </div>

                            </div>


                            <div className="col-lg-2 col-md-2 col-sm-12 edit_del_dp">
                            <div className="d-flex add_edit_dlt">
                                {/* <Link className=" d-flex" to="#">
                              <div className="img_span">
                                <img src={active_btn} alt="" />
                              </div> */}
                              <div className="d-flex status_opn">
                              <div className="img_dp">
                                      <img src={greendot} />
                              </div>
                                <div className="box_cont_img_cont">
                               
                                  <small>Status</small>
                                  <span>{template.status}</span>
                                </div>
                                </div>
                                {/* </Link> */}

                                <div
                                  className="d-flex"
                                  onClick={() => handleDelete(template._id)}
                                >
                                  <div className="img_span">
                                    <img src={del_btn} alt="" />
                                  </div>
                                  <div className="box_cont_img_cont">
                                    <span>Delete</span>
                                  </div>
                                </div>
                              </div>
                             
                            </div>
                          </div>
                          {/* end second row  */}
                        </div>
                      ))
                  ) : (
                    <div>No templates</div>
                  )}
                </div>
              </div>
              {/* content end   */}
            </div>
          </div>
          <div
            className="modal right fade"
            id="myModal3"
            tabindex="-1"
            role="dialog"
            aria-labelledby="myModalLabel3"
          >
            <div className="modal-dialog main" role="document">
              <div className="modal-content main">
                <div className="modal-header">
                  <button
                    type="button"
                    className="close"
                    data-dismiss="modal"
                    aria-label="Close"
                  >
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>

                <div className="modal-body modal-main sidebar_popup">
                  {/* <div className="flex justify-between mb-6">
                    <button
                      className="create_btn fq-btn Text-white font-bold py-2.5 px-4 rounded ml-20"
                      onClick={() => {
                        setFormType("Topic");
                      }}
                    >
                      Add New Topic
                    </button>
                    <button
                      className="create_btn fq-btn faq-btn Text-white font-bold py-2.5 px-4 rounded ml-20"
                      onClick={() => {
                        setFormType("Question");
                      }}
                    >
                      Add New Question
                    </button>
                  </div> */}
                  <Form
                    onSubmit={handleSubmit}
                    id="topicForm"
                    className="common-form common-form-border login-signup-form"
                    autoComplete="off"
                  >
                    <div className="row mb-5">
                      <div className="col-lg-12">
                        <Form.Group controlId="formGridState">
                          <Form.Label>Language</Form.Label>
                          <Form.Select
                            defaultValue=""
                            className="form-control"
                            name="language"
                            value={formData.language}
                            onChange={handleChange}
                          >
                            <option value="">Choose...</option>
                            {languages ? (
                              languages.map((language) => (
                                <option
                                  key={language.name}
                                  value={language.name}
                                >
                                  {language.name}
                                </option>
                              ))
                            ) : (
                              <option value="">No language available</option>
                            )}
                          </Form.Select>
                        </Form.Group>

                        <Form.Group
                          className="mb-3 f-left w-100"
                          controlId="exampleForm.ControlInput1"
                        >
                          <Form.Label>Email Subject</Form.Label>
                          <Form.Control
                            type="text"
                            name="subject"
                            value={formData.subject}
                            onChange={handleChange}
                          />
                        </Form.Group>

                        <SunEditor
                          setOptions={{
                            height: 200,
                            buttonList: [
                              ["undo", "redo"],
                              ["font", "fontSize", "formatBlock"],
                              ["paragraphStyle", "blockquote"],
                              [
                                "bold",
                                "underline",
                                "italic",
                                "strike",
                                "subscript",
                                "superscript",
                              ],
                              ["fontColor", "hiliteColor", "textStyle"],
                              ["removeFormat"],
                              "/",
                              ["outdent", "indent"],
                              ["align", "horizontalRule", "list", "lineHeight"],
                              ["table", "link", "image", "video", "audio"],
                              ["fullScreen", "showBlocks", "codeView"],
                              ["preview", "print"],
                              ["save", "template"],
                            ],
                          }}
                          getSunEditorInstance={(editor) => {
                            editorRef.current = editor;
                          }} // Get editor instance
                          value={formData.body}
                          onChange={handleEditorChange}
                        />

                        <button
                          variant="primary"
                          className="create_btn form_submit text-center"
                          type="submit"
                        >
                          Submit
                        </button>
                      </div>
                    </div>
                  </Form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
