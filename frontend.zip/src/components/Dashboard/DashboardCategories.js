import React from "react";
import "./Common/css/admin_style.css";
import Sidemenu from "./Common/Sidebar_menu";
import DashboardHeader from "./Common/DashboardHeader";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faArrowUp } from "@fortawesome/free-solid-svg-icons";
import { faArrowDown } from "@fortawesome/free-solid-svg-icons";
// import DatePicker from "react-datepicker";
// import Calendarimgs from './Common/img/calender.svg';
import "react-datepicker/dist/react-datepicker.css";
import { useParams } from "react-router-dom";
import edit_btn from "./Common/img/edit_button.svg";
import del_btn from "./Common/img/delt_button.svg";
import { Link } from "react-router-dom";

import { confirmAlert } from "react-confirm-alert"; // Import
import "react-confirm-alert/src/react-confirm-alert.css";

import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

import Form from "react-bootstrap/Form";
import { useState } from "react";
import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useHistory } from "react-router-dom/cjs/react-router-dom";
import { checkAdminLogin } from "../../redux/Action";
import AxiosJWT from './Common/AxiosJWT'

export default function DashboardVisitersPage() {
  const isAdmin = useSelector((state) => state.reducer.isAdmin);
  const dispatch = useDispatch();
  const history = useHistory();

  

  // const [startDate, setStartDate] = useState(null);
  // const [endDate, setEndDate] = useState(null);
  const [pages, setPages] = useState({});
  const [languages, setLangs] = useState([]);
  const [formData, setFormData] = useState({});
  const [errors, setErrors] = useState({});

  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);

  const maxPageNumbersToShow = 10;

  const { id } = useParams();

  useEffect(() => {
    const type = getQueryVariable("type");
    get_langauages();
    console.log(type);
    get_pages(type, currentPage);
  }, [currentPage]);

  const get_langauages = () => {
    try {
      fetch(process.env.REACT_APP_API_URL + "languages")
        .then((response) => response.json())
        .then(
          (data) => {
            console.log(data);
            //setOrders(data)
            if (data.length > 0) setLangs(data);
          },
          (error) => {
            if (error) {
              console.log(error);
            }
          }
        );
    } catch (e) {
      //snotify()
    }
  };

  const editCat = (catid) => {
    const type = getQueryVariable("type");
    try {
      AxiosJWT.get(process.env.REACT_APP_API_URL + type + `/` + catid)
        .then((response) => response.json())
        .then(
          (response) => {
            console.log(response);
            setErrors({});
            //setOrders(data)
            setFormData(response);
          },
          (error) => {
            if (error) {
              console.log(error);
            }
          }
        );
    } catch (e) {
      //snotify()
    }
  };

  const get_pages = (type, page) => {
    try {
      /* let post_data = {
                method: 'POST',
                //credentials: 'same-origin',
                //mode: 'same-origin',
                body: JSON.stringify({'page_type':id}),
                headers: {
                    'Accept':       'application/json',
                    'Content-Type': 'application/json',
                    //'X-CSRFToken':  cookie.load('csrftoken')
                }
            } */
      AxiosJWT.get(process.env.REACT_APP_API_URL + type + `?page=${page}`)
        .then((response) => response.json())
        .then(
          (response) => {
            console.log(response);

            setTotalPages(response.totalPages);
            //setOrders(data)
            setPages(response.data);
          },
          (error) => {
            if (error) {
              console.log(error);
            }
          }
        );
    } catch (e) {
      //snotify()
    }
  };

  const getQueryVariable = (variable) => {
    var query = window.location.search.substring(1);
    //console.log(query)//"app=article&act=news_content&aid=160990"
    var vars = query.split("&");
    //console.log(vars) //[ 'app=article', 'act=news_content', 'aid=160990' ]
    for (var i = 0; i < vars.length; i++) {
      var pair = vars[i].split("=");
      //console.log(pair)//[ 'app', 'article' ][ 'act', 'news_content' ][ 'aid', '160990' ]
      if (pair[0] == variable) {
        return pair[1];
      }
    }
    return false;
  };

  let table_header = [
    {
      id: "1",
      label: "Name",
    },
    {
      id: "4",
      label: "Actions",
    },
  ];

  let table_data = [
    {
      id: "1",
      domains: "www.xyz.ez",
      new_visiter: "16,000",
      repvisiters: "16,000",
      ip: "800",
    },
    {
      id: "2",
      domains: "www.xyz.ez",
      new_visiter: "16,000",
      repvisiters: "16,000",
      ip: "800",
    },
    {
      id: "3",
      domains: "www.xyz.ez",
      new_visiter: "16,000",
      repvisiters: "16,000",
      ip: "800",
    },
  ];

  const handlePageChange = (pageNumber) => {
    if (pageNumber >= 1 && pageNumber <= totalPages) {
      setCurrentPage(pageNumber);
    }
  };

  const renderPageNumbers = () => {
    const pageNumbers = [];
    const halfMaxPageNumbers = Math.floor(maxPageNumbersToShow / 2);

    // Calculate the start and end page numbers to show
    let startPage = Math.max(currentPage - halfMaxPageNumbers, 1);
    let endPage = Math.min(startPage + maxPageNumbersToShow - 1, totalPages);

    if (endPage - startPage < maxPageNumbersToShow - 1) {
      startPage = Math.max(endPage - maxPageNumbersToShow + 1, 1);
    }

    for (let page = startPage; page <= endPage; page++) {
      pageNumbers.push(
        <button
          key={page}
          onClick={() => handlePageChange(page)}
          disabled={currentPage === page}
        >
          {page}
        </button>
      );
    }

    return pageNumbers;
  };

  const delCat = (id) => {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui">
            <h1>Are you sure?</h1>
            <p>You want to delete this file?</p>
            <button onClick={onClose}>No</button>
            <button
              onClick={() => {
                delCatRequest(id);
                onClose();
              }}
            >
              Yes, Delete it!
            </button>
          </div>
        );
      },
    });
  };

  const delCatRequest = (id) => {
    console.log(id);
    let post_data = {
      //credentials: 'same-origin',
      //mode: 'same-origin',
      //body: JSON.stringify({'id':id}),
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        //'X-CSRFToken':  cookie.load('csrftoken')
      },
    };

    // Simple GET request using fetch
    console.log(process.env.REACT_APP_API_URL);
    const type = getQueryVariable("type");
    try {
      AxiosJWT.delete(process.env.REACT_APP_API_URL + type + "/" + id, post_data)
        .then((response) => response.json())
        .then((data) => {
          console.log(data);
          get_pages(type, currentPage);
          //show_error()
          toast.error("Record deleted successfully!!");
        });
    } catch (e) {
      console.log("err", e);
    }
  };

  const handleLoginInputChange = (e) => {
    //console.log(e.target.checked)
    setFormData({ ...formData, [e.target.name]: e.target.value });

    console.log(formData);
  };

  const handleValidation = (e) => {
    let chk = false;
    if (e) {
      e.preventDefault();
      chk = true;
    }

    let fields = formData;
    let errors = {};
    let formIsValid = true;

    //Email

    let narr = {};
    languages.map((lang) => {
      if (!fields[lang.name.toLowerCase()]) {
        formIsValid = false;
        errors[lang.name.toLowerCase()] = lang.name + " title cannot be empty";
      } else {
        if (lang.code == "en") {
          console.log("titile", fields[lang.name.toLowerCase()]);
          fields["title"] = fields[lang.name.toLowerCase()];
        }
        narr[lang.name.toLowerCase()] = fields[lang.name.toLowerCase()];
      }
    });

    if (!fields["code"]) {
      formIsValid = false;
      errors["code"] = "Please enter code.";
    } else {
      narr["code"] = fields["code"];
    }

    console.log(fields, narr);

    setErrors(errors);
    //fields['languages'] = narr;

    if (formIsValid && chk) {
      //alert("Form submitted");

      let post_data = {
        method: fields["id"] ? "PUT" : "POST",
        //credentials: 'same-origin',
        //mode: 'same-origin',
        body: JSON.stringify(narr),
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          //'X-CSRFToken':  cookie.load('csrftoken')
        },
      };

      // Simple GET request using fetch
      console.log(process.env.REACT_APP_API_URL);

      const type = getQueryVariable("type");
      try {
        fetch(
          process.env.REACT_APP_API_URL +
            type +
            (fields["id"] ? "/" + fields["id"] : ""),
          post_data
        )
          .then((response) => response.json())
          .then((data) => {
            console.log(data);
            get_pages(type, currentPage);
            setFormData({});
            document.getElementById("webForm").reset();
            show_success("Record added successfully!!");
          });
      } catch (e) {
        console.log("err", e);
      }
    }
  };

  const show_success = (msg) => {
    toast.success(msg);
  };

  const show_error = (msg) => {
    toast.error(msg);
  };

  return (
    <>
      <section className="visitor-pages">
        <div className="container-fluid p-0">
          <div className="row p-0 m-0">
            <div className="col-md-2 bg-light">
              <Sidemenu />
            </div>

            <div className="col-md-10">
              <header>
                <DashboardHeader />
              </header>
              <div className="col-md-12 mt-4">
                <div className="row">
                  <div className="col-md-3"></div>
                  <div className="col-md-3"></div>
                  <div className="col-md-3"></div>
                  <div className="col-md-3 d-flex align-items-right ">
                    <div className="create_button">
                      <div className="right_side_dash">
                        <button
                          class="create_btn"
                          data-toggle="modal"
                          data-target="#myModal3"
                          onClick={() => {
                            setFormData({});
                            document.getElementById("webForm").reset();
                          }}
                        >
                          Add new
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="call_req_id">
                <table className="table ">
                  <thead className="thead-light">
                    <tr>
                      {table_header.map((tables_headr) => (
                        <th scope="col" key={tables_headr.id}>
                          {tables_headr.label}
                        </th>
                      ))}
                    </tr>
                  </thead>

                  <tbody>
                    {pages.length > 0 ? (
                      pages.map((tables) => (
                        <tr key={tables.id}>
                          <td>
                            {tables.airline_name
                              ? tables.airline_name
                              : tables.english}
                          </td>

                          <td>
                            <a
                              href="#"
                              className=" d-flex"
                              data-toggle="modal"
                              data-target="#myModal3"
                              onClick={() => editCat(tables.id)}
                            >
                              <div className="img_span">
                                <img src={edit_btn} alt="" />
                              </div>
                              <div className="box_cont_img_cont pl-2">
                                <span>Edit</span>
                              </div>
                            </a>

                            <Link
                              className=" d-flex "
                              onClick={() => delCat(tables.id)}
                            >
                              <div className="img_span">
                                <img src={del_btn} alt="" />
                              </div>
                              {/* <div className='box_cont_img_cont'>
                                                    <span>Delete</span>
                                                </div> */}
                            </Link>
                          </td>
                        </tr>
                      ))
                    ) : (
                      <>No Records Found!!</>
                    )}
                  </tbody>
                </table>
              </div>
              <div>
                <button
                  onClick={() => handlePageChange(currentPage - 1)}
                  disabled={currentPage === 1}
                >
                  Previous
                </button>
                {renderPageNumbers()}
                <button
                  onClick={() => handlePageChange(currentPage + 1)}
                  disabled={currentPage === totalPages}
                >
                  Next
                </button>
              </div>
              <p>
                Page {currentPage} of {totalPages}
              </p>
            </div>
          </div>
        </div>
      </section>

      <div
        className="modal right fade"
        id="myModal3"
        tabindex="-1"
        role="dialog"
        aria-labelledby="myModalLabel3"
      >
        <div className="modal-dialog main" role="document">
          <div className="modal-content main">
            <div className="modal-header">
              <button
                type="button"
                className="close"
                data-dismiss="modal"
                aria-label="Close"
              >
                <span aria-hidden="true">&times;</span>
              </button>
            </div>

            <div className="modal-body sidebar_popup">
              <Form
                id="webForm"
                onSubmit={handleValidation}
                className="common-form common-form-border login-signup-form"
                autoComplete="off"
              >
                <div className="row mb-5">
                  <div className="col-lg-12">
                    <Form.Group
                      className="mb-3 f-left w-100"
                      controlId="exampleForm.ControlInput1"
                    >
                      {languages.length > 0
                        ? languages.map((lang) => (
                            <div className="col-md-9">
                              <b>{lang.name}</b>{" "}
                              <input
                                type="text"
                                className="form-control"
                                id="title"
                                name={lang.name.toLowerCase()}
                                placeholder={"Add Name "}
                                onChange={(e) => handleLoginInputChange(e)}
                                value={formData[lang.name.toLowerCase()]}
                              />
                              <span style={{ color: "red" }}>
                                {errors[lang.name.toLowerCase()]}
                              </span>
                            </div>
                          ))
                        : ""}

                      <i class="fas fa-copy"></i>
                    </Form.Group>

                    <Form.Group
                      className="mb-3 f-left w-100"
                      controlId="exampleForm.ControlInput1"
                    >
                      <div className="col-md-9">
                        <b>Code</b>{" "}
                        <input
                          type="text"
                          className="form-control"
                          name={"code"}
                          placeholder={"Enter code"}
                          onChange={(e) => handleLoginInputChange(e)}
                          value={formData["code"]}
                        />
                        <span style={{ color: "red" }}>{errors["code"]}</span>
                      </div>
                    </Form.Group>

                    <div className="col-md-3 text-center">
                      <button
                        variant="primary"
                        className="create_btn form_submit text-center"
                        type="submit"
                      >
                        {" "}
                        Submit
                      </button>
                    </div>
                  </div>
                </div>
              </Form>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
