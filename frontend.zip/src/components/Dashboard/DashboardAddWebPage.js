import React, { useEffect, useRef, useState } from "react";
import "./Common/css/admin_style.css";
import Sidemenu from "./Common/Sidebar_menu";
import DashboardHeader from "./Common/DashboardHeader";

import { confirmAlert } from "react-confirm-alert"; // Import
import "react-confirm-alert/src/react-confirm-alert.css"; // Import css

import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

import Tab from "react-bootstrap/Tab";
import Tabs from "react-bootstrap/Tabs";

/* import Editor from 'ckeditor5-custom-build/build/ckeditor';
import { CKEditor } from '@ckeditor/ckeditor5-react'; */

import SunEditor, { buttonList } from "suneditor-react";
import "suneditor/dist/css/suneditor.min.css";

import Form from "react-bootstrap/Form";

import Plus from "./Common/img/plus.svg";
import Minus from "./Common/img/minus.svg";
import { useDispatch, useSelector } from "react-redux";
import { useHistory } from "react-router-dom/cjs/react-router-dom";
import { checkAdminLogin } from "../../redux/Action";

import AxiosJWT from './Common/AxiosJWT'

/* const editorConfiguration = {
    toolbar: {
        items: [
            'bold',
            'italic',
            '|',
            'bulletedList',
            'numberedList',
            'indent',
            'outdent',
            '|',
            'heading',
            '|',
            'undo',
            'redo', 'link', 'blockQuote','insetTable' 
        ]
    }
}; */

export default function DashboardVisitersPage() {
  const isAdmin = useSelector((state) => state.reducer.isAdmin);
  const dispatch = useDispatch();
  const history = useHistory();

  

  const [languages, setLangs] = useState([]);
  const [subcats, setSubCats] = useState([]);
  const [catName, setCatName] = useState("");
  const [subCat, setSubCat] = useState("");
  const [types, setTypes] = useState({});
  const [errors, setErrors] = useState({});
  const [contentState, setcontentState] = useState("demo");
  const [size, setSize] = useState("");
  const [formData, setFormData] = useState({
    data: {},
    category: null,
  });

  const addFlights = () => {
    const initializedFormData = {};
    languages.forEach(lang => {
      initializedFormData[lang.code] = {
        flights: [{ heading: "", slogan: "", queryType: "", componentType: "" }],
        faqs: []
      };
    });
    setFormData({ data: { ...formData.data, ...initializedFormData }, category: null });
  }

  
  useEffect(() => {
    get_langauages();
  }, []);

  useEffect(() => {
    if (languages.length > 0) {
      addFlights();
    }
  }, [languages]);

  const get_langauages = () => {
    try {
      fetch(process.env.REACT_APP_API_URL + "languages")
        .then((response) => response.json())
        .then(
          (data) => {
            console.log(data);
            //setOrders(data)
            if (data.length > 0){
              setLangs(data)
              addFlights();
              // console.log(formData);
            }
          },
          (error) => {
            if (error) {
              console.log(error);
            }
          }
        );
    } catch (e) {
      //snotify()
    }
  };

  /* const languages = [
  
      { 
          key: 'english', 
          title: 'English' ,
      },{ 
          key: 'hindi', 
          title: 'Hindi' ,
      },{ 
          key: 'spanish', 
          title: 'Spanish' ,
      },
    ] */

  //const animatedComponents = makeAnimated();
  const get_page_types = (catid) => {
    try {
      console.log("props.category", catid);
      let post_data = {
        //credentials: 'same-origin',
        //mode: 'same-origin',
        body: JSON.stringify({ category: catid }),
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          //'X-CSRFToken':  cookie.load('csrftoken')
        },
      };
      AxiosJWT.post(process.env.REACT_APP_API_URL + "page_types/filter", post_data)
        .then((response) => response.json())
        .then(
          (data) => {
            console.log(data);
            //setOrders(data)
            setTypes(data);
          },
          (error) => {
            if (error) {
              console.log(error);
            }
          }
        );
    } catch (e) {
      //snotify()
    }
  };

  const show_success = (msg) => {
    toast.success(msg);
  };

  function convertToSlug(Text) {
    return Text.toLowerCase()
      .replace(/ /g, "-")
      .replace(/[^\w-]+/g, "");
  }

  const handleInputChange = (e, key, field) => {
    if (key && field) {
      setFormData((prevFormData) => {
        const updatedObject = { ...prevFormData };
        console.log("updatedObject ==> " + JSON.stringify(updatedObject));
        // Check if the nested structure exists, if not, create it
        if (!updatedObject.data[key]) {
          updatedObject.data[key] = {};
        }
        // Update the nested structure
        updatedObject.data[key][field] = e.target.value;
        return updatedObject;
      });
    } else {
      setFormData((prevFormData) => ({
        ...prevFormData,
        [e.target.name]: e.target.value,
      }));
    }
    console.log(formData);
  };

  // end modal

  const handleValidation = async (e) => {
    let chk = false;
    if (e) {
      e.preventDefault();
      chk = true;
    }

    let fields = formData;
    console.log("fields ==> " + JSON.stringify(fields));
    let errors = {};
    let formIsValid = true;

    if (!fields["category"]) {
      formIsValid = false;
      errors["category"] = "Please select Category";
    }

    if (!fields["page_type"]) {
      formIsValid = false;
      errors["page_type"] = "Please select Type.";
    }

    setErrors(errors);

    // if (formIsValid && chk) {
    //     //alert("Form submitted");
    //     console.log('data =>', fields); //return;
    //     let post_data = {
    //         method: 'POST',
    //         //credentials: 'same-origin',
    //         //mode: 'same-origin',
    //         body: JSON.stringify(fields),
    //         headers: {
    //             'Accept': 'application/json',
    //             'Content-Type': 'application/json',
    //             //'X-CSRFToken':  cookie.load('csrftoken')
    //         }
    //     }

    //     // Simple GET request using fetch
    //     // console.log(process.env.REACT_APP_API_URL)

    //     try {
    //         fetch(process.env.REACT_APP_API_URL + 'webpages', post_data)
    //             .then(response => response.json())
    //             .then(data => {
    //                 // console.log(data)
    //                 get_page_types()
    //                 setFormData({ 'data': { 'en': { 'flights': [{ heading: '', slogan: '', queryType: '' }], faqs: [] }, 'es': { 'flights': [{ heading: '', slogan: '', queryType: '' }], faqs: [] } }, 'category': null })
    //                 document.getElementById('webForm').reset()
    //                 show_success('Web pages added successfully!!')
    //                 //props.parentFunction()
    //             })
    //     } catch (e) {
    //         console.log('err', e)
    //     }

    // }

    if (formIsValid && chk) {
      try {
        // Call the update API
        const updateResponse = await AxiosJWT.put(
          `${process.env.REACT_APP_API_URL}page_types/add-data/${fields.page_type_id}`,
          {
            body: JSON.stringify({ data: fields.data }),
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
            },
          }
        );

        if (updateResponse.ok) {
          // Update successful, now call the create API
          const createResponse = await AxiosJWT.post(
            `${process.env.REACT_APP_API_URL}webpages`,
            {
              body: JSON.stringify(fields),
              headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
              },
            }
          );

          if (createResponse.ok) {
            // Both update and create were successful
            const createData = await createResponse.json();
            get_page_types();
            addFlights();
            document.getElementById("webForm").reset();
            show_success("Web pages added successfully!!");
          } else {
            // Handle create API error
            console.error("Create API failed");
          }
        } else {
          // Handle update API error
          console.error("Update API failed");
        }
      } catch (error) {
        console.error("Error:", error);
      }
    }
  };

  const addFlight = (lang) => {
    // Use a mutable object to track whether addFlight has been called
    let addFlightCalled = { current: false };

    setFormData((prevFormData) => {
      if (!addFlightCalled.current) {
        addFlightCalled.current = true;

        const updatedObject = { ...prevFormData };
        const flightsArray = updatedObject.data[lang].flights;

        // Check if there is room to add a new flight
        if (flightsArray.length < 4) {
          // Create a new flight object and push it to the flights array
          const newFlight = { heading: "", slogan: "", selectedOption: "" };
          updatedObject.data[lang].flights = [...flightsArray, newFlight];
        }

        return { ...updatedObject };
      }

      return prevFormData; // No change if addFlight has already been called
    });
  };

  function generateSlug(Text) {
    // Extract and temporarily replace placeholders with unique markers
    const placeholderRegex = /%[^%]+%/g;
    const placeholders = [];
    let transformedText = Text.replace(placeholderRegex, (match) => {
      const marker = `__PLACEHOLDER_${placeholders.length}__`;
      placeholders.push(match);
      return marker;
    });

    // Transform the text to lowercase and replace spaces and non-word characters
    transformedText = transformedText
      .toLowerCase()
      .replace(/ /g, "-")
      .replace(/[^\w-]+/g, "");

    console.log("placeholders ==> ", placeholders);
    // Restore the original placeholders with the original format
    transformedText = transformedText.replace(
      /__placeholder_(\d+)__/g,
      (match, index) => {
        return placeholders[index];
      }
    );

    return transformedText;
  }

  const removeFlight = (lang) => {
    let removeFlightCalled = { current: false };

    setFormData((prevFormData) => {
      if (!removeFlightCalled.current) {
        removeFlightCalled.current = true;
        const updatedObject = { ...prevFormData };
        const flightsArray = updatedObject.data[lang].flights;

        // Check if there are flights to remove
        if (flightsArray.length > 0) {
          // Remove the last flight
          flightsArray.pop();
          updatedObject.data[lang].flights = [...flightsArray];
        }

        return { ...updatedObject };
      }
      return prevFormData;
    });
  };

  const addFaq = (langCode) => {
    let isAddClicked = { current: false };
    setFormData((prevFormData) => {
      if (!isAddClicked.current) {
        isAddClicked.current = true;

        const updatedObject = { ...prevFormData };

        updatedObject.data[langCode].faqs.push({
          question: "",
          answer: "",
        });

        return { ...updatedObject };
      }
      return prevFormData;
    });
  };

  const removeFaq = (langCode) => {
    let isRemoveClicked = { current: false };

    setFormData((prevFormData) => {
      if (!isRemoveClicked.current) {
        isRemoveClicked.current = true;

        const updatedObject = { ...prevFormData };

        if (updatedObject.data[langCode]) {
          const faqsArray = [...updatedObject.data[langCode].faqs];

          faqsArray.pop();

          updatedObject.data[langCode].faqs = faqsArray;
        }

        return { ...updatedObject };
      }

      return prevFormData;
    });
  };

  const onContentStateChange = (contentState) => {
    setcontentState(contentState);
  };

  const getsubcat = (val) => {
    console.log(val);

    let arrayy = {
      airport: "airports",
      airline: "airlines",
      country: "countries",
      city: "cities",
    };
    if (arrayy[val]) {
      try {
        fetch(process.env.REACT_APP_API_URL + arrayy[val])
          .then((response) => response.json())
          .then((data) => {
            console.log(data);
            setSubCats(data);
            //show_error()
            //toast.error('Page type deleted successfully!!');
          });
      } catch (e) {
        console.log("err", e);
      }
    }
  };

  return (
    <>
      <section className="visitor-pages">
        <div className="container-fluid p-0">
          <div className="row p-0 m-0">
            <div className="col-md-2 bg-light">
              <Sidemenu />
            </div>

            <div className="col-md-10">
              <header>
                <DashboardHeader />
              </header>

              <div className="row m-0 mt-5 p-3  bg-light">
                {/* <div className='col-md-5 d-flex'> 
                                        <div className='mr-3 d-flex clender_str'>
                                            <img src={ Calendarimgs } alt='' />
                                            <DatePicker className='form-control date_picker' selected={startDate} onChange={(date) => setStartDate(date)} placeholderText='From' />

                                        </div>
                                        <div className='d-flex clender_str '> 
                                            <img src={ Calendarimgs } alt='' />
                                            <DatePicker className='form-control date_picker' selected={endDate} onChange={(date) => setEndDate(date)} placeholderText='To'  />
                                           
                                        </div>
                                       </div> 
                                    <div className='col-md-1'> 
                                        <input type="submit" className='shortby ' value="Short by" />
                                    </div>*/}
              </div>

              <Form onSubmit={handleValidation} id="webForm">
                <div className="modal-content main">
                  <div className="modal-header">
                    <p className="form-heading mb-0 ">Add Web Pages</p>
                  </div>

                  <div className="modal-body sidebar_popup">
                    <div className="row mb-5">
                      <div className="col-lg-6">
                        <Form.Group controlId="formGridState">
                          <Form.Label>Category</Form.Label>
                          <Form.Select
                            defaultValue="Choose..."
                            className="form-control"
                            onChange={(e) => {
                              console.log("e.target.value", e.target.value);
                              get_page_types(e.target.value);
                              handleInputChange(e);
                            }}
                            name="category"
                          >
                            <option value="">Choose...</option>
                            <option value="cities">Cities</option>
                            <option value="countries">Countries</option>
                            <option value="airlines">Airlines</option>
                            <option value="airports">Airports</option>
                          </Form.Select>
                          <span style={{ color: "red" }}>
                            {errors["category"]}
                          </span>
                        </Form.Group>
                      </div>
                      <div className="col-lg-6">
                        <Form.Group controlId="formGridState">
                          <Form.Label>Type</Form.Label>
                          <Form.Select
                            defaultValue="Choose..."
                            className="form-control"
                            onChange={(e) => {
                              console.log("e.target.value", e.target);
                              const select = e.target;
                              const value = select.value;
                              const txt = select.selectedOptions[0].text;
                              //handleInputChange(e);
                              const updatedObject = { ...formData };
                              updatedObject["page_type_id"] = e.target.value;
                              updatedObject[e.target.name] = txt;
                              setFormData(updatedObject);
                              console.log(formData);
                            }}
                            name="page_type"
                          >
                            <option value="">Choose...</option>
                            {types.length > 0
                              ? types.map((ke) => (
                                  <option value={ke.id}>{ke.title}</option>
                                ))
                              : ""}
                          </Form.Select>
                          <span style={{ color: "red" }}>
                            {errors["page_type"]}
                          </span>
                        </Form.Group>
                      </div>
                    </div>

                    <div className="row">
                      <div className="col-md-3"></div>
                      <div className="col-md-3"></div>
                      <div className="col-md-3"></div>
                      <div className="col-md-3 d-flex align-items-right ">
                        <div className="create_button">
                          <div className="right_side_dash">
                            <button
                              type="button"
                              class="create_btn"
                              data-toggle="modal"
                              data-target="#myModal3"
                            >
                              Create Image Code
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div>{/* <CkEditorExampleComponent />        */}</div>
                    <Tabs
                      defaultActiveKey="en"
                      id="uncontrolled-tab-example"
                      className="mb-3"
                    >
                      {languages.length > 0
                        ? languages.map((lang) => (
                            <Tab eventKey={lang.code} title={lang.name}>
                              <div className="row">
                                {/* <div className='col-md-12'>
                                <p className='form-heading'>{props.heading}</p>
                            </div>

                            <div className='col-md-12'>

                            </div> */}

                                <div className="col-md-12 form_field_popup">
                                  <Form.Group
                                    className="mb-3 f-left w-100"
                                    controlId="exampleForm.ControlInput1"
                                  >
                                    <Form.Label>Slug (optional)</Form.Label>
                                    <Form.Control
                                      type="text"
                                      onChange={(e) => {
                                        console.log(
                                          "e.target.value",
                                          e.target.value
                                        );
                                        handleInputChange(e, lang.code, "slug");
                                      }}
                                      name={lang.code + "_slug"}
                                      placeholder="Add URL"
                                    />
                                  </Form.Group>

                                  <Form.Group
                                    className="mb-3 f-left w-100"
                                    controlId="exampleForm.ControlInput1"
                                  >
                                    <Form.Label>
                                      Cover Photo Shortcode (optional)
                                    </Form.Label>
                                    <Form.Control
                                      type="text"
                                      onChange={(e) => {
                                        console.log(
                                          "e.target.value",
                                          e.target.value
                                        );
                                        handleInputChange(
                                          e,
                                          lang.code,
                                          "cover_img"
                                        );
                                      }}
                                      name={"cover_img"}
                                      placeholder="Add ShortCode"
                                    />
                                  </Form.Group>

                                  <Form.Group
                                    className="mb-3 f-left w-100"
                                    controlId="exampleForm.ControlInput1"
                                  >
                                    <Form.Label>
                                      Cover Sub Heading (optional)
                                    </Form.Label>
                                    <Form.Control
                                      type="text"
                                      onChange={(e) => {
                                        console.log(
                                          "e.target.value",
                                          e.target.value
                                        );
                                        handleInputChange(
                                          e,
                                          lang.code,
                                          "subheading"
                                        );
                                      }}
                                      name={lang.code + "_subheading"}
                                      placeholder="Add Sub Heading"
                                    />
                                  </Form.Group>

                                  {/* <Form.Group className="mb-3 f-right" controlId="exampleForm.ControlInput1">
                                    <Form.Label>Permalink: https://vmaans.com/</Form.Label>
                                    <Form.Control type="url" placeholder="https://vmaans.com/"  />
                                </Form.Group> */}
                                </div>

                                <div className="col-md-12 form_field_popup">
                                  <Form.Group
                                    className="mb-3 f-right w-100"
                                    controlId="exampleForm.ControlInput1"
                                  >
                                    <Form.Label>Main Content</Form.Label>
                                    {/* <Form.Control as="textarea" rows={3} /> */}
                                    <SunEditor
                                      onChange={(data) => {
                                        setFormData((prevFormData) => {
                                          const updatedObject = {
                                            ...prevFormData,
                                          };
                                          if (
                                            updatedObject["data"][lang.code] ===
                                            undefined
                                          ) {
                                            console.log("if block");
                                            updatedObject["data"][lang.code] = {
                                              content: data,
                                            };
                                          } else {
                                            // Preserve existing data and update the content
                                            updatedObject["data"][lang.code] = {
                                              ...updatedObject["data"][
                                                lang.code
                                              ],
                                              content: data,
                                            };
                                          }
                                          return updatedObject;
                                        });
                                        console.log(formData);
                                      }}
                                      setOptions={{
                                        height: 200,
                                        buttonList: [
                                          ["undo", "redo"],
                                          ["font", "fontSize", "formatBlock"],
                                          ["paragraphStyle", "blockquote"],
                                          [
                                            "bold",
                                            "underline",
                                            "italic",
                                            "strike",
                                            "subscript",
                                            "superscript",
                                          ],
                                          [
                                            "fontColor",
                                            "hiliteColor",
                                            "textStyle",
                                          ],
                                          ["removeFormat"],
                                          "/", // Line break
                                          ["outdent", "indent"],
                                          [
                                            "align",
                                            "horizontalRule",
                                            "list",
                                            "lineHeight",
                                          ],
                                          [
                                            "table",
                                            "link",
                                            "image",
                                            "video",
                                            "audio" /** ,'math' */,
                                          ], // You must add the 'katex' library at options to use the 'math' plugin.
                                          /** ['imageGallery'] */ // You must add the "imageGalleryUrl".
                                          [
                                            "fullScreen",
                                            "showBlocks",
                                            "codeView",
                                          ],
                                          ["preview", "print"],
                                          ["save", "template"],
                                          /** ['dir', 'dir_ltr', 'dir_rtl'] */ // "dir": Toggle text direction, "dir_ltr": Right to Left, "dir_rtl": Left to Right
                                        ], // Or Array of button list, eg. [['font', 'align'], ['image']]
                                        // plugins: [font] set plugins, all plugins are set by default
                                        // Other option
                                      }}
                                    />
                                    {/*                                     <Editor
  //editorState={contentState}
  toolbarClassName="toolbarClassName"
  wrapperClassName="wrapperClassName"
  editorClassName="editorClassName"
  onEditorStateChange={()=>onContentStateChange()}
/>
 */}
                                    {/* <CKEditor
                    editor={ Editor }
                    config={ editorConfiguration }
                    data=""
                    onReady={ editor => {
                        // You can store the "editor" and use when it is needed.
                        console.log( 'Editor is ready to use!', editor );
                    } }
                    onChange={ ( event, editor ) => {
                        const data = editor.getData();
                        console.log( { event, editor, data } );
                        //setFormData({ ...formData, [lang.code+'_content']: data }); 

                        const updatedObject = { ...formData };
                        if(updatedObject['data'][lang.code]==undefined){
                            updatedObject['data'][lang.code]={}
                        }
                        updatedObject['data'][lang.code]['content'] = data
                        setFormData(updatedObject); 

                    } }
                    onBlur={ ( event, editor ) => {
                        console.log( 'Blur.', editor );
                    } }
                    onFocus={ ( event, editor ) => {
                        console.log( 'Focus.', editor );
                    } }
                /> */}
                                  </Form.Group>
                                </div>

                                <div className="col-md-12 form_field_popup">
                                  <Form.Group
                                    className="mb-3 f-left w-100"
                                    controlId="exampleForm.ControlInput1"
                                  >
                                    <Form.Label>Meta Tittle*</Form.Label>
                                    <Form.Control
                                      type="text"
                                      onChange={(e) => {
                                        console.log(
                                          "e.target.value",
                                          e.target.value
                                        );
                                        handleInputChange(
                                          e,
                                          lang.code,
                                          "meta_title"
                                        );
                                      }}
                                      name={lang.code + "_meta_title"}
                                      placeholder="Meta Tittle"
                                    />
                                  </Form.Group>

                                  {/* <Form.Group className="mb-3 f-right" controlId="exampleForm.ControlInput1">
                                    <Form.Label>Permalink: https://vmaans.com/</Form.Label>
                                    <Form.Control type="url" placeholder="https://vmaans.com/"  />
                                </Form.Group> */}
                                </div>

                                <div className="col-md-12 form_field_popup">
                                  <Form.Group
                                    className="mb-3 f-right w-100"
                                    controlId="exampleForm.ControlInput1"
                                  >
                                    <Form.Label>Meta Description*</Form.Label>
                                    <Form.Control
                                      type="text"
                                      onChange={(e) => {
                                        console.log(
                                          "e.target.value",
                                          e.target.value
                                        );
                                        handleInputChange(
                                          e,
                                          lang.code,
                                          "meta_description"
                                        );
                                      }}
                                      name={lang.code + "_meta_description"}
                                      placeholder="Meta  Description"
                                    />
                                  </Form.Group>
                                </div>

                                {/* {formData.data.flights.map((flight) => (
                                                        <div>
                                                            <Form.Group className="mb-3 f-right w-100" controlId="exampleForm.ControlInput1">
                                                                <Form.Label>Flight heading*</Form.Label>
                                                                <Form.Control type="text"
                                                                    onChange={e => {
                                                                        handleInputChange(e, lang.code, 'meta_description');
                                                                    }}
                                                                    name={lang.code + '_meta_description'} placeholder="Flight heading"  />
                                                            </Form.Group>
                                                        </div>
                                                    ))} */}

                                {formData.data[lang.code] &&
                                  formData.data[lang.code].flights.map(
                                    (flight, index) => (
                                      <div className="main-flight-box" key={index}>
                                        <Form.Group
                                          className="mb-3 f-right w-100"
                                          controlId={`flightHeading_${index}`}
                                        >
                                          <Form.Label>
                                            Flight heading*
                                          </Form.Label>
                                          <Form.Select
                                            defaultValue="Choose..."
                                            className="form-control"
                                            onChange={(e) => {
                                              const { value } = e.target;
                                              setFormData((prevFormData) => {
                                                const updatedFormData = {
                                                  ...prevFormData,
                                                };

                                                // Initialize nested structure if not present
                                                if (
                                                  !updatedFormData.data?.[
                                                    lang.code
                                                  ]?.flights
                                                ) {
                                                  updatedFormData.data = {
                                                    ...updatedFormData.data,
                                                    [lang.code]: {
                                                      ...updatedFormData.data?.[
                                                        lang.code
                                                      ],
                                                      flights: [],
                                                    },
                                                  };
                                                }

                                                // Ensure the specific flight index is initialized
                                                if (
                                                  !updatedFormData.data[
                                                    lang.code
                                                  ].flights[index]
                                                ) {
                                                  updatedFormData.data[
                                                    lang.code
                                                  ].flights[index] = {};
                                                }

                                                // Update the heading and slug
                                                updatedFormData.data[
                                                  lang.code
                                                ].flights[index].heading =
                                                  value;
                                                updatedFormData.data[
                                                  lang.code
                                                ].flights[index].slug =
                                                  generateSlug(value);

                                                return updatedFormData;
                                              });
                                              console.log(formData);
                                            }}
                                            name="page_type"
                                          >
                                            <option value="">Choose...</option>
                                            {types.length > 0
                                              ? types.map((ke) => (
                                                  <option
                                                    value={
                                                      ke.languages[lang.code]
                                                    }
                                                    key={ke.id}
                                                  >
                                                    {ke.languages[lang.code]}
                                                  </option>
                                                ))
                                              : ""}
                                          </Form.Select>
                                        </Form.Group>

                                        <Form.Group
                                          className="mb-3 f-right w-100"
                                          controlId={`flightSlogan_${index}`}
                                        >
                                          <Form.Label>
                                            Flight slogan*
                                          </Form.Label>
                                          <Form.Control
                                            type="text"
                                            onChange={(e) => {
                                              setFormData((prevFormData) => {
                                                const updatedObject = {
                                                  ...prevFormData,
                                                };

                                                // Check if the flights array and title property exist
                                                if (
                                                  !updatedObject["data"][
                                                    lang.code
                                                  ].flights[index].slogan
                                                ) {
                                                  // If the title doesn't exist, create a new object for the flight
                                                  updatedObject["data"][
                                                    lang.code
                                                  ].flights[index] = {
                                                    ...updatedObject["data"][
                                                      lang.code
                                                    ].flights[index],
                                                    slogan: e.target.value,
                                                  };
                                                } else {
                                                  // If the title exists, update the existing title
                                                  updatedObject["data"][
                                                    lang.code
                                                  ].flights[index].slogan =
                                                    e.target.value;
                                                }

                                                return updatedObject;
                                              });
                                            }}
                                            name={`flight_${index}_slogan`}
                                            placeholder="Flight slogan"
                                          />
                                        </Form.Group>

                                        <Form.Group
                                          className="mb-3 f-right w-100"
                                          controlId={`flightType_${index}`}
                                        >
                                          <Form.Label>Flight type*</Form.Label>
                                          <Form.Select
                                            defaultValue="Choose..."
                                            className="form-control form-label-box"
                                            onChange={(e) => {
                                              setFormData((prevFormData) => {
                                                const updatedObject = {
                                                  ...prevFormData,
                                                };

                                                // Check if the flights array and title property exist
                                                if (
                                                  !updatedObject["data"][
                                                    lang.code
                                                  ].flights[index].queryType
                                                ) {
                                                  // If the title doesn't exist, create a new object for the flight
                                                  updatedObject["data"][
                                                    lang.code
                                                  ].flights[index] = {
                                                    ...updatedObject["data"][
                                                      lang.code
                                                    ].flights[index],
                                                    queryType: e.target.value,
                                                  };
                                                } else {
                                                  // If the title exists, update the existing title
                                                  updatedObject["data"][
                                                    lang.code
                                                  ].flights[index].queryType =
                                                    e.target.value;
                                                }

                                                return updatedObject;
                                              });
                                            }}
                                            name={`flight_${index}_queryType`}
                                          >
                                            <option value="">Choose...</option>
                                            <option value="latest">
                                              Latest Flights
                                            </option>
                                            <option value="cheapest">
                                              Cheapest Flights
                                            </option>
                                            <option value="non-stop">
                                              Non stop Flights
                                            </option>
                                            <option value="latest">
                                              Popular Flights
                                            </option>
                                          </Form.Select>
                                        </Form.Group>

                                        <Form.Group
                                          className="mb-3 f-right w-100"
                                          controlId={`flightComponentType_${index}`}
                                        >
                                          <Form.Label>
                                            Flight Component type*
                                          </Form.Label>
                                          <Form.Select
                                            defaultValue="Choose..."
                                            className="form-control"
                                            onChange={(e) => {
                                              setFormData((prevFormData) => {
                                                const updatedObject = {
                                                  ...prevFormData,
                                                };

                                                // If the title exists, update the existing title
                                                updatedObject["data"][
                                                  lang.code
                                                ].flights[index].componentType =
                                                  e.target.value;

                                                return updatedObject;
                                              });
                                            }}
                                            name={`flight_${index}_componentType`}
                                          >
                                            <option value="">Choose...</option>
                                            <option value="flight">
                                              Flight Component
                                            </option>
                                            <option value="airline">
                                              Airline Component
                                            </option>
                                            <option value="city">
                                              City Component
                                            </option>
                                            <option value="popular">
                                              Popular Component
                                            </option>
                                          </Form.Select>
                                        </Form.Group>
                                      </div>
                                    )
                                  )}

                                {formData.data[lang.code] &&
                                  formData.data[lang.code].flights.length <
                                    4 && (
                                    <img
                                      src={Plus}
                                      className="butns___4"
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        addFlight(lang.code);
                                      }}
                                    />
                                  )}

                                {formData.data[lang.code] &&
                                  formData.data[lang.code].flights.length >
                                    1 && (
                                    <img
                                      src={Minus}
                                      className="butns___4"
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        removeFlight(lang.code);
                                      }}
                                    />
                                  )}
                              </div>

                              <div className="faq-section-box">
                                <h3>FAQs</h3>
                                {formData.data[lang.code] &&
                                  formData.data[lang.code].faqs.map(
                                    (faq, index) => (
                                      <div className="ques-ans-label" key={index}>
                                        {/* FAQ Question */}
                                        <Form.Group
                                          className="mb-3 f-right w-100"
                                          controlId={`faqQuestion`}
                                        >
                                          <Form.Label>Question*</Form.Label>
                                          <Form.Control
                                            type="text"
                                            onChange={(e) => {
                                              setFormData((prevFormData) => {
                                                const updatedObject = {
                                                  ...prevFormData,
                                                };
                                                updatedObject["data"][
                                                  lang.code
                                                ].faqs[index].question =
                                                  e.target.value;
                                                return updatedObject;
                                              });
                                            }}
                                            name={`faq_0_question`}
                                            placeholder="Question"
                                            value={
                                              formData.data[lang.code]?.faqs[
                                                index
                                              ]?.question || ""
                                            }
                                          />
                                        </Form.Group>

                                        {/* FAQ Answer */}
                                        <Form.Group
                                          className="mb-3 f-right w-100"
                                          controlId={`faqAnswer`}
                                        >
                                          <Form.Label>Answer*</Form.Label>
                                          <Form.Control
                                            type="text"
                                            onChange={(e) => {
                                              setFormData((prevFormData) => {
                                                const updatedObject = {
                                                  ...prevFormData,
                                                };
                                                updatedObject["data"][
                                                  lang.code
                                                ].faqs[index].answer =
                                                  e.target.value;
                                                return updatedObject;
                                              });
                                            }}
                                            name={`faq_0_answer`}
                                            placeholder="Answer"
                                            value={
                                              formData.data[lang.code]?.faqs[
                                                index
                                              ]?.answer || ""
                                            }
                                          />
                                        </Form.Group>
                                      </div>
                                    )
                                  )}

                                {/* Add FAQ Button */}
                                {(!formData.data[lang.code]?.faqs ||
                                  formData.data[lang.code]?.faqs.length <
                                    4) && (
                                  <img
                                    src={Plus}
                                    className="butns___4"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      addFaq(lang.code);
                                    }}
                                  />
                                )}

                                {/* Remove FAQ Button */}
                                {formData.data[lang.code]?.faqs &&
                                  formData.data[lang.code].faqs.length > 0 && (
                                    <img
                                      src={Minus}
                                      className="butns___4"
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        removeFaq(lang.code);
                                      }}
                                    />
                                  )}
                              </div>

                              <div className="col-md-12 text-center">
                                {/*   <div
				className="ckeditor-wrapper"
				
			>



                                     <CKEditor
                    editor={ ClassicEditor }
                    config={ editorConfiguration }
                    data="<p>Hello from CKEditor 5!</p>"
                    onReady={ editor => {
                        // You can store the "editor" and use when it is needed.
                        console.log( 'Editor is ready to use!', editor );
                    } }
                    onChange={ ( event, editor ) => {
                        const data = editor.getData();
                        console.log( { event, editor, data } );
                    } }
                    onBlur={ ( event, editor ) => {
                        console.log( 'Blur.', editor );
                    } }
                    onFocus={ ( event, editor ) => {
                        console.log( 'Focus.', editor );
                    } }
                /> 
                </div>*/}
                              </div>
                            </Tab>
                          ))
                        : ""}
                    </Tabs>
                  </div>

                  <div className="col-md-12 form_field_popup">
                    <button
                      variant="primary"
                      className="create_btn form_submit text-center"
                      type="submit"
                    >
                      {" "}
                      Submit
                    </button>
                  </div>
                </div>
              </Form>
            </div>
          </div>
        </div>
      </section>

      <div
        className="modal right fade"
        id="myModal3"
        tabindex="-1"
        role="dialog"
        aria-labelledby="myModalLabel3"
      >
        <div className="modal-dialog main" role="document">
          <div className="modal-content main">
            <div className="modal-header">
              <button
                type="button"
                className="close"
                data-dismiss="modal"
                aria-label="Close"
              >
                <span aria-hidden="true">&times;</span>
              </button>
            </div>

            <div className="modal-body sidebar_popup">
              <Form
                onSubmit={handleValidation}
                id="webForm"
                className="common-form common-form-border login-signup-form"
                autoComplete="off"
              >
                <div className="row mb-5">
                  <div className="col-lg-12">
                    <Form.Group controlId="formGridState">
                      <Form.Label>Category</Form.Label>
                      <Form.Select
                        defaultValue="Choose..."
                        className="form-control"
                        onChange={(e) => {
                          console.log("e.target.value", e.target.name);
                          //createMediaCode(e.target);
                          getsubcat(e.target.value);
                          setCatName(e.target.value);
                          setSubCat("");
                        }}
                        name="category"
                      >
                        <option value="">Choose...</option>
                        <option value="city">Cities</option>
                        <option value="country">Countries</option>
                        <option value="airline">Airlines</option>
                        <option value="airport">Airports</option>
                      </Form.Select>
                    </Form.Group>
                  </div>

                  <div className="col-lg-12">
                    <Form.Group controlId="formGridState">
                      <Form.Label>Select Subcategory</Form.Label>
                      <Form.Select
                        defaultValue="Choose..."
                        className="form-control"
                        onChange={(e) => {
                          console.log("e.target.value", e.target.name);
                          setSubCat(e.target.value);
                        }}
                        name="subcategory"
                      >
                        <option value="">Choose...</option>

                        {subcats.length > 0
                          ? subcats.map((ke) => (
                              <option
                                value={
                                  catName == "airline"
                                    ? ke.airline_name
                                    : ke.english
                                }
                              >
                                {catName == "airline"
                                  ? ke.airline_name
                                  : ke.english}
                              </option>
                            ))
                          : ""}
                      </Form.Select>
                    </Form.Group>
                  </div>

                  <div className="col-lg-12">
                    <Form.Group controlId="formGridState">
                      <Form.Label>Type</Form.Label>
                      <Form.Select
                        defaultValue="Choose..."
                        className="form-control"
                        onChange={(e) => {
                          console.log("e.target.value", e.target.name);
                          setSize(e.target.value);
                        }}
                        name="type"
                      >
                        <option value="">Choose...</option>
                        <option value="square">Square</option>
                        <option value="cover">Cover</option>
                        <option value="rectangle">Rectangle</option>
                      </Form.Select>
                    </Form.Group>

                    <Form.Group
                      className="mb-3 f-left w-100"
                      controlId="exampleForm.ControlInput1"
                    >
                      <Form.Label>Image Code</Form.Label>
                      <Form.Control
                        type="text"
                        value={
                          (catName !== "" &&
                            size !== "" &&
                            subCat == "" &&
                            "{{#^#%" + catName + "%#^#" + size + "#^#}}") ||
                          (catName !== "" &&
                            size !== "" &&
                            subCat !== "" &&
                            "{{#^#" + subCat + "#^#" + size + "#^#}}")
                        }
                        readonly
                      />

                      <i class="fas fa-copy"></i>
                    </Form.Group>
                  </div>
                </div>
              </Form>
            </div>
          </div>
        </div>
      </div>
      {/* category={category} parentFunction={parentFunction} */}
    </>
  );
}
