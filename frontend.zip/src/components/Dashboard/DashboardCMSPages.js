import React, { useEffect, useState } from "react";
import { Link, useHistory } from "react-router-dom/cjs/react-router-dom";

import Sidemenu from "./Common/Sidebar_menu";
import DashboardHeader from "./Common/DashboardHeader";

import edit_btn from "./Common/img/edit_button.svg";
import eye_icon from "./Common/img/eye_icon.svg";
import { useDispatch, useSelector } from "react-redux";
import { checkAdminLogin } from "../../redux/Action";
import AxiosJWT from './Common/AxiosJWT'

const DashboardCMSPages = () => {
  const isAdmin = useSelector((state) => state.reducer.isAdmin);
  const dispatch = useDispatch();
  const history = useHistory();

  

  const [pages, setPages] = useState({});
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);

  const maxPageNumbersToShow = 10;

  let table_header = [
    {
      id: "1",
      label: "Category",
    },
    {
      id: "2",
      label: "Title",
    },
    {
      id: "3",
      label: "Slug",
    },
    {
      id: "4",
      label: "Actions",
    },
  ];

  const handlePageChange = (pageNumber) => {
    if (pageNumber >= 1 && pageNumber <= totalPages) {
      setCurrentPage(pageNumber);
    }
  };

  return (
    <>
      <section className="visitor-pages">
        <div className="container-fluid p-0">
          <div className="row p-0 m-0">
            <div className="col-md-2 bg-light">
              <Sidemenu />
            </div>

            <div className="col-md-10">
              <header>
                <DashboardHeader />
              </header>

              <table className="table ">
                <thead className="thead-light">
                  <tr>
                    {table_header.map((tables_headr) => (
                      <th scope="col" key={tables_headr.id}>
                        {tables_headr.label}
                      </th>
                    ))}
                  </tr>
                </thead>

                <tbody>
                  {pages.length > 0 ? (
                    pages.map((tables) => (
                      <tr key={tables.id}>
                        <td>{tables.category}</td>
                        <td>{tables.title}</td>
                        <td>{tables.slug}</td>
                        <td>
                          {/* <Link className=" d-flex " onClick={() => delPage(tables.id)} to={window.location.pathname}>
                                                            <div className='img_span'>
                                                                <img src={del_btn} alt="" />
                                                            </div>
                                                        </Link> */}
                        </td>
                        <td>
                          <Link
                            className=" d-flex "
                            to={`/admin/update-page/${tables.slug}`}
                          >
                            <div className="img_span">
                              <img src={edit_btn} alt="" />
                            </div>
                          </Link>
                        </td>
                        <td>
                          <Link
                            className=" d-flex "
                            to={`/${tables.slug}`}
                            target="_blank"
                          >
                            <div className="img_span">
                              <img
                                src={eye_icon}
                                alt=""
                                style={{ width: "32px" }}
                              />
                            </div>
                          </Link>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <>No Records Found!!</>
                  )}
                </tbody>
              </table>

              <div>
                <button
                  onClick={() => handlePageChange(currentPage - 1)}
                  disabled={currentPage === 1}
                >
                  Previous
                </button>
                {/* {renderPageNumbers()} */}
                <button
                  onClick={() => handlePageChange(currentPage + 1)}
                  disabled={currentPage === totalPages}
                >
                  Next
                </button>
                <Link to="/admin/add-cms-page">go to page</Link>
              </div>
              <p>
                Page {currentPage} of {totalPages}
              </p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default DashboardCMSPages;
