import React, { useEffect, useState } from "react";
import Sidebar from "./Common/Sidebar_menu";
import DashboardHeader from "./Common/DashboardHeader";
import { Form, Tab, Tabs } from "react-bootstrap";
import axios from "axios";
import SunEditor from "suneditor-react";
import "suneditor/dist/css/suneditor.min.css";
import AxiosJWT from "./Common/AxiosJWT";
import { toast } from "react-toastify";

const DashboardAddOffer = () => {
  const [airports, setAirports] = useState([]);
  const [filteredAirports, setFilteredAirports] = useState([]);
  const [airlines, setAirlines] = useState([]);
  const [languages, setLangs] = useState([]);
  const [formData, setFormData] = useState({
    from: "",
    to: "",
    price: "",
    airline: "",
    travelDate: "",
    salesValid: "",
    bagAllot: "",
    bagAllotUnit: "kg", // default unit
    policy: {},
    cabin: "",
    image: null,
    createdBy: "User", // Replace with actual user identifier if needed
    cancelFees: "",
    changeFees: "",
    description: {},
  });
  const [errors, setErrors] = useState({});

  const getLanguages = async () => {
    try {
      const response = await fetch(`${process.env.REACT_APP_API_URL}languages`);
      const data = await response.json();
      if (data.length > 0) setLangs(data);
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    getLanguages();

    AxiosJWT.get(
      "https://flight-backend-ro3e.onrender.com/api/airports/country-code/IN"
    )
      .then((response) => {
        setAirports(response.data);
        setFilteredAirports(response.data);
      })
      .catch((error) => {
        console.error("There was an error fetching the airports!", error);
      });

    AxiosJWT.get("https://flight-backend-ro3e.onrender.com/api/airlines")
      .then((response) => {
        setAirlines(response.data);
      })
      .catch((error) => {
        console.error("There was an error fetching the airlines!", error);
      });

    AxiosJWT.get("https://flight-backend-ro3e.onrender.com/api/offers")
      .then((response) => {
        // Handle offers data if needed
      })
      .catch((error) => {
        console.error("There was an error fetching the offers!", error);
      });
  }, []);

  const handleInputChange = (e) => {
    const { name, value, files } = e.target;
    setFormData((prevFormData) => ({
      ...prevFormData,
      [name]: name === "image" ? files[0] : value,
    }));
  };  

  const handleEditorChange = (langCode, name, content) => {
    setFormData((prevFormData) => ({
      ...prevFormData,
      [name]: {
        ...prevFormData[name],
        [langCode]: content,
      },
    }));
  };

  const validateForm = () => {
    const newErrors = {};
    // Add form validation logic here if needed
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validateForm()) {
      const formDataToSend = new FormData();
      formDataToSend.append("from", formData.from);
      formDataToSend.append("to", formData.to);
      formDataToSend.append("price", formData.price);
      formDataToSend.append("airline", formData.airline);
      formDataToSend.append("travelDate", formData.travelDate);
      formDataToSend.append("salesValid", formData.salesValid);
      formDataToSend.append("bagAllot", `${formData.bagAllot} ${formData.bagAllotUnit}`);
      formDataToSend.append("cabin", formData.cabin);
      formDataToSend.append("image", formData.image);
      formDataToSend.append("cancelFees", formData.cancelFees);
      formDataToSend.append("changeFees", formData.changeFees);
      
      languages.forEach((lang) => {
        formDataToSend.append(`desc[${lang.code}]`, formData.description[lang.code] || "");
        formDataToSend.append(`policy[${lang.code}]`, formData.policy[lang.code] || "");
      });
  
      AxiosJWT.post("https://flight-backend-ro3e.onrender.com/api/offers", formDataToSend, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      })
        .then((response) => {
          toast.success("Offer created successfully");
        })
        .catch((error) => {
          toast.error(error.response.data.message);
        });
    }
  };

  return (
    <div>
      <section className="visitor-pages">
        <div className="container-fluid p-0">
          <div className="row p-0 m-0">
            <div className="col-md-2 bg-light">
              <Sidebar />
            </div>
            <div className="col-md-10">
              <header>
                <DashboardHeader />
              </header>
              <Form id="webForm" onSubmit={handleSubmit}>
                <div className="modal-content main">
                  <div className="modal-header">
                    <p className="form-heading mb-0">Add Offer</p>
                  </div>
                  <div className="row mb-5">
                    <div className="col-lg-6">
                      <Form.Group controlId="formGridState">
                        <Form.Label>From Airport</Form.Label>
                        <Form.Select
                          className="form-control"
                          name="from"
                          onChange={handleInputChange}
                        >
                          <option value="">Choose...</option>
                          {filteredAirports.map((airport) => (
                            <option
                              key={airport.airport_name}
                              value={airport.airport_name}
                            >
                              {airport.airport_name}
                            </option>
                          ))}
                        </Form.Select>
                        <span style={{ color: "red" }}>{errors["from"]}</span>
                      </Form.Group>
                    </div>
                    <div className="col-lg-6">
                      <Form.Group controlId="formGridState">
                        <Form.Label>To Airport</Form.Label>
                        <Form.Select
                          className="form-control"
                          name="to"
                          onChange={handleInputChange}
                        >
                          <option value="">Choose...</option>
                          {filteredAirports.map((airport) => (
                            <option
                              key={airport.airport_name}
                              value={airport.airport_name}
                            >
                              {airport.airport_name}
                            </option>
                          ))}
                        </Form.Select>
                        <span style={{ color: "red" }}>{errors["to"]}</span>
                      </Form.Group>
                    </div>
                  </div>
                  <div className="row mb-5">
                    <div className="col-lg-6">
                      <Form.Group controlId="formGridState">
                        <Form.Label>Airline</Form.Label>
                        <Form.Select
                          className="form-control"
                          name="airline"
                          onChange={handleInputChange}
                        >
                          <option value="">Choose...</option>
                          {airlines.map((airline) => (
                            <option
                              key={airline.airline_name}
                              value={airline.airline_name}
                            >
                              {airline.airline_name}
                            </option>
                          ))}
                        </Form.Select>
                        {/* <Form.Control
                          type="text"
                          name="airline"
                          onChange={handleInputChange}
                        /> */}
                        <span style={{ color: "red" }}>
                          {errors["airline"]}
                        </span>
                      </Form.Group>
                    </div>
                    <div className="col-lg-6">
                      <Form.Group controlId="formPrice">
                        <Form.Label>Price</Form.Label>
                        <Form.Control
                          type="number"
                          name="price"
                          min="0"
                          onChange={handleInputChange}
                        />
                        <span style={{ color: "red" }}>{errors["price"]}</span>
                      </Form.Group>
                    </div>
                  </div>
                  <div className="row mb-5">
                    <div className="col-lg-6">
                      <Form.Group controlId="formTravelDate">
                        <Form.Label>Travel Date</Form.Label>
                        <Form.Control
                          type="date"
                          name="travelDate"
                          onChange={handleInputChange}
                        />
                        <span style={{ color: "red" }}>
                          {errors["travelDate"]}
                        </span>
                      </Form.Group>
                    </div>
                    <div className="col-lg-6">
                      <Form.Group controlId="formSalesValid">
                        <Form.Label>Sales Valid</Form.Label>
                        <Form.Control
                          type="date"
                          name="salesValid"
                          onChange={handleInputChange}
                        />
                        <span style={{ color: "red" }}>
                          {errors["salesValid"]}
                        </span>
                      </Form.Group>
                    </div>
                  </div>
                  <div className="row mb-5">
                    <div className="col-lg-6">
                      <Form.Group controlId="formBagAllot">
                        <Form.Label>Bag Allotment</Form.Label>
                        <div className="input-group">
                          <Form.Control
                            type="number"
                            name="bagAllot"
                            min="0"
                            onChange={handleInputChange}
                            className="form-control"
                          />
                          <Form.Select
                            name="bagAllotUnit"
                            onChange={handleInputChange}
                            className="form-control"
                          >
                            <option value="kg">kg</option>
                            <option value="piece">piece</option>
                          </Form.Select>
                        </div>
                        <span style={{ color: "red" }}>
                          {errors["bagAllot"]}
                        </span>
                      </Form.Group>
                    </div>
                    <div className="col-lg-6">
                      <Form.Group controlId="formCancelFees">
                        <Form.Label>Cancel Fees</Form.Label>
                        <Form.Control
                          type="number"
                          name="cancelFees"
                          min="0"
                          onChange={handleInputChange}
                        />
                        <span style={{ color: "red" }}>
                          {errors["cancelFees"]}
                        </span>
                      </Form.Group>
                    </div>
                  </div>
                  <div className="row mb-5">
                    <div className="col-lg-6">
                      <Form.Group controlId="formChangeFees">
                        <Form.Label>Change Fees</Form.Label>
                        <Form.Control
                          type="number"
                          name="changeFees"
                          min="0"
                          onChange={handleInputChange}
                        />
                        <span style={{ color: "red" }}>
                          {errors["changeFees"]}
                        </span>
                      </Form.Group>
                    </div>
                    <div className="col-lg-6">
                      <Form.Group controlId="formCabin">
                        <Form.Label>Cabin</Form.Label>
                        <Form.Select
                          className="form-control"
                          name="cabin"
                          onChange={handleInputChange}
                        >
                          <option value="">Choose...</option>
                          <option key={"1"} value={"Economy"}>
                            Economy
                          </option>
                          <option key={"2"} value={"Business"}>
                            Business
                          </option>
                          <option key={"3"} value={"Premium Economy"}>
                            Premium Economy
                          </option>
                        </Form.Select>
                        <span style={{ color: "red" }}>{errors["cabin"]}</span>
                      </Form.Group>
                    </div>
                  </div>
                  <div className="row mb-5">
                    <div className="col-lg-6">
                      <Form.Group controlId="formImage">
                        <Form.Label>Image</Form.Label>
                        <Form.Control
                          type="file"
                          name="image"
                          onChange={handleInputChange}
                        />
                        <span style={{ color: "red" }}>{errors["image"]}</span>
                      </Form.Group>
                    </div>
                  </div>
                  <Tabs
                    defaultActiveKey="en"
                    id="uncontrolled-tab-example"
                    className="mb-3"
                  >
                    {languages.map((lang) => (
                      <Tab
                        key={lang.code}
                        eventKey={lang.code}
                        title={lang.name}
                      >
                        <div className="row">
                          <div className="col-md-12 form_field_popup">
                            <Form.Group controlId={`formDesc-${lang.code}`}>
                              <Form.Label>Description</Form.Label>
                              <Form.Control
                                type="text"
                                name={`desc_${lang.code}`}
                                onChange={(e) =>
                                  handleEditorChange(
                                    lang.code,
                                    "description",
                                    e.target.value
                                  )
                                }
                              />
                              <span style={{ color: "red" }}>
                                {errors[`desc_${lang.code}`]}
                              </span>
                            </Form.Group>
                            <Form.Label>Policy</Form.Label>
                            <SunEditor
                              setOptions={{
                                height: 200,
                                buttonList: [
                                  ["undo", "redo"],
                                  ["font", "fontSize", "formatBlock"],
                                  ["paragraphStyle", "blockquote"],
                                  [
                                    "bold",
                                    "underline",
                                    "italic",
                                    "strike",
                                    "subscript",
                                    "superscript",
                                  ],
                                  ["fontColor", "hiliteColor", "textStyle"],
                                  ["removeFormat"],
                                  "/",
                                  ["outdent", "indent"],
                                  [
                                    "align",
                                    "horizontalRule",
                                    "list",
                                    "lineHeight",
                                  ],
                                  ["table", "link", "image", "video", "audio"],
                                  ["fullScreen", "showBlocks", "codeView"],
                                  ["preview", "print"],
                                  ["save", "template"],
                                ],
                              }}
                              onChange={(content) =>
                                handleEditorChange(lang.code, "policy", content)
                              }
                            />
                          </div>
                        </div>
                      </Tab>
                    ))}
                  </Tabs>
                  <div className="col-md-12 form_field_popup">
                    <button
                      variant="primary"
                      className="create_btn form_submit text-center"
                      type="submit"
                    >
                      Submit
                    </button>
                  </div>
                </div>
              </Form>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default DashboardAddOffer;
