import React, { useEffect } from "react";
import "./Common/css/admin_style.css";
import Sidemenu from "./Common/Sidebar_menu";
import DashboardHeader from "./Common/DashboardHeader";
import { useState } from "react";
import DatePicker from "react-datepicker";
import Calendarimgs from "./Common/img/calender.svg";
import "react-datepicker/dist/react-datepicker.css";
import airoplane from "./Common/img/airplane (8) 1.svg";
import currency from "./Common/img/currency.svg";
import Language from "./Common/img/lang.svg";
import webpage from "./Common/img/044-webpage 1.svg";
import vision from "./Common/img/030-vision 1.svg";
import celendr from "./Common/img/calendar2.svg";
import oferpage from "./Common/img/offer.svg";
import active_btn from "./Common/img/active_icon.svg";
import edit_btn from "./Common/img/edit_button.svg";
import del_btn from "./Common/img/delt_button.svg";
import plane_from from "./Common/img/plane (14) 1.svg";
import plane_to from "./Common/img/plane (15) 1.svg";
import clendr_from from "./Common/img/calendar-1 1.svg";
import clender_to from "./Common/img/calendar-1 2.svg";
import airlinetk from "./Common/img/airlinetk.svg";
import { Link } from "react-router-dom";
import Dashboardpopup from "./Common/dashboardpopup";
import { Form, Tabs } from "react-bootstrap";
import { toast } from "react-toastify";
import { format } from "date-fns";
import SunEditor from "suneditor-react";
import AxiosJWT from "./Common/AxiosJWT";

export default function DashboardOfferpage() {
  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(null);
  const [offerData, setOfferData] = useState(null);

  const getOffers = async () => {
    await AxiosJWT.get("https://flight-backend-ro3e.onrender.com/api/offers")
      .then((response) => {
        setOfferData(response.data);
      })
      .catch((error) => {
        console.error("There was an error fetching the offers!", error);
      });
  };

  const handleDelete = async (offerId) => {
    if (window.confirm("Are you sure you want to delete this offer?")) {
      try {
        await AxiosJWT.delete(
          `https://flight-backend-ro3e.onrender.com/api/offers/${offerId}`
        ); // Make sure the endpoint is correct
        getOffers();
      } catch (error) {
        console.error("There was an error deleting the offer!", error);
      }
    }
  };

  useEffect(() => {
    getOffers();
  }, []);

  if (!offerData) {
    return <div>Loading...</div>;
  }

  return (
    <>
      <section className="admin-pages offer-pages">
        <div className="container-fluid p-0">
          <div className="row p-0 m-0">
            <div className="col-lg-2 col-md-12 bg-light">
              <Sidemenu />
            </div>

            <div className="col-lg-10 col-md-12 my-id2">
              <header>
                <DashboardHeader />
              </header>

              {/* content */}
              <div className="col-md-12 mt-4">
                <div className="row top_dash_box">
                  <div className="col-md-3">
                    <div className="green_section offer new_visi">
                      <div className="left_side_dash">
                        <span className="visi">Total Call Request</span>
                        <span className="texts new_text">30,000</span>
                      </div>
                    </div>
                  </div>
                  <div className="col-md-3">
                    <div className="blue_section new_visi">
                      <div className="left_side_dash">
                        <span className="visi">Closed Request</span>
                        <span className="texts new_text">16,000</span>
                      </div>
                    </div>
                  </div>
                  <div className="col-md-3">
                    <div className="orang_section new_visi">
                      <div className="left_side_dash">
                        <span className="visi">Open Request</span>
                        <span className="texts new_text">16,000</span>
                      </div>
                    </div>
                  </div>
                  <div className="col-md-3 d-flex align-items-center justify-content-center">
                    <div className="create_button">
                      <div className="left_side_dash">
                        {/* popup start */}
                        <Link to={`/admin/add-offer`}>
                          <button
                            className="create_btn"
                            data-toggle="modal"
                            data-target="#myModal2"
                          >
                            Create new offer
                          </button>
                        </Link>
                        {/* end popup */}
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="row m-0 mt-4 p-3  bg-light">
                <div className="col-md-5">
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Search"
                  />
                </div>
                <div className="col-md-4 d-flex gap-div">
                  {/* <div className="mr-3 d-flex clender_str">
                    <img src={Calendarimgs} alt="" />
                    <DatePicker
                      className="form-control date_picker"
                      selected={startDate}
                      onChange={(date) => setStartDate(date)}
                      placeholderText="From"
                    />
                  </div>
                  <div className="d-flex clender_str ">
                    <img src={Calendarimgs} alt="" />
                    <DatePicker
                      className="form-control date_picker"
                      selected={endDate}
                      onChange={(date) => setEndDate(date)}
                      placeholderText="To"
                    />
                  </div> */}
                  <div class="date-input">
      <span class="icon-container">
      <img src={Calendarimgs} alt="" />
      </span>
      <input type="text" placeholder="From"/>
  </div>
  <div class="date-input">
      <span class="icon-container img-2">
      <img src={Calendarimgs} alt="" />
      </span>
      <input type="text" placeholder="To"/>
  </div>
                </div>
                <div className="col-md-1 pl-2">
                  <select
                    className="custom_select form-control"
                    id="inputGroupSelect03"
                  >
                    <option>Type</option>
                    <option value="1">One</option>
                    <option value="2">Two</option>
                  </select>
                </div>
                <div className="col-md-2">
                  <input
                    type="submit"
                    className="form-control"
                    Name="shortby"
                    value="Short by"
                    class="form-control short-by"
                  />
                </div>
              </div>

              {/* first call request */}
              {offerData.map((offer) => (
                <div className="call_req_id">
                  <div className="row ">
                    <div className="col-md-12 light_blue_dp">
                      {/* first row */}
                      <div className="row">
                        <div className="col-md-4 ">
                          <div className="main_cnt_box d-flex w-100">
                            <div className="img_span">
                              <img src={oferpage} alt="" />
                            </div>
                            <div className="box_cont_img_cont">
                              <small>Offer ID</small>
                              <span>{offer._id}</span>
                            </div>
                          </div>
                        </div>

                        <div className="col-md-4 ">
                          <div className="main_cnt_box d-flex w-100">
                            <div className="img_span">
                              <img src={celendr} alt="" />
                            </div>
                            <div className="box_cont_img_cont">
                              <small>Offer created date</small>
                              <span>
                                {format(
                                  new Date(offer.createdAt),
                                  "EEE dd MMM yyyy HH:mm"
                                )}
                              </span>
                            </div>
                          </div>
                        </div>

                        {/* add edit delt start */}

                        <div className="col-md-4 ">
                          <div className="d-flex add_edit_dlt">
                            <Link className=" d-flex" to="#">
                              <div className="img_span">
                                <img src={active_btn} alt="" />
                              </div>
                              <div className="box_cont_img_cont">
                                <small>Status</small>
                                <span>Active</span>
                              </div>
                            </Link>

                            <Link
                              className=" d-flex"
                              to={`/admin/edit-offer/${offer._id}`}
                            >
                              <div className="img_span">
                                <img src={edit_btn} alt="" />
                              </div>
                              <div className="box_cont_img_cont pl-2">
                                <span>Edit</span>
                              </div>
                            </Link>

                            <div
                              className="d-flex"
                              onClick={() => handleDelete(offer._id)}
                            >
                              <div className="img_span">
                                <img src={del_btn} alt="" />
                              </div>
                              <div className="box_cont_img_cont">
                                {/* <small>Call request date</small> */}
                                <span>Delete</span>
                              </div>
                            </div>
                          </div>
                        </div>

                        {/* add edit delt end */}
                      </div>

                      {/* end first row */}

                      <hr className="hr_dashbord" />

                      {/* start second row */}

                      <div className="row">
                        <div className="secd_lins box_border">
                          <div className="main_cnt_box d-flex">
                            <div className="img_span">
                              <img src={webpage} alt="" />
                            </div>
                            <div className="box_cont_img_cont">
                              <small>Domain</small>
                              <span>www.xyz.es</span>
                            </div>
                          </div>

                          <div className="main_cnt_box d-flex">
                            <div className="img_span">
                              <img src={airoplane} alt="" />
                            </div>
                            <div className="box_cont_img_cont">
                              <small>Booking Type</small>
                              <span>{offer.cabin}</span>
                            </div>
                          </div>

                          <div className="main_cnt_box d-flex">
                            <div className="img_span">
                              <img src={Language} alt="" />
                            </div>
                            <div className="box_cont_img_cont">
                              <small>Language</small>
                              <span>English</span>
                            </div>
                          </div>

                          <div className="main_cnt_box d-flex">
                            <div className="img_span">
                              <img src={currency} alt="" />
                            </div>
                            <div className="box_cont_img_cont">
                              <small>Currency</small>
                              <span>Euro</span>
                            </div>
                          </div>

                          <div className="main_cnt_box d-flex">
                            <div className="img_span">
                              <img src={vision} alt="" />
                            </div>
                            <div className="box_cont_img_cont">
                              <small>No of Visiters</small>
                              <span>400</span>
                            </div>
                          </div>
                        </div>
                      </div>
                      {/* end second row */}

                      <hr className="hr_dashbord" />

                      {/* start three row */}

                      <div className="row">
                        <div className="plan_loc_from_to">
                          <div className="secd_lins box_border org_border">
                            <div className="main_cnt_box d-flex">
                              <div className="img_span">
                                <img src={plane_to} alt="" />
                              </div>
                              <div className="box_cont_img_cont">
                                <small>From</small>
                                <span>{offer.from}</span>
                              </div>
                            </div>

                            <div className="main_cnt_box d-flex">
                              <div className="img_span">
                                <img src={plane_from} alt="" />
                              </div>
                              <div className="box_cont_img_cont">
                                <small>To</small>
                                <span>{offer.to}</span>
                              </div>
                            </div>

                            <div className="main_cnt_box d-flex">
                              <div className="img_span">
                                <img src={clendr_from} alt="" />
                              </div>
                              <div className="box_cont_img_cont">
                                <small>Depart</small>
                                <span>
                                  {format(
                                    new Date(offer.travelDate),
                                    "dd MMM yy"
                                  )}
                                </span>
                              </div>
                            </div>

                            {/* <div className="main_cnt_box d-flex">
                              <div className="img_span">
                                <img src={clender_to} alt="" />
                              </div>
                              <div className="box_cont_img_cont">
                                <small>Retun</small>
                                <span>22 Jul ‘22</span>
                              </div>
                            </div> */}

                            <div className="main_cnt_box d-flex">
                              <div className="img_span">
                                <img src={airlinetk} alt="" />
                              </div>
                              <div className="box_cont_img_cont">
                                <small>Airline</small>
                                <span>{offer.airline}</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      {/* end three row */}
                    </div>
                  </div>
                </div>
              ))}
              {/* content end */}
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
