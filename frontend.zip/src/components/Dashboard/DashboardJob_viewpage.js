import React, { useEffect } from 'react'
import './Common/css/admin_style.css'; 
import Sidemanu from './Common/Sidebar_menu';
import DashboardHeader from './Common/DashboardHeader';
import  { useState } from "react";
import DatePicker from "react-datepicker";
import Calendarimgs from './Common/img/calender.svg';
import "react-datepicker/dist/react-datepicker.css";
import { Link } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { useHistory } from 'react-router-dom/cjs/react-router-dom';
import { checkAdminLogin } from '../../redux/Action';




export default function DashboardJobs_viewpage() {
  
 
    const [startDate, setStartDate] = useState(null);
    const [endDate, setEndDate] = useState(null);

    const isAdmin = useSelector((state) => state.reducer.isAdmin);
  const dispatch = useDispatch();
  const history = useHistory();

  
//     let table_header = [
     
//         {
//             label: 'Name',
            
//         },
//         {
//             label: 'Email',
            
//         },
//         {
//             label: 'Contact no.',
        
//         },
//         {
//             label: 'Date',
        
//         },
//         {
//             label: 'Resume',
        
//         },
     
   
// ]

// let table_data =  [ 
  
//       {
//         name: 'John deo',
//         email: 'johndeo@gmail.com',
//         phonenumber: 'johndeo@gmail.com',
//         date: '12-07-2022',
//         resume: 'Download',
//       },
//       {
//         name: 'John deo',
//         email: 'johndeo@gmail.com',
//         phonenumber: 'johndeo@gmail.com',
//         date: '12-07-2022',
//         resume: 'Download',
//       },
//       {
//         name: 'John deo',
//         email: 'johndeo@gmail.com',
//         phonenumber: 'johndeo@gmail.com',
//         date: '12-07-2022',
//         resume: 'Download',
//       },
     
     
//     ]







  return (
    <>
      
<section className="admin-pages job_viwe_page">
  <div className="container-fluid p-0">
    <div className="row p-0 m-0">
            <div className="col-md-2 bg-light">
                <Sidemanu/>
            </div>

            <div className="col-md-10">
                <header><DashboardHeader/></header>
               

{/* header start */}
                           <div className='col-md-12'>
                                <Link to='/jobs' className='back_btn'>Back</Link>
                           </div>
                
                {/* <div className="col-md-12 mt-4">
                                <div className="row">
                                    <div className="col-md-3">
                                    <div className="green_section offer new_visi">
                                        <div className='left_side_dash'>
                                            <span className="visi">Post Name</span>
                                            <span className="texts new_text">Travel Consultant</span>
                                        </div>
                                           
                                        </div>
                                    </div>
                                    <div className="col-md-3">
                                        <div className="blue_section new_visi">
                                        <div className='left_side_dash'>
                                            <span className="visi">No. of Post</span>
                                            <span className="texts new_text">05</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-md-3">
                                        <div className="orang_section new_visi">
                                             <div className='left_side_dash'>
                                            <span className="visi">No. of Applicants</span>
                                            <span className="texts new_text">16,000</span>
                                            </div>
                                            
                                         </div>
                                    </div>
                                    <div className="col-md-3">
                                        <div className="grey_section new_visi">
                                        <div className='left_side_dash' >
                                            <span className="visi">Status</span>
                                            <span className="texts new_text">Active</span>
                                        </div>
                                        </div>
                                    </div>
                                </div>
                            </div> */}


                                <div className='row m-0 mt-4 p-3  bg-light'>
                                    <div className='col-md-5'> 
                                        <input type="text" className="form-control" placeholder='Search' />
                                    </div>
                                    <div className='col-md-4 d-flex'> 
                                        <div className='mr-3 d-flex clender_str'>
                                            <img src={ Calendarimgs } alt='' />

                                            <DatePicker className='form-control date_picker' selected={startDate} onChange={(date) => setStartDate(date)} placeholderText='From' />

                                        </div> 
                                        <div className='d-flex clender_str '> 
                                            <img src={ Calendarimgs } alt='' />
                                            <DatePicker className='form-control date_picker' selected={endDate} onChange={(date) => setEndDate(date)} placeholderText='To'/>
                                           
                                        </div>
                                       </div>
                                    <div className='col-md-1 pl-2'> 
                                      
                                        <select className="custom_select form-control" id="inputGroupSelect03">
                                            <option>Type</option>
                                            <option value="1">One</option>
                                            <option value="2">Two</option>
                                        </select>
                                    </div>
                                    <div className='col-md-2'> 
                                        <input type="submit" name='shortby' value="Short by" className="form-control short-by" />
                                    </div>

                                </div>



{/* end header */}


                {/* content */}

                    <div className='call_req'>
                        <div className="row ">
                            <div className='col-md-12'>
{/*                 
                            <table className="table ">

                          
<thead className="thead-light">
    <tr>
    {  
        table_header.map( 
            tables_headr =>(
                    <th scope="col">{ tables_headr.label }</th>
            )

        )
    }

    </tr>
</thead>




<tbody>
{
    table_data.map( 
        tables =>(
                <tr>
                    <td>{ tables.name }</td>
                    <td>{ tables.email }</td>
                    <td>{ tables.phonenumber }</td>
                    <td>{ tables.date }</td>
                    <td><Link to="/#" className='table_resume'> { tables.resume } </Link></td>
                </tr>
            )

    )
           
}
</tbody>



</table> 
                  */}


                            </div>
                        </div>  
                    </div>  
 {/* content end */}




            </div>
    </div>
  </div>   
</section> 
    
    
    
    
    </>
  )
}
