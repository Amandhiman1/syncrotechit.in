import React, { useEffect } from 'react'
import './Common/css/admin_style.css';
import Sidemenu from './Common/Sidebar_menu';
import DashboardHeader from './Common/DashboardHeader';
import { useDispatch, useSelector } from 'react-redux';
import { useHistory } from 'react-router-dom/cjs/react-router-dom';
import { checkAdminLogin } from '../../redux/Action';



export default function DashboardReportspage() {
  const isAdmin = useSelector((state) => state.reducer.isAdmin);
  const dispatch = useDispatch();
  const history = useHistory();

  
  return (
    <>
      <section className="admin-pages report_page">
        <div className="container-fluid p-0">
          <div className="row p-0 m-0">
            <div className="col-md-2 bg-light">
              <Sidemenu />
            </div>

            <div className="col-md-10">
              <header><DashboardHeader /></header>
              <h2>Comming Soon Reports Page</h2>
            </div>
          </div>
        </div>
      </section>
    </>


  )
}
