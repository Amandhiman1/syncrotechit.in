import React, { useRef, useState } from 'react'
import edit_btn from './img/edit_button.svg';
import architecture from './img/architecture-and-city (4) 1.svg';
import { Link } from 'react-router-dom';
import { confirmAlert } from 'react-confirm-alert'; // Import
import 'react-confirm-alert/src/react-confirm-alert.css'; // Import css
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import ImageCrop from './ImageCrop';
import Form from 'react-bootstrap/Form';

const AddMediapopup = (props) => {

    //const [title, setTitle] = useState("");
    const [errors, setErrors] = useState({});
    const [formData, setFormData] = useState({ 'data': {} });
    const [subcats, setSubCats] = useState([]);
    const [alt, setAlt] = useState('');
    const inputRef = useRef("");

    const handleUpload = () => {
        inputRef.current.click();
    };
    const handleDisplayFileDetails = () => {

        console.log(inputRef.current.files[0])

        setFormData({ ...formData, ['image']: (inputRef.current.files[0]) })

    };


    const handleValidation = (e) => {

        let chk = false;
        if (e) {
            e.preventDefault();
            chk = true;
        }

        let fields = formData;
        let errors = {};
        let formIsValid = true;

        //fields['category'] = props.category

        //Email
        if (!fields["category"]) {
            formIsValid = false;
            errors["category"] = "Please select category.";
        }

        if (!fields["type"]) {
            formIsValid = false;
            errors["type"] = "Please select type.";
        }

        if (!fields["image"]) {
            formIsValid = false;
            errors["image"] = "Please select image.";
        }

        if (!fields["subcategory"]) {
            formIsValid = false;
            errors["subcategory"] = "Please select subcategory.";
        }

        if (alt == '') {
            formIsValid = false;
            errors["alt"] = "Please write alt tag.";
        }

        setErrors(errors);


        if (formIsValid && chk) {
            //alert("Form submitted");



            var formData2 = new FormData();
            formData2.append("image", fields["image"]);
            formData2.append('category', fields["category"]);
            formData2.append('type', fields["type"]);
            formData2.append('subcategory', fields["subcategory"]);
            formData2.append('alt', alt);
            //return;
            console.log(Object.fromEntries(formData2.entries()))
            console.log(fields)

            let post_data = {
                method: 'POST',
                //credentials: 'same-origin',
                //mode: 'same-origin',
                body: formData2,
            }


            // Simple GET request using fetch
            console.log(process.env.REACT_APP_API_URL)

            try {
                fetch(process.env.REACT_APP_API_URL + 'media', post_data)
                    .then(response => response.json())
                    .then(data => {
                        console.log(data)

                        setFormData({})
                        setAlt('')
                        document.getElementById('webForm').reset()
                        show_success('Image added successfully!!')
                        props.parentFunction()
                    })
            } catch (e) {
                console.log('err', e)
            }

        }
    }

    const delType = (id) => {
        console.log(id)
        // confirmAlert({
        //     title: 'Are you sure?',
        //     message: 'You want to delete this record?',
        //     buttons: [
        //       {
        //         label: 'Yes',
        //         onClick: () => delTypeRequest(id)
        //       },
        //       {
        //         label: 'No',
        //         //onClick: () => alert('Click No')
        //       }
        //     ]
        //   });

        confirmAlert({
            customUI: ({ onClose }) => {
                return (
                    <div className='custom-ui'>
                        <h1>Are you sure?</h1>
                        <p>You want to delete this file?</p>
                        <button onClick={onClose}>No</button>
                        <button
                            onClick={() => {
                                delTypeRequest(id);
                                onClose();
                            }}
                        >
                            Yes, Delete it!
                        </button>
                    </div>
                );
            }
        });
    }

    const delTypeRequest = (id) => {
        console.log(id)
        let post_data = {
            method: 'DELETE',
            //credentials: 'same-origin',
            //mode: 'same-origin',
            //body: JSON.stringify({'id':id}),
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                //'X-CSRFToken':  cookie.load('csrftoken')
            }
        }

        // Simple GET request using fetch
        console.log(process.env.REACT_APP_API_URL)

        try {
            fetch(process.env.REACT_APP_API_URL + 'page_types/' + id, post_data)
                .then(response => response.json())
                .then(data => {
                    console.log(data)
                    //show_error()
                    toast.error('Page type deleted successfully!!');
                })
        } catch (e) {
            console.log('err', e)
        }
    }

    const show_success = (msg) => {
        toast.success(msg);
    }

    const show_error = (msg) => {
        toast.error(msg);
    }

    const handleInputChange = (e, key, field) => {
        //console.log(e.target.checked)
        if (key && field) {
            const updatedObject = { ...formData };
            if (updatedObject['data'][key] == undefined) {
                updatedObject['data'][key] = {}
            }
            updatedObject['data'][key][field] = e.target.value
            setFormData(updatedObject);
        } else setFormData({ ...formData, [e.target.name]: e.target.value });

        console.log(formData)
    };

    const getsubcat = (val) => {
        console.log(val)

        try {
            fetch(process.env.REACT_APP_API_URL + val)
                .then(response => response.json())
                .then(data => {
                    console.log(data)
                    setSubCats(data)
                    //show_error()
                    //toast.error('Page type deleted successfully!!');
                })
        } catch (e) {
            console.log('err', e)
        }
    }

    return (
        <>

            <div className="modal right fade" id="myModal3" tabindex="-1" role="dialog" aria-labelledby="myModalLabel3">
                <div className="modal-dialog main" role="document">
                    <div className="modal-content main">
                        <div className="modal-header">
                            <button type="button" className="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>

                        <div className="modal-body sidebar_popup">
                            <Form onSubmit={handleValidation} id="webForm" className="common-form common-form-border login-signup-form" autoComplete="off">
                                <div className='row mb-5'>
                                    <div className='col-lg-6'>
                                        <Form.Group controlId="formGridState">
                                            <Form.Label>Category</Form.Label>
                                            <Form.Select defaultValue="Choose..." className='form-control' onChange={e => {
                                                console.log("e.target.value", e.target.name);
                                                handleInputChange(e);
                                                getsubcat(e.target.value);
                                            }}
                                                name="category"
                                            >
                                                <option value="">Choose...</option>
                                                <option value="cities">Cities</option>
                                                <option value="countries">Countries</option>
                                                <option value="airlines">Airlines</option>
                                                <option value="airports">Airports</option>
                                            </Form.Select>
                                            <span style={{ color: "red" }}>{errors["category"]}</span>
                                        </Form.Group>
                                    </div>

                                    <div className='col-lg-6'>
                                        <Form.Group controlId="formGridState">
                                            <Form.Label>Select Subcategory</Form.Label>
                                            <Form.Select defaultValue="Choose..." className='form-control' onChange={e => {
                                                console.log("e.target.value", e.target.name);
                                                handleInputChange(e);
                                            }}
                                                name="subcategory"
                                            >
                                                <option value="">Choose...</option>

                                                {subcats.length > 0 ? subcats.map((ke) => (<option value={formData['category'] == 'airlines' ? ke.airline_name : ke.english}>{formData['category'] == 'airlines' ? ke.airline_name : ke.english}</option>)) : ''}

                                            </Form.Select>
                                            <span style={{ color: "red" }}>{errors["subcategory"]}</span>
                                        </Form.Group>
                                    </div>


                                    <div className='col-lg-6'>

                                        <Form.Group controlId="formGridState">
                                            <Form.Label>Type</Form.Label>
                                            <Form.Select defaultValue="Choose..." className='form-control'
                                                onChange={e => {
                                                    console.log("e.target.value", e.target.name);
                                                    handleInputChange(e)
                                                }}
                                                name="type"
                                            >
                                                <option value="">Choose...</option>
                                                <option value="square">Square</option>
                                                <option value="cover">Cover</option>
                                                <option value="rectangle">Rectangle</option>

                                            </Form.Select>
                                            <span style={{ color: "red" }}>{errors["type"]}</span>
                                        </Form.Group>


                                    </div>

                                    <div className='col-lg-6'>
                                        <div className="m-12">
                                            <Form.Group controlId="formGridState">
                                                <label className="mx-3">Alt Text</label>
                                                <input
                                                    type="text"
                                                    name="alt"
                                                    className=""
                                                    value={alt}
                                                    onChange={(e) => setAlt(e.target.value)}
                                                />
                                                <span style={{ color: "red" }}>{errors["alt"]}</span>
                                            </Form.Group>
                                        </div>
                                    </div>

                                    <div className='col-lg-6'>

                                        <div className="m-12">
                                            <Form.Group controlId="formGridState">
                                                <label className="mx-3"></label>
                                                <input
                                                    ref={inputRef}
                                                    onChange={handleDisplayFileDetails}
                                                    className=""
                                                    type="file"
                                                /><span style={{ color: "red" }}>{errors["image"]}</span>
                                            </Form.Group>

                                        </div>

                                    </div>

                                </div>

                                <button variant="primary" className="create_btn form_submit text-center" type="submit"> Submit</button>

                            </Form>

                            <hr />
                        </div>
                    </div>
                </div>
            </div>


        </>
    )
}

export default AddMediapopup