import React from "react";
import "./css/admin_style.css";
import adminImg from "./img/Devon Lane.svg";
import { Link } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faBell } from "@fortawesome/free-solid-svg-icons";
import { faUser } from "@fortawesome/free-solid-svg-icons";
import { faCogs } from "@fortawesome/free-solid-svg-icons";
import { faList } from "@fortawesome/free-solid-svg-icons";
import { faSignOut } from "@fortawesome/free-solid-svg-icons";
import AxiosJWT from "./AxiosJWT";
import { useHistory } from "react-router-dom";
import NotiModal from '../dashboardnotimodal'

export default function DashboardHeader() {
    const {history} = useHistory();
  const logout = async () => {
    const response = await AxiosJWT.get("/auth/logout");
    console.log(response);
    sessionStorage.removeItem("token");
    sessionStorage.removeItem("refreshToken");
    window.location.href = '/admin/login';
  };

  const user = JSON.parse(sessionStorage.getItem('user'));
  console.log('user', JSON.stringify(user));
  

  return (
    <>
      {/* <!-- Content Wrapper --> */}
      <div id="content-wrapper" className="d-flex flex-column bg_dashboard">
        {/* <!-- Main Content --> */}
        <div id="content">
          {/* <!-- Topbar --> */}
          <NotiModal/>
          <nav className="navbar navbar-expand navbar-light  topbar mt-3 mb-2 static-top dashboard_pro-dp">
            <ul className="navbar-nav ml-auto ">
              {/* <!-- Nav Item - Messages --> */}

              <li className="nav-item dropdown no-arrow bell">
                <div
                  className="nav-link dropdown-toggle"
                  to="/"
                  id="bellsDropdown"
                  role="button"
                  data-toggle="dropdown"
                  aria-haspopup="true"
                  aria-expanded="false"
                >
                  <FontAwesomeIcon icon={faBell} />
                </div>

                {/* <!-- Dropdown - User Information --> */}
                <div
                  className="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                  aria-labelledby="bellsDropdown"
                >
                  <Link className="dropdown-item" to="/">
                    <FontAwesomeIcon icon={faUser} /> Profile
                  </Link>
                  <Link className="dropdown-item" to="/">
                    <FontAwesomeIcon icon={faCogs} />
                    Settings
                  </Link>
                  <Link className="dropdown-item" to="/">
                    <FontAwesomeIcon icon={faList} />
                    Activity Log
                  </Link>
                  <div className="dropdown-divider"></div>
                  <Link
                    className="dropdown-item"
                    to="/"
                    data-toggle="modal"
                    data-target="#logoutModal"
                  >
                    <FontAwesomeIcon icon={faSignOut} />
                    Logout
                  </Link>
                </div>
              </li>

              {/* <!-- Nav Item - User Information --> */}
              <li className="nav-item dropdown no-arrow">
                <div
                  className="nav-link dropdown-toggle"
                  to="/"
                  id="userDropdown"
                  role="button"
                  data-toggle="dropdown"
                  aria-haspopup="true"
                  aria-expanded="false"
                >
                  <div className="d-flex">
                    <img
                      className="img-profile rounded-circle"
                      src={adminImg}
                      alt=""
                    />
                    <div className="user_name">
                      <span className="mr-2 d-none d-lg-inline text-gray-600 small">
                        {user.name}
                      </span>
                      <span className="sub_name small">{user.designation}</span>
                    </div>
                  </div>
                </div>

                {/* <!-- Dropdown - User Information --> */}
                <div
                  className="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                  aria-labelledby="userDropdown"
                >
                  <Link className="dropdown-item" to="/admin/profile">
                    <FontAwesomeIcon icon={faUser} /> Profile
                  </Link>
                  <Link className="dropdown-item" to="/">
                    <FontAwesomeIcon icon={faCogs} />
                    Settings
                  </Link>
                  <Link className="dropdown-item" to="/">
                    <FontAwesomeIcon icon={faList} />
                    Activity Log
                  </Link>
                  <div className="dropdown-divider"></div>
                  <div className="dropdown-item" onClick={logout}>
                    <FontAwesomeIcon icon={faSignOut} />
                    Logout
                  </div>
                </div>
              </li>
            </ul>
          </nav>
          {/* <!-- End of Topbar --> */}
        </div>
      </div>
      {/* <!--/////////////end contant//////////////////--> */}
    </>
  );
}
