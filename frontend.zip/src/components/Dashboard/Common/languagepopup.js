import React, { useState } from 'react'
import './css/admin_style.css'; 
import "react-datepicker/dist/react-datepicker.css";
// modal

import Form from 'react-bootstrap/Form';
//import Select from 'react-select';
//import makeAnimated from 'react-select/animated';

import Editor from 'ckeditor5-custom-build/build/ckeditor';
import { CKEditor } from '@ckeditor/ckeditor5-react';



import Tab from 'react-bootstrap/Tab';
import Tabs from 'react-bootstrap/Tabs';

import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

import CkEditorExampleComponent from './CkEditorExampleComponent'
 


const editorConfiguration = {
    toolbar: {
        items: [
            'bold',
            'italic',
            '|',
            'bulletedList',
            'numberedList',
            'indent',
            'outdent',
            '|',
            'heading',
            '|',
            'undo',
            'redo', 'link', 'blockQuote','insetTable' 
        ]
    }
};



export default function Languagepopup(props) {


    // const [state, setState] = useState({
    //     data: "",
    //     editor: null
    // })
    // useEffect(() => {
    //     console.log(state.data);
    //     const editor = (
    //         <CKEditor
    //             id={"ck-editor-text"}
    //             editor={ClassicEditor}
    //             data={state.data}
    //             onReady={editor => {console.log('Editor is ready to use!', editor)}}
    //         />
    //     )
    //     setState({...state, editor: editor});
    // }, [])

  const languages = [

    { 
        key: 'english', 
        title: 'English' ,
    },{ 
        key: 'hindi', 
        title: 'Hindi' ,
    },{ 
        key: 'spanish', 
        title: 'Spanish' ,
    },
  ]

  //const animatedComponents = makeAnimated();

  const [formData, setFormData] = useState({ 'data': {} });
  //const [types, setLangs] = useState({});
    const [errors, setErrors] = useState({});
    const get_languages = (catid) => {

    try {
        
        fetch(process.env.REACT_APP_API_URL+'languages')
        .then(response => response.json())
        .then(data => {
                    console.log(data)
                    //setOrders(data)
                    //setLangs(data)
                }, (error) => {
                if (error) {
                    console.log(error)
                }
        });
    }catch(e){
        //snotify()
    }           

}

    const show_success = (msg) => {
        toast.success(msg);
    }

    const handleInputChange = (e,key,field) => {
        //console.log(e.target.checked)
        setFormData({ ...formData, [e.target.name]: e.target.value }); 

        console.log(formData)
    };

// end modal

const handleValidation = (e) => {

    let chk = false;
    if(e) {
        e.preventDefault();
        chk = true;
    }

    let fields = formData;
    let errors = {};
    let formIsValid = true;

    if (!fields["name"]) {
      formIsValid = false;
      errors["name"] = "Please enter language name.";
    }

    if (!fields["code"]) {
        formIsValid = false;
        errors["code"] = "Please enter language code.";
      }

    setErrors(errors);

    if (formIsValid && chk) {
    //alert("Form submitted");
        console.log(fields)
    let post_data = {
                    method: 'POST',
                    //credentials: 'same-origin',
                    //mode: 'same-origin',
                    body: JSON.stringify(fields),
                    headers: {
                        'Accept':       'application/json',
                        'Content-Type': 'application/json',
                        //'X-CSRFToken':  cookie.load('csrftoken')
                    }
                }

        
            // Simple GET request using fetch
            console.log(process.env.REACT_APP_API_URL)

            try {
                fetch(process.env.REACT_APP_API_URL+'languages',post_data)
                .then(response => response.json())
                .then(data => {
                            console.log(data)
                            get_languages()
                            setFormData({})
                            document.getElementById('webForm').reset()
                        show_success('Language added successfully!!')
                        props.parentFunction()
                    })
            }catch(e){
                console.log('err',e)
            }

        }
}

  return (
    <>
 
    <div className="modal right fade" id="myModal2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel2">
        <div className="modal-dialog main" role="document">
        <Form onSubmit={handleValidation} id="webForm">
            <div className="modal-content main">
                <div className="modal-header">

                <p className='form-heading mb-0 '>{props.page_heading}</p>

                    <button type="button" className="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>   
                </div>

                <div className="modal-body sidebar_popup">
     
               

             
                <div className="row">
                            {/* <div className='col-md-12'>
                                <p className='form-heading'>{props.heading}</p>
                            </div>

                            <div className='col-md-12'>

                            </div> */}

                            <div className='col-md-12 form_field_popup'>
                                <Form.Group className="mb-3 f-left w-100" controlId="exampleForm.ControlInput1">
                                    <Form.Label>Full Name*</Form.Label>
                                    <Form.Control type="text" 
                                    onChange={e => {
                                        console.log("e.target.value", e.target.value);
                                        handleInputChange(e,'meta_title');
                                    }}
                                    name={'name'}
                                    placeholder="Language Name" autoFocus />
                                     <span style={{ color: "red" }}>{errors["name"]}</span>
                                </Form.Group>

                                {/* <Form.Group className="mb-3 f-right" controlId="exampleForm.ControlInput1">
                                    <Form.Label>Permalink: https://vmaans.com/</Form.Label>
                                    <Form.Control type="url" placeholder="https://vmaans.com/" autoFocus />
                                </Form.Group> */}
                            </div>
                            
                            <div className='col-md-12 form_field_popup'>
                                <Form.Group className="mb-3 f-right w-100" controlId="exampleForm.ControlInput1">
                                    <Form.Label>Code*</Form.Label>
                                    <Form.Control type="text" 
                                    onChange={e => {
                                        console.log("e.target.value", e.target.value);
                                        handleInputChange(e,'meta_description');
                                    }}
                                    name={'code'} placeholder="Language Code" autoFocus />
                                    <span style={{ color: "red" }}>{errors["code"]}</span>
                                </Form.Group>
                            </div>
                            <div className='col-md-12'>
                            <button variant="primary" className="create_btn form_submit text-center" type="submit"> Submit</button>
                            </div>
                                                
                        </div>

                    </div>
                </div>
                </Form>
            </div>
        </div>
{/* end moadl */}

  </>
  )
}
