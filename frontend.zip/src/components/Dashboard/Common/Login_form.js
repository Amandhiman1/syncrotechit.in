import React, { useState } from "react";
import { Form, Button, Alert } from "react-bootstrap";
import { useDispatch } from "react-redux";
import { useHistory } from "react-router-dom/cjs/react-router-dom";
import { setIsAdmin } from "../../../redux/Action";
import VerifyForm from "./VerifyForm";

const Login_form = () => {
  const dispatch = useDispatch();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [errorMessage, setErrorMessage] = useState(null);
  const [formType, setFormType] = useState("login");
  const [res, setRes] = useState();

  const history = useHistory();

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await fetch("https://flight-backend-ro3e.onrender.com/api/auth/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email, password }),
        credentials: "include"
      });

      const data = await response.json();
      console.log('data', data);
      await setRes(data);
      sessionStorage.setItem('token', data.accessToken);
      sessionStorage.setItem('user', JSON.stringify(data.user));
      if (response.ok) {
        setFormType("verify");
      } else {
        setErrorMessage(data.message);
      }
    } catch (error) {
      console.error("Error during login:", error);
    }
  };

  return (
    formType === 'login' ? (
      // <section className="login_Section">
      //   <div className="login">
      //     <div className="container">
      //       <div className="row mt-4">
      //         <h2>Continue to your account</h2>
      //         <p>
      //           Track prices, make trip planning easier, and enjoy faster
      //           booking.
      //         </p>
      //       </div>
      //       <div className="row">
      //         <Form className="w-100" onSubmit={handleSubmit}>
      //           <Form.Group className="mb-3" controlId="">
      //             <Form.Label>Email address</Form.Label>
      //             <Form.Control
      //               type="email"
      //               placeholder="Enter Email address"
      //               onChange={(e) => setEmail(e.target.value)}
      //             />
      //           </Form.Group>
      //           <Form.Group className="mb-3" controlId="">
      //             <Form.Label htmlFor="inputPassword5">Password</Form.Label>
      //             <Form.Control
      //               type="password"
      //               id="inputPassword5"
      //               placeholder="Enter Password"
      //               aria-describedby="passwordHelpBlock"
      //               onChange={(e) => setPassword(e.target.value)}
      //             />
      //           </Form.Group>
      //           {errorMessage && <p>{errorMessage}</p>}
      //           <Button variant="primary" type="submit">
      //             Submit
      //           </Button>
      //         </Form>
      //       </div>
      //     </div>
      //   </div>
      // </section>

      <section >
        <div className="container">
          <div className="row">
            <div className="col-lg-12 login-section">
              <div className="col-lg-6 left-side-login">
                <div>
                <h2>Continue to your account</h2>
         <p> Track prices, make trip planning easier, and enjoy faster booking.</p>
                </div>
                <div>
                  <img 
                  src={`${process.env.PUBLIC_URL}/image/login-img.jpg`}
                  />
                </div>
              </div>
              <div className="col-lg-6 right-side-login">
              <Form className="w-100 login-form" onSubmit={handleSubmit}>
                 <Form.Group className="mb-3 text-left" controlId="">
                   <Form.Label>Email address</Form.Label>
                   <Form.Control
                     type="email"
                     placeholder="Enter Email address"
                     onChange={(e) => setEmail(e.target.value)}
                   />
                </Form.Group>
                <Form.Group className="mb-3 text-left" controlId="">
                  <Form.Label htmlFor="inputPassword5">Password</Form.Label>
                  <Form.Control
                    type="password"
                    id="inputPassword5"
                  placeholder="Enter Password"
                   aria-describedby="passwordHelpBlock"
                   onChange={(e) => setPassword(e.target.value)}
                  />
                </Form.Group>
               {errorMessage && <p>{errorMessage}</p>}
               <Button variant="primary" type="submit">
                Submit
               </Button>
            </Form>
              </div>
            </div>
          </div>
        </div>
      </section>

    ) : (
      <VerifyForm is2fa={res.isTwoFactorEnabled} />
    )
  );
}

export default Login_form;
