import React from 'react'
import edit_btn from './img/edit_button.svg';
import architecture from './img/architecture-and-city (4) 1.svg';
import { Link } from 'react-router-dom';
import { confirmAlert } from 'react-confirm-alert'; // Import
import 'react-confirm-alert/src/react-confirm-alert.css'; // Import css
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useState } from 'react';
import { useEffect } from 'react';
import EditTypepopup from './EditTypepopup';

export default function AddTypepopup(props) {

    //const [title, setTitle] = useState("");
    const [errors, setErrors] = useState({});
    const [formData, setFormData] = useState({ title_en: '' });
    const [pageTypes, setPageTypes] = useState({});
    const [languages, setLangs] = useState([]);
    const [isEditClicked, setIsEditClicked] = useState(false);
    const [selectedType, setSelectedType] = useState();

    const get_langauages = () => {
        try {

            fetch(process.env.REACT_APP_API_URL + 'languages')
                .then(response => response.json())
                .then(data => {
                    console.log(data)
                    //setOrders(data)
                    if (data.length > 0) setLangs(data)

                }, (error) => {
                    if (error) {
                        console.log(error)
                    }
                });
        } catch (e) {
            console.error(e)
        }
    }

    useEffect(() => {
        get_page_types()
        get_langauages()
    }, [props.category])

    const get_page_types = () => {

        try {
            console.log('props.category', props.category)
            let post_data = {
                method: 'POST',
                //credentials: 'same-origin',
                //mode: 'same-origin',
                body: JSON.stringify({ 'category': props.category }),
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json',
                    //'X-CSRFToken':  cookie.load('csrftoken')
                }
            }
            fetch(process.env.REACT_APP_API_URL + 'page_types/filter', post_data)
                .then(response => response.json())
                .then(data => {
                    console.log('pageTypes data', data)
                    //setOrders(data)
                    setPageTypes(data)
                }, (error) => {
                    if (error) {
                        console.log(error)
                    }
                });
        } catch (e) {
            //snotify()
        }

    }

    const handleLoginInputChange = e => {
        //console.log(e.target.checked)
        setFormData({ ...formData, [e.target.name]: e.target.value });

        console.log(e.target.value)
    };

    // const addTag = (tag) => {
    //     languages.map(async (lang) => {
    //         console.log('title_' + lang.code);
    //         formData['title_' + lang.code] = (formData['title_' + lang.code] || '') + ' ' + tag;
    //         //setFormData({ ...formData, ['title_'+lang.code]: (formData['title_'+lang.code] || '')+' '+tag }); 
    //         setFormData(formData)
    //         console.log(formData)
    //     })
    // }

    const addTag = async (tag) => {
        await Promise.all(languages.map(async (lang) => {
            console.log('title_' + lang.code);
            // Assuming setFormData is a function that returns a promise
            await setFormData((prevData) => {
                return { ...prevData, ['title_' + lang.code]: (prevData['title_' + lang.code] || '') + ' ' + tag };
            });
            console.log(formData);
        }));
    };


    const handleValidation = (e) => {

        let chk = false;
        if (e) {
            e.preventDefault();
            chk = true;
        }

        let fields = formData;
        let errors = {};
        let formIsValid = true;

        fields['category'] = props.category

        //Email

        let narr = {}
        languages.map((lang) => {

            if (!fields["title_" + lang.code]) {
                formIsValid = false;
                errors["title_" + lang.code] = lang.name + " title cannot be empty";
            } else {
                if (lang.code == 'en') {
                    console.log('titile', fields["title_" + lang.code])
                    fields['title'] = fields["title_" + lang.code];
                }
                narr[lang.code] = fields["title_" + lang.code]
            }

        })

        setErrors(errors);
        fields['languages'] = narr;

        if (formIsValid && chk) {
            //alert("Form submitted");
            const { title_en, title_es, ...apiData } = fields;
            apiData.title = title_en;

            let post_data = {
                method: 'POST',
                //credentials: 'same-origin',
                //mode: 'same-origin',
                body: JSON.stringify(apiData),
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json',
                    //'X-CSRFToken':  cookie.load('csrftoken')
                }
            }


            // Simple GET request using fetch
            console.log(process.env.REACT_APP_API_URL)

            try {
                fetch(process.env.REACT_APP_API_URL + 'page_types', post_data)
                    .then(response => response.json())
                    .then(data => {
                        console.log(data)
                        get_page_types()
                        setFormData({})
                        document.getElementById('typeForm').reset()
                        show_success('Page type added successfully!!')
                        props.parentFunction()
                    })
            } catch (e) {
                console.log('err', e)
            }

        }
    }

    const delType = (id) => {
        console.log(id)
        // confirmAlert({
        //     title: 'Are you sure?',
        //     message: 'You want to delete this record?',
        //     buttons: [
        //       {
        //         label: 'Yes',
        //         onClick: () => delTypeRequest(id)
        //       },
        //       {
        //         label: 'No',
        //         //onClick: () => alert('Click No')
        //       }
        //     ]
        //   });

        confirmAlert({
            customUI: ({ onClose }) => {
                return (
                    <div className='custom-ui'>
                        <h1>Are you sure?</h1>
                        <p>You want to delete this file?</p>
                        <button onClick={onClose}>No</button>
                        <button
                            onClick={() => {
                                delTypeRequest(id);
                                onClose();
                            }}
                        >
                            Yes, Delete it!
                        </button>
                    </div>
                );
            }
        });
    }

    const delTypeRequest = (id) => {
        console.log(id)
        let post_data = {
            method: 'DELETE',
            //credentials: 'same-origin',
            //mode: 'same-origin',
            //body: JSON.stringify({'id':id}),
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                //'X-CSRFToken':  cookie.load('csrftoken')
            }
        }

        // Simple GET request using fetch
        console.log(process.env.REACT_APP_API_URL)

        try {
            fetch(process.env.REACT_APP_API_URL + 'page_types/' + id, post_data)
                .then(response => response.json())
                .then(data => {
                    console.log(data)
                    get_page_types()
                    //show_error()
                    toast.error('Page type deleted successfully!!');
                })
        } catch (e) {
            console.log('err', e)
        }
    }

    const show_success = (msg) => {
        toast.success(msg);
    }

    const show_error = (msg) => {
        toast.error(msg);
    }

    useEffect(() => {
        console.log('formData ==> ', formData);
    }, [formData])

    return (
        <>

            <div className="modal right fade" id="myModal3" tabindex="-1" role="dialog" aria-labelledby="myModalLabel3">
                <div className="modal-dialog main" role="document">
                    <div className="modal-content main">
                        <div className="modal-header">
                            <button type="button" className="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>

                        {isEditClicked ? (
                            <EditTypepopup languages={languages} category={props.category} selectedType={selectedType} setIsEditClicked={setIsEditClicked} />
                        ) : (
                            <div className="modal-body sidebar_popup">
                                <form onSubmit={handleValidation} className='common-form common-form-border login-signup-form' id="typeForm" autoComplete="off">
                                    <div className='row mb-2 d-flex align-items-center'>
                                        {languages.length > 0 ? languages.map((lang) => (<div className='col-md-9'>
                                            <b>{lang.name}</b>
                                            <input type="text" className="form-control"
                                                id="title"
                                                name={"title" + '_' + lang.code}
                                                placeholder={'Add Type for ' + props.category} onChange={e => handleLoginInputChange(e)}
                                                value={formData['title_' + lang.code]}
                                            />
                                            <span style={{ color: "red" }}>{errors["title" + '_' + lang.code]}</span>
                                        </div>)) : ''}
                                        <div className='col-md-3 text-center'>
                                            <button variant="primary" className="create_btn form_submit text-center" type="submit"> Submit</button>
                                        </div>
                                    </div>
                                </form>

                                <hr />

                                <div className='row table_btn'>

                                    <button onClick={() => {
                                        if (formData.title_en.includes('%city%')) {
                                            addTag('%city2%')
                                        } else {
                                            addTag('%city%')
                                        }
                                    }} class="tag create_btn_type" disabled={formData.title_en && formData.title_en.includes('%city2%')}>city</button>

                                    <button onClick={() => {
                                        if (formData.title_en.includes('%country%')) {
                                            addTag('%country2%')
                                        } else {
                                            addTag('%country%')
                                        }
                                    }} class="tag create_btn_type" disabled={formData.title_en && formData.title_en.includes('%country2%')}>country</button>

                                    <button onClick={() => {
                                        if (formData.title_en.includes('%airline%')) {
                                            addTag('%airline2%')
                                        } else {
                                            addTag('%airline%')
                                        }
                                    }} class="tag create_btn_type" disabled={formData.title_en && formData.title_en.includes('%airline2%')}>airline</button>

                                    <button onClick={() => {
                                        if (formData.title_en.includes('%airport%')) {
                                            addTag('%airport2%')
                                        } else {
                                            addTag('%airport%')
                                        }
                                    }} class="tag create_btn_type" disabled={formData.title_en && formData.title_en.includes('%airport2%')}>airport</button>

                                </div>

                                <div className='row'>

                                    <table class="table table_show_data">
                                        <thead>
                                            <tr>
                                                <th>Type</th>
                                                <th> Action</th>
                                            </tr>
                                        </thead>

                                        <tbody>

                                            {pageTypes.length > 0 ? pageTypes.map((ke) => (
                                                <tr>
                                                    <td>
                                                        <span className='text-center pb-3'>{ke.title}</span>
                                                    </td>
                                                    <td >
                                                        {/* <span>Edit </span> */}
                                                        <a href="#" onClick={() => delType(ke.id)}> Delete</a> | <Link to={"/admin/pages/" + ke.id} onClick={() => {
                                                            document.querySelectorAll(".modal-backdrop").forEach(el => el.remove());
                                                            document.querySelector('body').classList.remove('modal-open');
                                                        }}> View Pages</Link> | <Link onClick={() => {
                                                                setSelectedType(ke)
                                                                setIsEditClicked(true);
                                                            }} to={window.location.pathname}>Edit</Link>
                                                    </td>
                                                </tr>

                                            )) : ''}

                                        </tbody>
                                    </table>


                                    {/*   <div className='col-md-2'>
                                <a href="#" onClick={()=>addTag('%city%')} class="tag">city</a>                             
                            </div> 

                            <div className='col-md-2'>
                                <a href="#" onClick={()=>addTag('%country%')} class="tag">country</a>                             
                            </div>

                            <div className='col-md-2'>
                                <a href="#" onClick={()=>addTag('%airline%')} class="tag">airline</a>                             
                            </div>*/}

                                </div>

                                {/* {pageTypes.length>0?pageTypes.map((ke) => (
                        <div className='row'>
                            <div className='col-md-10'>
                               
                                        <span className='text-center pb-3'>{ke.title}</span>
                                  

                            </div>

                        

                        <div className='col-md-2 d-flex align-items-center'>
                            <div className='d-flex add_edit_dlt pt-4'>
                                <Link className=" d-flex" to="#">
                                    
                                    <div className='box_cont_img_cont pl-2'>
                                        <span>Edit</span>
                                    </div>
                                </Link>
                            </div>
                        </div>
                    </div>
                     )):''}  */}
                            </div>
                        )}
                    </div>
                </div>
            </div>


        </>
    )
}
