import React, { useEffect, useState } from 'react';
import './css/admin_style.css'; 
import  logoImg  from './img/air-freight 2.svg';
import  dashboardImg  from './img/ic_round-dashboard.svg';
import  visitersImg  from './img/Visiters.svg';
import  callBackImg  from './img/call back.svg';
import  offerPageImg  from './img/offer.svg';
import  messagesImg  from './img/Messages.svg';
import  blogImg  from './img/blog.svg';
import  newsletterImg  from './img/newsletter.svg';
import  webgageImg  from './img/webpage.svg';
import  jobImg  from './img/jobs.svg';
import  lanImg  from './img/lang.svg';
import  faImg  from './img/faq.svg';
import  peoplesImg  from './img/user.svg';
import  reportsImg  from './img/reports.svg';
import  currencyImg  from './img/currency.svg';

import { NavLink } from 'react-router-dom';


// start hover images  //
import  hovdash  from './img/hover-image/ic_round-dashboard.svg';
import  hovvisiters  from './img/hover-image/031-question-mark 3.svg';
import  hovcallBack  from './img/hover-image/call-back 1.svg';
import  hovofferPage  from './img/hover-image/offerhover4.svg';
import  hovmessages  from './img/hover-image/050-message 2.svg';
import  hovblog  from './img/hover-image/Group.svg';
import  hovnewsletter  from './img/hover-image/047-agreement 1.svg';
import  hovwebgage  from './img/hover-image/043-webpage 1.svg';
import  hovjob  from './img/hover-image/039-job-hunting 1.svg';
import  hovfa  from './img/hover-image/046-question 2.svg';
import AxiosJWT from './AxiosJWT';

// End hover images //

export default function Sidebar() {
  const user = JSON.parse(sessionStorage.getItem('user'));
   const [tasks, setTasks] = useState([]);
   const [allowPermissionBlog, setAllowPermissionBlog] = useState(false);
   const [allowPermissionJob, setAllowPermissionJob] = useState(false);
   const [allowPermissionFaq, setAllowPermissionFaq] = useState(false);
    
    
  const getTasks = async () => {
    try {
      const response = await AxiosJWT.get(`https://flight-backend-ro3e.onrender.com/api/tasks`);

      // const response = await AxiosJWT.get(`http://localhost:8000/api/tasks`);

      console.log("58798978979task1",response.data);
 
      setTasks(response.data);
    } catch (error) {
      console.error("Error fetching tasks:", error);
    }
  };
 



useEffect(()=>{
    getTasks()
},[])

    
    let menu=[
            {
            id: "1",
            title: "Dashboard",
            url: "/admin/dashboard",
            imgs:  dashboardImg ,
            hovimgs:  hovdash ,
        },
        {
            id: "2",
            title: "Visiters",
            url: "/admin/visiters",
            imgs:  visitersImg ,
            hovimgs:  hovvisiters ,
        },
        {
            id: "3",
            title: "Call Back",
            url: "/admin/call-back",
            imgs:  callBackImg ,
            hovimgs:  hovcallBack ,
        },
        {
            id: "4",
            title: "Messages",
            url: "/admin/message",
            imgs:  messagesImg ,
            hovimgs:  hovmessages ,
        },
        {
            id: "5",
            title: "Offer Page",
            url: "/admin/offer",
            imgs:  offerPageImg ,
            hovimgs:  hovofferPage ,
        },
        {
            id: "6",
            title: "Blog",
            url: "/admin/blog",
            imgs:  blogImg ,
            hovimgs:  hovblog ,
            permission: allowPermissionBlog,
        },

        {
            id: "7", 
            title: "Newsletter",
            url: "/admin/news-letter",
            imgs:  newsletterImg ,
            hovimgs:  hovnewsletter ,
        },
        {
            id: "15",
            title: "Media",
            url: "/admin/media",
            imgs:  webgageImg ,
            hovimgs:  hovwebgage ,
        },
        {
            id: "8",
            title: "Web Pages",
            url: "/admin/web-pages",
            imgs:  webgageImg ,
            hovimgs:  hovwebgage ,
        },
        {
            id: "9",
            title: "Jobs",
            url: "/admin/jobs",
            imgs:  jobImg ,
            hovimgs:  hovjob ,
            permission: allowPermissionJob,
        },
     
        {
            id: "10",
            title: "Frequently Asked",
            url: "/admin/frequently-asked",
            imgs:  faImg ,
            hovimgs:  hovfa ,
            permission: allowPermissionFaq,
        },
        {
            id: "11",
            title: "Task Assigning",
            url: "/admin/task-assigning",
            imgs:  faImg ,
            hovimgs:  hovfa ,
        },
        {
            id: "12",
            title: "Peoples",
            url: "/admin/peoples",
            imgs:  peoplesImg , 
            hovimgs:  hovdash ,
        },
        {
            id: "13",
            title: "Reports",
            url: "/admin/reports",
            imgs:  reportsImg ,
            hovimgs:  hovdash ,
        },
        {
            id: "14",
            title: "Currency",
            url: "/admin/currency",
            imgs:  currencyImg ,
            hovimgs:  hovdash ,
        },
        {
            id: "15",
            title: "Language",
            url: "/admin/language",
            imgs:  lanImg ,
            hovimgs:  hovdash ,
        },

    ]


    useEffect(() => {
        // Update the state based on the data
        if (user.role !== "Admin") {
            const blogPermission = tasks.some(
                (item) =>
                  (item.taskType === "Blog" && 
                  (item.queryObject?.allowAddBlog === true || item.queryObject?.allowAddBlog === undefined))
              );
              
          const jobPermission = tasks.some(
            (item) =>
              (item.taskType === "Job" && 
                (item.queryObject?.allowAddJob === true || item.queryObject?.allowAddJob === undefined))
          );
          const faqPermission = tasks.some(
            (item) =>
              (item.taskType === "Faq" && 
                (item.queryObject?.allowAddFaq === true || item.queryObject?.allowAddFaq === undefined))
          );
      
          console.log("blogPermission", blogPermission);
          console.log("jobPermission", jobPermission);
          console.log("faqPermission", faqPermission);
      
          setAllowPermissionBlog(blogPermission);
          setAllowPermissionJob(jobPermission);
          setAllowPermissionFaq(faqPermission);
        } else {
          // Admin has all permissions
          setAllowPermissionBlog(true);
          setAllowPermissionJob(true);
          setAllowPermissionFaq(true);
        }
      }, [tasks, user]);
      

 console.log("tasksasdsa",tasks)
  return (
    <>


    <div id="page-top">
        <div id="wrapper " className='admin_css_sidebar' >
                <nav className="navbar navbar-expand-lg navbar-light bg-light w-100">
                        <NavLink className="sidebar-brand d-flex align-items-center " to="/">
                            <div className="sidebar-brand-icon">
                                <img src={ logoImg } tittle="" alt="" />
                                
                            </div>
                        </NavLink>

                        <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                            <span className="navbar-toggler-icon"></span>
                        </button>

                        <div className="collapse navbar-collapse" id="navbarNav">
                        <ul className="navbar-nav sidebar sidebar-dark accordion sidebar_dashboard hamburgerDropDown" id="accordionSidebar">
  {menu
    .filter((menus) => menus.permission === undefined || menus.permission) // Filter menus based on permission
    .map((menus) => (
      <li className="nav-item" key={menus.id}>
        <NavLink className="nav-link" to={menus.url}>
          <img className="simple-image" src={menus.imgs} title={menus.title} alt="" />
          <img className="hover-image" src={menus.hovimgs} title={menus.title} alt="" />
          <span>{menus.title}</span>
        </NavLink>
      </li>
    ))}
</ul>


                        </div>
                </nav>
        </div>
    </div> 
            
    </>
  )
}
