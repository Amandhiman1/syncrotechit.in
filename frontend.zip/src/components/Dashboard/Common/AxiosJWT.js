import axios from 'axios';

// Create an Axios instance
const AxiosJWT = axios.create({
  baseURL: 'https://flight-backend-ro3e.onrender.com/api',
});

// Add a request interceptor to include the token in the headers
AxiosJWT.interceptors.request.use(
  (config) => {
    const token = sessionStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Add a response interceptor to handle token refresh
AxiosJWT.interceptors.response.use(
  (response) => {
    return response;
  },
  async (error) => {
    const originalRequest = error.config;

    // Check if the error is due to an expired token
    if (error.response && error.response.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true;

      try {
        // Request a new token using the refresh token
        const refreshToken = sessionStorage.getItem('refreshToken');
        const response = await axios.post('https://flight-backend-ro3e.onrender.com/api/auth/token', {
          token: refreshToken,
        });

        if (response.status === 200) {
          // Store the new tokens
          const newToken = response.data.token;
          sessionStorage.setItem('token', newToken);

          // Retry the original request with the new token
          AxiosJWT.defaults.headers.common['Authorization'] = `Bearer ${newToken}`;
          originalRequest.headers['Authorization'] = `Bearer ${newToken}`;

          return AxiosJWT(originalRequest);
        }
      } catch (refreshError) {
        console.error('Token refresh failed:', refreshError);
        sessionStorage.removeItem('token');
        sessionStorage.removeItem('refreshToken');
        // Redirect to login or handle token refresh failure
      }
    }

    return Promise.reject(error);
  }
);

export default AxiosJWT;
