import React, { useEffect, useState } from 'react'

const EditTypepopup = ({languages, category, selectedType, setIsEditClicked}) => {
    const [formData, setFormData] = useState([]);
    console.log('selectedType', selectedType);

    const addTag = async (tag) => {
        await Promise.all(languages.map(async (lang) => {
            console.log('title_' + lang.code);
            // Assuming setFormData is a function that returns a promise
            await setFormData((prevData) => {
                return { ...prevData, ['title_' + lang.code]: (prevData['title_' + lang.code] || '') + ' ' + tag };
            });
            console.log(formData);
        }));
    };

    useEffect(() => {
        setFormData(selectedType.languages);
    }, [selectedType])

    return (
        <div className="modal-body sidebar_popup">
            <form className='common-form common-form-border login-signup-form' id="typeForm" autoComplete="off">
                <div className='row mb-2 d-flex align-items-center'>
                    {languages.length > 0 ? languages.map((lang) => (<div className='col-md-9'>
                        <b>{lang.name}</b>
                        <input type="text" className="form-control" 
                            id="title"
                            name={"title" + '_' + lang.code}
                            placeholder={'Add Type for ' + category}
                            value={formData[lang.code]}
                        />
                        {/* <span style={{ color: "red" }}>{errors["title" + '_' + lang.code]}</span> */}
                    </div>)) : ''}
                    <div className='col-md-3 text-center'>
                        <button variant="primary" className="create_btn form_submit text-center" type="submit"> Submit</button>
                    </div>
                </div>
            </form>

            <hr />

            <div className='row table_btn'>

                <button onClick={() => {
                    if (formData.title_en.includes('%city%')) {
                        addTag('%city2%')
                    } else {
                        addTag('%city%')
                    }
                }} class="tag create_btn_type" disabled={formData.title_en && formData.title_en.includes('%city2%')}>city</button>

                <button onClick={() => {
                    if (formData.title_en.includes('%country%')) {
                        addTag('%country2%')
                    } else {
                        addTag('%country%')
                    }
                }} class="tag create_btn_type" disabled={formData.title_en && formData.title_en.includes('%country2%')}>country</button>

                <button onClick={() => {
                    if (formData.title_en.includes('%airline%')) {
                        addTag('%airline2%')
                    } else {
                        addTag('%airline%')
                    }
                }} class="tag create_btn_type" disabled={formData.title_en && formData.title_en.includes('%airline2%')}>airline</button>

                <button onClick={() => {
                    if (formData.title_en.includes('%airport%')) {
                        addTag('%airport2%')
                    } else {
                        addTag('%airport%')
                    }
                }} class="tag create_btn_type" disabled={formData.title_en && formData.title_en.includes('%airport2%')}>airport</button>

            </div>
            <button onClick={() => setIsEditClicked(false)} class="tag create_btn_type">Cancel</button>
        </div>
    )
}

export default EditTypepopup
