import React from 'react'
import './css/admin_style.css'; 
import "react-datepicker/dist/react-datepicker.css";
// modal

import Form from 'react-bootstrap/Form';
//import Select from 'react-select';
//import makeAnimated from 'react-select/animated';

import Editor from 'ckeditor5-custom-build/build/ckeditor';
import { CKEditor } from '@ckeditor/ckeditor5-react';



import Tab from 'react-bootstrap/Tab';
import Tabs from 'react-bootstrap/Tabs';

import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

import CkEditorExampleComponent from './CkEditorExampleComponent'
import { useEffect } from 'react';
import { useState } from 'react';
 


const editorConfiguration = {
    toolbar: {
        items: [
            'bold',
            'italic',
            '|',
            'bulletedList',
            'numberedList',
            'indent',
            'outdent',
            '|',
            'heading',
            '|',
            'undo',
            'redo', 'link', 'blockQuote','insetTable' 
        ]
    }
};



export default function Dashboardpopup(props) {


    // const [state, setState] = useState({
    //     data: "",
    //     editor: null
    // })
    // useEffect(() => {
    //     console.log(state.data);
    //     const editor = (
    //         <CKEditor
    //             id={"ck-editor-text"}
    //             editor={ClassicEditor}
    //             data={state.data}
    //             onReady={editor => {console.log('Editor is ready to use!', editor)}}
    //         />
    //     )
    //     setState({...state, editor: editor});
    // }, [])
    const [languages, setLangs] = useState([]);

    useEffect(() => {
        get_langauages()
    }, [])

    const get_langauages = () => {

        try {
            
            fetch(process.env.REACT_APP_API_URL+'languages')
            .then(response => response.json())
            .then(data => {
                        console.log(data)
                        //setOrders(data)
                        if(data.length>0) setLangs(data)
    
                    }, (error) => {
                    if (error) {
                        console.log(error)
                    }
            });
        }catch(e){
            //snotify()
        }           
    
    }



  /* const languages = [

    { 
        key: 'english', 
        title: 'English' ,
    },{ 
        key: 'hindi', 
        title: 'Hindi' ,
    },{ 
        key: 'spanish', 
        title: 'Spanish' ,
    },
  ] */

  //const animatedComponents = makeAnimated();

  const [formData, setFormData] = useState({ 'data': {} });
  const [types, setTypes] = useState({});
    const [errors, setErrors] = useState({});
    const get_page_types = (catid) => {

    try {
        console.log('props.category',catid)
        let post_data = {
            method: 'POST',
            //credentials: 'same-origin',
            //mode: 'same-origin',
            body: JSON.stringify({'category':catid}),
            headers: {
                'Accept':       'application/json',
                'Content-Type': 'application/json',
                //'X-CSRFToken':  cookie.load('csrftoken')
            }
        }
        fetch(process.env.REACT_APP_API_URL+'page_types/filter',post_data)
        .then(response => response.json())
        .then(data => {
                    console.log(data)
                    //setOrders(data)
                    setTypes(data)
                }, (error) => {
                if (error) {
                    console.log(error)
                }
        });
    }catch(e){
        //snotify()
    }           

}

    const show_success = (msg) => {
        toast.success(msg);
    }

    const handleInputChange = (e,key,field) => {
        //console.log(e.target.checked)
        if(key && field){
            const updatedObject = { ...formData };
            if(updatedObject['data'][key]==undefined){
                updatedObject['data'][key]={}
            }
            updatedObject['data'][key][field] = e.target.value
            setFormData(updatedObject); 
        }else setFormData({ ...formData, [e.target.name]: e.target.value }); 

        console.log(formData)
    };

// end modal

const handleValidation = (e) => {

    let chk = false;
    if(e) {
        e.preventDefault();
        chk = true;
    }

    let fields = formData;
    let errors = {};
    let formIsValid = true;

    if (!fields["category"]) {
      formIsValid = false;
      errors["category"] = "Please select Category";
    }

    if (!fields["page_type"]) {
        formIsValid = false;
        errors["page_type"] = "Please select Type.";
      }

    setErrors(errors);

    if (formIsValid && chk) {
    //alert("Form submitted");
        console.log(fields)
    let post_data = {
                    method: 'POST',
                    //credentials: 'same-origin',
                    //mode: 'same-origin',
                    body: JSON.stringify(fields),
                    headers: {
                        'Accept':       'application/json',
                        'Content-Type': 'application/json',
                        //'X-CSRFToken':  cookie.load('csrftoken')
                    }
                }

        
            // Simple GET request using fetch
            console.log(process.env.REACT_APP_API_URL)

            try {
                fetch(process.env.REACT_APP_API_URL+'webpages',post_data)
                .then(response => response.json())
                .then(data => {
                            console.log(data)
                            get_page_types()
                            setFormData({})
                            document.getElementById('webForm').reset()
                        show_success('Web pages added successfully!!')
                        props.parentFunction()
                    })
            }catch(e){
                console.log('err',e)
            }

        }
}

  return (
    <>
 
    <div className="modal right fade" id="myModal2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel2">
        <div className="modal-dialog main" role="document">
        <Form onSubmit={handleValidation} id="webForm">
            <div className="modal-content main">
                <div className="modal-header">

                <p className='form-heading mb-0 '>{props.page_heading}</p>

                    <button type="button" className="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>   
                </div>

                <div className="modal-body sidebar_popup">
     
                <div className='row mb-5'>
                     <div className='col-lg-6'>
                        <Form.Group  controlId="formGridState">
                            <Form.Label>Category</Form.Label>
                            <Form.Select defaultValue="Choose..." className='form-control' onChange={e => {
                                        console.log("e.target.value", e.target.value);
                                        get_page_types(e.target.value);
                                        handleInputChange(e);
                                    }}
                                name="category"
                                >
                                <option value="">Choose...</option>
                                <option value="cities">Cities</option>
                                <option value="countries">Countries</option>
                                <option value="airlines">Airlines</option>
                            </Form.Select>
                            <span style={{ color: "red" }}>{errors["category"]}</span>
                        </Form.Group>
                    </div>
                    <div className='col-lg-6'>

                        <Form.Group  controlId="formGridState">
                            <Form.Label>Type</Form.Label>
                            <Form.Select defaultValue="Choose..." className='form-control'
                            onChange={e => {
                                console.log("e.target.value", e.target);
                                const select = e.target;
                                const value = select.value;
                                const txt = select.selectedOptions[0].text;
                                //handleInputChange(e);
                                const updatedObject = { ...formData };
                                updatedObject['page_type_id']= e.target.value;
                                updatedObject[e.target.name] = txt;
                                setFormData(updatedObject)
                            }}
                            name="page_type"
                            >
                                <option value="">Choose...</option>
                                {types.length>0?types.map((ke) => (<option value={ke.id}>{ke.title}</option>)):''} 
                            </Form.Select>
                            <span style={{ color: "red" }}>{errors["page_type"]}</span>
                        </Form.Group>
     
                    </div>
                    
                </div>

                <div> 
                    {/* <CkEditorExampleComponent />        */}

                

</div>
                <Tabs defaultActiveKey="en" id="uncontrolled-tab-example" className="mb-3">
                {languages.length>0?languages.map((lang) => ( <Tab eventKey={lang.code} title={lang.name}>                    
                    
                   
 

                        <div className="row">
                            {/* <div className='col-md-12'>
                                <p className='form-heading'>{props.heading}</p>
                            </div>

                            <div className='col-md-12'>

                            </div> */}

<div className='col-md-12 form_field_popup'>
                                <Form.Group className="mb-3 f-right w-100" controlId="exampleForm.ControlInput1">
                                    <Form.Label>Main Content</Form.Label>
                                    {/* <Form.Control as="textarea" rows={3} /> */}

                                    <CKEditor
                    editor={ Editor }
                    config={ editorConfiguration }
                    data=""
                    onReady={ editor => {
                        // You can store the "editor" and use when it is needed.
                        console.log( 'Editor is ready to use!', editor );
                    } }
                    onChange={ ( event, editor ) => {
                        const data = editor.getData();
                        console.log( { event, editor, data } );
                        //setFormData({ ...formData, [lang.code+'_content']: data }); 

                        const updatedObject = { ...formData };
                        if(updatedObject['data'][lang.code]==undefined){
                            updatedObject['data'][lang.code]={}
                        }
                        updatedObject['data'][lang.code]['content'] = data
                        setFormData(updatedObject); 

                    } }
                    onBlur={ ( event, editor ) => {
                        console.log( 'Blur.', editor );
                    } }
                    onFocus={ ( event, editor ) => {
                        console.log( 'Focus.', editor );
                    } }
                />
                                   
                                </Form.Group>
                            </div> 

                            <div className='col-md-12 form_field_popup'>
                                <Form.Group className="mb-3 f-left w-100" controlId="exampleForm.ControlInput1">
                                    <Form.Label>Meta Tittle*</Form.Label>
                                    <Form.Control type="text" 
                                    onChange={e => {
                                        console.log("e.target.value", e.target.value);
                                        handleInputChange(e,lang.code,'meta_title');
                                    }}
                                    name={lang.code+'_meta_title'}
                                    placeholder="Meta Tittle" autoFocus />
                                </Form.Group>

                                {/* <Form.Group className="mb-3 f-right" controlId="exampleForm.ControlInput1">
                                    <Form.Label>Permalink: https://vmaans.com/</Form.Label>
                                    <Form.Control type="url" placeholder="https://vmaans.com/" autoFocus />
                                </Form.Group> */}
                            </div>


                            
                            <div className='col-md-12 form_field_popup'>
                                <Form.Group className="mb-3 f-right w-100" controlId="exampleForm.ControlInput1">
                                    <Form.Label>Meta  Description*</Form.Label>
                                    <Form.Control type="text" 
                                    onChange={e => {
                                        console.log("e.target.value", e.target.value);
                                        handleInputChange(e,lang.code,'meta_description');
                                    }}
                                    name={lang.code+'_meta_description'}placeholder="Meta  Description" autoFocus />
                                </Form.Group>
                            </div>
                                            
                        </div>
                        <div className='col-md-12 text-center'>

                     {/*   <div
				className="ckeditor-wrapper"
				
			>



                                     <CKEditor
                    editor={ ClassicEditor }
                    config={ editorConfiguration }
                    data="<p>Hello from CKEditor 5!</p>"
                    onReady={ editor => {
                        // You can store the "editor" and use when it is needed.
                        console.log( 'Editor is ready to use!', editor );
                    } }
                    onChange={ ( event, editor ) => {
                        const data = editor.getData();
                        console.log( { event, editor, data } );
                    } }
                    onBlur={ ( event, editor ) => {
                        console.log( 'Blur.', editor );
                    } }
                    onFocus={ ( event, editor ) => {
                        console.log( 'Focus.', editor );
                    } }
                /> 
                </div>*/}


                <button variant="primary" className="create_btn form_submit text-center" type="submit"> Submit</button>
                        </div>
                    
                    </Tab>)):''} 
                   
                </Tabs>

                    </div>
                </div>
                </Form>
            </div>
        </div>
{/* end moadl */}

  </>
  )
}
