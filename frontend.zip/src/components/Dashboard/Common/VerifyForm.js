import React, { useEffect, useState } from "react";
import { Button, Form } from "react-bootstrap";
import AxiosJWT from './AxiosJWT'
import { useDispatch } from "react-redux";
import { useHistory } from "react-router-dom/cjs/react-router-dom";
import { setIsAdmin } from "../../../redux/Action";

const VerifyForm = ({is2fa}) => {
    const dispatch = useDispatch();
  const [OTP, setOTP] = useState("");
  const [data, setData] = useState({});
  const [errorMessage, setErrorMessage] = useState(null);

  const history = useHistory();
  console.log(is2fa);
  const handleSubmit = async(e) => {
    e.preventDefault();
    console.log(OTP);
    try {
        const response = await AxiosJWT.post('https://flight-backend-ro3e.onrender.com/api/auth/verify-2fa', {
            "totp": OTP
        });
        if (response.status == 200) {
            dispatch(setIsAdmin(true));
            console.log('reached here');
            
            history.push("/admin/dashboard");
        }
    } catch (error) {
        setErrorMessage(error.response.message);
    }
  }

    useEffect(() => {
        if (!is2fa) {
            const enable2fa = async () => {
                try {
                    const response = await AxiosJWT.post('/auth/enable-2fa');
                    setData(response.data);
                } catch (error) {
                    setErrorMessage(error.response.message);
                }
            }
            enable2fa();
        }
    }, []);
  return (
    <>
      <section className="login_Section">
        <div className="login">
          <div className="container">
            <div className="row mt-4">
              <h2>Continue to your account</h2>
              <p>
                {!is2fa && (
                    <img src={data.qrCode} alt="qr" />
                )}
              </p>
            </div>
            <div className="row">
              <Form className="w-100" onSubmit={handleSubmit}>
                <Form.Group className="mb-3" controlId="">
                  <Form.Label>One Time Password</Form.Label>
                  <Form.Control
                    type="text"
                    placeholder="Enter OTP"
                    onChange={(e) => setOTP(e.target.value)}
                  />
                </Form.Group>
                {errorMessage && <p>{errorMessage}</p>}
                <Button variant="primary" type="submit">
                  Submit
                </Button>
              </Form>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default VerifyForm;
