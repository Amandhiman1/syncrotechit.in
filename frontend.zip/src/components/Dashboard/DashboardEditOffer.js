import React, { useEffect, useState } from "react";
import Sidebar from "./Common/Sidebar_menu";
import DashboardHeader from "./Common/DashboardHeader";
import { Form, Tab, Tabs } from "react-bootstrap";
import axios from "axios";
import SunEditor from "suneditor-react";
import "suneditor/dist/css/suneditor.min.css";
import AxiosJWT from "./Common/AxiosJWT";
import { toast } from "react-toastify";
import { useParams } from "react-router-dom"; // Import for getting offer ID from URL

const DashboardEditOffer = () => {
  const [airports, setAirports] = useState([]);
  const [filteredAirports, setFilteredAirports] = useState([]);
  const [airlines, setAirlines] = useState([]);
  const [languages, setLangs] = useState([]);
  const [formData, setFormData] = useState({
    from: "",
    to: "",
    price: "",
    airline: "",
    travelDate: "",
    salesValid: "",
    bagAllot: "",
    bagAllotUnit: "kg", // New state property for unit
    policy: {},
    cabin: "",
    image: null,
    createdBy: "User",
    cancelFees: "",
    changeFees: "",
    description: {},
  });
  const [errors, setErrors] = useState({});
  const { id } = useParams(); // Get offer ID from URL

  const getLanguages = async () => {
    try {
      const response = await fetch(`${process.env.REACT_APP_API_URL}languages`);
      const data = await response.json();
      if (data.length > 0) setLangs(data);
    } catch (error) {
      console.error(error);
    }
  };

  const getOfferDetails = async () => {
    try {
      const response = await AxiosJWT.get(
        `https://flight-backend-ro3e.onrender.com/api/offers/${id}`
      );
      const offer = response.data;
      console.log(offer);

      const travelDate = offer.travelDate ? new Date(offer.travelDate) : null;
      const salesValid = offer.salesValid ? new Date(offer.salesValid) : null;

      // Split bagAllot into value and unit
      const bagAllotMatch = offer.bagAllot.match(/^(\d+)\s*(kg|piece)?$/);
      const bagAllotValue = bagAllotMatch ? bagAllotMatch[1] : ""; // Numeric value
      const bagAllotUnit = bagAllotMatch ? bagAllotMatch[2] : "kg"; // Default to "kg" if not specified

      setFormData({
        from: offer.from,
        to: offer.to,
        price: offer.price,
        airline: offer.airline,
        travelDate:
          travelDate && !isNaN(travelDate.getTime())
            ? travelDate.toISOString().split("T")[0]
            : "",
        salesValid:
          salesValid && !isNaN(salesValid.getTime())
            ? salesValid.toISOString().split("T")[0]
            : "",
        bagAllot: bagAllotValue, // Set numerical part
        bagAllotUnit: bagAllotUnit, // Set unit part
        policy: offer.policy || {},
        cabin: offer.cabin,
        image: offer.image,
        createdBy: offer.createdBy,
        cancelFees: offer.cancelFees,
        changeFees: offer.changeFees,
        description: offer.desc || {},
      });
    } catch (error) {
      console.error("Error fetching offer details:", error);
    }
  };

  useEffect(() => {
    getLanguages();
    getOfferDetails(); // Fetch the details of the offer to edit

    AxiosJWT.get(
      "https://flight-backend-ro3e.onrender.com/api/airports/country-code/IN"
    )
      .then((response) => {
        setAirports(response.data);
        setFilteredAirports(response.data);
      })
      .catch((error) => {
        console.error("There was an error fetching the airports!", error);
      });

    AxiosJWT.get("https://flight-backend-ro3e.onrender.com/api/airlines")
      .then((response) => {
        setAirlines(response.data);
      })
      .catch((error) => {
        console.error("There was an error fetching the airlines!", error);
      });
  }, [id]); // Adding `id` as a dependency to refetch data if the ID changes

  const handleInputChange = (e) => {
    const { name, value, files } = e.target;
    setFormData((prevFormData) => ({
      ...prevFormData,
      [name]: name === "image" ? files[0] : value,
    }));
  };

  const handleEditorChange = (langCode, name, content) => {
    setFormData((prevFormData) => ({
      ...prevFormData,
      [name]: {
        ...prevFormData[name],
        [langCode]: content,
      },
    }));
  };

  const validateForm = () => {
    const newErrors = {};
    // Add form validation logic here if needed
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validateForm()) {
      const formDataToSend = new FormData();
      formDataToSend.append("from", formData.from);
      formDataToSend.append("to", formData.to);
      formDataToSend.append("price", formData.price);
      formDataToSend.append("airline", formData.airline);
      formDataToSend.append("travelDate", formData.travelDate);
      formDataToSend.append("salesValid", formData.salesValid);

      // Merge bagAllot and bagAllotUnit into a single string
      const bagAllotCombined = `${formData.bagAllot} ${formData.bagAllotUnit}`;
      formDataToSend.append("bagAllot", bagAllotCombined);

      formDataToSend.append("cabin", formData.cabin);
      formDataToSend.append("image", formData.image);
      formDataToSend.append("cancelFees", formData.cancelFees);
      formDataToSend.append("changeFees", formData.changeFees);

      languages.forEach((lang) => {
        formDataToSend.append(
          `desc[${lang.code}]`,
          formData.description[lang.code] || ""
        );
        formDataToSend.append(
          `policy[${lang.code}]`,
          formData.policy[lang.code] || ""
        );
      });

      AxiosJWT.put(
        `https://flight-backend-ro3e.onrender.com/api/offers/${id}`,
        formDataToSend,
        {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        }
      )
        .then((response) => {
          toast.success("Offer updated successfully");
        })
        .catch((error) => {
          toast.error(error.response.data.message);
        });
    }
  };

  return (
    <div>
      <section className="visitor-pages">
        <div className="container-fluid p-0">
          <div className="row p-0 m-0">
            <div className="col-md-2 bg-light">
              <Sidebar />
            </div>
            <div className="col-md-10">
              <header>
                <DashboardHeader />
              </header>
              <Form id="webForm" onSubmit={handleSubmit}>
                <div className="modal-content main">
                  <div className="modal-header">
                    <p className="form-heading mb-0">Edit Offer</p>
                  </div>
                  <div className="row mb-5">
                    <div className="col-lg-6">
                      <Form.Group controlId="formGridState">
                        <Form.Label>From Airport</Form.Label>
                        <Form.Select
                          className="form-control"
                          name="from"
                          onChange={handleInputChange}
                          value={formData.from}
                        >
                          <option value="">Choose...</option>
                          {filteredAirports.map((airport) => (
                            <option
                              key={airport.airport_name}
                              value={airport.airport_name}
                            >
                              {airport.airport_name}
                            </option>
                          ))}
                        </Form.Select>
                        <span style={{ color: "red" }}>{errors["from"]}</span>
                      </Form.Group>
                    </div>
                    <div className="col-lg-6">
                      <Form.Group controlId="formGridState">
                        <Form.Label>To Airport</Form.Label>
                        <Form.Select
                          className="form-control"
                          name="to"
                          onChange={handleInputChange}
                          value={formData.to}
                        >
                          <option value="">Choose...</option>
                          {filteredAirports.map((airport) => (
                            <option
                              key={airport.airport_name}
                              value={airport.airport_name}
                            >
                              {airport.airport_name}
                            </option>
                          ))}
                        </Form.Select>
                        <span style={{ color: "red" }}>{errors["to"]}</span>
                      </Form.Group>
                    </div>
                  </div>
                  <div className="row mb-5">
                    <div className="col-lg-6">
                      <Form.Group controlId="formGridState">
                        <Form.Label>Airline</Form.Label>
                        <Form.Select
                          className="form-control"
                          name="airline"
                          onChange={handleInputChange}
                          value={formData.airline}
                        >
                          {airlines.map((airline) => (
                            <option
                              key={airline.airline_name}
                              value={airline.airline_name}
                            >
                              {airline.airline_name}
                            </option>
                          ))}
                        </Form.Select>
                        <span style={{ color: "red" }}>
                          {errors["airline"]}
                        </span>
                      </Form.Group>
                    </div>
                    <div className="col-lg-6">
                      <Form.Group controlId="formPrice">
                        <Form.Label>Price</Form.Label>
                        <Form.Control
                          type="number"
                          name="price"
                          min="0"
                          onChange={handleInputChange}
                          value={formData.price}
                        />
                        <span style={{ color: "red" }}>{errors["price"]}</span>
                      </Form.Group>
                    </div>
                  </div>
                  <div className="row mb-5">
                    <div className="col-lg-6">
                      <Form.Group controlId="formTravelDate">
                        <Form.Label>Travel Date</Form.Label>
                        <Form.Control
                          type="date"
                          name="travelDate"
                          onChange={handleInputChange}
                          value={formData.travelDate}
                        />
                        <span style={{ color: "red" }}>
                          {errors["travelDate"]}
                        </span>
                      </Form.Group>
                    </div>
                    <div className="col-lg-6">
                      <Form.Group controlId="formSalesValid">
                        <Form.Label>Sales Valid Till</Form.Label>
                        <Form.Control
                          type="date"
                          name="salesValid"
                          onChange={handleInputChange}
                          value={formData.salesValid}
                        />
                        <span style={{ color: "red" }}>
                          {errors["salesValid"]}
                        </span>
                      </Form.Group>
                    </div>
                  </div>
                  <div className="row mb-5">
                    <div className="col-lg-6">
                      <Form.Group controlId="formBagAllot">
                        <Form.Label>Baggage Allowance</Form.Label>
                        <div className="d-flex">
                          <Form.Control
                            type="number"
                            name="bagAllot"
                            onChange={handleInputChange}
                            value={formData.bagAllot}
                            className="from-control"
                          />
                          <Form.Select
                            name="bagAllotUnit"
                            onChange={handleInputChange}
                            value={formData.bagAllotUnit}
                          >
                            <option value="kg">kg</option>
                            <option value="piece">piece</option>
                          </Form.Select>
                        </div>
                        <span style={{ color: "red" }}>
                          {errors["bagAllot"]}
                        </span>
                      </Form.Group>
                    </div>
                    <div className="col-lg-6">
                      <Form.Group controlId="formGridState">
                        <Form.Label>Cabin Class</Form.Label>
                        <Form.Select
                          className="form-control"
                          name="cabin"
                          onChange={handleInputChange}
                          value={formData.cabin}
                        >
                          <option value="">Choose...</option>
                          <option value="Economy">Economy</option>
                          <option value="Business">Business</option>
                        </Form.Select>
                        <span style={{ color: "red" }}>{errors["cabin"]}</span>
                      </Form.Group>
                    </div>
                  </div>
                  <div className="row mb-5">
                    <div className="col-lg-6">
                      <Form.Group controlId="formCancelFees">
                        <Form.Label>Cancellation Fees</Form.Label>
                        <Form.Control
                          type="number"
                          name="cancelFees"
                          min="0"
                          onChange={handleInputChange}
                          value={formData.cancelFees}
                        />
                        <span style={{ color: "red" }}>
                          {errors["cancelFees"]}
                        </span>
                      </Form.Group>
                    </div>
                    <div className="col-lg-6">
                      <Form.Group controlId="formChangeFees">
                        <Form.Label>Change Fees</Form.Label>
                        <Form.Control
                          type="number"
                          name="changeFees"
                          min="0"
                          onChange={handleInputChange}
                          value={formData.changeFees}
                        />
                        <span style={{ color: "red" }}>
                          {errors["changeFees"]}
                        </span>
                      </Form.Group>
                    </div>
                  </div>
                  <div className="row mb-5">
                    <div className="col-lg-6">
                      <Form.Group controlId="formImage">
                        <Form.Label>Upload Image</Form.Label>
                        <img
                          src={`https://flight-backend-ro3e.onrender.com/images/${formData.image}`}
                          alt="currentImage"
                        />
                        <Form.Control
                          type="file"
                          name="image"
                          onChange={handleInputChange}
                        />
                        <span style={{ color: "red" }}>{errors["image"]}</span>
                      </Form.Group>
                    </div>
                  </div>
                  <Tabs defaultActiveKey={languages[0]?.code} id="desc-tabs">
                    {languages.map((lang) => (
                      <Tab
                        eventKey={lang.code}
                        title={lang.name}
                        key={lang.code}
                      >
                        <Form.Group controlId={`formDesc-${lang.code}`}>
                          <Form.Label>Description</Form.Label>
                          <SunEditor
                            setContents={formData.description[lang.code] || ""}
                            onChange={(content) =>
                              handleEditorChange(
                                lang.code,
                                "description",
                                content
                              )
                            }
                          />
                          <span style={{ color: "red" }}>
                            {errors[`description_${lang.code}`]}
                          </span>
                        </Form.Group>
                        <Form.Group controlId={`formPolicy-${lang.code}`}>
                          <Form.Label>Policy</Form.Label>
                          <SunEditor
                            setContents={formData.policy[lang.code] || ""}
                            onChange={(content) =>
                              handleEditorChange(lang.code, "policy", content)
                            }
                          />
                          <span style={{ color: "red" }}>
                            {errors[`policy_${lang.code}`]}
                          </span>
                        </Form.Group>
                      </Tab>
                    ))}
                  </Tabs>
                  <div className="modal-footer">
                    <button type="submit" className="btn btn-primary">
                      Update Offer
                    </button>
                  </div>
                </div>
              </Form>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default DashboardEditOffer;
