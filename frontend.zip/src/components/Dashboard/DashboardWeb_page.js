import React from "react";
import "./Common/css/admin_style.css";
import Sidemenu from "./Common/Sidebar_menu";
import DashboardHeader from "./Common/DashboardHeader";
import { useState } from "react";
import DatePicker from "react-datepicker";
import Calendarimgs from "./Common/img/calender.svg";
import "react-datepicker/dist/react-datepicker.css";
import edit_btn from "./Common/img/edit_button.svg";
import architecture from "./Common/img/architecture-and-city (4) 1.svg";
import earth from "./Common/img/earth.svg";
import plane_webpage from "./Common/img/plane webpage.svg";
import cms from "./Common/img/cms.svg";
import { Link } from "react-router-dom";
import Typepopup from "./Common/AddTypepopup";
import { useEffect } from "react";
import EditTypepopup from "./Common/EditTypepopup";
import { useHistory } from "react-router-dom/cjs/react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { checkAdminLogin } from "../../redux/Action";
import AxiosJWT from './Common/AxiosJWT'

export default function DashboardWeb_page() {
  const isAdmin = useSelector((state) => state.reducer.isAdmin);
  const dispatch = useDispatch();
  const history = useHistory();

  

  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(null);
  const [category, setCategory] = useState("cities");

  const [countData, setCountData] = useState({});

  useEffect(() => {
    get_allcount();
  }, []);

  const parentFunction = () => {
    get_allcount();
  };

  const get_allcount = () => {
    try {
      AxiosJWT.get(process.env.REACT_APP_API_URL + "page_types/allcount")
        .then((response) => response.json())
        .then(
          (data) => {
            console.log(data);
            //setOrders(data)
            if (data.data) setCountData(data.data);
          },
          (error) => {
            if (error) {
              console.log(error);
            }
          }
        );
    } catch (e) {
      //snotify()
    }
  };

  return (
    <>
      <section className="admin-pages web_page">
        <div className="container-fluid p-0">
          <div className="row p-0 m-0">
            <div className="col-md-2 bg-light">
              <Sidemenu />
            </div>

            <div className="col-md-10 my-id2">
              <header>
                <DashboardHeader />
              </header>

              {/* header and search */}

              <div className="col-md-12 mt-4">
                <div className="row">
                  <div className="col-md-3"></div>

                  <div className="col-md-3"></div>

                  <div className="col-md-3"></div>

                  <div className="col-md-3 d-flex align-items-center justify-content-center">
                    <div className="create_button mb-3">
                      <div className="left_side_dash p-0">
                        {/* popup start onClick={()=>Dashboardpopup} */}
                        <Link to="/admin/add-page">
                          <button
                            className="create_btn" /* data-toggle="modal" data-target="#myModal2" */
                          >
                            Add New Page
                          </button>
                        </Link>
                        {/* <Dashboardpopup heading="Add Offer" page_heading='Add Web Pages'  parentFunction={parentFunction} /> */}
                        {/* end popup */}
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="row m-0 mt-4 p-3  bg-light">
                <div className="col-md-5">
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Search"
                  />
                </div>
                <div className="col-md-4 d-flex gap-div">
                  {/* <div className="mr-3 d-flex clender_str">
                    <img src={Calendarimgs} alt="" />
                    <DatePicker
                      className="form-control date_picker"
                      selected={startDate}
                      onChange={(date) => setStartDate(date)}
                      placeholderText="From"
                    />
                  </div>
                  <div className="d-flex clender_str ">
                    <img src={Calendarimgs} alt="" />
                    <DatePicker
                      className="form-control date_picker"
                      selected={endDate}
                      onChange={(date) => setEndDate(date)}
                      placeholderText="To"
                    />
                  </div> */}
                  <div class="date-input">
      <span class="icon-container">
      <img src={Calendarimgs} alt="" />
      </span>
      <input type="text" placeholder="From"/>
  </div>
  <div class="date-input">
      <span class="icon-container img-2">
      <img src={Calendarimgs} alt="" />
      </span>
      <input type="text" placeholder="To"/>
  </div>
                </div>
                <div className="col-md-1 pl-2">
                  <select
                    className="custom_select form-control"
                    id="inputGroupSelect03"
                  >
                    <option>Type</option>
                    <option value="1">One</option>
                    <option value="2">Two</option>
                  </select>
                </div>
                <div className="col-md-2">
                  <input
                    type="submit"
                    Name="shortby"
                    value="Short by"
                    className="form-control short-by"
                  />
                </div>
              </div>
              {/* header and search */}

              {/* content  */}
              <div className="call_req_id">
                <div className="row ">
                  <div className="col-md-12">
                    <div className="row">
                      <div className="col-md-2 ">
                        <div className="main_cnt_box d-flex">
                          <div className="box_cont_img_cont">
                            <span className="text-center pb-3">Cities</span>
                            <img src={architecture} alt="" />
                          </div>
                        </div>
                      </div>

                      <div className="col-md-8 webpage_cont_rows">
                        <div className="row">
                          <div className="col-md-3">
                            <div className="box_cont_img_cont">
                              <small>Total No of Cities</small>
                              <span>
                                {countData.cities ? countData.cities : 0}
                              </span>
                            </div>
                          </div>

                          <div className="col-md-3">
                            <div className="box_cont_img_cont">
                              <small>Types of URLs</small>
                              <span>
                                {countData.city_paget_count
                                  ? countData.city_paget_count
                                  : 0}
                              </span>
                            </div>
                          </div>

                          <div className="col-md-3">
                            <div className="box_cont_img_cont">
                              <small>Pages with DC</small>
                              <span>
                                {countData.city_page_count
                                  ? countData.city_page_count
                                  : 0}
                              </span>
                            </div>
                          </div>

                          <div className="col-md-3">
                            <div className="box_cont_img_cont">
                              <small>Pages with OC</small>
                              <span>
                                {countData.city_page_count
                                  ? countData.city_page_count
                                  : 0}
                              </span>
                            </div>
                          </div>
                        </div>

                        <div className="row">
                          <div className="col-md-3">
                            <div className="box_cont_img_cont">
                              <small>No of visitors</small>
                              <span>0</span>
                            </div>
                          </div>

                          <div className="col-md-3"></div>

                          <div className="col-md-3">
                            <div className="box_cont_img_cont">
                              <small>No of visitors</small>
                              <span>0</span>
                            </div>
                          </div>

                          <div className="col-md-3">
                            <div className="box_cont_img_cont">
                              <small>No of visitors</small>
                              <span>0</span>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="col-md-2 add_edit_div">
                        {/* popup start */}
                        <button
                          type="button"
                          className="create_btn_type"
                          data-toggle="modal"
                          data-target="#myModal3"
                          onClick={() => setCategory("cities")}
                        >
                          Add Type
                        </button>
                        {/* end popup */}

                        <div className="d-flex add_edit_dlt ">
                          <Link
                            className=" d-flex"
                            to="/admin/categories?type=cities"
                          >
                            <div className="img_span">
                              <img src={edit_btn} alt="" />
                            </div>
                            <div className="box_cont_img_cont pl-2">
                              <span>Edit</span>
                            </div>
                          </Link>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* content end */}

              {/* content  */}
              <div className="call_req_id">
                <div className="row ">
                  <div className="col-md-12">
                    <div className="row">
                      <div className="col-md-2">
                        <div className="main_cnt_box d-flex">
                          <div className="box_cont_img_cont">
                            <span className="text-center pb-3">countries</span>
                            <img src={earth} alt="" />
                          </div>
                        </div>
                      </div>

                      <div className="col-md-8 webpage_cont_rows">
                        <div className="row">
                          <div className="col-md-3">
                            <div className="box_cont_img_cont">
                              <small>Total No of Countries</small>
                              <span>
                                {countData.countries ? countData.countries : 0}
                              </span>
                            </div>
                          </div>

                          <div className="col-md-3">
                            <div className="box_cont_img_cont">
                              <small>Types of URLs</small>
                              <span>
                                {countData.country_paget_count
                                  ? countData.country_paget_count
                                  : 0}
                              </span>
                            </div>
                          </div>

                          <div className="col-md-3">
                            <div className="box_cont_img_cont">
                              <small>Pages with DC</small>
                              <span>
                                {countData.country_page_count
                                  ? countData.country_page_count
                                  : 0}
                              </span>
                            </div>
                          </div>

                          <div className="col-md-3">
                            <div className="box_cont_img_cont">
                              <small>Pages with OC</small>
                              <span>
                                {countData.country_page_count
                                  ? countData.country_page_count
                                  : 0}
                              </span>
                            </div>
                          </div>
                        </div>

                        <div className="row">
                          <div className="col-md-3">
                            <div className="box_cont_img_cont">
                              <small>No of visitors</small>
                              <span>0</span>
                            </div>
                          </div>

                          <div className="col-md-3"></div>

                          <div className="col-md-3">
                            <div className="box_cont_img_cont">
                              <small>No of visitors</small>
                              <span>0</span>
                            </div>
                          </div>

                          <div className="col-md-3">
                            <div className="box_cont_img_cont">
                              <small>No of visitors</small>
                              <span>0</span>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="col-md-2 add_edit_div">
                        {/* popup start */}
                        <button
                          type="button"
                          className="create_btn_type"
                          data-toggle="modal"
                          data-target="#myModal3"
                          onClick={() => setCategory("countries")}
                        >
                          Add Type
                        </button>
                        {/* <Typepopup/> */}
                        {/* end popup */}

                        <div className="d-flex add_edit_dlt">
                          <Link
                            className=" d-flex"
                            to="/admin/categories?type=countries"
                          >
                            <div className="img_span">
                              <img src={edit_btn} alt="" />
                            </div>
                            <div className="box_cont_img_cont pl-2">
                              <span>Edit</span>
                            </div>
                          </Link>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* content end */}

              {/* content  */}
              <div className="call_req_id">
                <div className="row ">
                  <div className="col-md-12">
                    <div className="row">
                      <div className="col-md-2">
                        <div className="main_cnt_box d-flex">
                          <div className="box_cont_img_cont">
                            <span className="text-center pb-3">Airlines</span>
                            <img src={plane_webpage} alt="" />
                          </div>
                        </div>
                      </div>

                      <div className="col-md-8 webpage_cont_rows">
                        <div className="row">
                          <div className="col-md-3">
                            <div className="box_cont_img_cont">
                              <small>Total No of Airlines</small>
                              <span>
                                {countData.airlines ? countData.airlines : 0}
                              </span>
                            </div>
                          </div>

                          <div className="col-md-3">
                            <div className="box_cont_img_cont">
                              <small>Types of URLs</small>
                              <span>
                                {countData.airline_paget_count
                                  ? countData.airline_paget_count
                                  : 0}
                              </span>
                            </div>
                          </div>

                          <div className="col-md-3">
                            <div className="box_cont_img_cont">
                              <small>Pages with DC</small>
                              <span>
                                {countData.airline_page_count
                                  ? countData.airline_page_count
                                  : 0}
                              </span>
                            </div>
                          </div>

                          <div className="col-md-3">
                            <div className="box_cont_img_cont">
                              <small>Pages with OC</small>
                              <span>
                                {countData.airline_page_count
                                  ? countData.airline_page_count
                                  : 0}
                              </span>
                            </div>
                          </div>
                        </div>

                        <div className="row">
                          <div className="col-md-3">
                            <div className="box_cont_img_cont">
                              <small>No of visitors</small>
                              <span>0</span>
                            </div>
                          </div>

                          <div className="col-md-3"></div>

                          <div className="col-md-3">
                            <div className="box_cont_img_cont">
                              <small>No of visitors</small>
                              <span>0</span>
                            </div>
                          </div>

                          <div className="col-md-3">
                            <div className="box_cont_img_cont">
                              <small>No of visitors</small>
                              <span>0</span>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="col-md-2 add_edit_div">
                        {/* popup start */}
                        <button
                          type="button"
                          className="create_btn_type"
                          data-toggle="modal"
                          data-target="#myModal3"
                          onClick={() => setCategory("airlines")}
                        >
                          Add Type
                        </button>
                        {/* <Typepopup/> */}
                        {/* end popup */}

                        <div className="d-flex add_edit_dlt">
                          <Link
                            className=" d-flex"
                            to="/admin/categories?type=airlines"
                          >
                            <div className="img_span">
                              <img src={edit_btn} alt="" />
                            </div>
                            <div className="box_cont_img_cont pl-2">
                              <span>Edit</span>
                            </div>
                          </Link>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* content end */}

              {/* content  */}
              <div className="call_req_id">
                <div className="row ">
                  <div className="col-md-12">
                    <div className="row">
                      <div className="col-md-2">
                        <div className="main_cnt_box d-flex">
                          <div className="box_cont_img_cont">
                            <span className="text-center pb-3">Airports</span>
                            <img src={cms} alt="" />
                          </div>
                        </div>
                      </div>

                      <div className="col-md-8 webpage_cont_rows">
                        <div className="row">
                          <div className="col-md-3">
                            <div className="box_cont_img_cont">
                              <small>Total No of Airlines</small>
                              <span>
                                {countData.airports ? countData.airports : 0}
                              </span>
                            </div>
                          </div>

                          <div className="col-md-3">
                            <div className="box_cont_img_cont">
                              <small>Types of URLs</small>
                              <span>
                                {countData.airport_paget_count
                                  ? countData.airport_paget_count
                                  : 0}
                              </span>
                            </div>
                          </div>

                          <div className="col-md-3">
                            <div className="box_cont_img_cont">
                              <small>Pages with DC</small>
                              <span>
                                {countData.airport_page_count
                                  ? countData.airport_page_count
                                  : 0}
                              </span>
                            </div>
                          </div>

                          <div className="col-md-3">
                            <div className="box_cont_img_cont">
                              <small>Pages with OC</small>
                              <span>
                                {countData.airport_page_count
                                  ? countData.airport_page_count
                                  : 0}
                              </span>
                            </div>
                          </div>
                        </div>

                        <div className="row">
                          <div className="col-md-3">
                            <div className="box_cont_img_cont">
                              <small>No of visitors</small>
                              <span>0</span>
                            </div>
                          </div>

                          <div className="col-md-3"></div>

                          <div className="col-md-3">
                            <div className="box_cont_img_cont">
                              <small>No of visitors</small>
                              <span>0</span>
                            </div>
                          </div>

                          <div className="col-md-3">
                            <div className="box_cont_img_cont">
                              <small>No of visitors</small>
                              <span>0</span>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="col-md-2 add_edit_div">
                        {/* popup start */}
                        <button
                          type="button"
                          className="create_btn_type"
                          data-toggle="modal"
                          data-target="#myModal3"
                          onClick={() => setCategory("airports")}
                        >
                          Add Type
                        </button>

                        {/* end popup */}

                        <div className="d-flex add_edit_dlt">
                          <Link
                            className=" d-flex"
                            to="/admin/categories?type=airports"
                          >
                            <div className="img_span">
                              <img src={edit_btn} alt="" />
                            </div>
                            <div className="box_cont_img_cont pl-2">
                              <span>Edit</span>
                            </div>
                          </Link>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* content end */}

              {/* content  */}
              <div className="call_req_id">
                <div className="row ">
                  <div className="col-md-12">
                    <div className="row">
                      <div className="col-md-2">
                        <div className="main_cnt_box d-flex">
                          <div className="box_cont_img_cont">
                            <span className="text-center pb-3">CMS</span>
                            <img src={cms} alt="" />
                          </div>
                        </div>
                      </div>

                      <div className="col-md-8 webpage_cont_rows">
                        <div className="row">
                          <div className="col-md-3">
                            <div className="box_cont_img_cont">
                              <small>Total No of CMS Pages</small>
                              <span>0</span>
                            </div>
                          </div>

                          <div className="col-md-3">
                            <div className="box_cont_img_cont">
                              <small>Types of URLs</small>
                              <span>0</span>
                            </div>
                          </div>

                          <div className="col-md-3">
                            <div className="box_cont_img_cont">
                              <small>Pages with DC</small>
                              <span>0</span>
                            </div>
                          </div>

                          <div className="col-md-3">
                            <div className="box_cont_img_cont">
                              <small>Pages with OC</small>
                              <span>0</span>
                            </div>
                          </div>
                        </div>

                        <div className="row">
                          <div className="col-md-3">
                            <div className="box_cont_img_cont">
                              <small>No of visitors</small>
                              <span>0</span>
                            </div>
                          </div>

                          <div className="col-md-3"></div>

                          <div className="col-md-3">
                            <div className="box_cont_img_cont">
                              <small>No of visitors</small>
                              <span>0</span>
                            </div>
                          </div>

                          <div className="col-md-3">
                            <div className="box_cont_img_cont">
                              <small>No of visitors</small>
                              <span>0</span>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="col-md-2 add_edit_div">
                        {/* popup start */}
                        {/* <button type="button" className="create_btn_type" data-toggle="modal" data-target="#myModal3">
                                                    Add Type
                                                </button>
                                                    <Typepopup/> */}
                        {/* end popup */}
                        <button
                          type="button"
                          className="create_btn_type"
                          data-toggle="modal"
                          data-target="#myModal3"
                          onClick={() => setCategory("cms")}
                        >
                          Add Type
                        </button>

                        <div className="d-flex add_edit_dlt">
                          <Link className="d-flex" to="/admin/cms-pages">
                            <div className="img_span">
                              <img src={edit_btn} alt="" />
                            </div>
                            <div className="box_cont_img_cont pl-2">
                              <span>Edit</span>
                            </div>
                          </Link>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* content end */}
            </div>
          </div>
        </div>
      </section>
      <Typepopup category={category} parentFunction={parentFunction} />
    </>
  );
}
