import React, { useEffect, useState } from "react";
import "./Common/css/admin_style.css";
import Sidemenu from "./Common/Sidebar_menu";
import DashboardHeader from "./Common/DashboardHeader";
import DatePicker from "react-datepicker";
import Calendarimgs from "./Common/img/calender.svg";
import "react-datepicker/dist/react-datepicker.css";
import celendr from "./Common/img/calendar2.svg";
import jobs from "./Common/img/jobs.svg";
import edit_btn from "./Common/img/edit_button.svg";
import del_btn from "./Common/img/delt_button.svg";
import { Link } from "react-router-dom";
import { format } from "date-fns";
import AxiosJWT from "./Common/AxiosJWT";
import Modal from "react-bootstrap/Modal";
import Button from "react-bootstrap/Button";

export default function DashboardJobspage() {
  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(null);
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [applicants, setApplicants] = useState([]);
  const [selectedJobId, setSelectedJobId] = useState(null);

  useEffect(() => {
    const fetchJobs = async () => {
      try {
        const response = await AxiosJWT.get("https://flight-backend-ro3e.onrender.com/api/job");
        console.log(response.data);
        setJobs(response.data);
      } catch (err) {
        setError("Failed to fetch jobs");
      } finally {
        setLoading(false);
      }
    };

    fetchJobs();
  }, []);

  const fetchApplicants = async (jobId) => {
    try {
      const response = await AxiosJWT.get(
        `https://flight-backend-ro3e.onrender.com/api/jobs/${jobId}/applications`
      );
      console.log(response.data);

      setApplicants(response.data);
      setSelectedJobId(jobId);
      setShowModal(true);
    } catch (err) {
      console.error(err);

      setError("Failed to fetch applicants");
    }
  };

  const deleteJob = async (jobSlug) => {
    if (window.confirm("Are you sure you want to delete this job?")) {
      try {
        await AxiosJWT.delete(`https://flight-backend-ro3e.onrender.com/api/job/${jobSlug}`);
        setJobs(jobs.filter((job) => job.jobSlug !== jobSlug));
      } catch (err) {
        console.error("Failed to delete the job", err);
        setError("Failed to delete the job");
      }
    }
  };

  const handleClose = () => setShowModal(false);

  if (loading) {
    return <p>Loading...</p>;
  }

  if (error) {
    return <p>{error}</p>;
  }

  return (
    <>
      <section className="admin-pages job_page">
        <div className="container-fluid p-0">
          <div className="row p-0 m-0">
            <div className="col-md-2 bg-light">
              <Sidemenu />
            </div>

            <div className="col-md-10 my-id2">
              <header>
                <DashboardHeader />
              </header>

              {/* header start */}
              <div className="col-md-12 mb-4 mt-4">
                <div className="row">
                  <div className="col-md-3"></div>
                  <div className="col-md-3"></div>
                  <div className="col-md-3"></div>
                  <div className="col-md-3 d-flex align-items-center justify-content-center">
                    <div className="create_button">
                      <div className="left_side_dash p-0">
                        <Link to="/admin/add-job">
                          <button className="create_btn">Add new job</button>
                        </Link>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              {/*  */}
              <div className="row m-0 mt-4 p-3 bg-light">
                <div className="col-md-5">
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Search"
                  />
                </div>
                <div className="col-md-4 d-flex gap-div">
                <div class="date-input">
      <span class="icon-container">
      <img src={Calendarimgs} alt="" />
      </span>
      <input type="text" placeholder="From"/>
  </div>
  <div class="date-input">
      <span class="icon-container img-2">
      <img src={Calendarimgs} alt="" />
      </span>
      <input type="text" placeholder="To"/>
  </div>
  
                  {/* <div className="mr-3 d-flex clender_str">
                    <img src={Calendarimgs} alt="" />
                    <DatePicker
                      className="form-control date_picker"
                      selected={startDate}
                      onChange={(date) => setStartDate(date)}
                      placeholderText="From"
                    />
                  </div>
                  <div className="d-flex clender_str ">
                    <img src={Calendarimgs} alt="" />
                    <DatePicker
                      className="form-control date_picker"
                      selected={endDate}
                      onChange={(date) => setEndDate(date)}
                      placeholderText="To"
                    />
                  </div> */}
                </div>
                <div className="col-md-1 pl-2">
                  <select
                    className="custom_select form-control"
                    id="inputGroupSelect03"
                  >
                    <option>Type</option>
                    <option value="1">One</option>
                    <option value="2">Two</option>
                  </select>
                </div>
                <div className="col-md-2">
                  <input
                    type="submit"
                    name="shortby"
                    value="Short by"
                    className="form-control short-by"
                  />
                </div>
              </div>

              {/* end header */}

              {/* content */}
              {jobs.map((job) => (
                <div className="call_req_id" key={job._id}>
                  <div className="row">
                    <div className="col-md-12">
                      <div className="row">
                        <div className="col-md-4">
                          <div className="main_cnt_box d-flex w-100">
                            <div className="img_span">
                              <img src={jobs} alt="" />
                            </div>
                            <div className="box_cont_img_cont">
                              <small>Post Name</small>
                              <span>{job.jobTitle.en}</span>
                            </div>
                          </div>
                        </div>

                        <div className="col-md-4">
                          <div className="main_cnt_box d-flex w-100">
                            <div className="img_span">
                              <img src={celendr} alt="" />
                            </div>
                            <div className="box_cont_img_cont">
                              <small>Last Update</small>
                              <span>
                                {format(
                                  new Date(job.createdAt),
                                  "EEE dd MMM yyyy HH:mm"
                                )}
                              </span>
                            </div>
                          </div>
                        </div>

                        {/* add edit delete start */}
                        <div className="col-md-4">
                          <div className="d-flex add_edit_dlt">
                            <Link to={`/admin/edit-job/${job.jobSlug}`} className=" d-flex">
                              <div className="img_span">
                                <img src={edit_btn} alt="" />
                              </div>
                              <div className="box_cont_img_cont pl-2">
                                <span>Edit</span>
                              </div>
                            </Link>

                            <div
                              className="d-flex"
                              onClick={() => deleteJob(job.jobSlug)}
                            >
                              <div className="img_span">
                                <img src={del_btn} alt="Delete" />
                              </div>
                              <div className="box_cont_img_cont">
                                <span>Delete</span>
                              </div>
                            </div>
                          </div>
                        </div>
                        {/* add edit delete end */}
                      </div>

                      <hr className="hr_dashbord" />

                      {/* start second row */}
                      <div className="row">
                        <div className="secd_lins">
                          <div className="main_cnt_box d-flex">
                            <div className="box_cont_img_cont">
                              <small>Location</small>
                              <span>{job.location}</span>
                            </div>
                          </div>

                          <div className="main_cnt_box d-flex">
                            <div className="box_cont_img_cont">
                              <small>No of Post</small>
                              <span>05</span>
                            </div>
                          </div>

                          <div className="main_cnt_box d-flex">
                            <div className="box_cont_img_cont">
                              <small>No of Applicants</small>
                              <span>20</span>
                            </div>
                          </div>

                          <div className="main_cnt_box d-flex">
                            <div className="box_cont_img_cont">
                              <small>No of Visitors</small>
                              <span>2500</span>
                            </div>
                          </div>

                          <div className="main_cnt_box d-flex">
                            <div className="left_side_dash p-0">
                              <button
                                className="create_btn"
                                onClick={() => fetchApplicants(job._id)}
                              >
                                View applicant
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                      {/* end second row */}
                    </div>
                  </div>
                </div>
              ))}
              {/* content end */}
            </div>
          </div>
        </div>
      </section>

      {/* Modal for applicants */}
      <Modal show={showModal} onHide={handleClose} size="lg">
        <Modal.Header closeButton>
          <Modal.Title>Applicants</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {applicants.length > 0 ? (
            applicants.map((applicant) => (
              <div key={applicant.id} className="applicant-details">
                <p>Name: {applicant.name}</p>
                <p>Email: {applicant.email}</p>
                <p>Phone: {applicant.phone}</p>
                <Link
                  to={{
                    pathname: `https://flight-backend-ro3e.onrender.com/cv/${applicant.cvFile}`,
                  }}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  View CV
                </Link>

                <hr />
              </div>
            ))
          ) : (
            <p>No applicants found.</p>
          )}
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
}
