import React, { useEffect, useState } from "react";
import "./Common/css/admin_style.css";
import DashboardHeader from "./Common/DashboardHeader";
import { Form, Tab, Tabs } from "react-bootstrap";
import SunEditor from "suneditor-react";
import Sidebar from "./Common/Sidebar_menu";
import { toast } from "react-toastify";
import AxiosJWT from "./Common/AxiosJWT";

const DashboardAddJob = () => {
  const [languages, setLangs] = useState([]);
  const [cities, setCities] = useState([]);
  const [formData, setFormData] = useState({
    jobTitle: {},
    jobDesc: {},
    location: "",
    department: "",
  });
  const [errors, setErrors] = useState({});

  const getLanguages = async () => {
    try {
      const response = await fetch(`https://flight-backend-ro3e.onrender.com/api/languages`);
      const data = await response.json();
      if (data.length > 0) setLangs(data);
    } catch (error) {
      console.error(error);
    }
  };

  const getCities = async () => {
    try {
      const response = await AxiosJWT.get(`https://flight-backend-ro3e.onrender.com/api/cities`);
      const data = await response.data;
      console.log(data);
      if (data.length > 0) setCities(data);
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    getLanguages();
    getCities();
  }, []);

  const handleChange = (lang, field, value) => {
    // Regex to allow only alphabetic characters and spaces
    const isValid = /^[A-Za-z\s]*$/.test(value) || field === "jobDesc"; // Allow any characters for jobDesc

    if (!isValid) {
      setErrors((prevErrors) => ({
        ...prevErrors,
        [`${field}-${lang}`]: "Only letters and spaces are allowed.",
      }));
      return;
    }

    setErrors((prevErrors) => ({
      ...prevErrors,
      [`${field}-${lang}`]: "", // Clear error if input is valid
    }));

    setFormData((prevState) => ({
      ...prevState,
      [field]: {
        ...prevState[field],
        [lang]: value,
      },
    }));
  };

  const handleFieldChange = (field, value) => {
    // Regex to allow only alphabetic characters and spaces
    const isValid = /^[A-Za-z\s]*$/.test(value);

    if (!isValid) {
      setErrors((prevErrors) => ({
        ...prevErrors,
        [field]: "Only letters and spaces are allowed.",
      }));
      return;
    }

    setErrors((prevErrors) => ({
      ...prevErrors,
      [field]: "", // Clear error if input is valid
    }));

    setFormData((prevState) => ({
      ...prevState,
      [field]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    console.log(formData);

    try {
      const response = await AxiosJWT.post(
        `https://flight-backend-ro3e.onrender.com/api/job`,
        formData
      );
      const data = await response.data; // Use `response.data` to get the JSON data
      console.log(data);
      toast.success("New job created");
    } catch (error) {
      console.error(error);
      toast.error("Error creating job");
    }
  };

  return (
    <div>
      <section className="visitor-pages">
        <div className="container-fluid p-0">
          <div className="row p-0 m-0">
            <div className="col-md-2 bg-light">
              <Sidebar />
            </div>
            <div className="col-md-10">
              <header>
                <DashboardHeader />
              </header>
              <Form id="webForm" onSubmit={handleSubmit}>
                <div className="modal-content main">
                  <div className="modal-header">
                    <p className="form-heading mb-0">Add Job</p>
                  </div>
                  <div className="row mb-5">
                    <div className="col-lg-6">
                      <Form.Group className="mb-3" controlId="formLocation">
                        <Form.Label>Location*</Form.Label>
                        <Form.Select
                          value={formData.location}
                          className="form-control"
                          required
                          onChange={(e) =>
                            handleFieldChange("location", e.target.value)
                          }
                        >
                          <option value="">Select Location...</option>
                          {cities.map((city) => (
                            <option value={city.english} key={city.english}>
                              {city.english}
                            </option>
                          ))}
                        </Form.Select>
                      </Form.Group>
                    </div>
                    <div className="col-lg-6">
                      <Form.Group className="mb-3" controlId="formDepartment">
                        <Form.Label>Department*</Form.Label>
                        <Form.Control
                          type="text"
                          value={formData.department}
                          required
                          onChange={(e) =>
                            handleFieldChange("department", e.target.value)
                          }
                        />
                        {errors["department"] && (
                          <span style={{ color: "red" }}>
                            {errors["department"]}
                          </span>
                        )}
                      </Form.Group>
                    </div>
                  </div>
                  <Tabs
                    defaultActiveKey="en"
                    id="uncontrolled-tab-example"
                    className="mb-3"
                  >
                    {languages.map((lang) => (
                      <Tab
                        key={lang.code}
                        eventKey={lang.code}
                        title={lang.name}
                      >
                        <div className="row">
                          <div className="col-md-12 form_field_popup">
                            <Form.Group
                              className="mb-3 f-left w-100"
                              controlId={`title-${lang.code}`}
                            >
                              <Form.Label>Job Title*</Form.Label>
                              <Form.Control
                                type="text"
                                required
                                value={formData.jobTitle[lang.code] || ""}
                                onChange={(e) =>
                                  handleChange(
                                    lang.code,
                                    "jobTitle",
                                    e.target.value
                                  )
                                }
                              />
                              {errors[`jobTitle-${lang.code}`] && (
                                <span style={{ color: "red" }}>
                                  {errors[`jobTitle-${lang.code}`]}
                                </span>
                              )}
                            </Form.Group>
                            <Form.Label>Job Description</Form.Label>
                            <SunEditor
                              setOptions={{
                                height: 200,
                                buttonList: [
                                  ["undo", "redo"],
                                  ["font", "fontSize", "formatBlock"],
                                  ["paragraphStyle", "blockquote"],
                                  [
                                    "bold",
                                    "underline",
                                    "italic",
                                    "strike",
                                    "subscript",
                                    "superscript",
                                  ],
                                  ["fontColor", "hiliteColor", "textStyle"],
                                  ["removeFormat"],
                                  "/",
                                  ["outdent", "indent"],
                                  [
                                    "align",
                                    "horizontalRule",
                                    "list",
                                    "lineHeight",
                                  ],
                                  ["table", "link", "image", "video", "audio"],
                                  ["fullScreen", "showBlocks", "codeView"],
                                  ["preview", "print"],
                                  ["save", "template"],
                                ],
                              }}
                              onChange={(content) =>
                                handleChange(lang.code, "jobDesc", content)
                              }
                            />
                          </div>
                        </div>
                      </Tab>
                    ))}
                  </Tabs>
                  <div className="col-md-12 form_field_popup">
                    <button
                      variant="primary"
                      className="create_btn form_submit text-center"
                      type="submit"
                    >
                      Submit
                    </button>
                  </div>
                </div>
              </Form>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default DashboardAddJob;
