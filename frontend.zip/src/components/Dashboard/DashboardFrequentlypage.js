import React, { useEffect } from "react";
import "./Common/css/admin_style.css";
import Sidemanu from "./Common/Sidebar_menu";
import DashboardHeader from "./Common/DashboardHeader";
import { useState } from "react";
import DatePicker from "react-datepicker";
import Calendarimgs from "./Common/img/calender.svg";
import "react-datepicker/dist/react-datepicker.css";
import celendr from "./Common/img/calendar2.svg";
import edit_btn from "./Common/img/edit_button.svg";
import eye_icon from "./Common/img/eye_icon.svg";
import del_btn from "./Common/img/delt_button.svg";
import faq from "./Common/img/faq.svg";
import { Link } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { useHistory } from "react-router-dom/cjs/react-router-dom";
import { Form, Tab, Tabs } from "react-bootstrap";
import axios from "axios";
import SunEditor, { buttonList } from "suneditor-react";
import "suneditor/dist/css/suneditor.min.css";
import { checkAdminLogin } from "../../redux/Action";
import Swal from "sweetalert2";
import { format } from "date-fns";
import AxiosJWT from './Common/AxiosJWT'

export default function DashboardFrequentlypage() {
  const [languages, setLangs] = useState([]);
  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(null);
  const [formType, setFormType] = useState("Topic");
  const [categories, setCategories] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState([]);
  const [selectedArticles, setSelectedArticles] = useState([]);
  const [dataType, setDataType] = useState("question");
  const [searchQuery, setSearchQuery] = useState("");

  // const [topicFormValues, setTopicFormValues] = useState({
  //   name: "",
  // });

  const [topicFormValues, setTopicFormValues] = useState(
    languages.reduce((acc, lang) => {
      acc[lang.code] = { name: "" };
      return acc;
    }, {})
  );

  const [questionFormValues, setQuestionFormValues] = useState({
    faqCategory: "",
    name: languages.reduce((acc, lang) => {
      acc[lang.code] = { name: "" };
      return acc;
    }, {}),
  });

  const isAdmin = useSelector((state) => state.reducer.isAdmin);
  const dispatch = useDispatch();
  const history = useHistory();

  const showalert = (heading) => {
    Swal.fire({
      title: heading,
      icon: "question",
      customClass: {
        popup: "my-popup",
        confirmButton: "my-confirm-button",
        cancelButton: "my-cancel-button",
      },
    });
  };

  const getCategories = async () => {
    const res = await AxiosJWT.get(
      "https://flight-backend-ro3e.onrender.com/api/faqCategory"
    );
    console.log(res.data);
    setCategories(res.data);
  };

  const get_langauages = () => {
    try {
      AxiosJWT
        .get("https://flight-backend-ro3e.onrender.com/api/languages")
        // .then((response) => response.json())
        .then(
          (data) => {
            console.log(data.data);
            //setOrders(data)
            if (data.data.length > 0) setLangs(data.data);
          },
          (error) => {
            if (error) {
              console.log(error);
            }
          }
        );
    } catch (e) {
      //snotify()
      console.error(e);
    }
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    // Handle form submission here
    if (formType == "Topic") {
      console.log(topicFormValues);
      AxiosJWT
        .post("https://flight-backend-ro3e.onrender.com/api/faqCategory", {
          title: topicFormValues,
        })
        .then((res) => {
          console.log(res);
          showalert("New Topic added successfully");
          getCategories();
          setTopicFormValues(
            languages.reduce((acc, lang) => {
              acc[lang.code] = { name: "" };
              return acc;
            }, {})
          );
        })
        .catch((err) => {
          console.error(err);
          showalert("some error occured");
        });
    } else {
      console.log(questionFormValues);
      AxiosJWT
        .post(
          "https://flight-backend-ro3e.onrender.com/api/faqQuestion",
          questionFormValues
        )
        .then((res) => {
          console.log(res);
          showalert("new question added successfully");
          setQuestionFormValues({
            faqCategory: "",
            name: languages.reduce((acc, lang) => {
              acc[lang.code] = { name: "" };
              return acc;
            }, {}),
          });
        })
        .catch((err) => {
          console.error(err);
          showalert("some error occured");
        });
    }
  };

  // const handleSubmit = (event) => {
  //   event.preventDefault();

  //   console.log(questionFormValues);
  // };

  const handleTopicFormChange = (e, langCode) => {
    const { name, value } = e.target;
    setTopicFormValues((prevValues) => ({
      ...prevValues,
      [langCode]: {
        ...prevValues[langCode],
        [name]: value,
      },
    }));
  };

  const convertDate = (isoDate) => {
    const date = new Date(isoDate);
    return format(date, "EEE dd MMM yyyy HH:mm");
  };

  const handleQuestionFormChange = (event, langCode) => {
    const { name, value } = event.target;
    if (langCode) {
      setQuestionFormValues((prevValues) => ({
        ...prevValues,
        name: {
          ...prevValues.name,
          [langCode]: {
            ...prevValues[langCode],
            [name]: value,
          },
        },
      }));
    } else {
      setQuestionFormValues((prevValues) => ({
        ...prevValues,
        [name]: value,
      }));
    }
  };

  const handleGetArticles = async (question) => {
    const res = await AxiosJWT.get(
      `https://flight-backend-ro3e.onrender.com/api/faqQuestion/${question}`
    );
    console.log(res.data);
    setSelectedArticles(res.data.faqArticles);
    setDataType("articles");
  };

  const handleDelete = async (Id, slugType) => {
    try {
      const response = await AxiosJWT.delete(
        `https://flight-backend-ro3e.onrender.com/api/${slugType}/${Id}`
      );
      if (response.status === 200) {
        // Remove the deleted article from the state
        getCategories();
        showalert("Deleted successfully");
      }
    } catch (error) {
      console.error("Error deleting:", error);
      showalert("Failed to delete");
    }
  };

  const filteredCategories = categories.filter(category =>
    category.title.en.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  

  useEffect(() => {
    get_langauages();
    getCategories();
  }, []);

  return (
    <>
      <section className="admin-pages faq_page">
        <div className="container-fluid p-0">
          <div className="row p-0 m-0">
            <div className="col-md-2 bg-light">
              <Sidemanu />
            </div>

            <div className="col-md-10 my-id2">
              <header>
                <DashboardHeader />
              </header>
              <div className="col-md-12 mb-4 mt-4">
                <div className="row">
                  <div className="col-md-3"></div>

                  <div className="col-md-3"></div>

                  <div className="col-md-3"></div>

                  <div className="col-md-3 d-flex align-items-center justify-content-center">
                    <div className="create_button ">
                      <div className="left_side_dash p-0">
                        <button
                          type="button"
                          class="create_btn btn-main"
                          data-toggle="modal"
                          data-target="#myModal3"
                        >
                          Add new topic
                        </button>
                        <Link to="/admin/add-article">
                          <button type="button" class="create_btn btn-main">
                            Add new article
                          </button>
                        </Link>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              {/*  */}
              <div className="row m-0 mt-4 p-3  bg-light">
                <div className="col-md-5">
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Search"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
                {/* <div className="col-md-4 d-flex">
                  <div className="mr-3 d-flex clender_str">
                    <img src={Calendarimgs} alt="" />

                    <DatePicker
                      className="form-control date_picker"
                      selected={startDate}
                      onChange={(date) => setStartDate(date)}
                      placeholderText="From"
                    />
                  </div>
                  <div className="d-flex clender_str ">
                    <img src={Calendarimgs} alt="" />
                    <DatePicker
                      className="form-control date_picker"
                      selected={endDate}
                      onChange={(date) => setEndDate(date)}
                      placeholderText="To"
                    />
                  </div>
                </div>
                <div className="col-md-1 pl-2">
                  <select
                    className="custom_select form-control"
                    id="inputGroupSelect03"
                  >
                    <option>Type</option>
                    <option value="1">One</option>
                    <option value="2">Two</option>
                  </select>
                </div>
                <div className="col-md-2">
                  <input
                    type="submit"
                    className="form-control"
                    Name="shortby"
                    value="Short by"
                    class="form-control short-by"
                  />
                </div> */}
              </div>

              {/* end header */}

              {/* content */}

              {filteredCategories.map((category) => (
                <div className="call_req_id">
                  <div className="row ">
                    <div className="col-md-12">
                      <div className="row">
                        <div className="col-md-2 ">
                          <div className="main_cnt_box d-flex w-100">
                            <div className="img_span">
                              <img src={faq} alt="" />
                            </div>
                            <div className="box_cont_img_cont">
                              <small>Topic</small>
                              <span>{category.title.en.name}</span>
                            </div>
                          </div>
                        </div>

                        <div className="col-md-6 ">
                          <div className="main_cnt_box d-flex w-100">
                            <div className="img_span">
                              <img src={celendr} alt="" />
                            </div>
                            <div className="box_cont_img_cont">
                              <small>Last Update</small>
                              <span>{convertDate(category.createdAt)}</span>
                            </div>
                          </div>
                        </div>

                        {/* add edit delt start */}

                        <div className="col-md-4 pr-5">
                          <div className="d-flex add_edit_dlt">
                            <div
                              className=" d-flex"
                              data-toggle="modal"
                              data-target="#myModal1"
                              onClick={() =>
                                setSelectedCategory(category.questions)
                              }
                            >
                              <div className="img_span">
                                <img src={eye_icon} alt="" width='35px' />
                              </div>
                              <div className="box_cont_img_cont pl-2">
                                <span>View questions</span>
                              </div>
                            </div>

                            <div
                              className=" d-flex "
                              onClick={() =>
                                handleDelete(category._id, "faqCategory")
                              }
                            >
                              <div className="img_span">
                                <img src={del_btn} alt="" />
                              </div>
                              <div className="box_cont_img_cont">
                                <span>Delete</span>
                              </div>
                            </div>
                          </div>
                        </div>

                        {/* add edit delt end */}
                      </div>

                      {/* end first row */}

                      <hr className="hr_dashbord" />

                      {/* start second row**/}

                      <div className="row">
                        <div className="secd_lins">
                          <div className="main_cnt_box d-flex">
                            <div className="box_cont_img_cont">
                              <small>Domain</small>
                              <span>www.xyz.com</span>
                            </div>
                          </div>

                          <div className="main_cnt_box d-flex">
                            <div className="box_cont_img_cont">
                              <small>Link with</small>
                              <span>www.xyz.com/how-can-we-help-you</span>
                            </div>
                          </div>

                          <div className="main_cnt_box d-flex">
                            <div className="box_cont_img_cont">
                              <small>No of Visitor</small>
                              <span>2500</span>
                            </div>
                          </div>

                          <div className="main_cnt_box d-flex">
                            <div className="box_cont_img_cont">
                              <small>Number of Questions</small>
                              <span>{category.questions.length}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                      {/* end second row */}
                    </div>
                  </div>
                </div>
              ))}
              {/* content end */}
            </div>
          </div>
          <div
            className="modal right fade"
            id="myModal1"
            tabindex="-1"
            role="dialog"
            aria-labelledby="myModalLabel1"
          >
            <div className="modal-dialog main" role="document">
              <div className="modal-content main">
                <div className="modal-header">
                  <button
                    type="button"
                    className="close"
                    data-dismiss="modal"
                    aria-label="Close"
                  >
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>

                <div className="modal-body modal-main sidebar_popup">
                  {dataType === "question" ? (
                    selectedCategory.map((question) => (
                      <div className="d-flex" key={question.slug}>
                        <div>{question.title.en.name}</div>
                        <div onClick={() => handleGetArticles(question.slug)}>
                          <div className="d-flex">
                            <div className="img_span">
                              <img src={eye_icon} alt="edit" width='35px' />
                            </div>
                          </div>
                        </div>
                        <div>
                          <div
                            className="d-flex"
                            onClick={() =>
                              handleDelete(question._id, "faqQuestion")
                            }
                          >
                            <div className="img_span">
                              <img src={del_btn} alt="delete" />
                            </div>
                          </div>
                        </div>
                      </div>
                    ))
                  ) : selectedArticles.length === 0 ? (
                    <div>No data</div>
                  ) : (
                    <>
                      <div onClick={() => setDataType("question")}>Back</div>
                      {selectedArticles.map((article) => (
                        <div className="d-flex" key={article.slug}>
                          <div>{article.title.en.title}</div>
                          <Link to={`/article/${article.slug}`} target='_blank'>
                            <div className="d-flex">
                              <div className="img_span">
                                <img src={eye_icon} alt="edit" width='35px' />
                              </div>
                            </div>
                          </Link>
                          <div>
                            <div
                              className="d-flex"
                              onClick={() =>
                                handleDelete(article._id, "faqArticle")
                              }
                            >
                              <div className="img_span">
                                <img src={del_btn} alt="delete" />
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </>
                  )}
                </div>
              </div>
            </div>
          </div>

          <div
            className="modal right fade"
            id="myModal3"
            tabindex="-1"
            role="dialog"
            aria-labelledby="myModalLabel3"
          >
            <div className="modal-dialog main" role="document">
              <div className="modal-content main">
                <div className="modal-header">
                  <button
                    type="button"
                    className="close"
                    data-dismiss="modal"
                    aria-label="Close"
                  >
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>

                <div className="modal-body modal-main sidebar_popup">
                  <div className="flex justify-between mb-6">
                    <button
                      className="create_btn fq-btn Text-white font-bold py-2.5 px-4 rounded ml-20"
                      onClick={() => {
                        setFormType("Topic");
                      }}
                    >
                      Add New Topic
                    </button>
                    <button
                      className="create_btn fq-btn faq-btn Text-white font-bold py-2.5 px-4 rounded ml-20"
                      onClick={() => {
                        setFormType("Question");
                      }}
                    >
                      Add New Question
                    </button>
                  </div>
                  <Form
                    onSubmit={handleSubmit}
                    id="topicForm"
                    className="common-form common-form-border login-signup-form"
                    autoComplete="off"
                  >
                    <div className="row mb-5">
                      {formType === "Topic" ? (
                        <div className="col-lg-12">
                          <Tabs
                            defaultActiveKey="en"
                            id="uncontrolled-tab-example"
                            className="mb-3"
                          >
                            {languages.length > 0 &&
                              languages.map((lang) => (
                                <Tab
                                  key={lang.code}
                                  eventKey={lang.code}
                                  title={lang.name}
                                >
                                  <Form.Group
                                    className="mb-3 f-left w-100"
                                    controlId="exampleForm.ControlInput1"
                                  >
                                    <Form.Label>Topic Name</Form.Label>
                                    <Form.Control
                                      type="text"
                                      name="name"
                                      value={topicFormValues.name}
                                      onChange={(e) =>
                                        handleTopicFormChange(e, lang.code)
                                      }
                                    />
                                  </Form.Group>
                                </Tab>
                              ))}
                          </Tabs>
                          <button
                            variant="primary"
                            className="create_btn form_submit text-center shrink-border sub-btn"
                            type="submit"
                          >
                            Submit
                          </button>
                        </div>
                      ) : (
                        <div className="col-lg-12">
                          <Form.Group controlId="formGridState">
                            <Form.Label>Topic</Form.Label>
                            <Form.Select
                              defaultValue="Choose..."
                              className="form-control"
                              name="faqCategory"
                              value={questionFormValues.faqCategory}
                              onChange={handleQuestionFormChange}
                            >
                              <option value="">Choose...</option>
                              {categories ? (
                                categories.map((category) => (
                                  <option
                                    key={category._id}
                                    value={category._id}
                                  >
                                    {category.slug}
                                  </option>
                                ))
                              ) : (
                                <option value="">No topic available</option>
                              )}
                            </Form.Select>
                          </Form.Group>
                          <Tabs
                            defaultActiveKey="en"
                            id="uncontrolled-tab-example"
                            className="mb-3"
                          >
                            {languages.length > 0 &&
                              languages.map((lang) => (
                                <Tab
                                  key={lang.code}
                                  eventKey={lang.code}
                                  title={lang.name}
                                >
                                  <Form.Group
                                    className="mb-3 f-left w-100"
                                    controlId="exampleForm.ControlInput1"
                                  >
                                    <Form.Label>Question title</Form.Label>
                                    <Form.Control
                                      type="text"
                                      name="name"
                                      value={
                                        questionFormValues.name[lang.code]?.name
                                      }
                                      onChange={(e) =>
                                        handleQuestionFormChange(e, lang.code)
                                      }
                                    />
                                  </Form.Group>
                                </Tab>
                              ))}
                          </Tabs>
                          <button
                            variant="primary"
                            className="create_btn form_submit text-center"
                            type="submit"
                          >
                            Submit
                          </button>
                        </div>
                      )}
                    </div>
                  </Form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
