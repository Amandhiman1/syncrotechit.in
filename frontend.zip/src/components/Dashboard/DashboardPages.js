import React from "react";
import "./Common/css/admin_style.css";
import Sidemenu from "./Common/Sidebar_menu";
import DashboardHeader from "./Common/DashboardHeader";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faArrowUp } from "@fortawesome/free-solid-svg-icons";
import { faArrowDown } from "@fortawesome/free-solid-svg-icons";
// import DatePicker from "react-datepicker";
// import Calendarimgs from './Common/img/calender.svg';
import "react-datepicker/dist/react-datepicker.css";
import { useParams } from "react-router-dom";
import edit_btn from "./Common/img/edit_button.svg";
import del_btn from "./Common/img/delt_button.svg";
import eye_icon from "./Common/img/eye_icon.svg";
import { Link } from "react-router-dom";

import { confirmAlert } from "react-confirm-alert"; // Import
import "react-confirm-alert/src/react-confirm-alert.css";

import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { useState } from "react";
import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useHistory } from "react-router-dom/cjs/react-router-dom";
import { checkAdminLogin } from "../../redux/Action";
import AxiosJWT from "./Common/AxiosJWT";

export default function DashboardVisitersPage() {
  const isAdmin = useSelector((state) => state.reducer.isAdmin);
  const dispatch = useDispatch();
  const history = useHistory();

  

  // const [startDate, setStartDate] = useState(null);
  // const [endDate, setEndDate] = useState(null);
  const [pages, setPages] = useState({});

  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);

  const maxPageNumbersToShow = 10;

  const { id } = useParams();

  useEffect(() => {
    get_pages(currentPage);
  }, [currentPage]);

  const get_pages = (page) => {
    try {
      let post_data = {
        //credentials: 'same-origin',
        //mode: 'same-origin',
        body: JSON.stringify({ page_type: id }),
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          //'X-CSRFToken':  cookie.load('csrftoken')
        },
      };
      AxiosJWT.post(
        process.env.REACT_APP_API_URL + "webpages/filter" + `?page=${page}`,
        post_data
      )
        .then((response) => response.json())
        .then(
          (response) => {
            console.log(response);

            setTotalPages(response.totalPages);
            //setOrders(data)
            setPages(response.data);
          },
          (error) => {
            if (error) {
              console.log(error);
            }
          }
        );
    } catch (e) {
      //snotify()
    }
  };

  let table_header = [
    {
      id: "1",
      label: "Category",
    },
    {
      id: "2",
      label: "Title",
    },
    {
      id: "3",
      label: "Slug",
    },
    {
      id: "4",
      label: "Actions",
    },
  ];

  const delPage = (id) => {
    console.log(id);
    // confirmAlert({
    //     title: 'Are you sure?',
    //     message: 'You want to delete this record?',
    //     buttons: [
    //       {
    //         label: 'Yes',
    //         onClick: () => delTypeRequest(id)
    //       },
    //       {
    //         label: 'No',
    //         //onClick: () => alert('Click No')
    //       }
    //     ]
    //   });

    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui">
            <h1>Are you sure?</h1>
            <p>You want to delete this file?</p>
            <button onClick={onClose}>No</button>
            <button
              onClick={() => {
                delPageRequest(id);
                onClose();
              }}
            >
              Yes, Delete it!
            </button>
          </div>
        );
      },
    });
  };

  const delPageRequest = (id) => {
    console.log(id);
    let post_data = {
      //credentials: 'same-origin',
      //mode: 'same-origin',
      //body: JSON.stringify({'id':id}),
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        //'X-CSRFToken':  cookie.load('csrftoken')
      },
    };

    // Simple GET request using fetch
    console.log(process.env.REACT_APP_API_URL);

    try {
      AxiosJWT.delete(process.env.REACT_APP_API_URL + "webpages/" + id, post_data)
        .then((response) => response.json())
        .then((data) => {
          console.log(data);
          get_pages(currentPage);
          //show_error()
          toast.error("Page deleted successfully!!");
        });
    } catch (e) {
      console.log("err", e);
    }
  };

  const handlePageChange = (pageNumber) => {
    if (pageNumber >= 1 && pageNumber <= totalPages) {
      setCurrentPage(pageNumber);
    }
  };

  const renderPageNumbers = () => {
    const pageNumbers = [];
    const halfMaxPageNumbers = Math.floor(maxPageNumbersToShow / 2);

    // Calculate the start and end page numbers to show
    let startPage = Math.max(currentPage - halfMaxPageNumbers, 1);
    let endPage = Math.min(startPage + maxPageNumbersToShow - 1, totalPages);

    if (endPage - startPage < maxPageNumbersToShow - 1) {
      startPage = Math.max(endPage - maxPageNumbersToShow + 1, 1);
    }

    for (let page = startPage; page <= endPage; page++) {
      pageNumbers.push(
        <button
          key={page}
          onClick={() => handlePageChange(page)}
          disabled={currentPage === page}
        >
          {page}
        </button>
      );
    }

    return pageNumbers;
  };

  return (
    <>
      <section className="visitor-pages">
        <div className="container-fluid p-0">
          <div className="row p-0 m-0">
            <div className="col-md-2 bg-light">
              <Sidemenu />
            </div>

            <div className="col-md-10">
              <header>
                <DashboardHeader />
              </header>

              <table className="table ">
                <thead className="thead-light">
                  <tr>
                    {table_header.map((tables_headr) => (
                      <th scope="col" key={tables_headr.id}>
                        {tables_headr.label}
                      </th>
                    ))}
                  </tr>
                </thead>

                <tbody>
                  {pages.length > 0 ? (
                    pages.map((tables) => (
                      <tr key={tables.id}>
                        <td>{tables.category}</td>
                        <td>{tables.title}</td>
                        <td>{tables.slug}</td>
                        <td>
                          <Link
                            className=" d-flex "
                            onClick={() => delPage(tables.id)}
                            to={window.location.pathname}
                          >
                            <div className="img_span">
                              <img src={del_btn} alt="" />
                            </div>
                          </Link>
                        </td>
                        <td>
                          <Link
                            className=" d-flex "
                            to={`/admin/update-page/${tables.slug}`}
                          >
                            <div className="img_span">
                              <img src={edit_btn} alt="" />
                            </div>
                          </Link>
                        </td>
                        <td>
                          <Link
                            className=" d-flex "
                            to={`/${tables.slug}`}
                            target="_blank"
                          >
                            <div className="img_span">
                              <img
                                src={eye_icon}
                                alt=""
                                style={{ width: "32px" }}
                              />
                            </div>
                          </Link>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <>No Records Found!!</>
                  )}
                </tbody>
              </table>

              <div>
                <button
                  onClick={() => handlePageChange(currentPage - 1)}
                  disabled={currentPage === 1}
                >
                  Previous
                </button>
                {renderPageNumbers()}
                <button
                  onClick={() => handlePageChange(currentPage + 1)}
                  disabled={currentPage === totalPages}
                >
                  Next
                </button>
              </div>
              <p>
                Page {currentPage} of {totalPages}
              </p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
