import React from "react";
import "./Common/css/admin_style.css";
import Sidemenu from "./Common/Sidebar_menu";
import DashboardHeader from "./Common/DashboardHeader";

import { confirmAlert } from "react-confirm-alert"; // Import
import "react-confirm-alert/src/react-confirm-alert.css"; // Import css

import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faArrowUp } from "@fortawesome/free-solid-svg-icons";
import { faArrowDown } from "@fortawesome/free-solid-svg-icons";
import { useState } from "react";
import DatePicker from "react-datepicker";
import Calendarimgs from "./Common/img/calender.svg";
import "react-datepicker/dist/react-datepicker.css";
import Languagepopup from "./Common/languagepopup";
import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useHistory } from "react-router-dom/cjs/react-router-dom";
import { checkAdminLogin } from "../../redux/Action";
import AxiosJWT from "./Common/AxiosJWT";

export default function DashboardVisitersPage() {
  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(null);
  const [table_data, setLangs] = useState([]);

  const isAdmin = useSelector((state) => state.reducer.isAdmin);
  const dispatch = useDispatch();
  const history = useHistory();

  

  useEffect(() => {
    get_langauages();
  }, []);

  const parentFunction = () => {
    get_langauages();
  };

  const get_langauages = () => {
    try {
      fetch(process.env.REACT_APP_API_URL + "languages")
        .then((response) => response.json())
        .then(
          (data) => {
            console.log(data);
            //setOrders(data)
            if (data.length > 0) setLangs(data);
          },
          (error) => {
            if (error) {
              console.log(error);
            }
          }
        );
    } catch (e) {
      //snotify()
    }
  };

  let table_header = [
    {
      id: "1",
      label: "Name",
    },
    {
      id: "2",
      label: "Code",
    },
    {
      id: "3",
      label: "Action",
    },
    // {
    //     id : "4",
    //     label: 'IP Block',

    // },
  ];

  const delLang = (id) => {
    console.log(id);

    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui">
            <h1>Are you sure?</h1>
            <p>You want to delete this file?</p>
            <button onClick={onClose}>No</button>
            <button
              onClick={() => {
                delLangRequest(id);
                onClose();
              }}
            >
              Yes, Delete it!
            </button>
          </div>
        );
      },
    });
  };

  const delLangRequest = (id) => {
    console.log(id);
    let post_data = {
      //credentials: 'same-origin',
      //mode: 'same-origin',
      //body: JSON.stringify({'id':id}),
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        //'X-CSRFToken':  cookie.load('csrftoken')
      },
    };

    // Simple GET request using fetch
    console.log(process.env.REACT_APP_API_URL);

    try {
      AxiosJWT.delete(process.env.REACT_APP_API_URL + "languages/" + id, post_data)
        .then((response) => response.json())
        .then((data) => {
          console.log(data);
          get_langauages();
          //show_error()
          toast.error("Language deleted successfully!!");
        });
    } catch (e) {
      console.log("err", e);
    }
  };

  /* let table_data =  [ 
      
          {
            name: 'English',            
            code: 'en',            
           
          },
          /* {
            id : "2",
            domains: 'www.xyz.ez',
            new_visiter: '16,000',
            repvisiters: '16,000',
            ip: '800',
           
          },
          {
            id : "3",
            domains: 'www.xyz.ez',
            new_visiter: '16,000',
            repvisiters: '16,000',
            ip: '800',
           
          }, 
         
         
        ] */

  return (
    <>
      <section className="visitor-pages">
        <div className="container-fluid p-0">
          <div className="row p-0 m-0">
            <div className="col-md-2 bg-light">
              <Sidemenu />
            </div>

            <div className="col-md-10">
              <header>
                <DashboardHeader />
              </header>

              <div className="col-md-12 mt-4">
                <div className="row">
                  <div className="col-md-3"></div>

                  <div className="col-md-3"></div>

                  <div className="col-md-3"></div>

                  <div className="col-md-3 d-flex align-items-center justify-content-center">
                    <div className="create_button mb-3">
                      <div className="left_side_dash p-0">
                        {/* popup start   */}
                        <button
                          onClick={() => Languagepopup}
                          className="create_btn"
                          data-toggle="modal"
                          data-target="#myModal2"
                        >
                          Add New Language
                        </button>
                        <Languagepopup
                          heading="Add Language"
                          page_heading="Add Language"
                          parentFunction={parentFunction}
                        />
                        {/* end popup */}
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="row m-0 mt-5 p-3  bg-light">
                <div className="col-md-5">
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Search"
                  />
                </div>
                {/* <div className='col-md-5 d-flex'> 
                                        <div className='mr-3 d-flex clender_str'>
                                            <img src={ Calendarimgs } alt='' />
                                            <DatePicker className='form-control date_picker' selected={startDate} onChange={(date) => setStartDate(date)} placeholderText='From' />

                                        </div>
                                        <div className='d-flex clender_str '> 
                                            <img src={ Calendarimgs } alt='' />
                                            <DatePicker className='form-control date_picker' selected={endDate} onChange={(date) => setEndDate(date)} placeholderText='To'  />
                                           
                                        </div>
                                       </div> 
                                    <div className='col-md-1'> 
                                        <input type="submit" className='shortby ' value="Short by" />
                                    </div>*/}
              </div>

              <table className="table ">
                <thead className="thead-light">
                  <tr>
                    {table_header.map((tables_headr) => (
                      <th scope="col" key={tables_headr.id}>
                        {tables_headr.label}
                      </th>
                    ))}
                  </tr>
                </thead>

                <tbody>
                  {table_data.length > 0
                    ? table_data.map((tables) => (
                        <tr key={tables.id}>
                          <td>{tables.name}</td>
                          <td>{tables.code}</td>
                          {/*<td>{ tables.repvisiters }<span className="tbl_top_arrow texts"><FontAwesomeIcon icon={ faArrowUp } /></span></td> */}
                          <td>
                            <a href="#" onClick={() => delLang(tables.id)}>
                              {" "}
                              Delete
                            </a>
                          </td>
                        </tr>
                      ))
                    : ""}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
