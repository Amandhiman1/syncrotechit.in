import React, { useEffect, useState } from "react";
import "./Common/css/admin_style.css";
import DashboardHeader from "./Common/DashboardHeader";
import { Form, Tab, Tabs } from "react-bootstrap";
import SunEditor from "suneditor-react";
import Sidebar from "./Common/Sidebar_menu";
import { toast } from "react-toastify";
import { useParams } from "react-router-dom";
import AxiosJWT from "./Common/AxiosJWT";

const DashboardEditBlog = () => {
  const { slug } = useParams(); // Get blog slug from URL parameters
  const [categories, setCategories] = useState([]);
  const [languages, setLangs] = useState([]);
  const [loading, setLoading] = useState(true); // Loading state
  const [formData, setFormData] = useState({
    category: {},
    titles: {},
    shortDesc: {},
    imageAlt: {},
    contents: {},
    image: null,
    createdBy: "Admin",
  });
  const [currentImage, setCurrentImage] = useState(null); // State for current image URL

  const getLanguages = async () => {
    try {
      const response = await fetch(
        `https://flight-backend-ro3e.onrender.com/api/languages`
      );
      const data = await response.json();
      if (data.length > 0) setLangs(data);
    } catch (error) {
      console.error(error);
    }
  };

  const getCategories = async () => {
    try {
      const response = await AxiosJWT.get(
        `https://flight-backend-ro3e.onrender.com/api/blogcat`
      );
      const data = await response.data;
      if (data.length > 0) setCategories(data);
    } catch (error) {
      console.error(error);
    }
  };

  const getBlogData = async () => {
    try {
      const response = await AxiosJWT.get(
        `https://flight-backend-ro3e.onrender.com/api/blog/${slug}`
      );
      const data = await response.data;
      console.log(data);

      setFormData(data);
      setCurrentImage(data.imageUrl); // Set the current image URL
      setLoading(false); // Set loading to false once data is fetched
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    getLanguages();
    getCategories();
    if (slug) getBlogData(); // Fetch blog data if slug is provided
  }, [slug]);

  const handleChange = (lang, field, value) => {
    setFormData((prevState) => ({
      ...prevState,
      [field]: {
        ...prevState[field],
        [lang]: value,
      },
    }));
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    setFormData((prevState) => ({
      ...prevState,
      image: file,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const form = new FormData();
    form.append("image", formData.image);

    languages.forEach((lang) => {
      form.append(`titles[${lang.code}]`, formData.titles[lang.code] || "");
      form.append(`category[${lang.code}]`, formData.category[lang.code] || "");
      form.append(`contents[${lang.code}]`, formData.contents[lang.code] || "");
      form.append(
        `shortDesc[${lang.code}]`,
        formData.shortDesc[lang.code] || ""
      );
      form.append(`imageAlt[${lang.code}]`, formData.imageAlt[lang.code] || "");
    });

    try {
      const response = await AxiosJWT.put(
        `https://flight-backend-ro3e.onrender.com/api/blog/${slug}`,
        form
      );
      const data = await response.data;
      console.log(data);

      toast.success("Blog updated successfully");
      // Handle the response as needed
    } catch (error) {
      console.error(error);
    }
  };

  if (loading) {
    return <div>Loading...</div>; // Show loading message while fetching data
  }

  return (
    <div>
      <section className="visitor-pages">
        <div className="container-fluid p-0">
          <div className="row p-0 m-0">
            <div className="col-md-2 bg-light">
              <Sidebar />
            </div>
            <div className="col-md-10">
              <header>
                <DashboardHeader />
              </header>
              <Form id="webForm" onSubmit={handleSubmit}>
                <div className="modal-content main">
                  <div className="modal-header">
                    <p className="form-heading mb-0">Edit Blog</p>
                  </div>
                  <div className="row mb-5">
                    <div className="col-lg-6">
                      <Form.Group controlId="formGridState">
                        <Form.Label>Category</Form.Label>
                        <Form.Select
                          defaultValue="Choose..."
                          className="form-control"
                          name="category"
                          onChange={(e) => {
                            const selectedCategory = categories.find(
                              (category) => category.slug === e.target.value
                            );
                            setFormData({
                              ...formData,
                              category: selectedCategory.title,
                            });
                          }}
                        >
                          <option value={formData.categorySlug}>{formData.category.en}</option>
                          {categories.map((category) => (
                            <option key={category._id} value={category.slug}>
                              {category.title.en}
                            </option>
                          ))}
                        </Form.Select>
                      </Form.Group>
                    </div>
                    <div className="col-lg-6">
                      <Form.Group className="mb-3" controlId="formImage">
                        <Form.Label>Blog Image</Form.Label>
                        {currentImage && (
                          <div>
                            <img
                              src={`https://flight-backend-ro3e.onrender.com/images/${currentImage}`}
                              alt="Current Blog"
                              style={{
                                width: "100px",
                                height: "auto",
                                marginBottom: "10px",
                              }}
                            />
                          </div>
                        )}
                        <Form.Control type="file" onChange={handleFileChange} />
                      </Form.Group>
                    </div>
                  </div>
                  <Tabs
                    defaultActiveKey="en"
                    id="uncontrolled-tab-example"
                    className="mb-3"
                  >
                    {languages.map((lang) => (
                      <Tab
                        key={lang.code}
                        eventKey={lang.code}
                        title={lang.name}
                      >
                        <div className="row">
                          <div className="col-md-12 form_field_popup">
                            <Form.Group
                              className="mb-3 f-left w-100"
                              controlId={`title-${lang.code}`}
                            >
                              <Form.Label>Blog title</Form.Label>
                              <Form.Control
                                type="text"
                                value={formData.titles[lang.code] || ""}
                                onChange={(e) =>
                                  handleChange(
                                    lang.code,
                                    "titles",
                                    e.target.value
                                  )
                                }
                              />
                            </Form.Group>
                            <Form.Group
                              className="mb-3 f-left w-100"
                              controlId={`description-${lang.code}`}
                            >
                              <Form.Label>Blog description</Form.Label>
                              <Form.Control
                                type="text"
                                value={formData.shortDesc[lang.code] || ""}
                                onChange={(e) =>
                                  handleChange(
                                    lang.code,
                                    "shortDesc",
                                    e.target.value
                                  )
                                }
                              />
                            </Form.Group>
                            <Form.Group
                              className="mb-3 f-left w-100"
                              controlId={`imageAlt-${lang.code}`}
                            >
                              <Form.Label>Image Alt Tag</Form.Label>
                              <Form.Control
                                type="text"
                                value={formData.imageAlt[lang.code] || ""}
                                onChange={(e) =>
                                  handleChange(
                                    lang.code,
                                    "imageAlt",
                                    e.target.value
                                  )
                                }
                              />
                            </Form.Group>
                            <Form.Label>Blog content</Form.Label>
                            <SunEditor
                              setOptions={{
                                height: 200,
                                buttonList: [
                                  ["undo", "redo"],
                                  ["font", "fontSize", "formatBlock"],
                                  ["paragraphStyle", "blockquote"],
                                  [
                                    "bold",
                                    "underline",
                                    "italic",
                                    "strike",
                                    "subscript",
                                    "superscript",
                                  ],
                                  ["fontColor", "hiliteColor", "textStyle"],
                                  ["removeFormat"],
                                  "/",
                                  ["outdent", "indent"],
                                  [
                                    "align",
                                    "horizontalRule",
                                    "list",
                                    "lineHeight",
                                  ],
                                  ["table", "link", "image", "video", "audio"],
                                  ["fullScreen", "showBlocks", "codeView"],
                                  ["preview", "print"],
                                  ["save", "template"],
                                ],
                              }}
                              onChange={(content) =>
                                handleChange(lang.code, "contents", content)
                              }
                              setContents={formData.contents[lang.code] || ""}
                            />
                          </div>
                        </div>
                      </Tab>
                    ))}
                  </Tabs>
                  <div className="col-md-12 form_field_popup">
                    <button
                      variant="primary"
                      className="create_btn form_submit text-center"
                      type="submit"
                    >
                      Submit
                    </button>
                  </div>
                </div>
              </Form>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default DashboardEditBlog;
