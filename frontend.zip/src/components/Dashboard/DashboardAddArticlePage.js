import React, { useEffect, useState } from "react";
import Sidebar from "./Common/Sidebar_menu";
import DashboardHeader from "./Common/DashboardHeader";
import { Form, Tab, Tabs } from "react-bootstrap";
import SunEditor from "suneditor-react";
import axios from "axios";
import swal from "sweetalert2";
import AxiosJWT from './Common/AxiosJWT'

const DashboardAddArticlePage = () => {
  const [languages, setLangs] = useState([]);
  const [categories, setCategories] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState({});
  const [selectedQuestion, setSelectedQuestion] = useState();
  const [formData, setFormData] = useState({});

  const showalert = (heading) => {
    swal.fire({
      title: heading,
      icon: "question",
      customClass: {
        popup: "my-popup",
        confirmButton: "my-confirm-button",
        cancelButton: "my-cancel-button",
      },
    });
  };

  const get_langauages = () => {
    try {
      fetch(process.env.REACT_APP_API_URL + "languages")
        .then((response) => response.json())
        .then(
          (data) => {
            console.log(data);
            //setOrders(data)
            if (data.length > 0) setLangs(data);
          },
          (error) => {
            if (error) {
              console.log(error);
            }
          }
        );
    } catch (e) {
      //snotify()
    }
  };

  const getCategories = async () => {
    const res = await AxiosJWT.get("https://flight-backend-ro3e.onrender.com/api/faqCategory");
    console.log(res.data);
    setCategories(res.data);
  };

  const handleInputChange = (langCode, field, value) => {
    setFormData((prevData) => ({
      ...prevData,
      [langCode]: {
        ...prevData[langCode],
        [field]: value,
      },
    }));
  };

  const handleEditorChange = (langCode, content) => {
    setFormData((prevData) => ({
      ...prevData,
      [langCode]: {
        ...prevData[langCode],
        content: content,
      },
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Use formData object as needed, like sending it to an API or processing it further
    const postData = {
      articleData: formData,
      faqCategory: selectedCategory._id,
      faqQuestion: selectedQuestion
    }
    console.log(postData);

    AxiosJWT.post('https://flight-backend-ro3e.onrender.com/api/faqArticle', postData)
      .then((res) => {
        console.log(res);
        showalert("FAQ Article created successfully");
        setFormData({})
      }).catch((err) => {
        console.error(err)
      })
  };

  

  useEffect(() => {
    get_langauages();
    getCategories();
  }, []);
  return (
    <div>
      <section className="visitor-pages">
        <div className="container-fluid p-0">
          <div className="row p-0 m-0">
            <div className="col-md-2 bg-light">
              <Sidebar />
            </div>

            <div className="col-md-10">
              <header>
                <DashboardHeader />
              </header>
              <Form id="webForm" onSubmit={handleSubmit}>
                <div className="modal-content main">
                  <div className="modal-header">
                    <p className="form-heading mb-0 ">Add Articles</p>
                  </div>

                  <div className="row mb-5">
                    <div className="col-lg-6">
                      <Form.Group controlId="formGridState">
                        <Form.Label>Topic</Form.Label>
                        <Form.Select
                          defaultValue="Choose..."
                          className="form-control"
                          name="topic"
                          onChange={(e) => {
                            const selectedCategoryId = e.target.value;
                            const category = categories.find(
                              (cat) => cat._id === selectedCategoryId
                            );
                            console.log(category);
                            setSelectedCategory(category);
                          }}
                        >
                          <option value="">Choose...</option>
                          {categories ? (
                            categories.map((category) => (
                              <option key={category._id} value={category._id}>
                                {category.title.en.name}
                              </option>
                            ))
                          ) : (
                            <option value="">No topic available</option>
                          )}
                        </Form.Select>
                      </Form.Group>
                    </div>
                    <div className="col-lg-6">
                      <Form.Group controlId="formGridQuestion">
                        <Form.Label>Question</Form.Label>
                        <Form.Select
                          defaultValue="Choose..."
                          className="form-control"
                          name="question"
                          onChange={(e) => {
                            console.log(e.target.value);
                            setSelectedQuestion(e.target.value)
                          }}
                        >
                          <option value="">Choose a topic first</option>
                          {selectedCategory && selectedCategory.questions ? (
                            selectedCategory.questions.map(
                              (question, index) => (
                                <option key={index} value={question.questionid}>
                                  {question.title.en.name}
                                </option>
                              )
                            )
                          ) : (
                            <option value="">No questions available</option>
                          )}
                        </Form.Select>
                      </Form.Group>
                    </div>
                  </div>

                  <Tabs
                    defaultActiveKey="en"
                    id="uncontrolled-tab-example"
                    className="mb-3"
                  >
                    {languages.length > 0 &&
                      languages.map((lang) => (
                        <Tab
                          key={lang.code}
                          eventKey={lang.code}
                          title={lang.name}
                        >
                          <div className="row">
                            <div className="col-md-12 form_field_popup">
                              <Form.Group
                                className="mb-3 f-left w-100"
                                controlId="exampleForm.ControlInput1"
                              >
                                <Form.Label>Article title</Form.Label>
                                <Form.Control
                                  type="text"
                                  onChange={(e) =>
                                    handleInputChange(
                                      lang.code,
                                      "title",
                                      e.target.value
                                    )
                                  }
                                />
                              </Form.Group>
                              <SunEditor
                                setOptions={{
                                  height: 200,
                                  buttonList: [
                                    ["undo", "redo"],
                                    ["font", "fontSize", "formatBlock"],
                                    ["paragraphStyle", "blockquote"],
                                    [
                                      "bold",
                                      "underline",
                                      "italic",
                                      "strike",
                                      "subscript",
                                      "superscript",
                                    ],
                                    ["fontColor", "hiliteColor", "textStyle"],
                                    ["removeFormat"],
                                    "/",
                                    ["outdent", "indent"],
                                    [
                                      "align",
                                      "horizontalRule",
                                      "list",
                                      "lineHeight",
                                    ],
                                    [
                                      "table",
                                      "link",
                                      "image",
                                      "video",
                                      "audio",
                                    ],
                                    ["fullScreen", "showBlocks", "codeView"],
                                    ["preview", "print"],
                                    ["save", "template"],
                                  ],
                                }}
                                onChange={(content) =>
                                  handleEditorChange(lang.code, content)
                                }
                              />
                            </div>
                          </div>
                        </Tab>
                      ))}
                  </Tabs>

                  <div className="col-md-12 form_field_popup">
                    <button
                      variant="primary"
                      className="create_btn form_submit text-center"
                      type="submit"
                    >
                      {" "}
                      Submit
                    </button>
                  </div>
                </div>
              </Form>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default DashboardAddArticlePage;