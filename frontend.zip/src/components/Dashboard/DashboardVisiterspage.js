import React, { useEffect } from "react";
import "./Common/css/admin_style.css";
import Sidemenu from "./Common/Sidebar_menu";
import DashboardHeader from "./Common/DashboardHeader";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faArrowUp } from "@fortawesome/free-solid-svg-icons";
import { faArrowDown } from "@fortawesome/free-solid-svg-icons";
import { useState } from "react";
import DatePicker from "react-datepicker";
import Calendarimgs from "./Common/img/calender.svg";
import "react-datepicker/dist/react-datepicker.css";
import { useHistory } from "react-router-dom/cjs/react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { checkAdminLogin } from "../../redux/Action";

export default function DashboardVisitersPage() {
  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(null);

  const isAdmin = useSelector((state) => state.reducer.isAdmin);
  const dispatch = useDispatch();
  const history = useHistory();

  let table_header = [
    {
      id: "1",
      label: "Domain",
    },
    {
      id: "2",
      label: "New Visters",
    },
    {
      id: "3",
      label: "Repeat Visters",
    },
    {
      id: "4",
      label: "IP Block",
    },
  ];

  let table_data = [
    {
      id: "1",
      domains: "www.xyz.ez",
      new_visiter: "16,000",
      repvisiters: "16,000",
      ip: "800",
    },
    {
      id: "2",
      domains: "www.xyz.ez",
      new_visiter: "16,000",
      repvisiters: "16,000",
      ip: "800",
    },
    {
      id: "3",
      domains: "www.xyz.ez",
      new_visiter: "16,000",
      repvisiters: "16,000",
      ip: "800",
    },
  ];

  return (
    <>
      <section className="visitor-pages">
        <div className="container-fluid p-0">
          <div className="row p-0 m-0">
            <div className="col-lg-2 col-md-12 bg-light">
              <Sidemenu />
            </div>

            <div className="col-lg-10 col-md-12">
              <header>
                <DashboardHeader />
              </header>

              <div className="col-md-12 mt-5">
                <div className="row top_dash_box">
                  <div className="col-md-3">
                    <div className="orang_section offer new_visi">
                      <div className="left_side">
                        <span className="t-visi">Total Visitor</span>
                        <span className="texts new_text">30,000</span>
                      </div>
                      <div className="right_side">
                        <span className="texts">
                          <FontAwesomeIcon icon={faArrowUp} />
                        </span>
                        <span className="texts">+20%</span>
                      </div>
                    </div>
                  </div>
                  <div className="col-md-3">
                    <div className="blue_section new_visi">
                      <div className="left_side">
                        <span className="n-visi">New Visitors</span>
                        <span className="texts new_text">16,000</span>
                      </div>
                      <div className="right_side pink_color">
                        <span className="texts">
                          <FontAwesomeIcon icon={faArrowDown} />
                        </span>
                        <span className="texts">-20%</span>
                      </div>
                    </div>
                  </div>
                  <div className="col-md-3">
                    <div className="orang_section new_visi">
                      <div className="left_side">
                        <span className="r-visi">Report Visitors</span>
                        <span className="texts new_text">16,000</span>
                      </div>
                      <div className="right_side green_color">
                        <span className="texts">
                          <FontAwesomeIcon icon={faArrowUp} />
                        </span>
                        <span className="texts">-20%</span>
                      </div>
                    </div>
                  </div>
                  <div className="col-md-3">
                    <div className="grey_section new_visi">
                      <div className="left_side">
                        <span className="ip_visi">IP Block</span>
                        <span className="ip_texts">1800</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="row m-0 mt-5 p-3  bg-light">
                <div className="col-md-5">
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Search"
                  />
                </div>
                <div className="col-md-5 d-flex gap-div">
                  {/* <div className="mr-3 d-flex clender_str">
                    <img src={Calendarimgs} alt="" />
                    <DatePicker
                      className="form-control date_picker"
                      selected={startDate}
                      onChange={(date) => setStartDate(date)}
                      placeholderText="From"
                    />
                  </div> */}
                  <div class="date-input">
                    <span class="icon-container">
                      <img src={Calendarimgs} alt="" />
                    </span>
                    <input type="text" placeholder="From" />
                  </div>
                  {/* <div className="d-flex clender_str ">
                    <img src={Calendarimgs} alt="" />
                    <DatePicker
                      className="form-control date_picker"
                      selected={endDate}
                      onChange={(date) => setEndDate(date)}
                      placeholderText="To"
                    />
                  </div> */}
                  <div class="date-input">
                    <span class="icon-container img-2">
                      <img src={Calendarimgs} alt="" />
                    </span>
                    <input type="text" placeholder="To" />
                  </div>
                </div>
                <div className="col-md-1">
                  <input type="submit" className="shortby " value="Short by" />
                </div>
              </div>

              <table className="table ">
                <thead className="thead-light">
                  <tr>
                    {table_header.map((tables_headr) => (
                      <th scope="col" key={tables_headr.id}>
                        {tables_headr.label}
                      </th>
                    ))}
                  </tr>
                </thead>

                <tbody>
                  {table_data.map((tables) => (
                    <tr key={tables.id}>
                      <td>{tables.domains}</td>
                      <td>
                        {tables.new_visiter}{" "}
                        <span className="tbl_botm_arrow texts">
                          <FontAwesomeIcon icon={faArrowDown} />
                        </span>
                      </td>
                      <td>
                        {tables.repvisiters}
                        <span className="tbl_top_arrow texts">
                          <FontAwesomeIcon icon={faArrowUp} />
                        </span>
                      </td>
                      <td>{tables.ip}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
