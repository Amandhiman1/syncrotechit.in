import React from "react";
import "./Common/css/admin_style.css";
import Sidemenu from "./Common/Sidebar_menu";
import DashboardHeader from "./Common/DashboardHeader";
import { useState } from "react";
import DatePicker from "react-datepicker";
import Calendarimgs from "./Common/img/calender.svg";
import "react-datepicker/dist/react-datepicker.css";
import webpage from "./Common/img/pexels-mateusz.svg";
import blog_img from "./Common/img/calendar2.svg";
import news from "./Common/img/offer.svg";
import active_btn from "./Common/img/active_icon.svg";
import del_btn from "./Common/img/delt_button.svg";
import { Link } from "react-router-dom";

import { confirmAlert } from "react-confirm-alert"; // Import
import "react-confirm-alert/src/react-confirm-alert.css";

import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

import edit_btn from "./Common/img/edit_button.svg";

import ImageCrop from "./Common/AddMediapopup";
import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useHistory } from "react-router-dom/cjs/react-router-dom";
import { checkAdminLogin } from "../../redux/Action";

export default function DashboardMedia() {
  const isAdmin = useSelector((state) => state.reducer.isAdmin);
  const dispatch = useDispatch();
  const history = useHistory();

  

  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(null);
  const [media, setMedia] = useState({});

  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);

  const maxPageNumbersToShow = 10;

  useEffect(() => {
    get_media(currentPage);
  }, [currentPage]);

  const get_media = (page) => {
    try {
      fetch(process.env.REACT_APP_API_URL + `media?page=${page}`)
        .then((response) => response.json())
        .then(
          (response) => {
            console.log("res ==> " + response.data);
            setTotalPages(response.totalPages);

            setMedia(response.data);
          },
          (error) => {
            if (error) {
              console.log(error);
            }
          }
        );
    } catch (e) {
      //snotify()
    }
  };

  let table_header = [
    {
      id: "1",
      label: "Name",
    },
    {
      id: "2",
      label: "Type",
    },
    {
      id: "1",
      label: "Category",
    },
    {
      id: "4",
      label: "Actions",
    },
  ];

  const parentFunction = () => {
    get_media(currentPage);
  };

  const delType = (id) => {
    console.log(id);
    // confirmAlert({
    //     title: 'Are you sure?',
    //     message: 'You want to delete this record?',
    //     buttons: [
    //       {
    //         label: 'Yes',
    //         onClick: () => delTypeRequest(id)
    //       },
    //       {
    //         label: 'No',
    //         //onClick: () => alert('Click No')
    //       }
    //     ]
    //   });

    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="custom-ui">
            <h1>Are you sure?</h1>
            <p>You want to delete this file?</p>
            <button onClick={onClose}>No</button>
            <button
              onClick={() => {
                delTypeRequest(id);
                onClose();
              }}
            >
              Yes, Delete it!
            </button>
          </div>
        );
      },
    });
  };

  const delTypeRequest = (id) => {
    console.log(id);
    let post_data = {
      method: "DELETE",
      //credentials: 'same-origin',
      //mode: 'same-origin',
      //body: JSON.stringify({'id':id}),
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        //'X-CSRFToken':  cookie.load('csrftoken')
      },
    };

    // Simple GET request using fetch
    console.log(process.env.REACT_APP_API_URL);

    try {
      fetch(process.env.REACT_APP_API_URL + "media/" + id, post_data)
        .then((response) => response.json())
        .then((data) => {
          console.log(data);
          get_media(currentPage);
          //show_error()
          toast.error("Media deleted successfully!!");
        });
    } catch (e) {
      console.log("err", e);
    }
  };

  const handlePageChange = (pageNumber) => {
    if (pageNumber >= 1 && pageNumber <= totalPages) {
      setCurrentPage(pageNumber);
    }
  };

  const renderPageNumbers = () => {
    const pageNumbers = [];
    const halfMaxPageNumbers = Math.floor(maxPageNumbersToShow / 2);

    // Calculate the start and end page numbers to show
    let startPage = Math.max(currentPage - halfMaxPageNumbers, 1);
    let endPage = Math.min(startPage + maxPageNumbersToShow - 1, totalPages);

    if (endPage - startPage < maxPageNumbersToShow - 1) {
      startPage = Math.max(endPage - maxPageNumbersToShow + 1, 1);
    }

    for (let page = startPage; page <= endPage; page++) {
      pageNumbers.push(
        <button
          key={page}
          onClick={() => handlePageChange(page)}
          disabled={currentPage === page}
        >
          {page}
        </button>
      );
    }

    return pageNumbers;
  };

  return (
    <>
      <section className="admin-pages news_letter">
        <div className="container-fluid p-0">
          <div className="row p-0 m-0">
            <div className="col-md-2 bg-light">
              <Sidemenu />
            </div>

            <div className="col-md-10">
              <header>
                <DashboardHeader />
              </header>

              {/* content  */}
              <div className="col-md-12 mt-4">
                <div className="row">
                  <div className="col-md-3"></div>
                  <div className="col-md-3"></div>
                  <div className="col-md-3"></div>
                  <div className="col-md-3 d-flex align-items-right ">
                    <div className="create_button">
                      <div className="right_side_dash">
                        <button
                          class="create_btn"
                          data-toggle="modal"
                          data-target="#myModal3"
                        >
                          Add new
                        </button>
                      </div>
                    </div>
                  </div>
                </div>

                {/* 
                                <div className="row">
                                    <div className="col-md-3">
                                    <div className="green_section offer new_visi">
                                        <div className='left_side_dash'>
                                            <span className="visi">Countries</span>
                                            <span className="texts new_text">0</span>
                                        </div>
                                           
                                        </div>
                                    </div>
                                    <div className="col-md-3">
                                        <div className="blue_section new_visi">
                                        <div className='left_side_dash'>
                                            <span className="visi">Cities</span>
                                            <span className="texts new_text">0</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-md-3">
                                        <div className="orang_section new_visi">
                                             <div className='left_side_dash'>
                                            <span className="visi">Airlines</span>
                                            <span className="texts new_text">0</span>
                                            </div>
                                            
                                         </div>
                                    </div>

                                    <div className="col-md-3">
                                        <div className="orang_section new_visi">
                                             <div className='left_side_dash'>
                                            <span className="visi">Airports</span>
                                            <span className="texts new_text">0</span>
                                            </div>
                                            
                                         </div>
                                    </div>

                                    
                                </div>
 */}
              </div>

              <div className="row m-0 mt-4 p-3  bg-light">
                <div className="col-md-7">
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Search"
                  />
                </div>

                <div className="col-md-3 pl-2">
                  <select
                    className="custom_select form-control"
                    id="inputGroupSelect03"
                  >
                    <option>Category</option>
                    <option value="1">Countries</option>
                    <option value="2">Cities</option>
                    <option value="2">Airlines</option>
                    <option value="2">Airports</option>
                  </select>
                </div>
                <div className="col-md-2">
                  <input
                    type="submit"
                    className="form-control"
                    Name="shortby"
                    value="Search"
                    class="form-control short-by"
                  />
                </div>
              </div>

              {/* first call request  */}
              <div className="call_req_id">
                <table className="table ">
                  <thead className="thead-light">
                    <tr>
                      {table_header.map((tables_headr) => (
                        <th scope="col" key={tables_headr.id}>
                          {tables_headr.label}
                        </th>
                      ))}
                    </tr>
                  </thead>

                  <tbody>
                    {media.length > 0 ? (
                      media.map((tables) => (
                        <tr key={tables.id}>
                          <td>
                            {tables.image ? (
                              <img
                                src={
                                  process.env.REACT_APP_IMAGE_URL + tables.image
                                }
                                width="100px"
                                alt={tables.alt}
                              />
                            ) : (
                              ""
                            )}
                          </td>
                          <td>{tables.type ? tables.type : ""}</td>
                          <td>{tables.category ? tables.category : ""}</td>

                          <td>
                            {/* <Link className=" d-flex" to="#">
                                                <div className='img_span'>
                                                    <img src={ edit_btn } alt="" />
                                                </div>
                                                <div className='box_cont_img_cont pl-2'>
                                                    <span>Edit</span>
                                                </div>
                                            </Link> */}

                            <Link
                              className=" d-flex "
                              onClick={() => delType(tables.id)}
                              to={window.location.pathname}
                            >
                              <div className="img_span">
                                <img src={del_btn} alt="" />
                              </div>
                              <div className="box_cont_img_cont">
                                <span>Delete</span>
                              </div>
                            </Link>
                          </td>
                        </tr>
                      ))
                    ) : (
                      <>No Records Found!!</>
                    )}
                  </tbody>
                </table>

                <div class="media-div">
                  <button
                    onClick={() => handlePageChange(currentPage - 1)}
                    disabled={currentPage === 1}
                  >
                    Previous
                  </button>
                  {renderPageNumbers()}
                  <button
                    onClick={() => handlePageChange(currentPage + 1)}
                    disabled={currentPage === totalPages}
                  >
                    Next
                  </button>
                </div>
                <p className="text-center pt-3">
                  Page {currentPage} of {totalPages}
                </p>
              </div>
              {/* content end   */}
            </div>
          </div>
        </div>
      </section>
      <ImageCrop parentFunction={parentFunction} /> {/* category={category}  */}
    </>
  );
}
