import React, { useEffect, useState } from "react";
import DashboardHeader from "./Common/DashboardHeader";
import Sidemenu from "./Common/Sidebar_menu";
import { Form, Dropdown } from "react-bootstrap";
import axios from "axios"; // Assuming axios is used for API calls
import AxiosJWT from "./Common/AxiosJWT";
import Calendarimgs from "./Common/img/calender.svg";
import { format } from "date-fns";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import del_btn from "./Common/img/delt_button.svg";
import eye_icon from "./Common/img/eye_icon.svg";
import { Tab, Tabs } from "react-bootstrap";
import Swal from "sweetalert2";
import  reportsImg  from './Common//img/reports.svg';
import { useDispatch } from "react-redux";
//import { getTasksReducer } from "../../redux/assignedtaskReducer";
import { toast } from "react-toastify";
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';



const DashboardTaskAssigning = () => {
  const dispatch= useDispatch()
  const [openModal, setOpenModal] = useState(null);
  const [type, setType] = useState(""); // To store selected type
  const [origins, setOrigins] = useState([]); // To store fetched origin options
  const [destinations, setDestinations] = useState([]); // To store fetched destination options
  const [airlines, setAirlines] = useState([]); // To store fetched airline options
  const [managers, setManagers] = useState([]); // Assuming a list of managers is fetched
  const [tasks, setTasks] = useState([]); // Assuming a list of managers is fetched
  const [isAssignOpen, setIsAssignOpen] = useState(false);
  const [selectedTaskId, setSelectedTaskId] = useState(null);
  const [assignee, setAssignee] = useState("");
  const [categories, setCategories] = useState([]);
  const [blogcategories, setBlogCategories] = useState([]);
  const [cities, setCities] = useState([]);
  const [languages, setLangs] = useState([]);
  const [showDropdown, setShowDropdown] = useState(false);
  const [formFaqType, setFormFaqType] = useState(false);
  const [filterTask, setFilterTask] = useState([])
  const [selectedTaskType, setSelectedTaskType] = useState(null);
  const [teamLead, setTeamLeadList] = useState([])
  const [teamExective, setTeamExective] = useState([])
  const[loginUserId,setLoginUserId]=useState("")
  const [isModalOpen, setIsModalOpen] = useState(false);
  const[taskId,setTaskId]=useState("")
  const [formData, setFormData] = useState({
    type: "",
    origin: "",
    destination: "",
    airline: "",
    title: "",
    fromDate: "",
    toDate: "",
    // assignedTo: "",
    assignedTo: "",
    description: "",
    faqCategory: [],
    blogCategory: [],
    cityCategory: [],
    assignedTeamLead: "",
    assignedTeamExective: "",
    allowAddFaq:false,
    allowAddBlog:false,
    allowAddJob:false,
    taskId:taskId,
    reportMessage:"",
    reportDate:new Date().toISOString().split("T")[0]
  }); // To store the form data
  const [errors, setErrors] = useState({}); // To store form validation errors

  const handleOpenForm = (formType) => {
    setOpenModal(formType);
  };




  const handleFaqOpenForm = (formType) => {
    setFormFaqType(formType);
  };

  const handleCloseModal = () => {
    setOpenModal(null);
    setFormData("")
  };

  const handleOpenAssign = (taskId) => {
    setSelectedTaskId(taskId);
    setIsAssignOpen(true);
  };

  const handleAssignTask = async (e) => {
    e.preventDefault();

    if (!assignee) {
      // Set error if assignee is not selected
      setErrors({ type: "Please select an assignee." });
      return;
    }

    try {
      // Prepare the payload with taskId and assignedTo
      const payload = {
        taskId: selectedTaskId, // Send selected task ID
        assignedTo: assignee,
      };


      // API call to assign task
      await AxiosJWT.post("https://flight-backend-ro3e.onrender.com/api/tasks/assign", payload)
        .then((res) => {
          console.log(res);
          console.log("FAQ Article created successfully");
          setIsAssignOpen(false);
          setAssignee(""); // Clear the form
          getTasks(); // Refresh the task list (optional)
        })
        .catch((err) => {
          console.error(err);
        });
      // On successful assignment
    } catch (error) {
      console.error("Error assigning task:", error);
    }
  };

  const handleTypeChange = async (e) => {
    const selectedType = e.target.value;
    setType(selectedType);
    setFormData({ ...formData, type: selectedType });

    if (selectedType) {
      // Fetch origin and destination options based on selected type
      try {
        const response = await axios.get(
          `https://flight-backend-ro3e.onrender.com/api/${selectedType}`
        );
        setOrigins(response.data);
        setDestinations(response.data);
      } catch (error) {
        console.error("Error fetching origins and destinations:", error);
      }
    } else {
      setOrigins([]);
      setDestinations([]);
    }
  };

  const getAirline = async () => {
    try {
      const response = await axios.get(`https://flight-backend-ro3e.onrender.com/api/airlines`);
      console.log(response.data);

      setAirlines(response.data);
    } catch (error) {
      console.error("Error fetching airlines:", error);
    }
  };
 

  const getTasks = async () => {
    try {
      // const response = await AxiosJWT.get(`https://flight-backend-ro3e.onrender.com/api/tasks`);
      const response = await AxiosJWT.get(`http://localhost:8000/api/tasks`);
     console.log("response654",response)
      console.log(response.data.tasks);
      
      //dispatch(getTasksReducer(response.data))
      
      setTasks(response.data.tasks);
    } catch (error) {
      console.error("Error fetching tasks:", error);
    }
  };

  const getManagers = async () => {
    try {
      const response = await AxiosJWT.get(
        // `https://flight-backend-ro3e.onrender.com/api/users/list`
        `http://localhost:8000/api/users/list`

      );
   
      console.log("sadasdasd",response.data)
      setManagers(response.data); // Assuming the API returns a list of managers
    } catch (error) {
      console.error("Error fetching managers:", error);
    }
  };

 console.log("asdsadsadasd",formData)
  const [questionFormValues, setQuestionFormValues] = useState({
    faqCategory: "",
    name: languages.reduce((acc, lang) => {
      acc[lang.code] = { name: "" };
      return acc;
    }, {}),
  });

  const handleInputChange = async (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });

    if ((name === "assignedTo") && value?.trim()) {
      const userId = value
      try {
        // const response= await AxiosJWT.get(`https://flight-backend-ro3e.onrender.com/api/users/report/${userId}`)
        const response= await AxiosJWT.get(`http://localhost:8000/api/users/report/${userId}`)

        const data = response?.data
        setTeamLeadList(data)

      } catch (error) {
        if (error.response && error.response.status === 404) {
          console.log("404 Not Found:", error.response.data.message); // Expected message
        } else {
          console.log("Unexpected error:", error.message);
        }
      }
    }

  };

  const handleAllowAddFaqChange = (event) => {
    setFormData((prevData) => ({
      ...prevData,
      allowAddFaq: event.target.checked,
    }));
  };

  const handleAllowAddBlogChange = (e) => {
    setFormData(prevData => ({
      ...prevData,
      allowAddBlog: e.target.checked // This will be true when checked, false when unchecked
    }));
  };

  const handleAllowAddJobChange = (event) => {
    setFormData((prevData) => ({
      ...prevData,
      allowAddJob: event.target.checked,
    }));
  };

  const fetchedExecutive=async(e)=>{
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
      try {
        // const response= await AxiosJWT.get(`https://flight-backend-ro3e.onrender.com/api/users/report/${value}`)
        const response= await AxiosJWT.get(`http://localhost:8000/api/users/report/${value}`)

        const data = response?.data
        setTeamExective(data)

      } catch (error) {
        if (error.response && error.response.status === 404) {
          console.log("404 Not Found:", error.response.data.message); // Expected message
        } else {
          console.log("Unexpected error:", error.message);
        }
      }
    }
  


console.log("asdsadsadsadd",formData)


// const handleSubmit = async (e) => {
//   e.preventDefault();
  
//   // Basic validation
//   const validateForm = () => {
//     let requiredFields
//     if(loginUserId.role === "Admin"){
//          requiredFields = {
//         title: "Title is required",
//         description: "Description is required",
//         assignedTo: "Assigned To is required"
//       };
//     }
//       if(loginUserId.role === "Manager"){
//         requiredFields = {
//           title: "Title is required",
//           description: "Description is required",
//           assignedTeamLead: "Assigned TeamLead is required",
//           assignedTeamExective: "Assigned Team Exective is required"
//       }
//     }
//     if(loginUserId.role === "TeamLead"){
//       requiredFields = {
//         title: "Title is required",
//         description: "Description is required",
//         // assignedTeamLead: "Assigned TeamLead is required",
//         assignedTeamExective: "Assigned Team Exective is required"
//     }
//   }
//   if(loginUserId.role === "Executive"){
//     requiredFields = {
//       title: "Title is required",
//       description: "Description is required",
//       // assignedTeamLead: "Assigned TeamLead is required",
//       // assignedTeamExective: "Assigned Team Exective is required"
//   }
// }
   
//     // Add conditional required fields based on modal type
//     if (openModal === "faq") {
//       requiredFields.faqCategory = "FAQ Category is required";
//     } else if (openModal === "blog") {
//       requiredFields.blogCategory = "Blog Category is required";
//     } else if (openModal === "job") {
//       requiredFields.cityCategory = "City Category is required";
//     }
//     const errors = {};
//     Object.entries(requiredFields).forEach(([field, message]) => {
//       if (!formData[field]) {
//         errors[field] = message;
//       }
//     });

//     return errors;
//   };
 
//   const formErrors = validateForm();


//   if (Object.keys(formErrors).length > 0) {
//     setErrors(formErrors);
//     return;
//   }
//   console.log("me click")
//   // Prepare assigned array
//   const assignedArray = [
//     formData.assignedTo,
//     formData.assignedTeamLead,
//     formData.assignedTeamExective
//   ].filter(Boolean); // Remove any undefined/null values

//   // Prepare query object based on modal type
//   const prepareQueryObject = () => {
//     const queryObject = {};
    
//     if (loginUserId.role !== 'Executive') {
//       const modalPermissions = {
//         faq: 'allowAddFaq',
//         blog: 'allowAddBlog',
//         job: 'allowAddJob'
//       };
      
//       const permission = modalPermissions[openModal];
//       if (permission) {
//         queryObject[permission] = formData[permission] || false;
//       }
//     }

//     const categoryMapping = {
//       faq: 'faqCategory',
//       blog: 'blogCategory',
//       job: 'cityCategory'
//     };

//     const category = categoryMapping[openModal];
//     if (category && formData[category]) {
//       queryObject[category] = formData[category];
//     }

//     return queryObject;
//   };

//   // Prepare base submission data
//   const prepareSubmissionData = (taskType) => ({
//     title: formData.title,
//     description: formData.description,
//     assignedTo: assignedArray,
//     taskType,
//     queryObject: prepareQueryObject()
//   });
  
//   try {
//     const API_BASE_URL ='http://localhost:8000/api/tasks';
//     // const API_BASE_URL= "https://flight-backend-ro3e.onrender.com/api/tasks";

//     let submissionData;

//     switch(openModal) {
//       case 'faq':
//         submissionData = prepareSubmissionData('Faq');
//         break;
//       case 'blog':
//         submissionData = prepareSubmissionData('Blog');
//         break;
//       case 'job':
//         submissionData = prepareSubmissionData('Job');
//         break;
//       case 'callback':
//         submissionData = prepareSubmissionData('Inquiry');
//         // Add any callback-specific logic here
//         break;
//       default:
//         throw new Error('Invalid modal type');
//     }
  
//     const response = await AxiosJWT.post(API_BASE_URL, submissionData);
//     console.log('Submission successful:', response.data);
//     toast.success(response.data?.message)
//     setOpenModal(null);
//     setFormData("")
    
//     // Clear form and refresh tasks
//     getTasks();
//     // You might want to add success notification here
    
//   } catch (error) {
//     console.error('Submission failed:', error);
//     // Add error handling/notification here
//   }
// };



const handleSubmit = async (e) => {
  e.preventDefault();

  // Modularized Validation Logic
  const validateForm = () => {
    let requiredFields = {};

    // Role-based required fields
    const roleFields = {
      Admin: {
        title: "Title is required",
        description: "Description is required",
        assignedTo: "Assigned To is required",
      },
      Manager: {
        title: "Title is required",
        description: "Description is required",
        assignedTeamLead: "Assigned TeamLead is required",
        assignedTeamExective: "Assigned Team Executive is required",
      },
      TeamLead: {
        title: "Title is required",
        description: "Description is required",
        assignedTeamExective: "Assigned Team Executive is required",
      },
      Executive: {
        title: "Title is required",
        description: "Description is required",
      },
    };

    // Include role-specific fields
    requiredFields = { ...requiredFields, ...roleFields[loginUserId.role] };

    // Modal-specific required fields
    const modalFields = {
      faq: { faqCategory: "FAQ Category is required" },
      blog: { blogCategory: "Blog Category is required" },
      job: { cityCategory: "City Category is required" },
    };

    if (openModal in modalFields) {
      requiredFields = { ...requiredFields, ...modalFields[openModal] };
    }

    // Validate required fields
    const errors = {};
    Object.entries(requiredFields).forEach(([field, message]) => {
      if (!formData[field]) {
        errors[field] = message;
      }
    });

    return errors;
  };

  const formErrors = validateForm();

  if (Object.keys(formErrors).length > 0) {
    setErrors(formErrors);
    return;
  }

  console.log("Form validation passed, preparing submission...");

  // Prepare assigned array
  const assignedArray = [
    formData.assignedTo,
    formData.assignedTeamLead,
    formData.assignedTeamExective,
  ].filter(Boolean); // Remove undefined/null values

  // Prepare query object
  const prepareQueryObject = () => {
    const queryObject = {};

    if (loginUserId.role !== "Executive") {
      const modalPermissions = {
        faq: "allowAddFaq",
        blog: "allowAddBlog",
        job: "allowAddJob",
      };

      const permission = modalPermissions[openModal];
      if (permission) {
        queryObject[permission] = formData[permission] || false;
      }
    }

    // Category mapping
    const categoryMapping = {
      faq: "faqCategory",
      blog: "blogCategory",
      job: "cityCategory",
    };

    const category = categoryMapping[openModal];
    if (category && formData[category]) {
      queryObject[category] = formData[category];
    }

    return queryObject;
  };

  // Prepare submission data
  const prepareSubmissionData = (taskType) => ({
    title: formData.title,
    description: formData.description,
    assignedTo: assignedArray,
    taskType,
    queryObject: prepareQueryObject(),
  });

  try {
    let submissionData;
    const taskTypeMapping = {
      faq: "Faq",
      blog: "Blog",
      job: "Job",
      callback: "Inquiry",
    };

    const taskType = taskTypeMapping[openModal];
    if (!taskType) throw new Error("Invalid modal type");

    submissionData = prepareSubmissionData(taskType);

    console.log("Submitting data:", submissionData);

    const response = await AxiosJWT.post("http://localhost:8000/api/tasks", submissionData);
    console.log("Submission successful:", response.data);

    toast.success(response.data?.message);

    // Reset form state and fetch tasks
    setOpenModal(null);
    setFormData("");
    getTasks();
  } catch (error) {
    console.error("Submission failed:", error);
    toast.error("Submission failed. Please try again.");
  }
};













  // const handleSubmit = async (e) => {
  //   console.log("click on handleSubmit")
  //   e.preventDefault();
  //   //  const assignType=openModal
  //   // Simple validation
  //   const formErrors = {};
  //   if (!formData.title) formErrors.title = "Title is required.";
  //   if (!formData.assignedTo)
  //     formErrors.assignedTo = "Assigned To is required.";
  //   if (!formData.description)
  //     formErrors.description = "Description is required.";
  //   if (!formData.faqCategory)
  //     formErrors.faqCategory = "faq Category is required.";
  //   if (!formData.blogCategory)
  //     formErrors.blogCategory = "blog categories is required.";
  //   if (!formData.cityCategory)
  //     formErrors.cityCategory = "city categories is required.";
  //   if (!formData.assignedTeamLead)
  //     formErrors.assignedTeamLead = "Assign Team Lead  is required.";
  //   if (!formData.assignedTeamExective)
  //     formErrors.assignedTeamExective = "Assign Exective  is required.";


  //   let queryObject = {};

  //   if (Object.keys(formErrors).length > 0) {
  //     setErrors(formErrors);
  //     return;
  //   }

  //   const assignedArray = [
  //   formData.assignedTo,
  //   formData.assignedTeamLead,
  //   formData.assignedTeamExective
  // ].filter(Boolean);
    

  //   try {
  //     if (openModal === "faq") {
  //       if(loginUserId.role !== 'Executive'){
  //         queryObject.allowAddFaq =formData.allowAddFaq || false;
  //       }

  //      if (formData.faqCategory) queryObject.faqCategory = formData.faqCategory;
  
  //       const faqDataSubmission = {
  //         // assignType:"faq",
  //         title: formData.title,
  //         description: formData.description,
  //         // taskType: formData.faqCategory,
  //         taskType:"Faq",
  //         assignedTo:assignedArray,
  //         queryObject
  //       }
  //       console.log("faqDataSubmission",faqDataSubmission)
  //       // const response = await AxiosJWT.post("https://flight-backend-ro3e.onrender.com/api/tasks", faqDataSubmission)
  //       const response = await AxiosJWT.post("http://localhost:8000/api/tasks", faqDataSubmission)

  //       console.log("response321", response)
  //       const data = await response.data;
  //       console.log("data", data)
  //     }
  //   } catch (error) {
  //     console.log("error", error)
  //   }



  //   // const blogDataSubmission = {
  //   //   // assignType:"blog",
  //   //   title: formData.title,
  //   //   description: formData.description,
  //   //   // taskType: formData.blogcategories,
  //   //   taskType:"Blog",
      
  //   //   // assignedTo: formData.assignedTo,
  //   //   assignedTo:assignedArray,
  //   //   queryObject
  //   // }

  //   try {
  //     if (openModal === "blog") {
  //       if (formData.blogCategory) queryObject.blogCategory = formData.blogCategory;
      
  //       // Add this line to explicitly set allowAddBlog to false if not checked
  //       if(loginUserId.role !== 'Executive'){
  //       queryObject.allowAddBlog = formData.allowAddBlog || false;
  //       }
  //       const blogDataSubmission = {
  //         title: formData.title,
  //         description: formData.description,
  //         taskType: "Blog",
  //         assignedTo: assignedArray,
  //         queryObject
  //       }
  //       console.log("blogDataSubmission",blogDataSubmission)

  //       // const response = await AxiosJWT.post("https://flight-backend-ro3e.onrender.com/api/tasks", blogDataSubmission)
  //       const response = await AxiosJWT.post("http://localhost:8000/api/tasks", blogDataSubmission)


  //       console.log("response", response)
  //       const data = await response.data;
  //       console.log("data", data)
  //     }
  //   } catch (error) {
  //     console.log("error", error)
  //   }


  //   // if (openModal === "job") {
      
  //   //   // if (formData.assignedTo) queryObject.assignedTo = formData.assignedTo;
  //   //   // if (formData.assignedTeamLead) queryObject.assignedTeamLead = formData.assignedTeamLead;
  //   //   // if (formData.assignedTeamExective) queryObject.assignedTeamExective = formData.assignedTeamExective;
  //   //   if (formData.allowAddJob) queryObject.allowAddJob = formData.allowAddJob || false;
      
  //   // }
  

   

  //   try {
  //     if (openModal === "job") {
  //       if (formData.cityCategory) queryObject.cityCategory = formData.cityCategory;
  //       if(loginUserId.role !== 'Executive'){
  //        queryObject.allowAddJob = formData.allowAddJob || false;
  //       }
  //       const jobDataSubmission = {
  //         title: formData.title,
  //         // assignType:"job",
  //         description: formData.description,
  //         // taskType: formData.cityCategory,
  //         taskType: "Job",
    
  //         // assignedTo: formData.assignedTo,
  //         assignedTo:assignedArray,
  //         queryObject
  //       }
  //       console.log("jobDataSubmission",jobDataSubmission)

  //       // const response = await AxiosJWT.post("https://flight-backend-ro3e.onrender.com/api/tasks", jobDataSubmission)
  //       const response = await AxiosJWT.post("http://localhost:8000/api/tasks", jobDataSubmission)

  //       console.log("response", response)
  //       const data = await response.data;
  //       console.log("data", data)
  //     }
  //   } catch (error) {
  //     console.log("error", error)
  //   }




  //   // Dynamically create the query based on selected type and fields

  //   if (formData.type === "cities") {
  //     if (formData.origin) queryObject.originCity = formData.origin;
  //     if (formData.destination)
  //       queryObject.destinationCity = formData.destination;
  //   } else if (formData.type === "countries") {
  //     if (formData.origin) queryObject.originCountry = formData.origin;
  //     if (formData.destination)
  //       queryObject.destinationCountry = formData.destination;
  //   } else if (formData.type === "airports") {
  //     if (formData.origin) queryObject.originCode = formData.origin;
  //     if (formData.destination)
  //       queryObject.destinationCode = formData.destination;
  //   }




  //   const currentDate = new Date().toISOString(); // Get current date in ISO format

  //   if (formData.fromDate && formData.toDate) {
  //     // Both fromDate and toDate are selected
  //     queryObject["formData.Segments.DepartureDate"] = {
  //       $gte: new Date(formData.fromDate).toISOString(),
  //       $lte: new Date(formData.toDate).toISOString(),
  //     };
  //   } else if (formData.fromDate && !formData.toDate) {
  //     // Only fromDate is selected, show inquiries from fromDate onwards
  //     queryObject["formData.Segments.DepartureDate"] = {
  //       $gte: new Date(formData.fromDate).toISOString(),
  //     };
  //   } else if (!formData.fromDate && formData.toDate) {
  //     // Only toDate is selected, show inquiries from currentDate to toDate
  //     queryObject["formData.Segments.DepartureDate"] = {
  //       $lte: new Date(formData.toDate).toISOString(),
  //       $gte: currentDate,
  //     };
  //   }

  //   if (openModal === "callback") {
  //     // if (formData.assignedTeamLead) queryObject.assignedTeamLead = formData.assignedTeamLead;
  //     // if (formData.assignedTeamExective) queryObject.assignedTeamExective = formData.assignedTeamExective;
  //   }

  //   // Send only the required fields
  //   const submissionData = {
  //     // assignType:"callback",
  //     title: formData.title,
  //     description: formData.description,
  //     // assignedTo: formData.assignedTo,
  //     assignedTo:assignedArray,
  //     taskType: "Inquiry",
  //     queryObject, 
  //   };

  //   console.log("Form Data Submitted:", submissionData);
  //   // API call to submit the form can be added here

  //   if (openModal === "callback") {
  //     AxiosJWT.post("https://flight-backend-ro3e.onrender.com/api/tasks", submissionData)
  //       .then((res) => {
  //         console.log(res);
  //         console.log("FAQ Article created successfully");
  //       })
  //       .catch((err) => {
  //         console.error(err);
  //       });
  //   }
  //   getTasks();

  // };


  const getCategories = async () => {
    const res = await AxiosJWT.get(
      "https://flight-backend-ro3e.onrender.com/api/faqCategory"
    );
    console.log(res.data);

    setCategories(res.data);

  };


  const getBlogCategories = async () => {
    try {

      const response = await axios.get(`https://flight-backend-ro3e.onrender.com/api/blogcat`);
      if (response.data.length > 0)

        setBlogCategories(response.data);

    } catch (error) {
      console.error(error);
    }
  };

  const getCities = async () => {
    try {
      const response = await AxiosJWT.get(`https://flight-backend-ro3e.onrender.com/api/cities`);
      const data = await response.data;
      console.log("cities", data);
      if (data.length > 0) setCities(data);
    } catch (error) {
      console.error(error);
    }
  };

  // const handleCheckboxChange = (categoryId) => {
  //   setFormData((prevData) => {
  //     const updatedFaqCategory = prevData?.faqCategory?.includes(categoryId)
  //       ? prevData?.faqCategory?.filter((id) => id !== categoryId)
  //       : [...prevData?.faqCategory, categoryId];

  //     return {
  //       ...prevData,
  //       faqCategory: updatedFaqCategory,
  //     };
  //   });
  // };

  const handleCheckboxChange = (categoryId) => {
    setFormData((prevData) => {
      // Ensure faqCategory is initialized as an array
      const faqCategory = prevData?.faqCategory || [];
  
      const updatedFaqCategory = faqCategory.includes(categoryId)
        ? faqCategory.filter((id) => id !== categoryId)
        : [...faqCategory, categoryId];
  
      return {
        ...prevData,
        faqCategory: updatedFaqCategory,
      };
    });
  };
  

  // const handleBlogCheckboxChange = (categoryId) => {
  //   setFormData((prevData) => {
  //     const updatedFaqCategory = prevData?.blogcategories?.includes(categoryId)
  //       ? prevData?.blogcategories?.filter((id) => id !== categoryId)
  //       : [...prevData?.blogcategories, categoryId];

  //     return {
  //       ...prevData,
  //       blogcategories: updatedFaqCategory,
  //     };
  //   });
  // };

  const handleBlogCheckboxChange = (categoryId) => {
    setFormData((prevData) => {
      // Ensure blogCategory is initialized as an array
      const blogCategory = prevData?.blogCategory || [];
  
      const updatedBlogCategories = blogCategory.includes(categoryId)
        ? blogCategory.filter((id) => id !== categoryId)
        : [...blogCategory, categoryId];
  
      return {
        ...prevData,
        blogCategory: updatedBlogCategories,
      };
    });
  };
  
  


  // const handleCityCheckboxChange = (categoryId) => {
  //   setFormData((prevData) => {
  //     const updatedFaqCategory = prevData?.cityCategory?.includes(categoryId)
  //       ? prevData?.cityCategory?.filter((id) => id !== categoryId)
  //       : [...prevData?.cityCategory, categoryId];

  //     return {
  //       ...prevData,
  //       cityCategory: updatedFaqCategory,
  //     };
  //   });
  // };

  const handleCityCheckboxChange = (categoryId) => {
    setFormData((prevData) => {
      // Ensure cityCategory is initialized as an array
      const cityCategory = prevData?.cityCategory || [];
  
      const updatedCityCategory = cityCategory.includes(categoryId)
        ? cityCategory.filter((id) => id !== categoryId)
        : [...cityCategory, categoryId];
  
      return {
        ...prevData,
        cityCategory: updatedCityCategory,
      };
    });
  };
  


  const get_langauages = () => {
    try {
      AxiosJWT
        .get("https://flight-backend-ro3e.onrender.com/api/languages")
        // .then((response) => response.json())
        .then(
          (data) => {
            console.log(data.data);
            //setOrders(data)
            if (data.data.length > 0) setLangs(data.data);
          },
          (error) => {
            if (error) {
              console.log(error);
            }
          }
        );
    } catch (e) {
      //snotify()
      console.error(e);
    }
  };

  const [topicFormValues, setTopicFormValues] = useState(
    languages.reduce((acc, lang) => {
      acc[lang.code] = { name: "" };
      return acc;
    }, {})
  );
  const handleTopicFormChange = (e, langCode) => {
    const { name, value } = e.target;
    setTopicFormValues((prevValues) => ({
      ...prevValues,
      [langCode]: {
        ...prevValues[langCode],
        [name]: value,
      },
    }));
  };

  const showalert = (heading) => {
    Swal.fire({
      title: heading,
      icon: "question",
      customClass: {
        popup: "my-popup",
        confirmButton: "my-confirm-button",
        cancelButton: "my-cancel-button",
      },
    });
  };

  const handleAddFaqSubmit = async () => {
    // event.preventDefault();
    // Handle form submission here
    try {
      // if (formFaqType == "Topic") {
      console.log("topicFormValues", topicFormValues)
      const response = await AxiosJWT.post("https://flight-backend-ro3e.onrender.com/api/faqCategory", { title: topicFormValues })
      const data = await response.data
      showalert("New Topic added successfully");

      setTopicFormValues(
        languages.reduce((acc, lang) => {
          acc[lang.code] = { name: "" };
          return acc;
        }, {})
      );
      // }

    } catch (error) {
      console.log("error", error)
    }

    // else {
    //   console.log(questionFormValues);
    //   AxiosJWT
    //     .post(
    //       "https://flight-backend-ro3e.onrender.com/api/faqQuestion",
    //       questionFormValues
    //     )
    //     .then((res) => {
    //       console.log(res);
    //       showalert("new question added successfully");
    //       setQuestionFormValues({
    //         faqCategory: "",
    //         name: languages.reduce((acc, lang) => {
    //           acc[lang.code] = { name: "" };
    //           return acc;
    //         }, {}),
    //       });
    //     })
    //     .catch((err) => {
    //       console.error(err);
    //       showalert("some error occured");
    //     });
    // }

  };

  // Handle input field click to toggle dropdown
  const toggleDropdown = () => setShowDropdown(!showDropdown);



  // const getLeadLeadList=async()=>{
  //    try{
  //     console.log("sadsadsadsa",formData?.assignedTo)
  //     // const response=await AxiosJWT.post(`https://flight-backend-ro3e.onrender.com/api/report/${formData?.assignedTo}`)
  //     const response=await AxiosJWT.get(`http://localhost:8000/api/report/${formData?.assignedTo}`)

  //      console.log("response",response)
  //    }catch(error){
  //     console.log(error)
  //    }
  // }

    const fetchCurrentUserId=()=>{
      try{
        const user = JSON.parse(sessionStorage.getItem('user'));
        setLoginUserId(user)
      }catch(error){
        console.log(error)
      }
    }


    const handleFilterList = (taskType) => {    
      //  if(loginUserId.role != "Admin"){
      //   const filteredTasks = tasks?.map(task => {
      //     if (task.taskType === taskType) {
           
      //       const filteredAssignedTo = task.assignedTo.filter(ass =>((ass._id === loginUserId.id) && (ass.role === loginUserId.role)));

      //       console.log("filteredAssignedTo",filteredAssignedTo)
           
      //       if (filteredAssignedTo.length > 0) {
      //         return {
      //           ...task,
      //           assignedTo: filteredAssignedTo
      //         };
      //       }
      //     }
      //     return null;
      //   }).filter(Boolean); 
      
      //   console.log("filteredTasks", filteredTasks);
      //   setFilterTask(filteredTasks);
      //  }else{
        const newArr = tasks?.filter((task) =>task.taskType===taskType)
 
            setFilterTask(newArr)
            return newArr
      //  }
    };
    
  console.log("filterTask",filterTask)
    // useEffect(()=>{
    //   const results = tasks.map(task => ({
    //      taskUser:task?.assignedTo?.filter((ass)=>ass?._id===loginUserId?.id),
    //     allowAddFaq: task?.queryObject?.allowAddFaq === true
    //   }));
      
    //   console.log("results",results);
    // },[tasks])

    // useEffect(() => {
    //   const results = tasks.map(task => {
    //     const assignedToArray = Array.isArray(task?.assignedTo) ? task.assignedTo : [];
    //     return {
    //       taskUser: assignedToArray.filter(ass => ass?._id === loginUserId?.id),
    //       allowAddFaq: task?.queryObject?.allowAddFaq === true,
    //     };
    //   });
    
    //   console.log("results", results);
    // }, [tasks]);
    
  

   console.log("tasks",tasks)

//   const handleFilterList = (taskType) => {
//     const user = JSON.parse(sessionStorage.getItem('user'));
    
//     const filteredTasks = tasks?.filter((task) => {
//       const isAccessible = 
//         user.role === 'Admin' || 
//         task.createdBy._id === user.id || 
//         task.assignedTo.some(assignee => assignee._id === user.id);
  
//       const matchesTaskType = !taskType || task.taskType === taskType;
  
//       return isAccessible && matchesTaskType;
//     });
  
//     setFilterTask(filteredTasks);
//     return filteredTasks;
// };






  // const handleFilterList = (catType) => {
  //     const newArr = tasks?.filter((task) =>task.taskType===catType)
 
  //     setFilterTask(newArr)
  //     return newArr
  // };

  const handleDeleteTask=async(taskId)=>{
    try {
      const response= await AxiosJWT.delete(`https://flight-backend-ro3e.onrender.com/api/tasks/${taskId}`)
      const data = response?.data
      console.log("datadelete",data)
      toast.success(data.message)
      getTasks();
    } catch (error) {
      if (error.response && error.response.status === 404) {
        console.log("404 Not Found:", error.response.data.message); 
      } else {
        console.log("Unexpected error:", error.message);
      }
    }
  }



  const handleOpenReportModel = (taskId) => {
    setIsModalOpen(true)
    setTaskId(taskId)
  }
  const handleCloseReportModel = () => setIsModalOpen(false);


  const handleReportChange = (e) => {
    setFormData({ ...formData, reportMessage: e.target.value });
  };

  const handleDateChange = (e) => {
    setFormData({ ...formData, reportDate: e.target.value });
  };

  const handleSubmitReport = async(e) => {
    e.preventDefault();

    const assignedReport={
      reportMessage:formData.reportMessage,
      reportDate:formData.reportDate,
      currentUserId:loginUserId?.id
    }
   console.log("assignedReport",assignedReport)
    try{
    //  const response=AxiosJWT.post("https://flight-backend-ro3e.onrender.com/api/tasks", submissionData)
    // const response=AxiosJWT.post("https://localhost:8000/api/", assignedReport)  //zafar

      // const data = await response.data;
    
    }catch(error){
      console.log(error)
    }
 


    handleCloseReportModel(); // Close the modal after submission
  };
  


  useEffect(() => {
    get_langauages()
    getCities()
    getBlogCategories()
    getCategories()
    getAirline();
    getManagers();
    getTasks();
    fetchCurrentUserId()
  }, []);

  return (
    <>
      <section className="visitor-pages">
        <div className="container-fluid p-0">
          <div className="row p-0 m-0">
            <div className="col-md-2 bg-light">
              <Sidemenu />
            </div>
            <div className="col-md-10">
              <header>
                <DashboardHeader />
              </header>
              <div className="col-md-12 mt-4">
                <div className="row tasktop_row_dp">
                  <div className="col-md-3">
                    <div
                      className="green_section offer new_visi"
                    // onClick={() => handleOpenForm("callback")}
                    >
                      <div className="left_side_dash">
                        <span className="visi">Assign Callback</span>
                      </div>
                      <div className="task_btn">
                      {
                        (loginUserId.role == 'Executive') ? ""
                        :
                        <button className="btn btn-primary org_bg_dp" onClick={() => handleOpenForm("callback")}>Add</button>
                      }
                       
                        <button className="btn btn-danger green_bg_dp" onClick={() => handleFilterList("Inquiry")}>List</button>
                      </div>
                    </div>
                  </div>
                  <div className="col-md-3">
                    <div
                      className="blue_section new_visi"
                      onClick={() => handleOpenForm("messages")}
                    >
                      <div className="left_side_dash">
                        <span className="visi">Assign Messages</span>
                      </div>
                      <div className="task_btn">
                      {
                        (loginUserId.role == 'Executive') ? ""
                        :
                        <button className="btn btn-primary org_bg_dp">Add</button>
                      }
                        {/* <button className="btn btn-primary org_bg_dp">Add</button> */}
                        <button className="btn btn-danger green_bg_dp">List</button>
                      </div>
                    </div>
                  </div>
                  <div className="col-md-3">
                    <div
                      className="orang_section new_visi"
                    // onClick={() => handleOpenForm("faq")}
                    >
                      <div className="left_side_dash">
                        <span className="visi">Assign FAQ</span>
                      </div>
                      <div className="task_btn">
                      {
                        (loginUserId.role == 'Executive') ? ""
                        :
                        <button className="btn btn-primary org_bg_dp" onClick={() => handleOpenForm("faq")}>Add</button>
                      }
                        {/* <button className="btn btn-primary org_bg_dp" onClick={() => handleOpenForm("faq")}>Add</button> */}
                        <button className="btn btn-danger green_bg_dp" onClick={() => handleFilterList("Faq")}>List</button>
                      </div>
                    </div>

                  </div>
                  <div className="col-md-3">
                    <div
                      className="green_section offer new_visi"
                    // onClick={() => handleOpenForm("blog")}
                    >
                      <div className="left_side_dash">
                        <span className="visi">Assign Blog</span>
                      </div>
                      <div className="task_btn">
                      {
                        (loginUserId.role == 'Executive') ? ""
                        :
                        <button className="btn btn-primary org_bg_dp" onClick={() => handleOpenForm("blog")}>Add</button>
                      }
                        {/* <button className="btn btn-primary org_bg_dp" onClick={() => handleOpenForm("blog")}>Add</button> */}
                        <button className="btn btn-danger green_bg_dp" onClick={() => handleFilterList("Blog")}>List</button>
                      </div>
                    </div>
                  </div>
                  <div className="col-md-3">
                    <div
                      className="orang_section new_visi"
                    // onClick={() => handleOpenForm("job")}
                    >
                      <div className="left_side_dash">
                        <span className="visi">Assign Job</span>
                      </div>
                      <div className="task_btn">
                      {
                        (loginUserId.role == 'Executive') ? ""
                        :
                        <button className="btn btn-primary org_bg_dp" onClick={() => handleOpenForm("job")}>Add</button>
                      }
                        {/* <button className="btn btn-primary org_bg_dp" onClick={() => handleOpenForm("job")}>Add</button> */}
                        <button className="btn btn-danger green_bg_dp" onClick={() => handleFilterList("Job")}>List</button>
                      </div>
                    </div>
                  </div>

                </div>
                <div className="row m-0 mt-5 p-3  bg-light searchbar_row_dp">
                  <div className="col-md-5">
                    <input
                      type="text"
                      className="form-control"
                      placeholder="Search"
                    />
                  </div>
                  <div className="col-md-5 d-flex gap-div">
                    {/* <div className="mr-3 d-flex clender_str">
                    <img src={Calendarimgs} alt="" />
                    <DatePicker
                      className="form-control date_picker"
                      selected={startDate}
                      onChange={(date) => setStartDate(date)}
                      placeholderText="From"
                    />
                  </div> */}
                    <div class="date-input">
                      <span class="icon-container">
                        <img src={Calendarimgs} alt="" />
                      </span>
                      <input type="text" placeholder="From" />
                    </div>
                    {/* <div className="d-flex clender_str ">
                    <img src={Calendarimgs} alt="" />
                    <DatePicker
                      className="form-control date_picker"
                      selected={endDate}
                      onChange={(date) => setEndDate(date)}
                      placeholderText="To"
                    />
                  </div> */}
                    <div class="date-input">
                      <span class="icon-container img-2">
                        <img src={Calendarimgs} alt="" />
                      </span>
                      <input type="text" placeholder="To" />
                    </div>
                  </div>
                  <div className="col-md-1">
                    <input
                      type="submit"
                      className="shortby "
                      value="Short by"
                    />
                  </div>
                </div>
                <div className="table_dp">
                  <table className="table">
                    <thead className="thead-light">
                      <tr>
                        <th scope="col">Task Name</th>
                        <th scope="col">Task Assign To</th>
                        <th scope="col">Task Assign Type</th>
                        <th scope="col">Designation</th>
                        <th scope="col">Assign Date</th>
                        {/* <th scope="col">Assign</th> */}
                        <th scope="col">Report</th>
                        <th scope="col">Delete</th>
                      </tr>
                    </thead>
                        {console.log("filterTask5",filterTask)}
                    <tbody>
                      {
                        Array.isArray(filterTask) &&
                        filterTask.map((task) => (
                     
                        <tr key={task.id}>
                          <td>{task.title}</td>
                          <td>{task.assignedTo[0]?.name}</td>
                          <td>{task?.taskType}</td>
                          <td>{task?.assignedTo[0]?.role}</td>
                          <td>
                            {/* {format(
                              new Date(task.assignedTo[0]?.createdAt),
                              "EEE dd MMM yyyy HH:mm"
                            )} */}
                            {
                              task.assignedTo[0]?.createdAt
                            }

                      
                          </td>
                     
                          <td>
                            <img src={reportsImg} alt="" width={"35px"} height={"35px"}  onClick={()=>handleOpenReportModel(task.id)}/>
                          </td>
                          <td>
                            <img src={del_btn} alt="" onClick={()=>handleDeleteTask(task.id)}/>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {((openModal === "callback") || (openModal === 'faq') || (openModal === 'blog') || (openModal === 'job')) && (
                  <div className="task_poup_dp">
                    <div className="modal-dialog main" role="document">
                      <div className="modal-content main">
                        <div className="modal-header">
                          <button
                            type="button"
                            className="close"
                            onClick={handleCloseModal}
                          >
                          
                            <span aria-hidden="true">&times;</span>
                          </button>
                        </div>
                         {/* form start from assigned */}
                        <div className="modal-body modal-main sidebar_popup">
                          <Form
                            id="topicForm"
                            className="common-form common-form-border login-signup-form"
                            onSubmit={handleSubmit}
                            autoComplete="off"
                          >
                            <div className="row mb-5">
                              <div className="col-lg-12">
                                {/* Title Field */}
                                <Form.Group
                                  controlId="title"
                                  className="half_wt_dp"
                                >
                                  <Form.Label>Title*</Form.Label>
                                  <Form.Control
                                    type="text"
                                    placeholder="Enter Title"
                                    name="title"
                                    value={formData.title}
                                    className="my-form"
                                    onChange={handleInputChange}
                                    required
                                  />
                                  {errors.title && (
                                    <Form.Text className="text-danger">
                                      {errors.title}
                                    </Form.Text>
                                  )}
                                </Form.Group>

                                {/* Description Field */}
                                <Form.Group
                                  controlId="description"
                                  className="half_wt_dp"
                                >
                                  <Form.Label>Description*</Form.Label>
                                  <Form.Control
                                    as="textarea"
                                    rows={3}
                                    placeholder="Enter Description"
                                    name="description"
                                    value={formData.description}
                                    className="my-form"
                                    onChange={handleInputChange}
                                    required
                                  />
                                  {errors.description && (
                                    <Form.Text className="text-danger">
                                      {errors.description}
                                    </Form.Text>
                                  )}
                                </Form.Group>

                                {/* Type Selection */}

                                {
                                  (openModal === "faq")
                                    ?
                                    <Form.Group controlId="formAssignedTo" className="w-100">
                                      <Form.Label>Topic</Form.Label>

                                      {/* Display selected items inline with Bootstrap classes */}
                                      <div
                                        onClick={toggleDropdown}
                                        className="form-control d-flex flex-wrap align-items-center overflow-hidden w-100"
                                        style={{ cursor: 'pointer', padding: '0.375rem 0.75rem', minHeight: '2.4rem' }}
                                      >
                                        {formData?.faqCategory?.length > 0 ? (
                                          formData?.faqCategory.map((id) => {
                                            const category = categories.find((cat) => cat?._id === id);
                                            return (
                                              <span
                                                key={id}
                                                className="badge bg-white me-1 mb-1 text-black"
                                                style={{
                                                  whiteSpace: 'nowrap',
                                                  overflow: 'hidden',
                                                  textOverflow: 'ellipsis',
                                                  maxWidth: 'calc(100% - 1rem)',
                                                }}
                                              >
                                                {category?.slug}
                                              </span>
                                            );
                                          })
                                        ) : (
                                          <span className="text-muted">Choose...</span>
                                        )}
                                      </div>
                                      {errors.faqCategory && (
                                        <Form.Text className="text-danger">
                                          {errors.faqCategory}
                                        </Form.Text>
                                      )}


                                      {/* Dropdown with checkboxes */}
                                      {showDropdown && (
                                        <div
                                          className="border rounded p-2 mt-1"
                                          style={{
                                            maxHeight: '150px',
                                            overflowY: 'auto',
                                            width: '100%',
                                            boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
                                          }}
                                        >
                                         
                                          {categories.map((category) => (
                                            <Form.Check
                                              key={category?._id}
                                              type="checkbox"
                                              label={category?.slug}
                                              checked={formData?.faqCategory?.includes(category?._id)}
                                              onChange={() => handleCheckboxChange(category?._id)}
                                              className="w-100"
                                            />
                                          ))}
                                        </div>
                                      )}
                                    </Form.Group>


                                    :
                                    (openModal === "blog") ?
                                      <Form.Group controlId="formAssignedTo" className="w-100">
                                        <Form.Label>Blog category</Form.Label>

                                        {/* Display selected items inline with Bootstrap classes */}
                                        <div
                                          onClick={toggleDropdown}
                                          className="form-control d-flex flex-wrap align-items-center overflow-hidden w-100"
                                          style={{ cursor: 'pointer', padding: '0.375rem 0.75rem', minHeight: '2.4rem' }}
                                        >
                                          {formData?.blogCategory?.length > 0 ? (
                                            formData?.blogCategory.map((id) => {
                                              const category = blogcategories.find((cat) => cat?._id === id);
                                              return (
                                                <span
                                                  key={id}
                                                  className="badge bg-white me-1 mb-1 text-black"
                                                  style={{
                                                    whiteSpace: 'nowrap',
                                                    overflow: 'hidden',
                                                    textOverflow: 'ellipsis',
                                                    maxWidth: 'calc(100% - 1rem)',
                                                  }}
                                                >
                                                  {category?.slug}
                                                </span>
                                              );
                                            })
                                          ) : (
                                            <span className="text-muted">Choose...</span>
                                          )}
                                        </div>
                                        {errors.blogCategory && (
                                          <Form.Text className="text-danger">
                                            {errors.blogCategory}
                                          </Form.Text>
                                        )}


                                        {/* Dropdown with checkboxes */}
                                        {showDropdown && (
                                          <div
                                            className="border rounded p-2 mt-1"
                                            style={{
                                              maxHeight: '150px',
                                              overflowY: 'auto',
                                              width: '100%',
                                              boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
                                            }}
                                          >
                                            {blogcategories.map((category) => (
                                              <Form.Check
                                                key={category?._id}
                                                type="checkbox"
                                                label={category?.slug}
                                                checked={formData?.blogCategory?.includes(category?._id)}
                                                onChange={() => handleBlogCheckboxChange(category?._id)}
                                                className="w-100"
                                              />
                                            ))}
                                          </div>
                                        )}
                                      </Form.Group>
                                      :
                                      (openModal === "job") ?

                                        // Add Select All checkbox at the top of the list
                                        <Form.Group controlId="formAssignedTo" className="w-100">
                                          <Form.Label>Job Category</Form.Label>

                                          {/* Display selected items */}
                                          <div
                                            onClick={toggleDropdown}
                                            className="form-control d-flex flex-wrap align-items-center overflow-hidden w-100"
                                            style={{ cursor: 'pointer', padding: '0.375rem 0.75rem', minHeight: '2.4rem' }}
                                          >
                                            {formData?.cityCategory?.length > 0 ? (
                                              formData.cityCategory.map((id) => {
                                                const category = cities.find((cat) => cat?.id === id);
                                                return (
                                                  <span
                                                    key={id}
                                                    className="badge bg-white me-1 mb-1 text-black"
                                                    style={{
                                                      whiteSpace: 'nowrap',
                                                      overflow: 'hidden',
                                                      textOverflow: 'ellipsis',
                                                      maxWidth: 'calc(100% - 1rem)',
                                                    }}
                                                  >
                                                    {category?.english}
                                                  </span>
                                                );
                                              })
                                            ) : (
                                              <span className="text-muted">Choose...</span>
                                            )}
                                          </div>
                                          {errors.cityCategory && (
                                            <Form.Text className="text-danger">{errors.cityCategory}</Form.Text>
                                          )}

                                          {/* Dropdown with checkboxes */}
                                          {showDropdown && (
                                            <div
                                              className="border rounded p-2 mt-1"
                                              style={{
                                                maxHeight: '150px',
                                                overflowY: 'auto',
                                                width: '100%',
                                                boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
                                              }}
                                            >
                                              {/* Individual City Checkboxes */}
                                              {cities.map((category) => (
                                                <Form.Check
                                                  key={category?.id}
                                                  type="checkbox"
                                                  label={category?.english}
                                                  checked={formData?.cityCategory?.includes(category?.id)}
                                                  onChange={() => handleCityCheckboxChange(category.id)}
                                                  className="w-100"
                                                />
                                              ))}
                                            </div>
                                          )}
                                        </Form.Group>


                                        :
                                        <Form.Group
                                          controlId="formGridType"
                                          className="full_wt_dp"
                                        >
                                          <Form.Label>Select Type</Form.Label>
                                          <Form.Select
                                            value={formData.type}
                                            onChange={handleTypeChange}
                                            className="form-control"
                                            name="type"
                                          >
                                            <option value="">Choose...</option>
                                            <option value="cities">City</option>
                                            <option value="countries">Country</option>
                                            <option value="airports">Airport</option>
                                            <option value="airline">Airline</option>
                                          </Form.Select>
                                          {errors.type && (
                                            <Form.Text className="text-danger">
                                              {errors.type}
                                            </Form.Text>
                                          )}
                                        </Form.Group>
                                }
                                {/* add faq  start*/}
                                 {
                                  ((openModal === "faq") && (loginUserId.role !== 'Executive')) && (
                                    
                                   <div className="pl-3 pt-2">
                                   <Form.Check
                                      type="checkbox"
                                      placeholder="Allow add Faq"
                                      value={formData?.allowAddFaq}
                                      onChange={handleAllowAddFaqChange }
                                    />
                                    <span>Allow add Faq</span>
                                   </div>
                                  )
                                 }
                                 {
                                  ((openModal === "blog") && (loginUserId.role !== 'Executive')) && (
                                    
                                   <div className="pl-3 pt-2">
                                   <Form.Check
                                      type="checkbox"
                                      placeholder="Allow add Blog"
                                      value={formData?.allowAddBlog}
                                      onChange={handleAllowAddBlogChange }
                                    />
                                    <span>Allow add Blog</span>
                                   </div>
                                  )
                                 }
                                 {
                                  ((openModal === "job") && (loginUserId.role !== 'Executive')) && (
                                    
                                   <div className="pl-3 pt-2">
                                   <Form.Check
                                      type="checkbox"
                                      placeholder="Allow add Job"
                                      value={formData?.allowAddJob}
                                      onChange={handleAllowAddJobChange }
                                    />
                                    <span>Allow add Job</span>
                                   </div>
                                  )
                                 }

                                {/*add  faq  */}

                                {formData.type !== "airline" && (
                                  <>
                                    {
                                      ((openModal === 'faq') || (openModal === 'blog') || (openModal === 'job')) ?
                                        " "
                                        :
                                        <Form.Group
                                          controlId="formGridOrigin"
                                          className="half_wt_dp"
                                        >
                                          <Form.Label>Select Origin</Form.Label>
                                          <Form.Select
                                            value={formData.origin}
                                            onChange={handleInputChange}
                                            className="form-control"
                                            name="origin"
                                          >
                                            <option value="">Choose...</option>
                                            {origins.map((origin, index) => (
                                              <option
                                                key={index}
                                                value={
                                                  type === "cities"
                                                    ? origin.city_code
                                                    : type === "countries"
                                                      ? origin.country_code
                                                      : origin.code
                                                }
                                              >
                                                {origin.english}
                                              </option>
                                            ))}
                                          </Form.Select>

                                          {errors.origin && (
                                            <Form.Text className="text-danger">
                                              {errors.origin}
                                            </Form.Text>
                                          )}
                                        </Form.Group>
                                    }

                                    {
                                      ((openModal === 'faq') || (openModal === 'blog') || (openModal === 'job')) ? "" :

                                        <Form.Group
                                          controlId="formGridDestination"
                                          className="half_wt_dp"
                                        >
                                          <Form.Label>Destination</Form.Label>
                                          <Form.Select
                                            value={formData.destination}
                                            onChange={handleInputChange}
                                            className="form-control"
                                            name="destination"
                                          >
                                            <option value="">Choose...</option>
                                            {destinations.map(
                                              (destination, index) => (
                                                <option
                                                  key={index}
                                                  value={
                                                    type === "cities"
                                                      ? destination.city_code
                                                      : type === "countries"
                                                        ? destination.country_code
                                                        : destination.code
                                                  }
                                                >
                                                  {destination.english}
                                                </option>
                                              )
                                            )}
                                          </Form.Select>
                                          {errors.destination && (
                                            <Form.Text className="text-danger">
                                              {errors.destination}
                                            </Form.Text>
                                          )}
                                        </Form.Group>
                                    }

                                  </>
                                )}

                                {/* Airline Selection */}

                                {
                                  ((openModal === 'faq') || (openModal === 'blog') || (openModal === 'job')) ?
                                    ""
                                    :

                                    <Form.Group
                                      controlId="formGridAirline"
                                      className="full_wt_dp"
                                    >
                                      <Form.Label>Select Airline</Form.Label>
                                      <Form.Select
                                        value={formData.airline}
                                        onChange={handleInputChange}
                                        className="form-control"
                                        name="airline"
                                      >
                                        <option value="">Choose...</option>
                                        {airlines.map((airline, index) => (
                                          <option
                                            key={index}
                                            value={airline.airline_code}
                                          >
                                            {airline.airline_name}
                                          </option>
                                        ))}
                                      </Form.Select>
                                      {errors.airline && (
                                        <Form.Text className="text-danger">
                                          {errors.airline}
                                        </Form.Text>
                                      )}
                                    </Form.Group>
                                }


                                {/* Date Fields */}

                                {
                                  ((openModal === 'faq') || (openModal === 'blog') || (openModal === 'job')) ?
                                    "" :
                                    <Form.Group
                                      controlId="formFromDate"
                                      className="half_wt_dp"
                                    >
                                      <Form.Label>From Date</Form.Label>
                                      <Form.Control
                                        type="date"
                                        name="fromDate"
                                        value={formData.fromDate}
                                        onChange={handleInputChange}
                                      />
                                      {errors.fromDate && (
                                        <Form.Text className="text-danger">
                                          {errors.fromDate}
                                        </Form.Text>
                                      )}
                                    </Form.Group>

                                }

                                {
                                  ((openModal === 'faq') || (openModal === 'blog') || (openModal === 'job')) ?
                                    "" :
                                    <Form.Group
                                      controlId="formToDate"
                                      className="half_wt_dp"
                                    >
                                      <Form.Label>To Date</Form.Label>
                                      <Form.Control
                                        type="date"
                                        name="toDate"
                                        value={formData.toDate}
                                        onChange={handleInputChange}
                                      />
                                      {errors.toDate && (
                                        <Form.Text className="text-danger">
                                          {errors.toDate}
                                        </Form.Text>
                                      )}
                                    </Form.Group>
                                }


                                {/* Assigned To Field  manager*/}

                            <Form.Group controlId="formAssignedTo" className="full_wt_dp">
                              
                              {
                                loginUserId.role === 'Admin' && (
                                <>
                                  {/* Assigned To Dropdown */}
                                  <Form.Label>Assigned To</Form.Label>
                                  <Form.Select
                                    value={formData.assignedTo}
                                    onChange={handleInputChange}
                                    className="form-control "
                                    name="assignedTo"
                                  >
                                    <option value="">Choose...</option>
                                    {managers.map((manager, index) => (
                                      <option key={index} value={manager.id}>
                                        {manager.name}
                                      </option>
                                    ))}
                                  </Form.Select>
                                  {errors.assignedTo && (
                                    <Form.Text className="text-danger">{errors.assignedTo}</Form.Text>
                                  )}
                                  {(teamLead.length > 0) && (
                                <>
                                  {/* Assign To TeamLead Dropdown */}
                                  <Form.Label className="pt-3">Assign To TeamLead</Form.Label>
                                  <Form.Select
                                    value={formData.assignedTeamLead}
                                    onChange={fetchedExecutive}
                                    className="form-control"
                                    name="assignedTeamLead"
                                  >
                                    <option value="">Choose...</option>
                                    {teamLead.map((teamLeads, index) => (
                                      <option key={index} value={teamLeads.id}>
                                        {teamLeads.name}
                                      </option>
                                    ))}
                                  </Form.Select>
                                  {errors.assignedTeamLead && (
                                    <Form.Text className="text-danger">
                                      {errors.assignedTeamLead}
                                    </Form.Text>
                                  )}
                                </>
                              )}
                              {(teamExective.length > 0) && (
                                  <>
                                    {/* Assign To Team Executive Dropdown */}
                                    <Form.Label className="pt-3">Assign To Team Executive</Form.Label>
                                    <Form.Select
                                      value={formData.assignedTeamExective}
                                      onChange={handleInputChange}
                                      className="form-control"
                                      name="assignedTeamExective"
                                    >
                                      <option value="">Choose...</option>
                                      {teamExective.map((teamLeads, index) => (
                                        <option key={index} value={teamLeads.id}>
                                          {teamLeads.name}
                                        </option>
                                      ))}
                                    </Form.Select>
                                    {errors.assignedTeamExective && (
                                      <Form.Text className="text-danger">
                                        {errors.assignedTeamExective}
                                      </Form.Text>
                                    )}
                                  </>
                                )}
                                 
                                </>
                              )}
                         
                           
                            </Form.Group>

                          <Form.Group className="full_wt_dp">
                          {
                                (loginUserId.role === 'Manager') &&(
                                  <>
                                  {/* Assign To TeamLead Dropdown */}
                                  <Form.Label>Assign To TeamLead</Form.Label>
                                  <Form.Select
                                    value={formData.assignedTeamLead}
                                    onChange={fetchedExecutive}
                                    // onChange={handleInputChange}
                                    className="form-control"
                                    name="assignedTeamLead"
                                  >
                                    <option value="">Choose...</option>
                                    {managers.map((manager, index) => (
                                      <option key={index} value={manager.id}>
                                        {manager.name}
                                      </option>
                                    ))}
                                  </Form.Select>
                                  {errors.assignedTeamLead && (
                                    <Form.Text className="text-danger">
                                      {errors.assignedTeamLead}
                                    </Form.Text>
                                  )}
                                 {console.log("sadsadsa",formData)}
                                  {(teamExective.length > 0) && (
                                  <>
                                    {/* Assign To Team Executive Dropdown */}
                                    <Form.Label>Assign To Team Executive</Form.Label>
                                    <Form.Select
                                      value={formData.assignedTeamExective}
                                      onChange={handleInputChange}
                                      className="form-control"
                                      name="assignedTeamExective"
                                    >
                                      <option value="">Choose...</option>
                                      {teamExective.map((teamLeads, index) => (
                                        <option key={index} value={teamLeads.id}>
                                          {teamLeads.name}
                                        </option>
                                      ))}
                                    </Form.Select>
                                    {errors.assignedTeamExective && (
                                      <Form.Text className="text-danger">
                                        {errors.assignedTeamExective}
                                      </Form.Text>
                                    )}
                                  </>
                                )}
                                </>

                                )
                              }
                          </Form.Group>

                          <Form.Group className="full_wt_dp">
                          {
                                (loginUserId.role === 'TeamLead') &&(
                                  <>
                                      {/* Assign To Team Executive Dropdown */}
                                      <Form.Label>Assign To Team Executive</Form.Label>
                                      <Form.Select
                                        value={formData.assignedTeamExective}
                                        onChange={handleInputChange}
                                        className="form-control"
                                        name="assignedTeamExective"
                                      >
                                        <option value="">Choose...</option>
                                        {managers.map((manager, index) => (
                                        <option key={index} value={manager.id}>
                                          {manager.name}
                                        </option>
                                      ))}
                                      </Form.Select>
                                      {errors.assignedTeamExective && (
                                        <Form.Text className="text-danger">
                                          {errors.assignedTeamExective}
                                        </Form.Text>
                                      )}
                                    </>
                                )
                              }
                          </Form.Group>

                                 



                                {/* <Form.Group
                                  controlId="formAssignedTo"
                                  className="full_wt_dp"
                                >
                                  <Form.Label>Assigned To</Form.Label>
                                  <Form.Select
                                    value={formData.assignedTo}
                                    onChange={handleInputChange}
                                    className="form-control"
                                    name="assignedTo"
                                  >
                                    <option value="">Choose...</option>
                                    {managers.map((manager, index) => (
                                      <option key={index} value={manager.id}>
                                        {manager.name}
                                      </option>
                                    ))}
                                  </Form.Select>
                                  {errors.assignedTo && (
                                    <Form.Text className="text-danger">
                                      {errors.assignedTo}
                                    </Form.Text>
                                  )}
                                </Form.Group>
                                {
                                  ((teamLead.length > 0)) && (

                                    <Form.Group
                                      controlId="formAssignedTo"
                                      className="full_wt_dp"
                                    >
                                      <Form.Label>Assign To TeamLead </Form.Label>
                                      <Form.Select
                                        value={formData.assignedTeamLead}
                                        onChange={fetchedExecutive}
                                        className="form-control"
                                        name="assignedTeamLead"
                                      >
                                        <option value="">Choose...</option>
                                        {teamLead.map((teamLeads, index) => (
                                          <option key={index} value={teamLeads.id}>
                                            {teamLeads.name}
                                          </option>
                                        ))}
                                      </Form.Select>
                                      {errors.assignedTeamLead && (
                                        <Form.Text className="text-danger">
                                          {errors.assignedTeamLead}
                                        </Form.Text>
                                      )}
                                    </Form.Group>

                                  )
                                }

                                {
                                  (teamExective.length > 0) && (

                                    <Form.Group
                                      controlId="formAssignedTo"
                                      className="full_wt_dp"
                                    >
                                      <Form.Label>Assign To Team Exective</Form.Label>
                                      <Form.Select
                                        value={formData.assignedTeamExective}
                                        onChange={handleInputChange}
                                        className="form-control"
                                        name="assignedTeamExective"
                                      >
                                        <option value="">Choose...</option>
                                        {teamExective.map((teamLeads, index) => (
                                          <option key={index} value={teamLeads.id}>
                                            {teamLeads.name}
                                          </option>
                                        ))}
                                      </Form.Select>
                                      {errors.assignedTeamExective && (
                                        <Form.Text className="text-danger">
                                          {errors.assignedTeamExective}
                                        </Form.Text>
                                      )}
                                    </Form.Group>

                                  )
                                } */}

                                {/* Submit Button */}
                               
                                 <button
                                  type="submit"
                                  className="btn btn-primary submit_btn_dp org_bg_dp"
                                >
                                  Submit
                                </button>
                               
                              </div>
                            </div>
                          </Form>
                        </div>
                       {/* form end */}

                      </div>
                    </div>
                  </div>
                )}

                {isAssignOpen && (
                  <div className="task_poup_dp">
                    <div className="modal-dialog main" role="document">
                      <div className="modal-content main">
                        <div className="modal-header">
                          <button
                            type="button"
                            className="close"
                            onClick={() => setIsAssignOpen(false)}
                          >
                            <span aria-hidden="true">&times;</span>
                          </button>
                        </div>

                        <div className="modal-body modal-main sidebar_popup">
                          <Form
                            id="assignForm"
                            className="common-form common-form-border login-signup-form"
                            onSubmit={handleAssignTask}
                            autoComplete="off"
                          >
                            <div className="row mb-5">
                              <div className="col-lg-12">
                                {/* Type Selection */}
                                <Form.Group
                                  controlId="formGridType"
                                  className="full_wt_dp"
                                >
                                  <Form.Label>Select Assignee</Form.Label>
                                  <Form.Select
                                    value={assignee}
                                    onChange={(e) =>
                                      setAssignee(e.target.value)
                                    }
                                    className="form-control"
                                    name="assignee"
                                  >
                                    <option value="">Choose...</option>
                                    {managers.map((manager, index) => (
                                      <option key={index} value={manager.id}>
                                        {manager.name}
                                      </option>
                                    ))}
                                  </Form.Select>
                                  {errors.type && (
                                    <Form.Text className="text-danger">
                                      {errors.type}
                                    </Form.Text>
                                  )}
                                </Form.Group>

                                {/* Submit Button */}
                                <button
                                  type="submit"
                                  className="btn btn-primary submit_btn_dp org_bg_dp"
                                >
                                  Submit
                                </button>
                              </div>
                            </div>
                          </Form>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>

     
        {/* <AssignedTaskReportModel
         
         isOpen={openReportModel}
         onClose={handleCloseReportModel}
        /> */}

      {/* report model */}

     {isModalOpen && (
        <div
          className="modal fade show"
          style={{ display: "block", backgroundColor: "rgba(0, 0, 0, 0.5)" }}
          tabIndex="-1"
          role="dialog"
        >
       <div className="modal-dialog" role="document">
      <div className="modal-content">
        <div className="modal-header">
          <h5 className="modal-title" id="exampleModalLabel">
            Assigned Task Report
          </h5>
          <button
            type="button"
            className="close"
            onClick={handleCloseReportModel}
            aria-label="Close"
          >
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div className="modal-body">
          <Form onSubmit={handleSubmitReport}>
            {/* Textarea for the report */}
            <Form.Control
              className="form-control shadow-sm"
              as="textarea"
              placeholder="Leave a report here"
              value={formData.reportMessage}
              onChange={handleReportChange}
              style={{ height: "100px" }}
            />

            {/* Date Input Field */}
            <div className="py-3">
              <Form.Label>Select Date:</Form.Label>
              <Form.Control
                type="date"
                className="form-control"
                value={formData.reportDate} // Current date
                onChange={handleDateChange} // Handle user change
              />
            </div>

            {/* Submit Button */}
            <div className="py-3">
              <button
                type="submit"
                className="btn btn-primary submit_btn_dp org_bg_dp"
              >
                Submit
              </button>
            </div>
          </Form>
        </div>
        <div className="modal-footer">
          <button
            type="button"
            className="btn btn-secondary"
            onClick={handleCloseReportModel}
          >
            Close
          </button>
        </div>
      </div>
    </div>

        </div>
      )}


    </>
  );
};

export default DashboardTaskAssigning;



