import React, { useEffect, useState } from "react";
import "./Common/css/admin_style.css";
import DashboardHeader from "./Common/DashboardHeader";
import { Form, Tab, Tabs } from "react-bootstrap";
import SunEditor from "suneditor-react";
import Sidebar from "./Common/Sidebar_menu";
import { toast } from "react-toastify";
import AxiosJWT from "./Common/AxiosJWT";
import { useParams } from "react-router-dom";

const DashboardEditJob = () => {
  const [languages, setLangs] = useState([]);
  const [errors, setErrors] = useState({});
  const [formData, setFormData] = useState({
    jobTitle: {},
    jobDesc: {},
    location: "",
    department: "",
  });

  const { jobSlug } = useParams();

  const getLanguages = async () => {
    try {
      const response = await fetch(`https://flight-backend-ro3e.onrender.com/api/languages`);
      const data = await response.json();
      if (data.length > 0) setLangs(data);
    } catch (error) {
      console.error(error);
    }
  };

  const fetchJobDetails = async () => {
    try {
      const response = await AxiosJWT.get(`https://flight-backend-ro3e.onrender.com/api/job/${jobSlug}`);
      const data = response.data;
      setFormData({
        jobTitle: data.jobTitle || {},
        jobDesc: data.jobDesc || {},
        location: data.location || "",
        department: data.department || "",
      });
    } catch (error) {
      console.error(error);
      toast.error("Failed to load job details");
    }
  };

  useEffect(() => {
    getLanguages();
    fetchJobDetails();
  }, [jobSlug]);

  const handleChange = (lang, field, value) => {
    // Regex to allow only alphabetic characters and spaces
    const isValid = /^[A-Za-z\s]*$/.test(value);

    if (!isValid) {
      setErrors((prevErrors) => ({
        ...prevErrors,
        [`${field}-${lang}`]: "Only letters and spaces are allowed.",
      }));
      return;
    }

    setErrors((prevErrors) => ({
      ...prevErrors,
      [`${field}-${lang}`]: "", // Clear error if input is valid
    }));

    setFormData((prevState) => ({
      ...prevState,
      [field]: {
        ...prevState[field],
        [lang]: value,
      },
    }));
  };

  const handleFieldChange = (field, value) => {
    // Regex to allow only alphabetic characters and spaces
    const isValid = /^[A-Za-z\s]*$/.test(value);

    if (!isValid) {
      setErrors((prevErrors) => ({
        ...prevErrors,
        [field]: "Only letters and spaces are allowed.",
      }));
      return;
    }

    setErrors((prevErrors) => ({
      ...prevErrors,
      [field]: "", // Clear error if input is valid
    }));

    setFormData((prevState) => ({
      ...prevState,
      [field]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await AxiosJWT.put(`https://flight-backend-ro3e.onrender.com/api/job/${jobSlug}`, formData);
      toast.success("Job updated successfully");
    } catch (error) {
      console.error(error);
      toast.error("Error updating job");
    }
  };

  return (
    <div>
      <section className="visitor-pages">
        <div className="container-fluid p-0">
          <div className="row p-0 m-0">
            <div className="col-md-2 bg-light">
              <Sidebar />
            </div>
            <div className="col-md-10">
              <header>
                <DashboardHeader />
              </header>
              <Form id="webForm" onSubmit={handleSubmit}>
                <div className="modal-content main">
                  <div className="modal-header">
                    <p className="form-heading mb-0">Edit Job</p>
                  </div>
                  <div className="row mb-5">
                    <div className="col-lg-6">
                      <Form.Group className="mb-3" controlId="formLocation">
                        <Form.Label>Location</Form.Label>
                        <Form.Control
                          type="text"
                          value={formData.location}
                          onChange={(e) => handleFieldChange("location", e.target.value)}
                        />
                      </Form.Group>
                    </div>
                    <div className="col-lg-6">
                      <Form.Group className="mb-3" controlId="formDepartment">
                        <Form.Label>Department</Form.Label>
                        <Form.Control
                          type="text"
                          value={formData.department}
                          onChange={(e) => handleFieldChange("department", e.target.value)}
                        />
                        {errors["department"] && (
                          <span style={{ color: "red" }}>
                            {errors["department"]}
                          </span>
                        )}
                      </Form.Group>
                    </div>
                  </div>
                  <Tabs defaultActiveKey="en" id="uncontrolled-tab-example" className="mb-3">
                    {languages.map((lang) => (
                      <Tab key={lang.code} eventKey={lang.code} title={lang.name}>
                        <div className="row">
                          <div className="col-md-12 form_field_popup">
                            <Form.Group className="mb-3 f-left w-100" controlId={`title-${lang.code}`}>
                              <Form.Label>Job Title</Form.Label>
                              <Form.Control
                                type="text"
                                value={formData.jobTitle[lang.code] || ""}
                                onChange={(e) => handleChange(lang.code, "jobTitle", e.target.value)}
                              />
                              {errors[`jobTitle-${lang.code}`] && (
                                <span style={{ color: "red" }}>
                                  {errors[`jobTitle-${lang.code}`]}
                                </span>
                              )}
                            </Form.Group>
                            <Form.Label>Job Description</Form.Label>
                            <SunEditor
                              setOptions={{
                                height: 200,
                                buttonList: [
                                  ["undo", "redo"],
                                  ["font", "fontSize", "formatBlock"],
                                  ["paragraphStyle", "blockquote"],
                                  [
                                    "bold",
                                    "underline",
                                    "italic",
                                    "strike",
                                    "subscript",
                                    "superscript",
                                  ],
                                  ["fontColor", "hiliteColor", "textStyle"],
                                  ["removeFormat"],
                                  "/",
                                  ["outdent", "indent"],
                                  [
                                    "align",
                                    "horizontalRule",
                                    "list",
                                    "lineHeight",
                                  ],
                                  [
                                    "table",
                                    "link",
                                    "image",
                                    "video",
                                    "audio",
                                  ],
                                  ["fullScreen", "showBlocks", "codeView"],
                                  ["preview", "print"],
                                  ["save", "template"],
                                ],
                              }}
                              onChange={(content) => handleChange(lang.code, "jobDesc", content)}
                              setContents={formData.jobDesc[lang.code] || ""}
                            />
                          </div>
                        </div>
                      </Tab>
                    ))}
                  </Tabs>
                  <div className="col-md-12 form_field_popup">
                    <button
                      variant="primary"
                      className="create_btn form_submit text-center"
                      type="submit"
                    >
                      Update Job
                    </button>
                  </div>
                </div>
              </Form>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default DashboardEditJob;
