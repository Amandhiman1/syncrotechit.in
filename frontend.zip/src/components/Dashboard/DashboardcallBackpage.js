import React, { useEffect } from "react";
import "./Common/css/admin_style.css";
import Sidemanu from "./Common/Sidebar_menu";
import DashboardHeader from "./Common/DashboardHeader";
import { useState } from "react";
import DatePicker from "react-datepicker";
import Calendarimgs from "./Common/img/calender.svg";
import "react-datepicker/dist/react-datepicker.css";
import airoplane from "./Common/img/airplane (8) 1.svg";
import currency from "./Common/img/currency.svg";
import Language from "./Common/img/lang.svg";
import webpage from "./Common/img/044-webpage 1.svg";
import visiter from "./Common/img/Visiters.svg";
import celendr from "./Common/img/calendar2.svg";
import call_back from "./Common/img/call back.svg";
import emails from "./Common/img/049-email 3.svg";
import webpagemini from "./Common/img/044-webpage-mini.svg";
import phone from "./Common/img/Group.svg";
import seate from "./Common/img/032-seat 1.svg";
import plane_from from "./Common/img/plane (14) 1.svg";
import plane_to from "./Common/img/plane (15) 1.svg";
import clendr_from from "./Common/img/calendar-1 1.svg";
import clender_to from "./Common/img/calendar-1 2.svg";
import pendulm from "./Common/img/033-hourglass 1.svg";
import axios from "axios";
import AxiosJWT from "./Common/AxiosJWT";

import { format } from "date-fns";
import { Dropdown } from "react-bootstrap";
import { useDispatch, useSelector } from "react-redux";
import { useHistory } from "react-router-dom/cjs/react-router-dom";
import { checkAdminLogin } from "../../redux/Action";

export default function DashboardcallBackpage() {
  const [inquiries, setInquiries] = useState([]);
  const [openDropdowns, setOpenDropdowns] = useState({});
  const [statusAndComment, setStatusAndComment] = useState({});
  const [openComments, setOpenComments] = useState({});
  const [selectedType, setSelectedType] = useState("On-line");
  const [loading, setLoading] = useState(true);
  const [totalPages, setTotalPages] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [error, setError] = useState();

  const isAdmin = useSelector((state) => state.reducer.isAdmin);
  const dispatch = useDispatch();
  const history = useHistory();

  const getAirportByCode = async (code) => {
    try {
      const response = await AxiosJWT.get(
        `https://flight-backend-ro3e.onrender.com/api/airports/code/${code}`
      );
      return response.data[0];
    } catch (error) {
      console.error(`Error fetching airport data for code ${code}:`, error);
      return null;
    }
  };

  const getInquiries = async (page) => {
    try {
      const response = await AxiosJWT.get(
        `https://flight-backend-ro3e.onrender.com/api/inquiry/${selectedType}/${page}`
      );
      
      if (response.status === 403) {
        console.error("No task assigned to you yet.");
        setError("No task assigned to you yet."); // Set error state
        setLoading(false);
        return;
      }
  
      const { inquiries, totalPages, currentPage } = response.data;
  
      const updatedInquiries = [];
  
      for (const inquiry of inquiries) {
        const fromAirport = await getAirportByCode(
          inquiry.formData.Segments[0].Origin
        );
        const toAirport = await getAirportByCode(
          inquiry.formData.Segments[0].Destination
        );
  
        const updatedInquiry = {
          ...inquiry,
          fromAirport,
          toAirport,
        };
  
        updatedInquiries.push(updatedInquiry);
      }
  
      await setInquiries(updatedInquiries);
      setCurrentPage(currentPage);
      setTotalPages(totalPages);
      setLoading(false);
    } catch (error) {
      console.error("Error fetching inquiries:", error);
      setError(error.response.data.message); // Set error state for other errors
      setLoading(false);
    }
  };

  const handleTypeChange = (e) => {
    setSelectedType(e.target.value);
  };

  const handleChangeStatus = (inquiryId, newStatus) => {
    setOpenDropdowns({});
    setStatusAndComment({
      ...statusAndComment,
      [inquiryId]: { status: newStatus, comment: "" },
    });
  };

  const handleCommentChange = (inquiryId, event) => {
    const comment = event.target.value;
    setStatusAndComment({
      ...statusAndComment,
      [inquiryId]: { ...statusAndComment[inquiryId], comment },
    });
  };

  const toggleDropdown = (inquiryId) => {
    setOpenDropdowns((prevState) => ({
      ...prevState,
      [inquiryId]: !prevState[inquiryId],
    }));
  };

  const toggleComment = (inquiryId) => {
    setOpenComments((prevState) => ({
      ...prevState,
      [inquiryId]: !prevState[inquiryId],
    }));
  };

  const handleSubmit = async (inquiryId) => {
    const { status, comment } = statusAndComment[inquiryId];
    try {
      await AxiosJWT.post(
        `https://flight-backend-ro3e.onrender.com/api/inquiry/${inquiryId}/status`,
        {
          user: "admin@email.com",
          status: status,
          comment: comment,
        }
      ).then((res) => {
        setStatusAndComment({});
        getInquiries(currentPage);
      });
    } catch (error) {
      // Handle errors here
      console.error("Error updating inquiry status:", error.message);

      // You might want to throw the error or handle it according to your application's needs
      throw error;
    }
  };

  const handlePageChange = (page) => {
    getInquiries(page);
  };

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (!event.target.closest(".btns_palneproces")) {
        setOpenDropdowns({});
      }

      if (!event.target.closest(".view_comment_dp")) {
        setOpenComments({});
      }
    };

    document.addEventListener("click", handleClickOutside);

    return () => {
      document.removeEventListener("click", handleClickOutside);
    };
  }, []);

  useEffect(() => {
    getInquiries(1); // Fetch inquiries for the first page initially
  }, [selectedType]);

  return (
    <>
      <section className="admin-pages back_page">
        <div className="container-fluid p-0">
          <div className="row p-0 m-0">
            <div className="col-lg-2 col-md-12 bg-light">
              <Sidemanu />
            </div>

            <div className="col-lg-10 col-md-12 my-id2">
              <header>
                <DashboardHeader />
              </header>
              <div className="col-md-12 mt-4">
                <div className="row top_dash_box">
                  <div className="col-md-3">
                    <div className="green_section offer new_visi">
                      <div className="left_side_dash">
                        <span className="visi">Total Call Request</span>
                        <span className="texts new_text">30,000</span>
                      </div>
                    </div>
                  </div>
                  <div className="col-md-3">
                    <div className="blue_section new_visi">
                      <div className="left_side_dash">
                        <span className="visi">Closed Request</span>
                        <span className="texts new_text">16,000</span>
                      </div>
                    </div>
                  </div>
                  <div className="col-md-3">
                    <div className="orang_section new_visi">
                      <div className="left_side_dash">
                        <span className="visi">Open Request</span>
                        <span className="texts new_text">16,000</span>
                      </div>
                    </div>
                  </div>
                  <div className="col-md-3">
                    <div className="grey_section new_visi">
                      <div className="left_side_dash">
                        <span className="visi">IP Block</span>
                        <span className="texts new_text">1800</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="row m-0 mt-4 p-3  bg-light">
                <div className="col-md-5">
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Search"
                  />
                </div>
                <div className="col-md-4 d-flex  gap-div">
                  {/* <div className="mr-3 d-flex clender_str">
                    <img src={Calendarimgs} alt="" />
                    <DatePicker className='form-control date_picker' selected={startDate} onChange={(date) => setStartDate(date)} placeholderText='From' />
                  </div>
                  <div className="d-flex clender_str ">
                    <img src={Calendarimgs} alt="" />
                    <DatePicker className='form-control date_picker' selected={endDate} onChange={(date) => setEndDate(date)} placeholderText='To' />
                  </div> */}
                  <div class="date-input">
                    <span class="icon-container">
                      <img src={Calendarimgs} alt="" />
                    </span>
                    <input type="text" placeholder="From" />
                  </div>
                  <div class="date-input">
                    <span class="icon-container img-2">
                      <img src={Calendarimgs} alt="" />
                    </span>
                    <input type="text" placeholder="To" />
                  </div>
                </div>
                <div className="col-md-1 pl-2">
                  <select
                    className="custom_select line-select form-control"
                    id="inputGroupSelect03"
                    value={selectedType} // Bind value to selectedType state
                    onChange={handleTypeChange} // Call handleTypeChange function on change
                  >
                    <option value="On-line">On-line</option>
                    <option value="OFF-line">OFF-line</option>
                  </select>
                </div>
                <div className="col-md-2">
                  <input
                    type="submit"
                    name="shortby"
                    value="Short by"
                    className="form-control short-by"
                  />
                </div>
              </div>

              {/* first call request */}
              {loading ? (
                <div>Loading....</div>
              ) : error ? (
                <div>{error}</div> // Show error message if there is an error
              ) : inquiries.length > 0 ? (
                <div>
                  {inquiries.map((inquiry) => (
                    <div key={inquiry._id} className="call_req_id">
                      <div className="row ">
                        <div className="col-md-12">
                          <div className="row">
                            <div className="col-md-6">
                              <div className="main_cnt_box d-flex w-100">
                                <div className="img_span">
                                  <img src={call_back} alt="" />
                                </div>
                                <div className="box_cont_img_cont">
                                  <small>Call request ID</small>
                                  <span>{inquiry._id}</span>
                                </div>
                              </div>
                            </div>
                            <div className="col-md-6">
                              <div className="left_cnt_box d-flex w-100">
                                <div className="img_span">
                                  <img src={celendr} alt="" />
                                </div>
                                <div className="box_cont_img_cont">
                                  <small>Call request date</small>
                                  <span>
                                    {format(
                                      new Date(inquiry.createdAt),
                                      "EEE dd MMM yyyy HH:mm"
                                    )}
                                  </span>
                                </div>
                              </div>
                            </div>
                          </div>
                          <hr className="hr_dashbord" />

                          <div className="row">
                            <div className="secd_lins">
                              <div className="main_cnt_box d-flex">
                                <div className="img_span">
                                  <img src={webpage} alt="" />
                                </div>
                                <div className="box_cont_img_cont">
                                  <small>Domain</small>
                                  <span>www.xyz.es</span>
                                </div>
                              </div>

                              <div className="main_cnt_box d-flex">
                                <div className="img_span">
                                  <img src={visiter} alt="" />
                                </div>
                                <div className="box_cont_img_cont">
                                  <small>Types of users</small>
                                  <span>Web client</span>
                                </div>
                              </div>

                              <div className="main_cnt_box d-flex">
                                <div className="img_span">
                                  <img src={airoplane} alt="" />
                                </div>
                                <div className="box_cont_img_cont">
                                  <small>Booking Type</small>
                                  <span>{inquiry.formData.JourneyType}</span>
                                </div>
                              </div>

                              <div className="main_cnt_box d-flex">
                                <div className="img_span">
                                  <img src={Language} alt="" />
                                </div>
                                <div className="box_cont_img_cont">
                                  <small>Language</small>
                                  <span>English</span>
                                </div>
                              </div>

                              <div className="main_cnt_box d-flex">
                                <div className="img_span">
                                  <img src={currency} alt="" />
                                </div>
                                <div className="box_cont_img_cont">
                                  <small>Currency</small>
                                  <span>Euro</span>
                                </div>
                              </div>
                            </div>
                          </div>

                          <hr className="hr_dashbord" />

                          <div className="row">
                            <div className="secd_lins">
                              <div className="main_cnt_box d-flex">
                                <div className="img_span">
                                  <img src={webpagemini} alt="" />
                                </div>
                                <div className="box_cont_img_cont">
                                  <small>Travelers</small>
                                  <span>
                                    {inquiry.formData.AdultCount} Adults |{" "}
                                    {inquiry.formData.ChildCount} Childs |{" "}
                                    {inquiry.formData.InfantCount} Infants
                                  </span>
                                </div>
                              </div>

                              <div className="main_cnt_box d-flex">
                                <div className="img_span">
                                  <img src={seate} alt="" />
                                </div>
                                <div className="box_cont_img_cont">
                                  <small>Cabin</small>
                                  <span>{inquiry.formData.CabinClass}</span>
                                </div>
                              </div>

                              <div className="main_cnt_box d-flex">
                                <div className="img_span">
                                  <img src={phone} alt="" />
                                </div>
                                <div className="box_cont_img_cont">
                                  <small>Contact Number</small>
                                  <span>{inquiry.phone}</span>
                                </div>
                              </div>

                              <div className="main_cnt_box d-flex">
                                <div className="img_span">
                                  <img src={emails} alt="" />
                                </div>
                                <div className="box_cont_img_cont">
                                  <small>Contact Email</small>
                                  <span>{inquiry.email}</span>
                                </div>
                              </div>
                            </div>
                          </div>

                          <hr className="hr_dashbord" />

                          <div className="row">
                            <div className="plan_loc_from_to">
                              <div className="secd_lins">
                                <div className="main_cnt_box d-flex">
                                  <div className="img_span">
                                    <img src={plane_to} alt="" />
                                  </div>
                                  <div className="box_cont_img_cont">
                                    <small>From</small>
                                    <span>
                                      {inquiry.fromAirport?.airport_name}{" "}
                                      {inquiry.fromAirport?.code}
                                    </span>
                                  </div>
                                </div>

                                <div className="main_cnt_box d-flex">
                                  <div className="img_span">
                                    <img src={plane_from} alt="" />
                                  </div>
                                  <div className="box_cont_img_cont">
                                    <small>To</small>
                                    <span>
                                      {inquiry.toAirport?.airport_name}{" "}
                                      {inquiry.toAirport?.code}
                                    </span>
                                  </div>
                                </div>

                                <div className="main_cnt_box d-flex">
                                  <div className="img_span">
                                    <img src={clendr_from} alt="" />
                                  </div>
                                  <div className="box_cont_img_cont">
                                    <small>Depart</small>
                                    <span>
                                      {format(
                                        new Date(
                                          inquiry.formData.Segments[0].DepartureDate
                                        ),
                                        "dd MMM yy"
                                      )}
                                    </span>
                                  </div>
                                </div>

                                {inquiry.formData.JourneyType == "Return" && (
                                  <div className="main_cnt_box d-flex">
                                    <div className="img_span">
                                      <img src={clender_to} alt="" />
                                    </div>
                                    <div className="box_cont_img_cont">
                                      <small>Retun</small>
                                      <span>
                                        {format(
                                          new Date(
                                            inquiry.formData.Segments[0].ReturnDate
                                          ),
                                          "dd MMM yy"
                                        )}
                                      </span>
                                    </div>
                                  </div>
                                )}
                              </div>
                            </div>
                          </div>

                          <hr className="hr_dashbord" />

                          <div className="row">
                            <div className="processing_btns">
                              <div className="secd_lins">
                                <div className="main_cnt_box d-flex">
                                  <div className="img_span">
                                    <img src={pendulm} alt="" />
                                  </div>
                                  <div className="box_cont_img_cont">
                                    <small>Status</small>
                                    <span>{inquiry.status}</span>
                                  </div>
                                </div>

                                <div className="view_comment_dp">
                                  <button
                                    type="button"
                                    class="btn"
                                    onClick={() => toggleComment(inquiry._id)}
                                  >
                                    View Comments
                                  </button>
                                </div>

                                <div className="main_cnt_box d-flex">
                                  <div className="btns_palneproces">
                                    <button
                                      className="process_btn_plane"
                                      onClick={() =>
                                        toggleDropdown(inquiry._id)
                                      }
                                    >
                                      Process
                                    </button>
                                    {openDropdowns[inquiry._id] && (
                                      <Dropdown.Menu show>
                                        <Dropdown.Item
                                          eventKey="1"
                                          onClick={() =>
                                            handleChangeStatus(
                                              inquiry._id,
                                              "Pending"
                                            )
                                          }
                                        >
                                          Pending
                                        </Dropdown.Item>
                                        <Dropdown.Item
                                          eventKey="2"
                                          onClick={() =>
                                            handleChangeStatus(
                                              inquiry._id,
                                              "Call Back"
                                            )
                                          }
                                        >
                                          Call Back
                                        </Dropdown.Item>
                                        <Dropdown.Item
                                          eventKey="3"
                                          onClick={() =>
                                            handleChangeStatus(
                                              inquiry._id,
                                              "Inquiry Only"
                                            )
                                          }
                                        >
                                          Inquiry Only
                                        </Dropdown.Item>
                                        <Dropdown.Item
                                          eventKey="4"
                                          onClick={() =>
                                            handleChangeStatus(
                                              inquiry._id,
                                              "Canceled"
                                            )
                                          }
                                        >
                                          Canceled
                                        </Dropdown.Item>
                                        <Dropdown.Item
                                          eventKey="5"
                                          onClick={() =>
                                            handleChangeStatus(
                                              inquiry._id,
                                              "On Hold"
                                            )
                                          }
                                        >
                                          On Hold
                                        </Dropdown.Item>
                                        <Dropdown.Item
                                          eventKey="6"
                                          onClick={() =>
                                            handleChangeStatus(
                                              inquiry._id,
                                              "Trash"
                                            )
                                          }
                                        >
                                          Trash
                                        </Dropdown.Item>
                                        <Dropdown.Item
                                          eventKey="7"
                                          onClick={() =>
                                            handleChangeStatus(
                                              inquiry._id,
                                              "Completed"
                                            )
                                          }
                                        >
                                          Completed
                                        </Dropdown.Item>
                                      </Dropdown.Menu>
                                    )}
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      {openComments[inquiry._id] && (
                        <div>
                          {inquiry.comments.length !== 0 ? (
                            inquiry.comments.map((comment) => {
                              const date = new Date(comment.timestamp);
                              const formattedDate = date.toLocaleString();
                              return (
                                <div className="comm_main_box_dp">
                                  <div className="row">
                                    <div className="col-lg-6">
                                      <p>
                                        <b>User:</b> {comment.user}
                                      </p>
                                    </div>
                                    <div className="col-lg-6">
                                      <p className="text-right">
                                        <b>Status:</b> {comment.status}
                                      </p>
                                    </div>
                                  </div>
                                  <div className="box_dp">
                                    {comment.comment}
                                    <p className="comm_time">{formattedDate}</p>
                                  </div>
                                </div>
                              );
                            })
                          ) : (
                            <div>No Comments</div>
                          )}
                        </div>
                      )}
                      {statusAndComment[inquiry._id] && (
                        <div className="callback_comm_dp">
                          <p>
                            <b>Selected Status:</b>{" "}
                            <span>{statusAndComment[inquiry._id].status}</span>
                          </p>
                          <textarea
                            value={statusAndComment[inquiry._id].comment}
                            onChange={(e) =>
                              handleCommentChange(inquiry._id, e)
                            }
                            placeholder="Add a comment..."
                          />
                          <button
                            className="process_btn_plane"
                            onClick={() => handleSubmit(inquiry._id)}
                          >
                            Submit
                          </button>
                        </div>
                      )}
                    </div>
                  ))}
                  <div className="pagination">
                    {Array.from({ length: totalPages }, (_, i) => (
                      <button
                        key={i}
                        onClick={() => handlePageChange(i + 1)} // Pages are 1-based
                        className={currentPage === i + 1 ? "active" : ""}
                      >
                        {i + 1}
                      </button>
                    ))}
                  </div>
                </div>
              ) : (
                <div>No inquiries available</div>
              )}
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
