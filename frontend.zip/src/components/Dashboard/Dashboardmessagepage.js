import React, { useEffect } from "react";
import "./Common/css/admin_style.css";
import Sidemenu from "./Common/Sidebar_menu";
import DashboardHeader from "./Common/DashboardHeader";

import { useState } from "react";

import Calendarimgs from "./Common/img/calender.svg";
import "react-datepicker/dist/react-datepicker.css";
import airoplane from "./Common/img/airplane (8) 1.svg";
import currency from "./Common/img/currency.svg";
import Language from "./Common/img/lang.svg";
import webpage from "./Common/img/044-webpage 1.svg";
import visiter from "./Common/img/Visiters.svg";
import celendr from "./Common/img/calendar2.svg";
import message from "./Common/img/Messages.svg";
import emails from "./Common/img/049-email 3.svg";
import webpagemini from "./Common/img/044-webpage-mini.svg";
import phone from "./Common/img/Group.svg";
import DatePicker from "react-datepicker";
import axios from "axios";
import { format } from "date-fns";
import { useDispatch, useSelector } from "react-redux";
import { useHistory } from "react-router-dom/cjs/react-router-dom";
import { Dropdown } from "react-bootstrap";
import { checkAdminLogin } from "../../redux/Action";
import AxiosJWT from './Common/AxiosJWT'
import bluedot from './Common/img/blue_dot.svg'
import orgdot from './Common/img/org_dot.svg'
import greendot from './Common/img/greendot.svg'

export default function Dashboardmessagepage() {
  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(null);
  const [contactData, setContactData] = useState([]);
  const [openDropdowns, setOpenDropdowns] = useState({});
  const [loading, setLoading] = useState(true);
  const [totalPages, setTotalPages] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);

  const isAdmin = useSelector((state) => state.reducer.isAdmin);
  const dispatch = useDispatch();
  const history = useHistory();

  

  useEffect(() => {
    getApiData(1);
  }, []);

  const getApiData = async (page) => {
    try {
      const res = await AxiosJWT.get(
        `https://flight-backend-ro3e.onrender.com/api/contact-help-you/${page}`
      );
      const { tickets, totalPages, currentPage } = res.data;
      await setContactData(tickets);
      setCurrentPage(currentPage);
      setTotalPages(totalPages);
      setLoading(false);
    } catch (error) {
      console.log(error);
      setLoading(false);
    }
  };

  const toggleDropdown = (itemId) => {
    setOpenDropdowns((prevState) => ({
      ...prevState,
      [itemId]: !prevState[itemId],
    }));
  };

  const handleChangeStatus = async (itemId, status) => {
    try {
      await AxiosJWT
        .put(
          `https://flight-backend-ro3e.onrender.com/api/contact-help-you/tickets/${itemId}/status`,
          {
            status: status,
          }
        )
        .then((res) => {
          console.log(res);
          getApiData(currentPage);
          setLoading(false);
          setOpenDropdowns({});
        });
    } catch (error) {
      // Handle errors here
      console.error("Error updating inquiry status:", error.message);

      // You might want to throw the error or handle it according to your application's needs
      throw error;
    }
  };

  const handlePageChange = (page) => {
    getApiData(page);
  };

  return (
    <section className="admin-pages massage_page">
      <div className="container-fluid p-0">
        <div className="row p-0 m-0">
          <div className="col-lg-2 col-md-12 bg-light">
            <Sidemenu />
          </div>

          <div className="col-lg-10 col-md-12 my-id2 message_box_dp">
            <header>
              <DashboardHeader />
            </header>

            {/* content */}
            <div className="col-md-12 mt-4">
              <div className="row top_dash_box">
                <div className="col-md-3">
                  <div className="green_section offer new_visi">
                    <div className="left_side_dash">
                      <span className="visi">Total Call Request</span>
                      <span className="texts new_text">30,000</span>
                    </div>
                  </div>
                </div>
                <div className="col-md-3">
                  <div className="blue_section new_visi">
                    <div className="left_side_dash">
                      <span className="visi">Closed Request</span>
                      <span className="texts new_text">
                      <img src={bluedot} />
                      16,000</span>
                    </div>
                  </div>
                </div>
                <div className="col-md-3">
                  <div className="orang_section new_visi">
                    <div className="left_side_dash">
                      <span className="visi">Open Request</span>
                      <span className="texts new_text">
                      <img src={orgdot} />
                      16,000</span>
                    </div>
                  </div>
                </div>
                <div className="col-md-3">
                  {/* <div className="grey_section new_visi">
                                        <div className='left_side_dash' >
                                            <span className="visi">IP Block</span>
                                            <span className="texts new_text">1800</span>
                                        </div>
                                        </div> */}
                </div>
              </div>
            </div>

            <div className="row m-0 mt-4 p-3  bg-light">
              <div className="col-md-5">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Search"
                />
              </div>
              <div className="col-md-4 d-flex gap-div">
                {/* <div className="mr-3 d-flex clender_str">
                  <img src={Calendarimgs} alt="" />
                  <DatePicker
                    className="form-control date_picker"
                    selected={startDate}
                    onChange={(date) => setStartDate(date)}
                    placeholderText="From"
                  />
                </div>
                <div className="d-flex clender_str ">
                  <img src={Calendarimgs} alt="" />
                  <DatePicker
                    className="form-control date_picker"
                    selected={endDate}
                    onChange={(date) => setEndDate(date)}
                    placeholderText="To"
                  />
                </div> */}
                <div class="date-input">
      <span class="icon-container">
      <img src={Calendarimgs} alt="" />
      </span>
      <input type="text" placeholder="From"/>
  </div>
  <div class="date-input">
      <span class="icon-container img-2">
      <img src={Calendarimgs} alt="" />
      </span>
      <input type="text" placeholder="To"/>
  </div>
              </div>
              <div className="col-md-1 pl-2">
                <select
                  className="custom_select form-control"
                  id="inputGroupSelect03"
                >
                  <option>Type</option>
                  <option value="1">One</option>
                  <option value="2">Two</option>
                </select>
              </div>
              <div className="col-md-2">
                <input
                  type="submit"
                  className="form-control"
                  Name="shortby"
                  value="Short by"
                  class="form-control short-by"
                />
              </div>
            </div>

            {/* first call request */}
            {loading ? (
              <div>Loading....</div>
            ) : contactData.length > 0 ? (
              <div>
                {contactData
                  .map((item, index) => {
                    return (
                      <div key={item.id} className="call_req_id">
                        <div className="row ">
                          <div className="col-md-12">
                            {/* first row */}
                            <div className="row">
                              <div className="col-md-6 ">
                                <div className="main_cnt_box d-flex w-100">
                                  <div className="img_span">
                                    <img src={message} alt="" />
                                  </div>
                                  <div className="box_cont_img_cont">
                                    <small>Call request ID</small>
                                    <span>{item.id}</span>
                                  </div>
                                </div>
                              </div>
                              <div className="col-md-6 ">
                                <div className="left_cnt_box d-flex w-100">
                                  <div className="img_span">
                                    <img src={celendr} alt="" />
                                  </div>
                                  <div className="box_cont_img_cont">
                                    <small>Call request date</small>
                                    <span>
                                      {format(
                                        new Date(item.createdAt),
                                        "EEE dd MMM yyyy HH:mm"
                                      )}
                                    </span>
                                  </div>
                                </div>
                              </div>
                            </div>

                            {/* end first row */}

                            <hr className="hr_dashbord" />

                            {/* start second row */}

                            <div className="row">
                              <div className="secd_lins box_border">
                                <div className="main_cnt_box d-flex">
                                  <div className="img_span">
                                    <img src={webpage} alt="" />
                                  </div>
                                  <div className="box_cont_img_cont">
                                    <small>Domain</small>
                                    <span>www.xyz.es</span>
                                  </div>
                                </div>

                                <div className="main_cnt_box d-flex">
                                  <div className="img_span">
                                    <img src={visiter} alt="" />
                                  </div>
                                  <div className="box_cont_img_cont">
                                    <small>Types of users</small>
                                    <span>Web client</span>
                                  </div>
                                </div>

                                <div className="main_cnt_box d-flex">
                                  <div className="img_span">
                                    <img src={airoplane} alt="" />
                                  </div>
                                  <div className="box_cont_img_cont">
                                    <small>Booking Type</small>
                                    <span>Flight</span>
                                  </div>
                                </div>

                                <div className="main_cnt_box d-flex">
                                  <div className="img_span">
                                    <img src={Language} alt="" />
                                  </div>
                                  <div className="box_cont_img_cont">
                                    <small>Language</small>
                                    <span>English</span>
                                  </div>
                                </div>

                                <div className="main_cnt_box d-flex">
                                  <div className="img_span">
                                    <img src={currency} alt="" />
                                  </div>
                                  <div className="box_cont_img_cont">
                                    <small>Currency</small>
                                    <span>Euro</span>
                                  </div>
                                </div>
                              </div>
                            </div>

                            {/* end second row */}

                            <hr className="hr_dashbord" />

                            {/* start third row */}

                            <div className="row">
                              <div className="secd_lins" key={index}>
                                <div className="main_cnt_box d-flex">
                                  <div className="img_span">
                                    <img src={webpagemini} alt="" />
                                  </div>
                                  <div className="box_cont_img_cont">
                                    <small>Travelers</small>
                                    <span>www.xyz.es</span>
                                  </div>
                                </div>

                                <div className="main_cnt_box d-flex">
                                  <div className="img_span">
                                    <img src={phone} alt="" />
                                  </div>
                                  <div className="box_cont_img_cont">
                                    <small>Contact Number</small>
                                    <span>{item.number}</span>
                                  </div>
                                </div>

                                <div className="main_cnt_box d-flex">
                                  <div className="img_span">
                                    <img src={emails} alt="" />
                                  </div>
                                  <div className="box_cont_img_cont">
                                    <small>Contact Email</small>
                                    <span>{item.email}</span>
                                  </div>
                                </div>
                              </div>
                            </div>
                            {/* end three row */}

                            <hr className="hr_dashbord" />

                            {/* start four row */}

                            <div className="row">
                              <div className="processing_btns">
                                <div className="secd_lins">
                                  <div className="d-flex status_opn">
                                    <div className="img_dp">
                                      <img src={greendot} />
                                    </div>
                                    <div className="box_cont_img_cont">
                                      <small>Status</small>
                                      <span>{item.status}</span>
                                    </div>
                                  </div>

                                  <div className="main_cnt_box d-flex w-50">
                                    <div className="box_cont_img_cont">
                                      <small>Subject</small>
                                      <span>{item.subject}</span>
                                    </div>
                                  </div>

                                  {/* <div class="view_comment_dp">
                                  <button
                                    type="button"
                                    class="btn"
                                    fdprocessedid="yw1z9n"
                                  >
                                    View Message
                                  </button>
                                </div> */}
                                  <div className="main_cnt_box d-flex">
                                    <div class="btns_palneproces">
                                      <button
                                        class="process_btn_plane green_bg_dp"
                                        onClick={() => toggleDropdown(item.id)}
                                      >
                                        Process
                                      </button>
                                      {openDropdowns[item.id] && (
                                        <Dropdown.Menu show>
                                          <Dropdown.Item
                                            eventKey="1"
                                            onClick={() =>
                                              handleChangeStatus(
                                                item.id,
                                                "Open"
                                              )
                                            }
                                          >
                                            Open
                                          </Dropdown.Item>
                                          <Dropdown.Item
                                            eventKey="2"
                                            onClick={() =>
                                              handleChangeStatus(
                                                item.id,
                                                "Closed"
                                              )
                                            }
                                          >
                                            Closed
                                          </Dropdown.Item>
                                        </Dropdown.Menu>
                                      )}
                                    </div>
                                  </div>
                                </div>
                                {/* <div class="message-box">
                                <div class="comm_main_box_dp">
                                  <div class="row">
                                    <div class="col-lg-6">
                                      <p>
                                        <b>User:</b> admin@email.com
                                      </p>
                                    </div>
                                    <div class="col-lg-6">
                                      <p class="text-right">
                                        <b>Status:</b> Pending
                                      </p>
                                    </div>
                                  </div>
                                  <div class="box_dp">
                                    test
                                    <p class="comm_time">
                                      4/12/2024, 11:32:31 AM
                                    </p>
                                  </div>
                                </div>

                                <div class="comm_main_box_dp">
                                  <div class="row">
                                    <div class="col-lg-6">
                                      <p>
                                        <b>User:</b> admin@email.com
                                      </p>
                                    </div>
                                    <div class="col-lg-6">
                                      <p class="text-right">
                                        <b>Status:</b> Pending
                                      </p>
                                    </div>
                                  </div>
                                  <div class="box_dp">
                                    test
                                    <p class="comm_time">
                                      4/12/2024, 11:32:31 AM
                                    </p>
                                  </div>
                                </div>
                              </div> */}
                              </div>
                            </div>
                            {/* end four row */}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                <div className="pagination">
                  {Array.from({ length: totalPages }, (_, i) => (
                    <button
                      key={i}
                      onClick={() => handlePageChange(i + 1)} // Pages are 1-based
                      className={currentPage === i + 1 ? "active" : ""}
                    >
                      {i + 1}
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              <div>No inquiries available</div>
            )}
            {/* content end */}
          </div>
        </div>
      </div>
    </section>
  );
}
