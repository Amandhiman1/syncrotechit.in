import React, { useState, useEffect } from "react";
import Sidemenu from "./Common/Sidebar_menu";
import DashboardHeader from "./Common/DashboardHeader";
import AxiosJWT from './Common/AxiosJWT';

const DashboardProfilePage = () => {
  const [profile, setProfile] = useState({
    id: "",
    name: "",
    email: "",
    mobile: "",
    designation: "",
    role: "",
    empId: "",
    userType: "",
    languagePermissions: [],
  });

  const user = JSON.parse(sessionStorage.getItem('user'));

  useEffect(() => {
    // Fetch the profile data from the API
    AxiosJWT.get(`https://flight-backend-ro3e.onrender.com/api/users/${user.id}`)
      .then((response) => setProfile(response.data))
      .catch((error) => console.error("Error fetching profile data:", error));
  }, [user.id]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setProfile({ ...profile, [name]: value });
  };

  const handleValidation = (e) => {
    e.preventDefault();
    
    // Prepare data for updating the profile
    const updatedProfile = {
      name: profile.name,
      email: profile.email,
      mobile: profile.mobile,
      designation: profile.designation,
      userType: profile.userType,
      // If languagePermissions is editable, you can add it here
      // languagePermissions: profile.languagePermissions,
    };

    // Send the PUT request to update the profile
    AxiosJWT.put(`https://flight-backend-ro3e.onrender.com/api/users/profile`, updatedProfile)
      .then((response) => {
        console.log("Profile updated successfully:", response.data);
        // Optionally update the session storage or profile state with the new data
        sessionStorage.setItem('user', JSON.stringify(response.data));
        setProfile(response.data);
      })
      .catch((error) => console.error("Error updating profile:", error));
  };

  return (
    <>
      <section className="visitor-pages">
        <div className="container-fluid p-0">
          <div className="row p-0 m-0">
            <div className="col-md-2 bg-light">
              <Sidemenu />
            </div>
            <div className="col-md-10">
              <header>
                <DashboardHeader />
              </header>
              <form onSubmit={handleValidation} id="webForm">
                <div className="modal-content main">
                  <div className="modal-header">
                    <p className="form-heading mb-0">Your Profile</p>
                  </div>
                  <div className="modal-body">
                    <div className="form-group">
                      <label htmlFor="id">ID</label>
                      <input
                        type="text"
                        className="form-control"
                        id="id"
                        name="id"
                        value={profile.id}
                        disabled
                      />
                    </div>
                    <div className="form-group">
                      <label htmlFor="name">Name</label>
                      <input
                        type="text"
                        className="form-control"
                        id="name"
                        name="name"
                        value={profile.name}
                        onChange={handleInputChange}
                        required
                      />
                    </div>
                    <div className="form-group">
                      <label htmlFor="email">Email</label>
                      <input
                        type="email"
                        className="form-control"
                        id="email"
                        name="email"
                        value={profile.email}
                        onChange={handleInputChange}
                        required
                      />
                    </div>
                    <div className="form-group">
                      <label htmlFor="mobile">Mobile</label>
                      <input
                        type="text"
                        className="form-control"
                        id="mobile"
                        name="mobile"
                        value={profile.mobile}
                        onChange={handleInputChange}
                        required
                      />
                    </div>
                    <div className="form-group">
                      <label htmlFor="designation">Designation</label>
                      <input
                        type="text"
                        className="form-control"
                        id="designation"
                        name="designation"
                        value={profile.designation}
                        onChange={handleInputChange}
                      />
                    </div>
                    <div className="form-group">
                      <label htmlFor="role">Role</label>
                      <input
                        type="text"
                        className="form-control"
                        id="role"
                        name="role"
                        value={profile.role}
                        disabled
                      />
                    </div>
                    <div className="form-group">
                      <label htmlFor="empId">Employee ID</label>
                      <input
                        type="text"
                        className="form-control"
                        id="empId"
                        name="empId"
                        value={profile.empId}
                        disabled
                      />
                    </div>
                    <div className="form-group">
                      <label htmlFor="userType">User Type</label>
                      <input
                        type="text"
                        className="form-control"
                        id="userType"
                        name="userType"
                        value={profile.userType}
                        onChange={handleInputChange}
                      />
                    </div>
                    <div className="form-group">
                      <label htmlFor="languagePermissions">Language Permissions</label>
                      <textarea
                        className="form-control"
                        id="languagePermissions"
                        name="languagePermissions"
                        value={profile.languagePermissions?.join(", ")}
                        disabled
                      />
                    </div>
                  </div>
                  <div className="col-md-12 form_field_popup">
                    <button
                      variant="primary"
                      className="create_btn form_submit text-center"
                      type="submit"
                    >
                      Submit
                    </button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default DashboardProfilePage;
