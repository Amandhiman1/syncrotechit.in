import React, { useState, useEffect } from "react";
import img_serch from "./Assets/blog_search.svg";
import Header from "./Include/Header";
import Footer from "./Include/Footer";
import { useParams } from "react-router-dom";
import { useSelector } from "react-redux";
import axios from "axios";
import { format } from "date-fns";
import {
  FacebookShareButton,
  TwitterShareButton,
  WhatsappShareButton,
  FacebookIcon,
  TwitterIcon,
  WhatsappIcon,
} from "react-share";
import { Nav } from "react-bootstrap";
import { NavLink } from "react-router-dom/cjs/react-router-dom";

export default function Blog_view() {
  const { blogSlug } = useParams();
  const [blog, setBlog] = useState({});
  const [loading, setLoading] = useState(true);
  const [likes, setLikes] = useState(0);
  const [dislikes, setDislikes] = useState(0);
  const [categories, setCategories] = useState([]);

  const selectedLanguage = useSelector((state) => state.reducer.language);

  const getBlog = async () => {
    await axios
      .get(`https://flight-backend-ro3e.onrender.com/api/blog/${blogSlug}`)
      .then((res) => {
        setBlog(res.data);
        setLikes(res.data.likes);
        setDislikes(res.data.dislikes);
        setLoading(false);
      })
      .catch((err) => {
        console.error(err);
        setLoading(false);
      });
  };

  const getCategories = async () => {
    await axios
      .get("https://flight-backend-ro3e.onrender.com/api/blogcat")
      .then((res) => {
        setCategories(res.data);
      })
      .catch((err) => {
        console.error(err);
      });
  };

  const handleLike = async () => {
    await axios
      .post(`https://flight-backend-ro3e.onrender.com/api/blog/${blogSlug}/like`)
      .then((res) => {
        setLikes(res.data.likes);
      })
      .catch((err) => {
        console.error(err);
      });
  };

  const handleDislike = async () => {
    await axios
      .post(`https://flight-backend-ro3e.onrender.com/api/blog/${blogSlug}/dislike`)
      .then((res) => {
        setDislikes(res.data.dislikes);
      })
      .catch((err) => {
        console.error(err);
      });
  };

  useEffect(() => {
    getBlog();
    getCategories();
  }, [blogSlug]);

  return (
    <>
      {/* header */}
      <Header />
      {/* end header  */}

      {/* one section */}
      {loading ? (
        <div>Loading...</div>
      ) : (
        <div>
          <section
            className="blog_view_section"
            style={{
              background: `url(https://flight-backend-ro3e.onrender.com/images/${blog.imageUrl})`,
            }}
          >
            <div className="container">
              <div className="row">
                <div className="col-md-12 mb-3">
                  <div className="">
                    <h2 className="about-prime-text text-center">
                      {blog.titles[selectedLanguage]}{" "}
                    </h2>
                    <div class="posted-create-sec">
                      <p className="post_by text-center ">Posted By :- Admin</p>
                      <div class="divider-box">,</div>
                      <p className="post_by text-center ">
                        Created At :-{" "}
                        {format(new Date(blog.createdAt), "EEE dd MMM yyyy")}
                      </p>
                      <div class="divider-box">,</div>
                      <p className="post_by text-center ">Category :- Abc</p>
                    </div>
                    <div className="relatedlocation d-flex align-content-center justify-content-center">
                      <button className="relt_location_blog">
                        {blog.category[selectedLanguage]}
                      </button>
                    </div>
                    <div>
                      <div class="like-dislike-btn">
                        <button
                          onClick={handleLike}
                          className="btn btn-primary me-2 like"
                        >
                          <img
                            src="../icons/white-like-1388-svgrepo-com.svg"
                            alt="Thumbs Up"
                            class="icon-1"
                          />
                          Like ({likes})
                        </button>
                        <button
                          onClick={handleDislike}
                          className="btn btn-danger me-2 like-dislike"
                        >
                          {" "}
                          <img
                            src="../icons/white-dislike-1388-svgrepo-com.svg"
                            alt="Thumbs Down"
                            class="icon-1"
                          />
                          Dislike ({dislikes})
                        </button>
                      </div>
                      <div class="social-icons">
                        <FacebookShareButton
                          url={window.location.href}
                          className="me-2"
                        >
                          <FacebookIcon size={32} round />
                        </FacebookShareButton>
                        <TwitterShareButton
                          url={window.location.href}
                          className="me-2"
                        >
                          <TwitterIcon size={32} round />
                        </TwitterShareButton>
                        <WhatsappShareButton url={window.location.href}>
                          <WhatsappIcon size={32} round />
                        </WhatsappShareButton>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              {/* <SearchComponent /> */}
            </div>
          </section>
          {/* end one section */}

          {/* one section */}
          <section className="blog_two_section">
            <div className="container blog-two">
              <div className="row">
                <div className="col-md-8">
                  <div
                    dangerouslySetInnerHTML={{
                      __html: blog.contents[selectedLanguage],
                    }}
                  />
                </div>
                <div className="col-md-4">
              <div className="sidebar_sticky">
                <div className="sidebar_blog">
                  <div className="search_blog_box">
                    <img src={img_serch} alt="" />
                    <input
                      type="search"
                      placeholder="Search"
                      className="me-2"
                      aria-label="Search"
                    />
                  </div>
                  <div className="cat_blog_box">
                    <h6 className="cat_blogstext">Categories</h6>
                    <Nav as="ul" className="blog_ul">
                      <Nav.Item as="li" className="blog_li">
                        <NavLink to="/blog">
                          All
                        </NavLink>
                      </Nav.Item>
                      {categories.map((category) => (
                        <Nav.Item as="li" className="blog_li" key={category.slug}>
                          <NavLink to={`/blog/category/${category.slug}`}>
                            {category.title[selectedLanguage]}
                          </NavLink>
                        </Nav.Item>
                      ))}
                    </Nav>
                  </div>
                </div>
              </div>
            </div>
              </div>
            </div>
          </section>
          {/* end one section */}
        </div>
      )}

      {/* header */}
      <Footer />
      {/* end header  */}
    </>
  );
}

// <section className='blog_view_three_section'>
//   <div className='container'>
//     <div className='row'>
//       <div className='col-md-8'>
//         <div className='relt_blog_blog_view'>
//           <h3 className='simi_stories'>Similar stories</h3>
//           <p className='interesting_blg_vi'>This could be interesting for you.</p>
//         </div>

//         <div className='blog_cat'>
//           {
//             blog_cont.map((blogs =>

//               <div className='blog_viwe_page'>

//                 <div className='blogs_cts'>

//                   <img src={blogs.img} alt='' className='blog_viwe_img' />
//                   <div className='blog_cont'>
//                     <p className='beach_cat'>{blogs.blog_cat}</p>
//                     <h6 className='visited_beaches'>{blogs.blog_name}</h6>
//                     <p className='miami_discover'>{blogs.blog_disc}</p>

//                     <div className='auther_details d-flex align-items-center '>
//                       <img src={blogs.author_img} alt='' />
//                       <div className=' ' >
//                         <h6 className='autherby'>{blogs.author_by}</h6>
//                         <p className='autherdate'>{blogs.author_date}</p>
//                       </div>
//                     </div>
//                   </div>
//                 </div>

//               </div>
//             ))
//           }

//         </div>
//       </div>

//     </div>

//   </div>
// </section>
