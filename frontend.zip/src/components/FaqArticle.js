import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import Header from "./Include/Header";
import Footer from "./Include/Footer";
import axios from "axios";
import { useSelector } from "react-redux";
import { Link } from "react-router-dom/cjs/react-router-dom";

const FaqArticle = () => {
  const { articleSlug } = useParams();
  const [article, setArticle] = useState({});
  const [loading, setLoading] = useState(true);

  const selectedLanguage = useSelector((state) => state.reducer.language);

  const getArticle = async () => {
    await axios
      .get(`https://flight-backend-ro3e.onrender.com/api/faqArticle/${articleSlug}`)
      .then((res) => {
        setArticle(res.data);
        setLoading(false);
      })
      .catch((err) => {
        console.error(err);
        setLoading(false);
      });
  };

  useEffect(() => {
    getArticle();
  }, [articleSlug]);

  return (
    <>
      <Header />
      {loading ? (
        <div>Loading...</div>
      ) : (
        <section>
          <div class="container main-cancel mx-auto px-4 py-8">
            <h1 class="text-2xl font-bold mb-4">
              {article.articleData[selectedLanguage].title}
            </h1>
            <div
              dangerouslySetInnerHTML={{
                __html: article.articleData[selectedLanguage].content,
              }}
            />
            <div class="footer-content mt-8 flex justify-end space-x-4">
              <span class="text-zinc-600">Still need help?</span>
              <Link to="/contact-us">
                <button class="contact-btn text-white px-4 py-2 rounded-lg">
                  Contact us
                </button>
              </Link>
            </div>
          </div>
        </section>
      )}
      <Footer />
    </>
  );
};

export default FaqArticle;
