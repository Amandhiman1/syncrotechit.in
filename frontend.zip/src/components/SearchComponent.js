import React, { useEffect, useRef, useState } from "react";
import { useHistory } from "react-router-dom";
import { Alert, Button, Form, Image } from "react-bootstrap";
import axios from "axios";
import DatePicker, { CalendarContainer } from "react-datepicker";
import PhoneInput from "react-phone-input-2";
import "react-phone-number-input/style.css";
import clendr_from from "./Dashboard/Common/img/calendar-1 1.svg";
import clender_to from "./Dashboard/Common/img/calendar-1 2.svg";
import user from "./Dashboard/Common/img/user.svg";
import seat from "./Dashboard/Common/img/032-seat 1.svg";
import search_img from "./Assets/search 1.svg";
import MulticityComponent from "./MulticityComponent";
import SearchableDropdown from "./SearchableDropdown";
import Popload from "./Popload";
import { useDispatch, useSelector } from "react-redux";
import { setCountryCode } from "../redux/Action";
import swal from "sweetalert2";
import Animatedgif from "./Animatedgif";
import leftarrow from './Common/img/left_arrow.svg';
import rightarrow from './Common/img/right_arrow.svg';
import increment from './Common/img/increment.svg';
import decrement from './Common/img/decrement.svg';
import child from './Common/img/child.svg';
import adult from './Common/img/adults.svg';
import infant from './Common/img/infarant.svg';
import CabinBaggage from './Common/img/Cabin_Baggage.svg';
import CheckedBaggage from './Common/img/Checked_Baggage.svg';




const showalert = (heading) => {
  swal.fire({
    title: heading,
    icon: "question",
    customClass: {
      popup: "my-popup",
      confirmButton: "my-confirm-button",
      cancelButton: "my-cancel-button",
    },
  });
};



const SearchComponent = () => {
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 3);
  const dispatch = useDispatch();
  const countryCode = useSelector((state) => state.reducer.countryCode);
  const [departDate, setDepartDate] = useState(tomorrow);
  const [returnDate, setReturnDate] = useState();
  const [airports, setAirports] = useState([]);
  const [loading, setLoading] = useState(true);
  const [dataLoading, setDataLoading] = useState(false);
  const [selectedFlightType, setSelectedFlightType] = useState("OneWay");
  const [fromAirport, setFromAirport] = useState();
  const [toAirport, setToAirport] = useState();
  const [isDetailOpen, setIsDetailOpen] = useState(false);
  const [isCabinDetailOpen, setIsCabinDetailOpen] = useState(false);
  const [openForm, setOpenForm] = useState(false);
  const [adultCount, setAdultCount] = useState("1");
  const [childCount, setChildCount] = useState("0");
  const [infantCount, setInfantCount] = useState("0");
  const [cabin, setCabin] = useState("Economy");
  const [errors, setErrors] = useState({});
  const [prices, setPrices] = useState({});
  const [isDaterangeOpen, setIsDaterangeOpen] = useState(false);
  const detailModalRef = useRef();
  const history = useHistory();

//  setAdultCount usestate condition for value Increment & Decrement  dharampreet //
  const handleDecrement = () => {
    setAdultCount(prevCount => Math.max(1, prevCount - 1));
  };

  const handleIncrement = () => {
    setAdultCount(prevCount => Math.min(9, prevCount + 1));
  };

  //  setChildCount usestate condition for value Increment & Decrement dharampreet //
  const chlildhandleDecrement = () => {
    setChildCount(prevCount => Math.max(0, prevCount - 1));
  };

  const childhandleIncrement = () => {
    setChildCount(prevCount => Math.min(9, prevCount + 1));
  };


 //  setChildCount usestate condition for value Increment & Decrement dharampreet //
 const InfanthandleDecrement = () => {
  setInfantCount(prevCount => Math.max(0, prevCount - 1));
};

const InfanthandleIncrement = () => {
  setInfantCount(prevCount => Math.min(9, prevCount + 1));
};




  const getCurrentLocation = async () => {
    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const { latitude, longitude } = position.coords;
        console.log(latitude, longitude);
        // Fetch nearest airport
        const response = await axios.get(
          `https://flight-backend-ro3e.onrender.com/api/airports/nearest-airport?latitude=${latitude}&longitude=${longitude}`
        );
        setFromAirport(response.data);
      },
      (error) => {
        console.error("Error getting user location:", error);
      }
    );
  };
  const getAirports = async () => {
    try {
      const locationDetails = await axios.get("https://ipapi.co/json/");
      // console.log("locationDetails =", locationDetails.data);
      dispatch(setCountryCode(locationDetails.data.country_code));
      const response = await axios.get(
        `https://flight-backend-ro3e.onrender.com/api/airports/country-code/${locationDetails.data.country_code}`
      );
      console.log("Airports data:", response.data);
      // const fromAirport = response.data.find(
      //   (airport) => airport.english === locationDetails.data.city
      // );
      // if (fromAirport) {
      //   setFromAirport(fromAirport);
      // } else {
      //   console.log(
      //     "No matching airport found for the city"
      //   );
      // }
      setAirports(response.data);
      setLoading(false);
    } catch (error) {
      console.error("Error fetching airports data:", error);
    }
  };
  const formattedddDate = (dateString) => {
    const date = new Date(dateString);
    // Format the date as "YYYY-MM-DD"
    const formattedDate = date.toISOString().split("T")[0];
    return formattedDate;
  };
  const [forms, setForms] = useState([
    {
      fromAirport: fromAirport,
      toAirport: null,
      departureDate: tomorrow,
      travelers: 2,
      cabin: "Economy",
    },
    {
      fromAirport: null,
      toAirport: null,
      departureDate: tomorrow,
      travelers: 2,
      cabin: "Economy",
    },
  ]);
  const [dates, setDatesState] = useState({
    startDate: tomorrow,
    endDate: "",
  });
  const [formData, setFormData] = useState({
    AdultCount: adultCount,
    ChildCount: childCount,
    InfantCount: infantCount,
    JourneyType: selectedFlightType,
    CabinClass: "Economy",
    Segments: [
      {
        Origin: fromAirport?.code,
        Destination: toAirport?.code,
        DepartureDate: departDate?.toISOString(),
      },
    ],
  });
  const [formValue, setFormValue] = useState({
    name: "",
    email: "",
    phone: "",
    formData: formData,
  });
  const handleFlightTypeChange = (event) => {
    setSelectedFlightType(event.target.value);
  };
  const formatDate = (date) => {
    const options = { day: "numeric", month: "short", year: "2-digit" };
    return new Intl.DateTimeFormat("en-US", options).format(date);
  };
  const handleDepartureDateChange = (date) => {
    console.log(date);
    setDepartDate(date);
  };
  const setDates = (e, { startDate, endDate }) => {
    setDatesState({
      startDate: startDate,
      endDate: endDate,
    });
  };
  const handleSwap = (e) => {
    e.preventDefault();
    const currentFrom = fromAirport;
    setFromAirport(toAirport);
    setToAirport(currentFrom);
  };
  const handleSubmit = async (e) => {
    // e.preventDefault();
    try {
      document.querySelector("button.close").click();
      setOpenForm(false);
      console.log(process.env.REACT_APP_API_URL);
      console.log("formData ==> " + JSON.stringify(formData));
      // Make the first API call
      await axios.post(
        "https://flight-backend-ro3e.onrender.com/api/inquiry",
        formValue,
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );
      // Handle success
      history.push("/thank-you");
    } catch (error) {
      // Handle errors
      console.error(error);
      alert(error);
    }
  };
  const handleValidation = async () => {
    const newErrors = {};
    if (!fromAirport || !toAirport) {
      showalert("Please select the origin and destination");
      newErrors.adultCount = "Please select the origin and destination";
    }
    // Validate adultCount, childCount, infantCount, and cabin here
    if (+adultCount < 1 || +adultCount >= 9) {
      newErrors.adultCount = "Number of adults must be between 1 to 9";
    }
    // Validate adultCount, childCount, infantCount, and cabin here
    if (+adultCount + +childCount < 1 || +adultCount + +childCount > 9) {
      newErrors.adultAndChildCount =
        "Number of adults + childs must be between 1 to 9";
    }
    if (+adultCount * 2 <= +infantCount) {
      newErrors.adultAndInfantCount =
        "Number of adults must be greater than Infant number * 2";
    }
    // Add similar validation for other fields...
    setErrors(newErrors);
    // Return true if there are no errors, otherwise false
    if (Object.keys(newErrors).length === 0) {
      setDataLoading(true);
      // Make the second API call based on selectedFlightType
      if (selectedFlightType === "OneWay" || selectedFlightType === "Return") {
        await axios
          .post(
            "https://flight-backend-ro3e.onrender.com/api/flights/oneway/add",
            formData,
            {
              headers: {
                "Content-Type": "application/json",
              },
            }
          )
          .then((res) => {
            console.log("reached here");
            setDataLoading(false);
            setOpenForm(true);
          })
          .catch((err) => {
            setDataLoading(false);
            setOpenForm(true);
            alert("No Flights Found!");
          });
      }
    }
  };
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormValue((prevFormValue) => ({
      ...prevFormValue,
      [name]: value,
    }));
  };
  const ReturnContainer = ({ className, children }) => {
    return (
      <CalendarContainer className={className}>
      <div className="calendar_pop_dp"> 
    
                              <div className="depart-retun d-flex">
                              <div className="main_cnt_box d-flex">
                                <div className="img_span">
                                  <img src={clendr_from} alt="" />
                                </div>
                                <div className="box_cont_img_cont">
                                  <small>
                                    <label>Depart</label>
                                  </small>
                                  <span>
                                    {departDate
                                      ? formatDate(departDate)
                                      : "22 Jul ‘22"}
                                  </span>
                                </div>
                              </div>
                              <div className="main_cnt_box d-flex">
                                <div className="img_span">
                                  <img src={clender_to} alt="" />
                                </div>
                                <div className="box_cont_img_cont">
                                  <small>
                                    <label>Retun</label>
                                  </small>
                                  <span>
                                    {returnDate
                                      ? formatDate(returnDate)
                                      : "Select date"}
                                  </span>
                                </div>
                              </div>
                            </div>
      </div>
        <div className="derpart_return_dp">{children}</div>
        <div className='btn_dp'>
                                <div className='left_btn_dp'>
                                <img src={leftarrow} width={40} height={40} className='img-fluid mx-auto'/>
                                    <Button className="cancel_btn"  onClick={() => setIsDaterangeOpen(false)}> Cancel</Button>
                                </div>
                                <div className='right_btn_dp'>
                                
                                     <Button className="done_btn" onClick={() => setIsDaterangeOpen(false)}> Done</Button>
                                     <img src={rightarrow} width={40} height={40} className='img-fluid mx-auto'/>
                                </div>
                            </div>

      
      </CalendarContainer>
    );
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get(
          "https://flight-backend-ro3e.onrender.com/api/flights/get-prices",
          {
            params: {
              originCode: fromAirport.code,
              destinationCode: toAirport.code,
            },
          }
        );
        console.log(response.data);
        setPrices(response.data);
      } catch (error) {
        console.error("Error fetching prices:", error);
      }
    };
    fetchData();
  }, [fromAirport, toAirport]);
  useEffect(() => {
    // Attach a click event listener to the document body
    const handleOutsideClick = (event) => {
      // Check if the clicked element is not inside the modal
      if (
        detailModalRef.current &&
        !detailModalRef.current.contains(event.target) &&
        !event.target.classList.contains("open-modal-button") &&
        !event.target.classList.contains("swal2-confirm")
      ) {
        // Close the modal
        setIsDetailOpen(false);
      }
    };
    // Add the event listener when the component mounts
    document.addEventListener("click", handleOutsideClick);
    // Remove the event listener when the component unmounts
    return () => {
      document.removeEventListener("click", handleOutsideClick);
    };
  }, []);
  useEffect(() => {
    getAirports();
    getCurrentLocation();
  }, []);
  useEffect(() => {
    const newErrors = {};
    // Validate adultCount, childCount, infantCount, and cabin here
    if (+adultCount < 1 || +adultCount >= 9) {
      showalert("Number of adults must be between 1 to 9");
      newErrors.adultCount = "Number of adults must be between 1 to 9";
    }
    // Validate adultCount, childCount, infantCount, and cabin here
    if (+adultCount + +childCount < 1 || +adultCount + +childCount > 9) {
      showalert("Number of adults + childs must be between 1 to 9");
      newErrors.adultAndChildCount =
        "Number of adults + childs must be between 1 to 9";
    }
    if (+adultCount * 2 <= +infantCount) {
      showalert("Number of adults must be greater than Infant number * 2");
      newErrors.adultAndInfantCount =
        "Number of adults must be greater than Infant number * 2";
    }
    // Add similar validation for other fields...
    setErrors(newErrors);
  }, [adultCount, childCount, infantCount]);
  useEffect(() => {
    // Update formValue based on selectedFlightType
    if (selectedFlightType === "OneWay") {
      setFormData({
        AdultCount: adultCount,
        ChildCount: childCount,
        InfantCount: infantCount,
        JourneyType: selectedFlightType,
        CabinClass: "Economy",
        Segments: [
          {
            Origin: fromAirport?.code,
            Destination: toAirport?.code,
            DepartureDate: departDate.toISOString(),
          },
        ],
      });
    } else if (
      selectedFlightType === "Return" &&
      dates.startDate &&
      dates.endDate
    ) {
      setFormData({
        AdultCount: adultCount,
        ChildCount: childCount,
        InfantCount: infantCount,
        JourneyType: "Return",
        CabinClass: "Economy",
        Segments: [
          {
            Origin: fromAirport?.code,
            Destination: toAirport?.code,
            DepartureDate: dates.startDate.toISOString(),
            ReturnDate: dates.endDate.toISOString(),
          },
        ],
      });
    } else {
      setFormData({
        AdultCount: adultCount,
        ChildCount: childCount,
        InfantCount: infantCount,
        JourneyType: "Multicity",
        CabinClass: "Economy",
        Segments: forms.map((form) => ({
          Origin: form.fromAirport?.code,
          Destination: form.toAirport?.code,
          DepartureDate: form.departureDate.toISOString(),
        })),
      });
    }
  }, [selectedFlightType, fromAirport, toAirport, departDate, dates]);
  useEffect(() => {
    setFormValue((prevFormValue) => ({
      ...prevFormValue,
      formData: formData,
    }));
  }, [formData]);
  const [datePrices, setDatePrices] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const tileContent = ({ date }) => {
    const priceForDate = datePrices[date.toISOString().split("T")[0]];
    return priceForDate ? <p>${priceForDate}</p> : null;
  };
  const startDate = new Date();
  const endDate = new Date();
  endDate.setMonth(endDate.getMonth() + 1); // Displaying one month
  const dateRange = [startDate, endDate];
  return (
    <div className="col-md-12 search_main_box_dp">
      {dataLoading ? (
        <section className="popupback" style={{ background: "#fff" }}>
          <div className="container mt-5">
            <div className="row">
              <div className="col-md-12 text-center">
                {/* 
            <BounceLoader color="#25B2A0" className="loader___12" />
            */}

                <div class="col-lg-12 animated-gif-plane">
                  <Animatedgif
                    src="https://gi.esmplus.com/elnetmall/%EB%8C%91%ED%84%B0%ED%81%90/QuerulousUnconsciousAndeancondor.gif"
                    alt="AnimatedGif"
                    className="animatedgif"
                  />
                </div>
              </div>
              <Popload />
              {/* <progress value={0.5} /> */}
              <div class=" col-lg-12 d-flex content1 pt-0 pb-0 mt-0 text-center">
                <h2 class="text_shadows text-center">
                  <span className="span-text">Please wait</span> while we
                  process your request
                </h2>
              </div>
            </div>
          </div>
        </section>
      ) : (
        <>
          <div className="col-md-12 uprj banner_section">
            <Form>
              <div className="search-box">
                <div className="search-content">
                  {/* form */}
                  {/* */}
                  <div className="row">
                    <fieldset>
                      <div className="mb-3">
                      <div className="d-flex radiobtns">
  <div className={`sradio radio_box ${selectedFlightType === "OneWay" ? "active" : ""}`}>
    <input
      type="radio"
      value="OneWay"
      checked={selectedFlightType === "OneWay"}
      onChange={handleFlightTypeChange}
    />
    <label className="pl-2">Oneway</label>
  </div>
  <div className={`fradio radio_box ${selectedFlightType === "Return" ? "active" : ""}`}>
    <input
      type="radio"
      value="Return"
      checked={selectedFlightType === "Return"}
      onChange={handleFlightTypeChange}
    />
    <label className="pl-2">Return</label>
  </div>
  <div className={`tradio radio_box ${selectedFlightType === "Multicity" ? "active" : ""}`}>
    <input
      type="radio"
      value="Multicity"
      checked={selectedFlightType === "Multicity"}
      onChange={handleFlightTypeChange}
    />
    <label className="pl-2">Multicity</label>
  </div>
</div>

                      </div>
                    </fieldset>
                    {selectedFlightType === "Multicity" ? (
                      <MulticityComponent
                        airports={airports}
                        loading={loading}
                        forms={forms}
                        setForms={setForms}
                        adultCount={adultCount}
                        childCount={childCount}
                        infantCount={infantCount}
                        setAdultCount={setAdultCount}
                        setChildCount={setChildCount}
                        setInfantCount={setInfantCount}
                        detailModalRef={detailModalRef}
                        setCabin={setCabin}
                        cabin={cabin}
                      />
                    ) : (
                      <div className="plan_loc_from_to">
                        <div className="secd_linsform">
                          <div className="from-to d-flex flight_details_dp">
                            <SearchableDropdown
                              options={airports}
                              loading={loading}
                              type="from"
                              selectedOption={fromAirport}
                              setSelectedOption={setFromAirport}
                            />
                            <img
                              src="/icons/swap-icon.svg"
                              onClick={handleSwap}
                              className="swap-icon"
                            />
                            <SearchableDropdown
                              options={airports}
                              loading={loading}
                              type="to"
                              selectedOption={toAirport}
                              setSelectedOption={setToAirport}
                            />
                          </div>
                          {/* 
                        <LocalizationProvider dateAdapter={AdapterDateFns}>
                           <DateRangePicker />
                        </LocalizationProvider>
                        */}
                          {selectedFlightType === "OneWay" ? (
                            <div className="depart-retun d-flex">
                              <div
                                className="main_cnt_box d-flex"
                                onClick={() =>
                                document
                                .getElementById("departdatepicker")
                                .click()
                                }
                                // onClick={() => setSelectedFlightType("Return")}
                                // onClick={() =>
                                //    setIsDaterangeOpen(!isDaterangeOpen)
                                //    }
                              >
                                <div className="img_span">
                                  <img src={clendr_from} alt="" />
                                </div>
                                <div className="box_cont_img_cont">
                                  <small>
                                    <label>Depart</label>
                                  </small>
                                  <span>
                                    {departDate
                                      ? formatDate(departDate)
                                      : "23 Jul ‘24"}
                                  </span>
                                </div>
                                
                              </div>
                              <DatePicker
                                id="departdatepicker"
                                selected={departDate}
                                onChange={handleDepartureDateChange}
                                dateFormat="dd MMM ''yy"
                                popperClassName="datepicker-popper"
                                minDate={tomorrow}
                                monthsShown={2}
                                dayClassName={(date) => {
                                  // Your logic to conditionally assign CSS classes based on date
                                  return "has-price"; // For example, always assign 'has-price' class
                                }}
                                className="custom-datepicker"
                                renderDayContents={(date, month) => {
                                  const formattedDate = formattedddDate(month); // Assuming formatDate is a function to format date as "YYYY-MM-DD"
                                  const price = prices[formattedDate]; // Assuming prices is the object you receive from the API
                                  return (
                                    <div class="box">
                                      <div class="main_box" id="myBox">
                                        {" "}
                                        <div class="second">{date}</div>
                                        <div class="three">
                                          {/* <p>{`${price ? "$" + price : ""}`}</p> */}
                                          <p>1250 $</p>
                                        </div>
                                      </div>
                                    </div>
                                  );
                                }}
                                

                             
                              />
                              <div
                                className="main_cnt_box d-flex"
                                onClick={() => setSelectedFlightType("Return")}
                              >
                                <div className="img_span">
                                  <img src={clender_to} alt="" />
                                </div>
                                <div className="box_cont_img_cont">
                                  <small>
                                    <label>Retun</label>
                                  </small>
                                  <span>Select date</span>
                                </div>
                              </div>
                            </div>
                          ) : (
                            <div
                              className="depart-retun d-flex"
                              onClick={() =>
                                setIsDaterangeOpen(!isDaterangeOpen)
                              }
                            >
                              <div className="main_cnt_box d-flex">
                                <div className="img_span">
                                  <img src={clendr_from} alt="" />
                                </div>
                                <div className="box_cont_img_cont">
                                  <small>
                                    <label>Depart</label>
                                  </small>
                                  <span>
                                    {departDate
                                      ? formatDate(departDate)
                                      : "22 Jul ‘22"}
                                  </span>
                                </div>
                              </div>
                              <div className="main_cnt_box d-flex">
                                <div className="img_span">
                                  <img src={clender_to} alt="" />
                                </div>
                                <div className="box_cont_img_cont">
                                  <small>
                                    <label>Retun</label>
                                  </small>
                                  <span>
                                    {returnDate
                                      ? formatDate(returnDate)
                                      : "Select date"}
                                  </span>
                                </div>
                              </div>
                            </div>
                          )}
                          <div className="trable-cabin d-flex open-modal-button">
                            <div
                              className="main_cnt_box d-flex open-modal-button"
                              onClick={() => setIsDetailOpen(true)}
                            >
                              <div className="img_span open-modal-button">
                                <img
                                  src={user}
                                  alt=""
                                  className="open-modal-button"
                                />
                              </div>
                              <div className="box_cont_img_cont open-modal-button">
                                <small className="open-modal-button">
                                  <label className="open-modal-button">
                                    Traveler’s
                                  </label>
                                </small>
                                <span className="open-modal-button">
                                  {+adultCount + +childCount + +infantCount}{" "}
                                  Traveler’s
                                </span>
                              </div>
                            </div>
                            <div
                              className="main_cnt_box d-flex open-modal-button"
                              onClick={() => setIsDetailOpen(true)}
                            >
                              <div className="img_span open-modal-button">
                                <img
                                  src={seat}
                                  alt=""
                                  className="open-modal-button"
                                />
                              </div>
                              <div className="box_cont_img_cont open-modal-button">
                                <small className="open-modal-button">
                                  <label className="open-modal-button">
                                    Cabin
                                  </label>
                                </small>
                                <span className="open-modal-button">
                                  {cabin}
                                </span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                  {isDetailOpen && (
                    <div className="adults_ls" ref={detailModalRef}>
                      <h2 className="travel_box_title">Passangers</h2>
                      <div className="row">
                      <div className="col-lg-12">
                      <div className="travel_del_dp">
                          <div className="left_side_dp">
                            <div className="image_dp">
                              <img src={adult} width={40} height={40} className='img-fluid mx-auto'/>
                            </div>
                            <div className="travel_lis_dp">
                              <p className="top-head">
                                <b>ADULTS</b>
                              </p>
                              <p className="num_count">Over 11</p>
                            </div>
                          </div>
                          <div className="right_side_dp">
                            <div className="quantity">
                              <img src={decrement} width={40} height={40} className='img-fluid mx-auto' onClick={handleDecrement}/>
                              <input className="w3-input" type="number" min="1" max="9" value={adultCount} onChange={(e) => { const value = parseInt(e.target.value); if (value >= 1 && value <= 9) { setAdultCount(value); } }} />
                              <img src={increment} width={40} height={40} className='img-fluid mx-auto' onClick={handleIncrement}/>
                            </div>
                          </div>
                      </div>



                        {/* <div class="w3-bar">
                          <span
                            onClick={() => {
                              setAdultCount("1");
                            }}
                            class={`w3-button ${
                              adultCount === "1" && "onclick-change"
                            }`}
                          >
                            1
                          </span>
                          <span
                            onClick={() => {
                              setAdultCount("2");
                            }}
                            class={`w3-button ${
                              adultCount === "2" && "onclick-change"
                            }`}
                          >
                            2
                          </span>
                          <span
                            onClick={() => {
                              setAdultCount("3");
                            }}
                            class={`w3-button ${
                              adultCount === "3" && "onclick-change"
                            }`}
                          >
                            3
                          </span>
                          <span
                            onClick={() => {
                              setAdultCount("4");
                            }}
                            class={`w3-button ${
                              adultCount === "4" && "onclick-change"
                            }`}
                          >
                            4
                          </span>
                          <span
                            onClick={() => {
                              setAdultCount("5");
                            }}
                            class={`w3-button ${
                              adultCount === "5" && "onclick-change"
                            }`}
                          >
                            5
                          </span>
                          <span
                            onClick={() => {
                              setAdultCount("6");
                            }}
                            class={`w3-button ${
                              adultCount === "6" && "onclick-change"
                            }`}
                          >
                            6
                          </span>
                          <span
                            onClick={() => {
                              setAdultCount("7");
                            }}
                            class={`w3-button ${
                              adultCount === "7" && "onclick-change"
                            }`}
                          >
                            7
                          </span>
                          <span
                            onClick={() => {
                              setAdultCount("8");
                            }}
                            class={`w3-button ${
                              adultCount === "8" && "onclick-change"
                            }`}
                          >
                            8
                          </span>
                          <span
                            onClick={() => {
                              setAdultCount("9");
                            }}
                            class={`w3-button ${
                              adultCount === "9" && "onclick-change"
                            }`}
                          >
                            9
                          </span>
                        </div> */}
                        
                      </div>


                     
                         <div className="col-lg-12">
                            <div className="travel_del_dp">
                                <div className="left_side_dp">
                                    <div className="image_dp">
                                      <img src={child} width={40} height={40} className='img-fluid mx-auto'/>
                                    </div>
                                    <div className="travel_lis_dp">
                                      <p className="top-head">
                                          <b>Child</b>
                                      </p>
                                      <p className="num_count">2 - 11</p>
                                    </div>
                                </div>
                                <div className="right_side_dp">
                                    <div className="quantity">
                                          <img src={decrement} width={40} height={40} className='img-fluid mx-auto' onClick={chlildhandleDecrement}/>
                                          <input className="w3-input" type="number" min="1" max="9" value={childCount} onChange={(e) => { const value = parseInt(e.target.value); if (value >= 1 && value <= 9) { setChildCount(value); } }} />
                                          <img src={increment} width={40} height={40} className='img-fluid mx-auto' onClick={childhandleIncrement}/>
                                    </div>
                                </div>
                            </div>

                            {/* <div class="w3-bar">
                            <span
                              onClick={() => {
                                setChildCount("1");
                              }}
                              class={`w3-button ${
                                childCount === "1" && "onclick-change"
                              }`}
                            >
                              1
                            </span>
                            <span
                              onClick={() => {
                                setChildCount("2");
                              }}
                              class={`w3-button ${
                                childCount === "2" && "onclick-change"
                              }`}
                            >
                              2
                            </span>
                            <span
                              onClick={() => {
                                setChildCount("3");
                              }}
                              class={`w3-button ${
                                childCount === "3" && "onclick-change"
                              }`}
                            >
                              3
                            </span>
                            <span
                              onClick={() => {
                                setChildCount("4");
                              }}
                              class={`w3-button ${
                                childCount === "4" && "onclick-change"
                              }`}
                            >
                              4
                            </span>
                            <span
                              onClick={() => {
                                setChildCount("5");
                              }}
                              class={`w3-button ${
                                childCount === "5" && "onclick-change"
                              }`}
                            >
                              5
                            </span>
                            <span
                              onClick={() => {
                                setChildCount("6");
                              }}
                              class={`w3-button ${
                                childCount === "6" && "onclick-change"
                              }`}
                            >
                              6
                            </span>
                            <span
                              onClick={() => {
                                setChildCount("7");
                              }}
                              class={`w3-button ${
                                childCount === "7" && "onclick-change"
                              }`}
                            >
                              7
                            </span>
                            <span
                              onClick={() => {
                                setChildCount("8");
                              }}
                              class={`w3-button ${
                                childCount === "8" && "onclick-change"
                              }`}
                            >
                              8
                            </span>
                            <span
                              onClick={() => {
                                setChildCount("9");
                              }}
                              class={`w3-button ${
                                childCount === "9" && "onclick-change"
                              }`}
                            >
                              9
                            </span>
                          </div> */}
                        </div>

                        <div className="col-lg-12">
                            <div className="travel_del_dp">
                              <div className="left_side_dp">
                                  <div className="image_dp">
                                      <img src={infant} width={40} height={40} className='img-fluid mx-auto'/>
                                  </div>
                                  <div className="travel_lis_dp">
                                      <p className="top_head">
                                        <b>Infant</b>
                                      </p>
                                      <p className="num_count">Under 2</p>
                                  </div>
                              </div>
                              <div className="right_side_dp">
                                 <div className="quantity">
                                    <img src={decrement} width={40} height={40} className='img-fluid mx-auto' onClick={InfanthandleDecrement}/>
                                    <input className="w3-input" type="number" min="1" max="9" value={infantCount} onChange={(e) => { const value = parseInt(e.target.value); if (value >= 1 && value <= 9) { setInfantCount(value);} }} />
                                    <img src={increment} width={40} height={40} className='img-fluid mx-auto' onClick={InfanthandleIncrement}/>
                                  </div>
                              </div>
                            </div>

                          {/* <div class="w3-bar">
                            <span
                              onClick={() => {
                                setInfantCount("1");
                              }}
                              class={`w3-button ${
                                infantCount === "1" && "onclick-change"
                              }`}
                            >
                              1
                            </span>
                            <span
                              onClick={() => {
                                setInfantCount("2");
                              }}
                              class={`w3-button ${
                                infantCount === "2" && "onclick-change"
                              }`}
                            >
                              2
                            </span>
                            <span
                              onClick={() => {
                                setInfantCount("3");
                              }}
                              class={`w3-button ${
                                infantCount === "3" && "onclick-change"
                              }`}
                            >
                              3
                            </span>
                            <span
                              onClick={() => {
                                setInfantCount("4");
                              }}
                              class={`w3-button ${
                                infantCount === "4" && "onclick-change"
                              }`}
                            >
                              4
                            </span>
                            <span
                              onClick={() => {
                                setInfantCount("5");
                              }}
                              class={`w3-button ${
                                infantCount === "5" && "onclick-change"
                              }`}
                            >
                              5
                            </span>
                            <span
                              onClick={() => {
                                setInfantCount("6");
                              }}
                              class={`w3-button ${
                                infantCount === "6" && "onclick-change"
                              }`}
                            >
                              6
                            </span>
                            <span
                              onClick={() => {
                                setInfantCount("7");
                              }}
                              class={`w3-button ${
                                infantCount === "7" && "onclick-change"
                              }`}
                            >
                              7
                            </span>
                            <span
                              onClick={() => {
                                setInfantCount("8");
                              }}
                              class={`w3-button ${
                                infantCount === "8" && "onclick-change"
                              }`}
                            >
                              8
                            </span>
                            <span
                              onClick={() => {
                                setInfantCount("9");
                              }}
                              class={`w3-button ${
                                infantCount === "9" && "onclick-change"
                              }`}
                            >
                              9
                            </span>
                          </div> */}
                   
                        </div>
                        </div>
                        <h2 className="travel_box_title">Bags</h2>
                        <div className="row">
                      <div className="col-lg-12">
                        <div className="travel_del_dp">
                            <div className="left_side_dp">
                              <div className="image_dp">
                                <img src={CabinBaggage} width={40} height={40} className='img-fluid mx-auto'/>
                              </div>
                              <div className="travel_lis_dp">
                                <p className="top-head">
                                  <b>Cabin Baggage</b>
                                </p>
                              </div>
                            </div>
                            <div className="right_side_dp">
                              <div className="quantity">
                                <img src={decrement} width={40} height={40} className='img-fluid mx-auto' onClick={handleDecrement}/>
                                <input className="w3-input" type="number" min="1" max="9" value={adultCount} onChange={(e) => { const value = parseInt(e.target.value); if (value >= 1 && value <= 9) { setAdultCount(value); } }} />
                                <img src={increment} width={40} height={40} className='img-fluid mx-auto' onClick={handleIncrement}/>
                              </div>
                            </div>
                        </div>  
                      </div>

                      <div className="col-lg-12">
                        <div className="travel_del_dp">
                            <div className="left_side_dp">
                              <div className="image_dp">
                                <img src={CheckedBaggage} width={40} height={40} className='img-fluid mx-auto'/>
                              </div>
                              <div className="travel_lis_dp">
                                <p className="top-head">
                                  <b>Checked Baggage</b>
                                </p>
                              </div>
                            </div>
                            <div className="right_side_dp">
                              <div className="quantity">
                                <img src={decrement} width={40} height={40} className='img-fluid mx-auto' onClick={handleDecrement}/>
                                <input className="w3-input" type="number" min="1" max="9" value={adultCount} onChange={(e) => { const value = parseInt(e.target.value); if (value >= 1 && value <= 9) { setAdultCount(value); } }} />
                                <img src={increment} width={40} height={40} className='img-fluid mx-auto' onClick={handleIncrement}/>
                              </div>
                            </div>
                        </div>  
                      </div>
                      </div>

                      <div className="row cabin_dp">
  <div className="col-lg-12">
  
      <div className=" p-0">
        <p>
          <b>Cabin</b>
          {/* <Button
            className="close-button1"
            onClick={() => setIsCabinDetailOpen(false)}
          >
            X
          </Button> */}
        </p>
        <div className="cabin_list_dp">
        {["Economy", "PremiumEconomy", "Business"].map((classType) => (
          <label key={classType} className={cabin === classType ? 'active' : ''}>
            <input
              type="radio"
              name="cabinClass"
              value={classType}
              checked={cabin === classType}
              onChange={() => {
                setCabin(classType);
                setIsCabinDetailOpen(false);
              }}
            />
            <span>{classType === "PremiumEconomy" ? "Premium Economy" : classType}</span>
          </label>
        ))}
        </div>
      </div>

  </div>
</div>

<div className="row">
 
  {Object.keys(errors).length === 0 && (

    <div className='btn_dp'>
                                <div className='left_btn_dp'>
                                <img src={leftarrow} width={40} height={40} className='img-fluid mx-auto'/>
                                    <Button className="cancel_btn"  onClick={() => setIsDetailOpen(false)}> Cancel</Button>
                                </div>
                                <div className='right_btn_dp'>
                                
                                     <Button className="done_btn" onClick={() => setIsDetailOpen(false)}> Done</Button>
                                     <img src={rightarrow} width={40} height={40} className='img-fluid mx-auto'/>
                                </div>
                            </div>
                         
                          )}




                     
 
</div>



                        <div className="col-lg-12">
                          {Object.keys(errors).map((field) => (
                            <div className="error-message">
                              {/* {errors[field]} */}
                            </div>
                          ))}
                        </div>
                    
                    </div>
                  )}
                </div>
                {isDaterangeOpen && (
                  
                  <DatePicker
                    id="returnDatepicker"
                    // selected={departDate}
                    inline
                    selectsRange={true}
                    startDate={departDate}
                    endDate={returnDate}
                    onChange={(dates) => {
                      const [start, end] = dates;
                      setDepartDate(start);
                      setReturnDate(end);
                    }}
                    dateFormat="dd MMM ''yy"
                    popperClassName="datepicker-popper"
                    minDate={tomorrow}
                    monthsShown={2}
                    dayClassName={(date) => {
                      // Your logic to conditionally assign CSS classes based on date
                      if (date) {
                        return "has-price"; // For example, always assign 'has-price' class
                      }
                    }}

                    
                    calendarClassName="custom-datepicker"
                    calendarContainer={ReturnContainer}
                    renderDayContents={(date, month) => {
                      const formattedDate = formattedddDate(month); // Assuming formatDate is a function to format date as "YYYY-MM-DD"
                      const price = prices[formattedDate]; // Assuming prices is the object you receive from the API
                      return (
                        <div class="box">
                          <div class="main_box" id="myBox">
                            {" "}
                            <div class="second">{date}</div>
                            <div class="three">
                              {/* <p>{`${price ? "$" + price : ""}`}</p> */}
                              <p>2351 $</p>
                            </div>
                          </div>
                        </div>
                      );
                    }}
                  />
                )}
                <div className="row d-flex align-items-center justify-content-center search-comp">
                  <div className="search-btn">
                    <Button
                      className="form-sign-submit"
                      data-toggle="modal"
                      data-target="#exampleModal"
                      onClick={handleValidation}
                    >
                      <img src={search_img} alt="" /> Search
                    </Button>
                  </div>
                </div>
              </div>
            </Form>
            {isCabinDetailOpen && (
              <div className="form-set">
                <div className="col-lg-4">
                  {/* 
            <p>on the day of travel</p>
            */}
                  <div class="w3-bar form-set-list">
                    <p>
                      <b>CHOOSE TRAVEL CLASS</b>
                      <Button
                        className="close-button1"
                        onClick={() => setIsCabinDetailOpen(false)}
                      >
                        X
                      </Button>
                    </p>
                    <span
                      onClick={() => {
                        setCabin("Economy");
                        setIsCabinDetailOpen(false);
                      }}
                      class="w3-button"
                    >
                      Economy
                    </span>
                    <span
                      onClick={() => {
                        setCabin("PremiumEconomy");
                        setIsCabinDetailOpen(false);
                      }}
                      class="w3-button"
                    >
                      Premium Economy
                    </span>
                    <span
                      onClick={() => {
                        setCabin("Business");
                        setIsCabinDetailOpen(false);
                      }}
                      class="w3-button"
                    >
                      Business
                    </span>
                  </div>
                </div>
              </div>
            )}
          </div>
          {openForm && (
            <div id="up-sec1">
              <div
                class="modal fade sec-up show"
                id="exampleModal"
                tabindex="-1"
                aria-labelledby="exampleModalLabel"
                aria-modal="true"
                role="dialog"
                style={{ display: "block" }}
              >
                <div class="modal-dialog">
                  <div class="modal-content">
                    <div class="modal-header form-background">
                      <div class="modal-header-inner">
                        <img
                          src={`${process.env.PUBLIC_URL}/image/airplane-form.png`}
                          alt="Example"
                        />
                      </div>
                      <div class="modal-heading">
                        <h5 class="modal-title" id="exampleModalLabel">
                          {/* {" "} */}
                          Please Fill The <span>Details Below</span>
                        </h5>
                        <p>
                          Founded by grandsons of the founders, created to make
                          flying easy and affordable
                        </p>
                      </div>
                      <button
                        type="button"
                        class="close"
                        data-dismiss="modal"
                        aria-label="Close"
                        fdprocessedid="n4qy62"
                        onClick={() => setOpenForm(false)}
                      >
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                    <div class="modal-body form-background">
                      <div className="overlay-body">
                        <Form onSubmit={handleSubmit}>
                          <Form.Group className="mb-3" controlId="name">
                            <Form.Label>Name</Form.Label>
                            <Form.Control
                              type="text"
                              placeholder="Enter Name"
                              name="name"
                              value={formValue.name}
                              className="my-form"
                              onChange={handleInputChange}
                              required
                            />
                          </Form.Group>
                          <Form.Group
                            className="mb-3"
                            controlId="formBasicEmail"
                          >
                            <Form.Label>Email</Form.Label>
                            <Form.Control
                              type="email"
                              placeholder="Email"
                              name="email"
                              className="my-form"
                              value={formValue.email}
                              onChange={handleInputChange}
                              required
                            />
                          </Form.Group>
                          <Form.Group className="mb-3" controlId="number">
                            <Form.Label>Phone Number</Form.Label>
                            {/* 
                        <Form.Control
                           type="number"
                           placeholder="Phone Number"
                           name="phone"
                           className="my-form"
                           value={formValue.phone}
                           onChange={handleInputChange}
                           required
                           />
                        */}
                            <PhoneInput
                              placeholder="Enter phone number"
                              value={formValue.phone}
                              onChange={(value) =>
                                setFormValue({ ...formValue, phone: value })
                              }
                              country={"in"}
                              className="my-form"
                              required
                            />
                          </Form.Group>
                          <Form.Group
                            controlId="termsCheckbox"
                            className="mb-3"
                          >
                            <Form.Check
                              type="checkbox"
                              label="I accept the terms and conditions"
                              name="termsAccepted"
                              checked={formValue.termsAccepted}
                              onChange={handleInputChange}
                              required
                            />
                          </Form.Group>
                          <div className="form-btn">
                            <Button
                              variant="primary"
                              type="submit"
                              className="sub-btn-form"
                            >
                              Submit
                            </Button>
                          </div>
                        </Form>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
};
export default SearchComponent;
