import React from 'react';
import SearchComponent from './SearchComponent';

const HomeSearch = () => {

    return (
        <>
            <section className='banner_section'>
                <div className='container'>
                    <div className='row'>
                        <div className='col-md-12'>
                            <div className='heading'>
                                <h4>
                                    Lets find out best flights deals to your next destination
                                </h4>
                            </div>
                        </div>
                        <SearchComponent />
                    </div>
                </div>
            </section>
        </>
    )
}

export default HomeSearch