import React from "react";
import { useEffect } from "react";
import Footer from "./Include/Footer";
import Header from "./Include/Header";
import brush_img from "./Assets/Brussels_Airlines_SN 2.png";
// import norwign from './Assets/Norwegian_DY 2.svg'
import airoplane from "./Assets/cloud-with-airoplane.svg";
import clender_str from "./Assets/calendar-1 3.png";
import beachs from "./Assets/beach.png";
import missoion from "./Assets/our-mission.png";
import { Link } from "react-router-dom";
import { useParams, useHistory } from "react-router-dom";
import { useState } from "react";
import { useSelector } from "react-redux";
import axios from "axios";
import Button from "react-bootstrap/Button";
import Form from "react-bootstrap/Form";
import HomeSearch from "./HomeSearch";
import SearchComponent from "./SearchComponent";
import FlightsSection from "./SinglePageComponents/FlightsSection";
import AirlinesList from "./SinglePageComponents/AirlinesList";
import PhoneInput from "react-phone-input-2";
import CityComponent from "./SinglePageComponents/CityComponent";
import HorizontalBarChart from "./HorizontalBarChart";
import MyVerticalBarChart from "./MyVerticalBarChart";
import PopularComponent from "./SinglePageComponents/PopularComponent";

export default function CheapFlight() {
  const { slug } = useParams();
  const history = useHistory();
  const [pageData, setPageData] = useState({});
  const [flights, setFlights] = useState([]);
  const [updatedFlights, setUpdatedFlights] = useState([]);
  const [openForm, setOpenForm] = useState(false);
  const [numberOfFlights, setNumberOfFlights] = useState(1);

  const [inquiryForm, setInquiryForm] = useState({
    name: "",
    email: "",
    phone: "",
    termsAccepted: "",
    formData: {
      AdultCount: "1",
      ChildCount: "0",
      InfantCount: "0",
      JourneyType: "OneWay",
      CabinClass: "Economy",
      Segments: [
        {
          Origin: "",
          Destination: "",
          DepartureDate: "",
        },
      ],
    },
  });

  const language = useSelector((state) => state.reducer.language);

  useEffect(() => {
    let isMounted = true;

    async function fetchData() {
      let pdata = await get_webpage();
      console.log("pdata", pdata);

      setPageData(pdata);
    }

    if (isMounted) {
      fetchData();
    }
    return () => {
      isMounted = false;
    };
  }, [slug]);

  useEffect(() => {
    if (
      pageData &&
      pageData.data &&
      pageData.data.length > 0 &&
      pageData.data[0].cover_img
    ) {
      extractString(pageData.data[0].cover_img, "cover_img");
    }

    if (
      pageData &&
      pageData.data &&
      pageData.data.length > 0 &&
      pageData.data[0].content
    ) {
      extractString(pageData.data[0].content, "content");
    }
  }, [pageData]);

  const getLanguageSlug = async () => {
    // console.log('slug ==> ', pageData.common_slug);
    try {
      // let post_data = {
      //   method: 'POST',
      //   body: { 'common_slug': pageData.common_slug, 'lang': language },
      //   headers: {
      //     'Accept': 'application/json',
      //     'Content-Type': 'application/json',
      //     //'X-CSRFToken':  cookie.load('csrftoken')
      //   }
      // }
      if (pageData.common_slug) {
        const post_data = { common_slug: pageData.common_slug, lang: language };
        const response = await axios.post(
          process.env.REACT_APP_API_URL + "webpages/byslug",
          post_data
        );

        console.log("data ==> " + JSON.stringify(response.data));
        if (response.data) {
          history.push(`/${response.data}`);
        }
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleFlightClick = (flight_dtl) => {
    setInquiryForm((prevState) => ({
      ...prevState,
      formData: {
        ...prevState.formData,
        Segments: [
          {
            ...prevState.formData.Segments[0],
            Origin: flight_dtl.Origin.AirportCode, // replace 'newOrigin' with the actual value
            Destination: flight_dtl.Destination.AirportCode, // replace 'newDestination' with the actual value
            DepartureDate: flight_dtl.Origin.DateTime, // replace 'newDepartureDate' with the actual value
          },
          ...prevState.formData.Segments.slice(1), // keep the rest of the segments unchanged
        ],
      },
    }));

    setOpenForm(true);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setInquiryForm((prevForm) => ({
      ...prevForm,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      // Make the POST request
      await axios.post("https://flight-backend-ro3e.onrender.com/api/inquiry", inquiryForm, {
        headers: {
          "Content-Type": "application/json",
        },
      });

      // Reset the form and update state after successful submission
      setInquiryForm({
        name: "",
        email: "",
        phone: "",
        termsAccepted: "",
        formData: {
          AdultCount: "1",
          ChildCount: "0",
          InfantCount: "0",
          JourneyType: "OneWay",
          CabinClass: "Economy",
          Segments: [
            {
              Origin: "",
              Destination: "",
              DepartureDate: "",
            },
          ],
        },
      });

      // Close the form
      setOpenForm(false);

      // Redirect to the thank-you page using history
      history.push("/thank-you");
    } catch (error) {
      console.error(error);
    }
  };

  const get_webpage = async () => {
    try {
      console.log("slug", slug);
      let post_data = { slug: slug };

      const response = await axios.post(
        process.env.REACT_APP_API_URL + "webpages/single",
        post_data
      );
      console.log(response);

      const data = await response.data;

      const query = { query: data[0].query, flightsNumber: numberOfFlights };

      const flightTypes = data[0].data[0].flights;
      setFlights([]);

      console.log("flightTypes", flightTypes);
      if (data.length > 0) {
        Object.values(flightTypes).forEach((flightType) => {
          get_flights(query, flightType);
        });
        return data[0];
      } else return false;
    } catch (e) {
      console.error(e);
    }
  };

  const get_flights = async (query, flightType) => {
    let url;
    if (flightType.queryType === "latest") {
      url = "latest-flights";
    } else if (flightType.queryType === "cheapest") {
      url = "cheapest-flights";
    } else {
      url = "direct-flights";
    }

    try {
      const res = await axios.post(
        `https://flight-backend-ro3e.onrender.com/api/flights/${url}`,
        query
      );

      // Use a functional update to ensure that you're working with the latest state
      console.log("flights", res);
      if (res.data.flights.length != 0) {
        setFlights((prevFlights) => {
          const newFlight = {
            heading: flightType.heading,
            slogan: flightType.slogan,
            slug: flightType.slug,
            componentType: flightType.componentType,
            flights: res.data.flights,
          };
          return [...prevFlights, newFlight];
        });
      }
    } catch (error) {
      console.error("Error fetching flights:", error.message);
      // Handle the error as needed
    }
  };

  useEffect(() => {
    window.scrollTo({
      top: 0,
    });
  }, []);

  useEffect(() => {
    setFlights([]);
    getLanguageSlug();
  }, [language]);

  let cheapflight = [
    {
      id: "1",
      from: "Amsterdam",
      to: "Istanbul",
      img: airoplane,
    },
    {
      id: "2",
      from: "Boston",
      to: "Thiruvananthapuram",
      img: airoplane,
    },
    {
      id: "3",
      from: "Toronto",
      to: "Delhi",
      img: airoplane,
    },
    {
      id: "4",
      from: "London",
      to: "Delhi",
      img: airoplane,
    },
    {
      id: "5",
      from: "Copenhegon",
      to: "Malaga",
      img: airoplane,
    },
    {
      id: "6",
      from: "Berlin",
      to: "Bongkok",
      img: airoplane,
    },
    {
      id: "7",
      from: "Madrid",
      to: "Quito",
      img: airoplane,
    },
    {
      id: "8",
      from: "Lisbon",
      to: "Sao Paulo",
      img: airoplane,
    },
  ];

  let beach_imgs = [
    {
      id: "1",
      beachname: "Bilbao",
      beachprice: "15$",
      beachimg: beachs,
    },
    {
      id: "2",
      beachname: "Bilbao",
      beachprice: "15$",
      beachimg: beachs,
    },
    {
      id: "3",
      beachname: "Bilbao",
      beachprice: "15$",
      beachimg: beachs,
    },
    {
      id: "4",
      beachname: "Bilbao",
      beachprice: "15$",
      beachimg: beachs,
    },
  ];

  let airline_fly_from = [
    {
      id: "1",
      fly_brand: brush_img,
      fly_name: "Brussel Airline",
      fly_stops: "1 Stop",
      fly_from_time: "10:30",
      fly_from: "Delhi",
      fly_to: "Mumbai",
      fly_to_time: "10:30",
      fly_price: "From 40 $ ",
    },
    {
      id: "2",
      fly_brand: brush_img,
      fly_name: "Brussel Airline",
      fly_stops: "1 Stop",
      fly_from_time: "10:30",
      fly_from: "Delhi",
      fly_to: "Mumbai",
      fly_to_time: "10:30",
      fly_price: "From 40 $ ",
    },
    {
      id: "3",
      fly_brand: brush_img,
      fly_name: "Brussel Airline",
      fly_stops: "1 Stop",
      fly_from_time: "10:30",
      fly_from: "Delhi",
      fly_to: "Mumbai",
      fly_to_time: "10:30",
      fly_price: "From 40 $ ",
    },
    {
      id: "4",
      fly_brand: brush_img,
      fly_name: "Brussel Airline",
      fly_stops: "1 Stop",
      fly_from_time: "10:30",
      fly_from: "Delhi",
      fly_to: "Mumbai",
      fly_to_time: "10:30",
      fly_price: "From 40 $ ",
    },
    {
      id: "5",
      fly_brand: brush_img,
      fly_name: "Brussel Airline",
      fly_stops: "1 Stop",
      fly_from_time: "10:30",
      fly_from: "Delhi",
      fly_to: "Mumbai",
      fly_to_time: "10:30",
      fly_price: "From 40 $ ",
    },
  ];

  const getimages = async (nmodifiedArray) => {
    try {
      let post_data = {
        method: "POST",
        //credentials: 'same-origin',
        //mode: 'same-origin',
        body: JSON.stringify({
          categoryOrSub: nmodifiedArray[0],
          type: nmodifiedArray[1],
        }),
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          //'X-CSRFToken':  cookie.load('csrftoken')
        },
      };
      const response = await fetch(
        process.env.REACT_APP_API_URL + "media/filter",
        post_data
      );
      /* .then(response => response.json())
      .then(async data => {
                  //setOrders(data)
                  if(data && data.image){
                    console.log(data.image)
                    return await data.image?(<img src={data.image} />):''                  
                  }
              }, (error) => {
              if (error) {
                  console.log(error)
                  return false
              }
      }); */
      const data = await response.json();

      if (data && data.image) {
        console.log(data.image);
        return data;
      }
    } catch (e) {
      //snotify()
      console.error(e);
      return false;
    }
  };

  const removeDuplicateObjectsWithOrder = (array) => {
    const seen = new Map();
    return array.filter((obj) => {
      const stringifiedObj = JSON.stringify(obj);
      return !seen.has(stringifiedObj) && seen.set(stringifiedObj, 1);
    });
  };

  useEffect(() => {
    const uniqueArrayWithOrder = removeDuplicateObjectsWithOrder(flights);
    setUpdatedFlights(uniqueArrayWithOrder);
  }, [flights]);

  const extractString = (fullString, parmas) => {
    const regex = /{{#(.*?)#}}/g;

    // Find all matches using the regular expression
    const matches = fullString.match(regex);

    //console.log('matches',matches)
    let nmodifiedArray = [];
    matches &&
      matches.map(async (match, index) => {
        console.log(match);
        // Split the string by comma delimiter
        const splitArray = match.split("#^#");
        // Define the words to remove
        const wordsToRemove = ["{{", "}}", "#^#"];
        // Remove the specified words from each substring
        const modifiedArray = splitArray.map((substring) => {
          wordsToRemove.forEach((word) => {
            substring = substring.replace(word, "").trim();
          });
          return substring;
        });
        nmodifiedArray = modifiedArray.filter((str) => str.trim() !== "");

        console.log(nmodifiedArray);

        if (nmodifiedArray.length == 2) {
          let replaceImg = await getimages(nmodifiedArray);

          //replaceImg = (<img src="aa.png" />)
          console.log(
            "replaceImg",
            `<img src="${
              process.env.REACT_APP_IMAGE_URL + replaceImg.image
            }" alt='${replaceImg.alt}' />`,
            match,
            fullString
          );

          const updatedObject = { ...pageData };
          if (parmas == "cover_img") {
            fullString = replaceImg
              ? fullString.replace(
                  match,
                  `${process.env.REACT_APP_IMAGE_URL + replaceImg.image}`
                )
              : fullString.replace(match, ` `);
            updatedObject["data"][0]["cover_img"] = fullString;
            setPageData(updatedObject);
          } else if (parmas == "content") {
            fullString = replaceImg
              ? fullString.replace(
                  match,
                  `<img src="${
                    process.env.REACT_APP_IMAGE_URL + replaceImg.image
                  }" alt="${replaceImg.alt}" />`
                )
              : fullString.replace(match, ` `);
            updatedObject["data"][0]["content"] = fullString;
            setPageData(updatedObject);
          }
        }
      });

    return <div dangerouslySetInnerHTML={{ __html: fullString }} />;

    /* return matches && matches.map((match, index) => (
      <li key={index}>{match}</li>
    )) */
  };

  return (
    <>
      {/* header */}
      <Header />
      {/* end header  */}

      {/* one section */}
      <section
        className="cheap_flight_section"
        style={{
          backgroundImage: `url('${
            pageData?.data &&
            pageData?.data.length > 0 &&
            pageData?.data[0].cover_img
              ? pageData?.data[0].cover_img
              : ""
          }')`,
          // backgroundImage: `url('${pageData.data && pageData.data.length > 0 && pageData.data[0].cover_img ? process.env.REACT_APP_IMAGE_URL + pageData.data[0].cover_img : ''}')`,
          // backgroundImage: `url(${externalImage})`,
          backgroundSize: "cover",
          backgroundRepeat: "no-repeat",
        }}
      >
        <div className="container">
          <div className="row">
            <div className="col-md-12">
              <h2 className="title_cheap_flight">
                {pageData.title ? pageData.title : "Not found"}
              </h2>
              {pageData.data &&
              pageData.data.length > 0 &&
              pageData.data[0].subheading ? (
                <p className="Idigo_text">{pageData.data[0].subheading}</p>
              ) : (
                ""
              )}
            </div>
          </div>
          <SearchComponent />
        </div>
      </section>
      {/* end one section */}
      <section className="cheap_flight_three_section">
        <div className="container">
          <div className="row">
            <div className="col-md-12 pt-5"></div>
            <p class="about-lowest-prices">
              {pageData.data &&
              pageData.data.length > 0 &&
              pageData.data[0].content ? (
                <div
                  dangerouslySetInnerHTML={{ __html: pageData.data[0].content }}
                />
              ) : (
                ""
              )}
            </p>
          </div>
        </div>
      </section>

      {/* two section */}
      {updatedFlights.length > 0 ? (
        updatedFlights.map((flight) => {
          if (flight.componentType == "airline") {
            return (
              <AirlinesList
                flight={flight}
                handleFlightClick={handleFlightClick}
              />
            );
          } else if (flight.componentType == "flight") {
            return (
              <FlightsSection
                flight={flight}
                handleFlightClick={handleFlightClick}
                moreFlightOnclick={async () => {
                  await setNumberOfFlights(numberOfFlights + 1);
                  get_webpage();
                }}
              />
            );
          } else if (flight.componentType == "popular") {
            return (
              <PopularComponent flight={flight} />
            );
          } else {
            return (
              <CityComponent
                flight={flight}
                handleFlightClick={handleFlightClick}
              />
            );
          }
        })
      ) : (
        <div className="container error-box">
          <div className="error-head">
            <img
              src={"../image/Globe_And_Plane_Drawing-removebg-preview.png"}
              alt="Logo"
              height={"200px"}
              width={"200px"}
            />
            <h1>No Flights To Fetch</h1>
          </div>
        </div>
      )}
      {/* end two section */}

      {/* start six section */}
      {/* end section */}

      <section className="faq_section">
        <div className="container">
          <div className="row">
            <h3 className="faq_title">Frequently asked questions</h3>
          </div>

          {pageData.data &&
            pageData.data[0].faqs &&
            Object.keys(pageData.data[0].faqs).map((key) => (
              <div className="row faq_row" key={key}>
                <h6 className="faq_heading">
                  {pageData.data[0].faqs[key].question}
                </h6>
                <p className="faq_dec">{pageData.data[0].faqs[key].answer}</p>
              </div>
            ))}
        </div>
      </section>

      {/* graph section start */}
      <div className="container graph-box">
        <HorizontalBarChart />
      </div>
      {/* graph section end  */}

      {/* 2nd graph section start */}
      <div className="container graph-box">
        <MyVerticalBarChart />
      </div>
      {/*2nd graph section end  */}

      {/* eight section */}
      <section className="nine_section">
        <div className="container">
          <div className="row">
            <div className="col-md-12">
              <div className="faster-booking ">
                <div className="row">
                  <div className="col-md-5">
                    <img src={missoion} alt="" className="w-100 img-fluid" />
                  </div>

                  <div className="col-md-7 p-3 pl-5 d-flex align-items-center">
                    <div className="fasstbooking">
                      <h3 className="signfastbook">
                        Our Mission make sure your travel is carbon negitive{" "}
                      </h3>
                      <p className="travel">
                        We care about this planet and we want make our
                        contribtutions in ensuring ..{" "}
                      </p>
                      <button className="fasstbooking_btn">Sign in</button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      {/* end nine section */}

      {openForm && (
        // <div
        //   class="modal fade popup_mine_dp"
        //   id="exampleModal"
        //   tabindex="-1"
        //   aria-labelledby="exampleModalLabel"
        //   aria-hidden="true"
        // >
        //   <div class="modal-dialog">
        //     <div class="modal-content">
        //       <div class="modal-header">
        //         <h5 class="modal-title" id="exampleModalLabel">
        //           Please fill the details below
        //         </h5>
        //         <button
        //           type="button"
        //           class="close"
        //           data-dismiss="modal"
        //           aria-label="Close"
        //           onClick={() => setOpenForm(false)}
        //         >
        //           <span aria-hidden="true">&times;</span>
        //         </button>
        //       </div>
        //       <div class="modal-body">
        //         <Form onSubmit={handleSubmit}>
        //           <Form.Group className="mb-3" controlId="name">
        //             <Form.Label>Name</Form.Label>
        //             <Form.Control
        //               type="text"
        //               placeholder="Enter Name"
        //               name="name"
        //               value={inquiryForm.name}
        //               onChange={handleChange}
        //             />
        //           </Form.Group>

        //           <Form.Group className="mb-3" controlId="formBasicEmail">
        //             <Form.Label>Email</Form.Label>
        //             <Form.Control
        //               type="email"
        //               placeholder="Email"
        //               name="email"
        //               value={inquiryForm.email}
        //               onChange={handleChange}
        //             />
        //           </Form.Group>

        //           <Form.Group className="mb-3" controlId="number">
        //             <Form.Label>Phone Number</Form.Label>
        //             <Form.Control
        //               type="number"
        //               placeholder="Phone Number"
        //               name="phone"
        //               value={inquiryForm.phone}
        //               onChange={handleChange}
        //             />
        //           </Form.Group>

        //           <Button variant="primary" type="submit">
        //             Submit
        //           </Button>
        //         </Form>
        //       </div>
        //     </div>
        //   </div>
        // </div>
        <div id="up-sec1">
          <div
            class="modal fade sec-up show"
            id="exampleModal"
            tabindex="-1"
            aria-labelledby="exampleModalLabel"
            aria-modal="true"
            role="dialog"
            style={{ display: "block" }}
          >
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header form-background">
                  <div class="modal-header-inner">
                    <img
                      src={`${process.env.PUBLIC_URL}/image/airplane-form.png`}
                      alt="Example"
                    />
                  </div>
                  <div class="modal-heading">
                    <h5 class="modal-title" id="exampleModalLabel">
                      {" "}
                      Please Fill The Details Below
                    </h5>
                    <p>
                      Founded by grandsons of the founders, created to make
                      flying easy and affordable
                    </p>
                  </div>
                  <button
                    type="button"
                    class="close"
                    data-dismiss="modal"
                    aria-label="Close"
                    fdprocessedid="n4qy62"
                    onClick={() => setOpenForm(false)}
                  >
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>

                <div class="modal-body form-background">
                  <div className="overlay-body">
                    <Form onSubmit={handleSubmit}>
                      <Form.Group className="mb-3" controlId="name">
                        <Form.Label>Name</Form.Label>
                        <Form.Control
                          type="text"
                          className="my-form"
                          placeholder="Enter Name"
                          name="name"
                          value={inquiryForm.name}
                          onChange={handleChange}
                          required
                        />
                      </Form.Group>

                      <Form.Group className="mb-3" controlId="formBasicEmail">
                        <Form.Label>Email</Form.Label>
                        <Form.Control
                          type="email"
                          placeholder="Email"
                          name="email"
                          className="my-form"
                          value={inquiryForm.email}
                          onChange={handleChange}
                          required
                        />
                      </Form.Group>

                      <Form.Group className="mb-3" controlId="number">
                        <Form.Label>Phone Number</Form.Label>
                        <PhoneInput
                          placeholder="Enter phone number"
                          value={inquiryForm.phone}
                          onChange={handleChange}
                          country={"in"}
                          className="my-form"
                          required
                        />
                      </Form.Group>
                      <Form.Group controlId="termsCheckbox" className="mb-3">
                        <Form.Check
                          type="checkbox"
                          label="I accept the terms and conditions"
                          name="termsAccepted"
                          checked={inquiryForm.termsAccepted}
                          onChange={handleChange}
                          required
                        />
                      </Form.Group>

                      <div className="form-btn">
                        <Button
                          variant="primary"
                          type="submit"
                          className="sub-btn-form"
                        >
                          Submit
                        </Button>
                      </div>
                    </Form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* header */}
      <Footer />
      {/* end header  */}
    </>
  );
}
