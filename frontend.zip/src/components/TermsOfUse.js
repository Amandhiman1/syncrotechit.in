import React from 'react'
import Footer from './Include/Footer'
import Header from './Include/Header'
import { Link } from 'react-router-dom';
import { useEffect } from 'react';
import HomeSearch from './HomeSearch';
import SearchComponent from './SearchComponent';



export default function TermsOfUse() {
  useEffect( ()=>{
    window.scrollTo({
      top : 0
    })
  },[] )





  let tou_link = [
    {
      id:"1",
      num_article: 'Article 1',
      link_name: "Our website",
      link_url: "/",
    },
    {
      id:"2",
      num_article: 'Article 2',
      link_name: "Access to and use of the Website",
      link_url: "/",
    },
    {
      id:"3",
      num_article: 'Article 3',
      link_name: "Website functionalities and XYZ.com Account",
      link_url: "/",
    },
    {
      id:"4",
      num_article: 'Article 4',
      link_name: "Our intellectual property",
      link_url: "/",
    },
    {
      id:"5",
      num_article: 'Article 5',
      link_name: "Trademarks, logos, and service marks of third parties",
      link_url: "/",
    },
    {
      id:"6",
      num_article: 'Article 6',
      link_name: "Final provisions",
      link_url: "/",
    },
  ];
  
  let tou_artione_link = [
    {
      id:"1",
      link_name: 'The website located at XYZ.com all of their contents ("Website") are owned and operated by private limited company XYZ.com s.r.o., ID No. *************, with a registered office at Calle Fuerteventura,70 4º3ª, Sabadell, Barcelona , 08205, the Spain, registered in the Commercial Register maintained by the Regional Court in Sabadell, file No. C 12247, Tax ID No. xxxxxxxxxx ("XYZ.com", "we", "our", "us").',
     
    },
    {
      id:"2",
      link_name: 'The Website is available to any visitor or customer ("User", "you", "your"), subject to acceptance of these special Terms and conditions of use of the Website ("Terms of Use"). Your access or use of the Website constitutes full and unconditional acceptance to these Terms of Use. If you do not agree with these Terms of Use, then you are not allowed to use the Website.',
      
    },
    {
      id:"3",
      link_name: "The rules regarding the processing of the personal data of the Users are available in the Privacy Policy on the Website.",
      
    },
  ];

  let tou_artitwo_link = [
    {
      id:"1",
      link_name: 'If you decide to use the Website, we will provide it to you "as-is" without any liabilities and warranties including but not limited to the guarantee of completeness, flawlessness, availability, or suitability.',
     
    },
    {
      id:"2",
      link_name: "The Website may be temporarily or permanently unavailable, in whole or in part, and it may be added to, changed, or removed at any time under our sole discretion without any notification.",
      
    },
    {
      id:"3",
      link_name: "Under no circumstance shall we be liable for any loss or damages (including direct, indirect, special, or consequential losses or damages of any kind or lost profits) in relation or connected with the Website regardless of the form of action by which such losses or damages may be claimed.",
      
    },
    {
      id:"4",
      link_name: "Access to specific parts of the Website may be restricted under specific rules and requirements. Unless indicated otherwise, Website functionalities are provided free of charge",
     
    },
    {
      id:"5",
      link_name: "The content and information on the Website (including subjects of intellectual property, price, and availability information relating to the products and services provided via the Website), as well as the infrastructure used to provide such content and information, is proprietary to XYZ.com or our suppliers and providers.",
      
    },
    {
      id:"6",
      link_name: "The User agrees to keep confidential any passwords provided to access the Website and ensure that no unauthorized third parties gain access to them. The User accepts responsibility for any financial consequences arising from the use of the Website with the User's password to the Website or from the use of the User's passwords by third parties.",
      
    },
    {
      id:"7",
      link_name: "We, in Our sole discretion, may use all comments and suggestions, whether written or oral, provided by the User in connection with the use of Our products and services or the Website",
      
    },

  ];

  let tou_artithree_link =[
    {
      id: "1",
      link_name: 'The Website contains multiple functionalities which are available to the User and may be used by a designated part of the interface of the Website or other designated online tools such as emails ("Website Interface"). We will provide you with functionalities of the Website provided that you use the functionalities in a way that has been intended and allowed by Us',
    },
    {
      id: "2",
      link_name: 'The XYZ.com Account is formed by additional functionalities of the Website with restricted access ("XYZ.com Account") such as tools for the management of your current and past bookings, or the storage of data necessary for making bookings in the future',
    },
    {
      id: "3",
      link_name: "You may access the XYZ.com Account associated with your email address by signing in via the Website Interface provided you previously made a booking on the Website with your email address, or you created a XYZ.com Account via the Website Interface with your email address.",
    },
  ];

  let tou_artifour_link =[
    {
      id: "1",
      link_name: 'We retain any, and all, rights to Our products and services and the Website and its content; including software, hardware, products, processes, algorithms, user interfaces, knowledge, technologies, inventions, designs, and other tangible or intangible materials or information made available to the User throughout the provision of the services or by using the Website.',
    },
    {
      id: "2",
      link_name: 'No expressed or implied license or right of any kind is granted to the User regarding Our services, products, or the Website, or any part thereof, including any right to obtain possession of any source code, data, or other material relating to the Website. All rights not expressly granted to the User herein are reserved to us or their respective owners.',
    },
    {
      id: "3",
      link_name: "Furthermore, all copyrights, trademarks, design rights, database rights, patents, and other intellectual property rights (registered and unregistered) in and on the Website and regarding the content of the Website belong to us or third parties and we do not grant anyone the right or license to use them.",
    },
  ];

  let tou_artifive_link = [
    {
      id: "1",
      link_name: 'The trademarks, logos, service marks, watermarks, and other third-party content ("Trademarks") displayed on the Website are registered and unregistered Trademarks of their respective owners. All Trademarks related to the operating airlines, railway companies, and other third-party providers that are displayed on the Website belong to their respective owners and we use these Trademarks solely for your convenience. Nothing contained on this Website should be construed as Our pretension to these third-party Trademarks or as granting, by implication, estoppel, or otherwise, any license or right to use any Trademark displayed on the Website without the express written permission of its respective owner.',
    },
    {
      id: "2",
      link_name: "Your misuse of the Trademarks displayed on the Website is strictly prohibited. You must ensure that your use of Trademarks complies with all applicable laws and the intellectual property and other rights of the relevant third-party provider. You acknowledge and agree that the Trademarks will remain the property of the relevant third-party provider. No part of Trademarks may be modified, duplicated, published, uploaded, distributed, translated, adapted, marketed or used, without the prior written consent of the relevant third-party provider.",
    },
  ];

  let tou_artisix_link = [
    {
      id: "1",
      link_name: 'In case of any disputes arising from or related to the Website or these Terms of Use, the courts of the Spain shall have complete jurisdiction over all disputes arising between you and us, unless otherwise provided by the mandatory applicable laws.',
    },
    {
      id: "2",
      link_name: "The Website and these Terms of Use and any legal relations established under it or derived from it, shall be governed by the laws of the Spain.",
    },
    {
      id: "3",
      link_name: "These Terms of Use are valid and effective from May 1, 2022.",
    },
  ];

  return (
    <>
    {/* header */}
        <Header/>
    {/* end header  */}
    {/* one section */}
    <section className='tou_section'>
      <div className='container'>
        <div className='row'>
          <div className='col-md-12'>
            <h2 className='meta_title_tac'>Terms of use</h2>
          </div>
          {/* <SearchComponent /> */}
        </div>
      </div>
    </section>
    {/* end one section */}
    
    {/* two section */}
    <section className='tou_two_section'>
      <div className='container'>
        <div className='row'>
          <div className='col-md-12'>
              <h2 className='toc_top_head'>Summary</h2>
              <ul className="tou_list">  
                {/* <li> Article 1. <a href='/' className='toc_link_tab'>Our website</a></li>
                <li> Article 2. <a href='/' className='toc_link_tab'>Access to and use of the Website</a></li>
                <li> Article 3. <a href='/' className='toc_link_tab'>Website functionalities and XYZ.com Account</a></li>
                <li> Article 4. <a href='/' className='toc_link_tab'>Our intellectual property</a></li>
                <li> Article 5. <a href='/' className='toc_link_tab'>Trademarks, logos, and service marks of third parties</a></li>
                <li> Article 6. <a href='/' className='toc_link_tab'>Final provisions</a></li> */}

                {
                  tou_link.map((li_link =>

                    <li key={li_link.id}><span>{li_link.num_article}</span><Link to={li_link.link_url}> {li_link.link_name}</Link></li>

                  ))
                }


              </ul>
          </div>
        </div>
      </div>
    </section>
    {/* end two section */}

     {/* three section */}
     <section className='tou_three_section tou_cont_sec pt-5 pb-5'>
      <div className='container'>
        <div className='row'>
          <div className='col-md-12'>
             <div className="arti_list_cont">
                 <h3 className='arti_list_hesd'>1.	Article. <span className='toc_link_tab'>Our website</span></h3>
                  <ul className='toc_list' >
                    {
                      tou_artione_link.map((li_link =>
                       <li key={li_link.id}>{li_link.link_name}</li>
                      ))
                    }
                  </ul>
             </div>
          </div>
        </div>
      </div>
    </section>
    {/* end three section */}


    {/* four section */}
    <section className='tou_four_section tou_cont_sec'>
      <div className='container'>
        <div className='row'>
          <div className='col-md-12'>
             <div className="arti_list_cont">
                 <h3 className='arti_list_hesd'>2.	Article. <span className='toc_link_tab'>Access to and use of the Website</span></h3>
                 <ul className='toc_list' >
                    {
                      tou_artitwo_link.map((li_link =>
                       <li key={li_link.id}>{li_link.link_name}</li>
                      ))
                    }
                  </ul>
             </div>
          </div>
        </div>
      </div>
    </section>
    {/* end four section */}

     {/* five section */}
     <section className='tou_five_section tou_cont_sec'>
      <div className='container'>
        <div className='row'>
          <div className='col-md-12'>
             <div className="arti_list_cont">
                 <h3 className='arti_list_hesd'>3.	Article. <span className='toc_link_tab'>Website functionalities and XYZ.com Account</span></h3>
                 <ul className='toc_list' >
                    {
                      tou_artithree_link.map((li_link =>
                       <li key={li_link.id}>{li_link.link_name}</li>
                      ))
                    }




</ul>
             </div>
          </div>
        </div>
      </div>
    </section>
    {/* end five section */}


     {/* six section */}
     <section className='tou_six_section tou_cont_sec'>
      <div className='container'>
        <div className='row'>
          <div className='col-md-12'>
             <div className="arti_list_cont">
                 <h3 className='arti_list_hesd'>4.	Article. <span className='toc_link_tab'>Our intellectual property</span></h3>
                 <ul className='toc_list' >
                    {
                      tou_artifour_link.map((li_link =>
                       <li key={li_link.id}>{li_link.link_name}</li>
                      ))
                    }




</ul>
             </div>
          </div>
        </div>
      </div>
    </section>
    {/* end six section */}

     {/* seven section */}
     <section className='tou_seven_section tou_cont_sec'>
      <div className='container'>
        <div className='row'>
          <div className='col-md-12'>
             <div className="arti_list_cont">
                 <h3 className='arti_list_hesd'>5.	Article. <span className='toc_link_tab'>Trademarks, logos, and service marks of third parties</span></h3>
                 <ul className='toc_list' >
                    {
                      tou_artifive_link.map((li_link =>
                       <li key={li_link.id}>{li_link.link_name}</li>
                      ))
                    }




</ul>
             </div>
          </div>
        </div>
      </div>
    </section>
    {/* end seven section */}

     {/* eight section */}
     <section className='tou_eight_section tou_cont_sec'>
      <div className='container'>
        <div className='row'>
          <div className='col-md-12'>
             <div className="arti_list_cont">
                 <h3 className='arti_list_hesd'>6.	Article. <span className='toc_link_tab'>Final provisions</span></h3>
                 <ul className='toc_list' >
                    {
                      tou_artisix_link.map((li_link =>
                       <li key={li_link.id}>{li_link.link_name}</li>
                      ))
                    }




</ul>
             </div>
          </div>
        </div>
      </div>
    </section>
    {/* end eight section */}
    
    
    
    {/* header */}
        <Footer/>
    {/* end header  */}
    
    
        </>
  )
}
