import React from 'react'
import "./Include/css/style.css"
import Footer from './Include/Footer'
import Header from './Include/Header'
import security_img from './Assets/Security.svg'
import reporting_img from './Assets/reporting.svg'
import { useEffect } from 'react'
import HomeSearch from './HomeSearch'
import SearchComponent from './SearchComponent'



export default function Security() {

  useEffect( ()=>{
    window.scrollTo({
      top : 0
    })
  },[] )


  return (
    <>
    {/* header */}
      <Header/>
    {/* end header  */}
    
    {/* <div className='container common-padding'>
    <SearchComponent />
    </div> */}
    
    {/* one section */}
    <section className='security_one_section mt-5'>
      <div className='container'>
        <div className='row'>
          <div className='col-md-6 d-flex align-items-center'>
              <div className=' '>
                <h6 className='about-prime-text'>Security</h6>
                <p className='about-lowest-prices'>As contributors to open source and to the IT community in general, we value the work of independent security researchers.</p>
              </div>
          </div>
    
          <div className='col-md-6'>
              <img src={security_img} alt='' className='img-fluid w-100'/>
          </div>
        </div>
    
      </div>
    </section>
    {/* end one section */}
    
  {/* two section */}
<section className='security_two_section'>
  <div className='container'>
    <div className='row'>
      <div className='col-md-12'>
        <div className='faster-booking '>
            <div className='row'>
              <div className='securty_text text-center'>
              If you’re good enough to spot a vulnerability on our site, we’d love to know about it. We’ll reward anyone who reports a critical vulnerability for the first time.
Just follow the guideline below to ensure that you qualify for a reward and don’t violate our Terms and Conditions.
              </div>
            </div>
        </div>
      </div>
    </div>
  </div>
</section>
{/* end two section */}



    {/* three section */}
<section className='security_three_section'>
  <div className='container'>
    <div className='row'>
      <div className='col-md-12'>
        <div className='faster-booking '>
            <div className='row  d-flex align-items-center'>
              <div className='col-md-4'>
                <img src={reporting_img} alt='' className='w-100 img-fluid'/>
              </div>
              <div className='col-md-8 p-3 pl-5 d-flex align-items-center'>
                <div className='fasstbooking '>
                    <h3 className='signfastbook'>Reporting vulnerabilities  </h3>
                    <ul>
                      <li>To send us an email, please check our security.txt file.</li>
                      <li>Provide full details of the vulnerability so that we can quickly reproduce it.</li>
                      <li>Avoid disrupting or degrading our services in any way. Given the nature of our business, denial-of-service attacks are not welcome at all.</li>
                      <li>Don’t copy, delete, access, or change any data that doesn’t belong to you.</li>
                      <li>Don’t publicize any details of the vulnerability until we’ve had a chance to fix it.</li>
                      <li>We’ll try to get back to you within two working days.</li>
                    </ul>
                </div>
              </div>
            </div>
        </div>
      </div>
    </div>
  </div>
</section>
{/* end three section */}


{/* four section */}

<section className='security_four_section pb-5'>
  <div className='container'>
    <div className='row'>
      <div className='col-md-12 d-flex align-items-center'>
          <div className='text-center '>
            <h6 className='about-prime-text'>Reporting fraud</h6>
            <p className='about-lowest-prices'>If an unauthorized transaction was made on your payment card, please contact the issuing bank and the police to notify them about the suspicious activity.
<br/>If you need any more assistance, check our Help center.</p>
          </div>
      </div>
    </div>
  </div>
</section>

{/* end four section */} 
    
    
    {/* header */}

      <Footer/>

    {/* end header  */}
    
        </>
  )
}
