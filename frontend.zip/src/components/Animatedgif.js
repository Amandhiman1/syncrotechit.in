import React from "react";


const Animatedgif = ({ src, alt }) =>{
    return <img src={src} alt={alt} style={{  marginTop: "30px",}}  />
}

export default Animatedgif;