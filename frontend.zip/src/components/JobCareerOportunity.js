import React, { useEffect, useState } from "react";
import Header from "./Include/Header";
import Footer from "./Include/Footer";
import cp_jobs from "./Assets/job-career-oportunity.svg";
import img_serch from "./Assets/blog_search.svg";
import { Link } from "react-router-dom";
import { useSelector } from "react-redux";

export default function JobCareerOportunity() {
  const [jobs, setJobs] = useState([]);
  const [searchLocation, setSearchLocation] = useState("");
  const [searchTitle, setSearchTitle] = useState("");
  const selectedLanguage = useSelector((state) => state.reducer.language);

  useEffect(() => {
    window.scrollTo({
      top: 0,
    });

    // Fetch jobs from API
    const fetchJobs = async () => {
      try {
        const response = await fetch("https://flight-backend-ro3e.onrender.com/api/job");
        const data = await response.json();
        setJobs(data);
      } catch (error) {
        console.error("Error fetching jobs:", error);
      }
    };

    fetchJobs();
  }, []);

  // Filter jobs based on search input
  const filteredJobs = jobs.filter((job) => {
    return (
      (searchLocation === "" || job.location.toLowerCase().includes(searchLocation.toLowerCase())) &&
      (searchTitle === "" || job.jobTitle[selectedLanguage].toLowerCase().includes(searchTitle.toLowerCase()))
    );
  });

  const handleSearch = (e) => {
    e.preventDefault();
  };

  return (
    <>
      <Header />

      <section className="pp_section job_pp_section">
        <div className="container">
          <div className="row">
            <div className="col-md-12">
              <h2 className="meta_title_tac mb-4">
                Choose your next career opportunity
              </h2>
              <form onSubmit={handleSearch}>
                <div className="jco_form">
                  <div className="row align-items-end">
                    <div className="col-md-5">
                      <div className="form-group m-0">
                        <label>By location:</label>
                        <input
                          type="text"
                          className="form-control"
                          placeholder="All Location"
                          value={searchLocation}
                          onChange={(e) => setSearchLocation(e.target.value)}
                        />
                      </div>
                    </div>
                    <div className="col-md-5">
                      <div className="form-group m-0">
                        <label>By title:</label>
                        <div className="search_blog_box">
                          <img src={img_serch} alt="search icon" />
                          <input
                            type="search"
                            placeholder="e.g. engineering manager"
                            className="me-2"
                            aria-label="Search"
                            value={searchTitle}
                            onChange={(e) => setSearchTitle(e.target.value)}
                          />
                        </div>
                      </div>
                    </div>
                    {/* <div className="col-md-2">
                      <button
                        type="submit"
                        className="btn btn-primary jco_form_btn"
                      >
                        Submit
                      </button>
                    </div> */}
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </section>

      <section className="jco_two_section">
        <div className="container">
          {filteredJobs.length > 0 ? (
            <div className="job-listing">
              {filteredJobs.map((job) => (
                <div key={job._id} className="job-item">
                  <div className="job-info">
                    <div className="job-title">{job.jobTitle[selectedLanguage]}</div>
                    <div className="job-date">Location: {job.location}</div>
                    <div className="job-date">Posted on: {new Date(job.createdAt).toLocaleDateString()}</div>
                  </div>
                  <Link to={`/job-view-detail/${job.jobSlug}`}>
                    <button className="view-job-btn">View Job</button>
                  </Link>
                </div>
              ))}
            </div>
          ) : (
            <div className="row">
              <div className="col-md-12 text-center">
                <h3 className="oportunity_jos text-center">
                  Oops, we don’t have any openings.
                </h3>
                <img src={cp_jobs} alt="No jobs available" className="text-center jco_imsg" />
              </div>
            </div>
          )}
        </div>
      </section>

      <Footer />
    </>
  );
}
