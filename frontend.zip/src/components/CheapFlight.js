import React from 'react'
import {useEffect} from 'react'
import Footer from './Include/Footer'
import Header from './Include/Header'
import brush_img from './Assets/Brussels_Airlines_SN 2.png'
// import norwign from './Assets/Norwegian_DY 2.svg'
import airoplane from './Assets/cloud-with-airoplane.svg'
import clender_str from './Assets/calendar-1 3.png'
import beachs from './Assets/beach.png'
import  missoion  from './Assets/our-mission.png';
import { Link } from 'react-router-dom'
import HomeSearch from './HomeSearch'
import SearchComponent from './SearchComponent'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faArrowsAltH } from '@fortawesome/free-solid-svg-icons';



export default function CheapFlight() {
  useEffect( ()=>{
    window.scrollTo({
      top : 0
    })
  },[] )

  let cheapflight=[
    {
      id: "1",
      from: "Amsterdam",
      to: "Istanbul",
      img: airoplane,
    },
    {
      id: "2",
      from: "Boston",
      to: "Thiruvananthapuram",
      img: airoplane,
    },
    {
      id: "3",
      from: "Toronto",
      to: "Delhi",
      img: airoplane,
    },
    {
      id: "4",
      from: "London",
      to: "Delhi",
      img: airoplane,
    },
    {
      id: "5",
      from: "Copenhegon",
      to: "Malaga",
      img: airoplane,
    },
    {
      id: "6",
      from: "Berlin",
      to: "Bongkok",
      img: airoplane,
    },
    {
      id: "7",
      from: "Madrid",
      to: "Quito",
      img: airoplane,
    },
    {
      id: "8",
      from: "Lisbon",
      to: "Sao Paulo",
      img: airoplane,
    },

  
]

let beach_imgs=[
  {
    id:"1",
    beachname:"Bilbao",
    beachprice:"15$",
    beachimg: beachs,
  },
  {
    id:"2",
    beachname:"Bilbao",
    beachprice:"15$",
    beachimg: beachs,
  },
  {
    id:"3",
    beachname:"Bilbao",
    beachprice:"15$",
    beachimg: beachs,
  },
  {
    id:"4",
    beachname:"Bilbao",
    beachprice:"15$",
    beachimg: beachs,
  },
]

let flight_enq=[

    {
        id:'1',
        brand_img: brush_img, 
        flight_class:'Economy',
        from_to:'Delhi',
        from_time:'10:30',
        by_to:'Mumbai',
        by_time:'15:30',
        price:'From 40 $ ',
        dirctly:'Direct',
        depart_date:'Sat 25 Jul',

    },
    
    {
        id:'2',
        brand_img: brush_img, 
        flight_class:'Economy',
        from_to:'Delhi',
        from_time:'10:30',
        by_to:'Mumbai',
        by_time:'15:30',
        price:'From 40 $ ',
        dirctly:'Direct',
        depart_date:'Sat 25 Jul',

    },
    
    {
        id:'3',
        brand_img: brush_img, 
        flight_class:'Economy',
        from_to:'Delhi',
        from_time:'10:30',
        by_to:'Mumbai',
        by_time:'15:30',
        price:'From 40 $ ',
        dirctly:'Direct',
        depart_date:'Sat 25 Jul',

    },
    
    {
        id:'4',
        brand_img: brush_img, 
        flight_class:'Economy',
        from_to:'Delhi',
        from_time:'10:30',
        by_to:'Mumbai',
        by_time:'15:30',
        price:'From 40 $ ',
        dirctly:'Direct',
        depart_date:'Sat 25 Jul',

    },
    
]

let airline_fly_from=[

  {
    id:"1",
    fly_brand: brush_img ,
    fly_name:"Brussel Airline",
    fly_stops:"1 Stop",
    fly_from_time:"10:30",
    fly_from:"Delhi",
    fly_to:"Mumbai",
    fly_to_time:"10:30",
    fly_price:"From 40 $ ",

  },
  {
    id:"2",
    fly_brand: brush_img ,
    fly_name:"Brussel Airline",
    fly_stops:"1 Stop",
    fly_from_time:"10:30",
    fly_from:"Delhi",
    fly_to:"Mumbai",
    fly_to_time:"10:30",
    fly_price:"From 40 $ ",

  },
  {
    id:"3",
    fly_brand: brush_img ,
    fly_name:"Brussel Airline",
    fly_stops:"1 Stop",
    fly_from_time:"10:30",
    fly_from:"Delhi",
    fly_to:"Mumbai",
    fly_to_time:"10:30",
    fly_price:"From 40 $ ",

  },
  {
    id:"4",
    fly_brand: brush_img ,
    fly_name:"Brussel Airline",
    fly_stops:"1 Stop",
    fly_from_time:"10:30",
    fly_from:"Delhi",
    fly_to:"Mumbai",
    fly_to_time:"10:30",
    fly_price:"From 40 $ ",

  },
  {
    id:"5",
    fly_brand: brush_img ,
    fly_name:"Brussel Airline",
    fly_stops:"1 Stop",
    fly_from_time:"10:30",
    fly_from:"Delhi",
    fly_to:"Mumbai",
    fly_to_time:"10:30",
    fly_price:"From 40 $ ",

  },
]

  return (
    <>

{/* header */}
    <Header/>
{/* end header  */}
{/* one section */}
<section className='cheap_flight_section'>
  <div className='container'>
    <div className='row'>
      <div className='col-md-12'>
        <h2 className='title_cheap_flight'>Cheap flight from <span className='city_bolds'> Delhi to Mumbai</span> </h2>
        <p className='Idigo_text'>Choose between  Air India, Idigo, Vistra or Spicejet to find the best price</p>
      </div>

      <div className="col-lg-12 p-0">
      <SearchComponent />
      </div>
    </div>
  </div>
</section>
{/* end one section */}

    

{/* two section */}
<section className='cheap_flight_three_section'>
  <div className='container'>

  <div className='row'>
      <div className='col-md-12 pt-5'>
        <h2 className='last_minute_flights'>Are last minute flights cheaper from<b> <span className='del_city'> Delhi</span> to <span className='mum_city'>Mumabi ?</span></b> </h2>
        <p className='flights_tickets'>we found last minute flights tickets price starting  from <span className='blue_clr'> 30$ </span>  form  <b> Delhi <span className='del_city'> DEL</span></b> to <b> Mumbai <span className='mum_city'> BOM</span></b> </p>
      </div>
    </div>

    <div className='row'>

      { 
        flight_enq.map((flight_dtl => 



        <div className='col-md-6'>
            <Link>
                <div className='Economy_box'>
                    <div className='uper_box'>
                        <div className='imgs_flight_logo d-flex align-items-center'>
                            <img src={flight_dtl.brand_img} alt='' />
                        </div>
                        <div className='fligth_vips'>
                            <span className='economy_tag'>{flight_dtl.flight_class}</span>
                        </div>
                    </div>
                    <div className='middle_box'>
                        <div className='Spicejet'>
                            <div className='airoplane_text'>
                                <p className='m-0'>{flight_dtl.from_to} <span className='del_city'> DEL</span> </p>
                                <span className='flight_time'>{flight_dtl.from_time}</span>
                            </div>
                            <img src={airoplane} alt='' />
                            <div className='airoplane_text'>
                                <p className='m-0'> {flight_dtl.by_to} <span className='mum_city'> BOM</span></p>
                                <span className='flight_time'>{flight_dtl.by_time}</span>
                            </div>
                        </div>
                    </div>
            <hr />
                    <div className='bottom_box'>
                        <div className='imgs_flight_logo d-flex align-items-center'>
                            <div className='m-0 from_direct'>{flight_dtl.price}<span>{flight_dtl.dirctly}</span></div>
                        </div>
                        <div className='fligth_Depart'>
                        <div className="main_cnt_box d-flex">
                            <div className='img_span'>
                                <img src={ clender_str }  alt="" />
                            </div>
                            <div className='box_cont_img_cont'>
                                <small>Depart</small>
                                <span>{flight_dtl.depart_date}</span>
                            </div>
                        </div>
                        </div>
                    </div>
                </div>
            </Link>
        </div>
     )) }       
    </div>
    <div className="row justify-content-center pt-4 pb-5">
        <button className='mint_flights'>Show more last minute  flights</button>
    </div>
  </div>
</section>  
{/* end two section */}
    
    






{/* three section */}
<section className='cheap_flight_three_section'>
  <div className='container'>

  <div className='row'>
      <div className='col-md-12 pt-5'>
        <h2 className='last_minute_flights'>Are last minute flights cheaper from<b> <span className='del_city'> Delhi</span> to <span className='mum_city'>Mumabi ?</span></b> </h2>
        <p className='flights_tickets'>we found last minute flights tickets price starting  from <span className='blue_clr'> 30$ </span>  form  <b> Delhi <span className='del_city'> DEL</span></b> to <b> Mumbai <span className='mum_city'> BOM</span></b> </p>
      </div>
    </div>

    <div className='row'>

      { 
        flight_enq.map((flight_dtl => 



        <div className='col-md-6'>
            <Link>
                <div className='Economy_box'>
                    <div className='uper_box'>
                        <div className='imgs_flight_logo d-flex align-items-center'>
                            <img src={flight_dtl.brand_img} alt='' />
                        </div>
                        <div className='fligth_vips'>
                            <span className='economy_tag'>{flight_dtl.flight_class}</span>
                        </div>
                    </div>
                    <div className='middle_box'>
                        <div className='Spicejet'>
                            <div className='airoplane_text'>
                                <p className='m-0'>{flight_dtl.from_to} <span className='del_city'> DEL</span> </p>
                                <span className='flight_time'>{flight_dtl.from_time}</span>
                            </div>
                            <img src={airoplane} alt='' />
                            <div className='airoplane_text'>
                                <p className='m-0'> {flight_dtl.by_to} <span className='mum_city'> BOM</span></p>
                                <span className='flight_time'>{flight_dtl.by_time}</span>
                            </div>
                        </div>
                    </div>
            <hr />
                    <div className='bottom_box'>
                        <div className='imgs_flight_logo d-flex align-items-center'>
                            <div className='m-0 from_direct'>{flight_dtl.price}<span>{flight_dtl.dirctly}</span></div>
                        </div>
                        <div className='fligth_Depart'>
                        <div className="main_cnt_box d-flex">
                            <div className='img_span'>
                                <img src={ clender_str }  alt="" />
                            </div>
                            <div className='box_cont_img_cont'>
                                <small>Depart</small>
                                <span>{flight_dtl.depart_date}</span>
                            </div>
                        </div>
                        </div>
                    </div>
                </div>
            </Link>
        </div>
     )) }       
    </div>
    <div className="row justify-content-center pt-4 pb-5">
        <button className='mint_flights'>Show more last minute  flights</button>
    </div>
  </div>
</section>  
{/* end three section */}












{/* four section */}
<section className='cheap_flight_three_section'>
  <div className='container'>

  <div className='row'>
      <div className='col-md-12 pt-5'>
        <h2 className='last_minute_flights'>Are last minute flights cheaper from<b> <span className='del_city'> Delhi</span> to <span className='mum_city'>Mumabi ?</span></b> </h2>
        <p className='flights_tickets'>we found last minute flights tickets price starting  from <span className='blue_clr'> 30$ </span>  form  <b> Delhi <span className='del_city'> DEL</span></b> to <b> Mumbai <span className='mum_city'> BOM</span></b> </p>
      </div>
    </div>

    <div className='row'>

      { 
        flight_enq.map((flight_dtl => 



        <div className='col-md-6'>
            <Link>
                <div className='Economy_box'>
                    <div className='uper_box'>
                        <div className='imgs_flight_logo d-flex align-items-center'>
                            <img src={flight_dtl.brand_img} alt='' />
                        </div>
                        <div className='fligth_vips'>
                            <span className='economy_tag'>{flight_dtl.flight_class}</span>
                        </div>
                    </div>
                    <div className='middle_box'>
                        <div className='Spicejet'>
                            <div className='airoplane_text'>
                                <p className='m-0'>{flight_dtl.from_to} <span className='del_city'> DEL</span> </p>
                                <span className='flight_time'>{flight_dtl.from_time}</span>
                            </div>
                            <img src={airoplane} alt='' />
                            <div className='airoplane_text'>
                                <p className='m-0'> {flight_dtl.by_to} <span className='mum_city'> BOM</span></p>
                                <span className='flight_time'>{flight_dtl.by_time}</span>
                            </div>
                        </div>
                    </div>
            <hr />
                    <div className='bottom_box'>
                        <div className='imgs_flight_logo d-flex align-items-center'>
                            <div className='m-0 from_direct'>{flight_dtl.price}<span>{flight_dtl.dirctly}</span></div>
                        </div>
                        <div className='fligth_Depart'>
                        <div className="main_cnt_box d-flex">
                            <div className='img_span'>
                                <img src={ clender_str }  alt="" />
                            </div>
                            <div className='box_cont_img_cont'>
                                <small>Depart</small>
                                <span>{flight_dtl.depart_date}</span>
                            </div>
                        </div>
                        </div>
                    </div>
                </div>
            </Link>
        </div>
     )) }       
    </div>
    <div className="row justify-content-center pt-4 pb-5">
        <button className='mint_flights'>Show more last minute  flights</button>
    </div>
  </div>
</section>  
{/* end four section */}



{/* five section */}


<section className='cheap_flight_airlinesearch_section'>
  <div className='container'>
    <div className='row'>
      <div className='col-md-12 pt-5 pb-4'>
        <h2 className='last_minute_flights'>Airlines that fly from<b><span className='del_city'> Delhi</span> to <span className='mum_city'>Mumabi ?</span></b> </h2>
      </div>
    </div>

{
 airline_fly_from.map((fly_dtl =>

    <div className='row airline_details_cheapest mb-4'>
      <div className='col-md-5'>
        <div className='search_first'>
          <img src={ fly_dtl.fly_brand } alt=''/>
            <h6 className='Airline_name m-0'>{ fly_dtl.fly_name }</h6> 
            <p className='btn_stops m-0'>{ fly_dtl.fly_stops }</p>
            <div className='date_time_city'>
              <span className='flight_time'>{ fly_dtl.fly_from_time }</span>
              <p className='m-0'> { fly_dtl.fly_from } <span className='del_city'> DEL</span></p>
            </div>
        </div>
      </div>
      <div className='col-md-2 d-flex justify-content-center '>
          <img src={airoplane} alt=''/>
      </div>
      <div className='col-md-5'>
          <div className='search_second'>
            <div className='date_time_city'>
              <span className='flight_time'>{ fly_dtl.fly_to_time }</span>
              <p className='m-0'>{ fly_dtl.fly_to } <span className='mum_city'> BOM</span></p>
            </div>
            <div className='m-0 from_direct'>{ fly_dtl.fly_price } </div>
            <button className='airline-searchs_btn'>Search</button>
        </div>
      </div>
    </div>
 ))
}
<div className="row justify-content-center pt-5 pb-5">
        <button className='mint_flights'>Show more last minute  flights</button>
    </div>
  </div>
</section>
{/* end five section */}



{/* start six section */}
<section className='cheap_flight_airlinesearch_section pb-3'>
  <div className='container'>
    <div className='row'>
      <div className='col-md-12 pt-5 pb-4'>
        <h2 className='last_minute_flights'>Explore flights and cheap airfare from <b><span className='mum_city'>Mumabi</span></b> ,India to other Populer destnations. </h2>
      </div>
    </div>
    <div className='row '>
        {/* {
            beach_imgs.map((beach_dtl =>
                  <div className='col-lg-3 col-md-6 col-sm-6 col-xs-12 p-0 m-0 chep_img_box'>
                    <div className='beach_detls_imgs'>
                      <img src={beach_dtl.beachimg} alt='' className='plane_beach'/>
                      <div className='bech_text_ups'>
                        <p className='bech_names'>{beach_dtl.beachname}</p>
                        <p className='bech__price'>{beach_dtl.beachprice}</p>
                      </div>
                    </div>
                  </div>
            ))
        } */}

<div class="col-lg-12 cheap-f-row">
  <div class="col-lg-3">
  <Link href="#">
                       <div class="small-image-container">
                        <img
                          src={`${process.env.PUBLIC_URL}/image/france.png`}
                          alt="Example"
                        />
                            <div class="content main12">
                                <div class="main-content">
                                    <h2>France</h2>
                                    <p>Ticket From<b>52$</b></p>
                                </div>
                                <div class="hover-content">
                                    <p>Chandigarh <FontAwesomeIcon icon={faArrowsAltH} className="icon-color"/></p>
                                    <h2>France</h2>
                                    <p>Ticket From<b>52$</b></p>
                                </div>
                            </div>
                       </div>
                       </Link>
  </div>
  <div class="col-lg-3">
  <Link href="#">
                       <div class="small-image-container">
                        <img
                          src={`${process.env.PUBLIC_URL}/image/england.png`}
                          alt="Example"
                        />
                            <div class="content main12">
                                <div class="main-content">
                                    <h2>England</h2>
                                    <p>Ticket From<b>52$</b></p>
                                </div>
                                <div class="hover-content">
                                    <p>Chandigarh <FontAwesomeIcon icon={faArrowsAltH} className="icon-color"/></p>
                                    <h2>England</h2>
                                    <p>Ticket From<b>52$</b></p>
                                </div>
                            </div>
                       </div>
                       </Link>
  </div>
  <div class="col-lg-3">
  <Link href="#">
                       <div class="small-image-container">
                        <img
                          src={`${process.env.PUBLIC_URL}/image/paris.png`}
                          alt="Example"
                        />
                            <div class="content main12">
                                <div class="main-content">
                                    <h2>Paris</h2>
                                    <p>Ticket From<b>52$</b></p>
                                </div>
                                <div class="hover-content">
                                    <p>Chandigarh <FontAwesomeIcon icon={faArrowsAltH} className="icon-color"/></p>
                                    <h2>Paris</h2>
                                    <p>Ticket From<b>52$</b></p>
                                </div>
                            </div>
                       </div>
                       </Link>
  </div>
  <div class="col-lg-3">
  <Link href="#">
                       <div class="small-image-container">
                        <img
                          src={`${process.env.PUBLIC_URL}/image/canada.png`}
                          alt="Example"
                        />
                            <div class="content main12">
                                <div class="main-content">
                                    <h2>Canada</h2>
                                    <p>Ticket From<b>52$</b></p>
                                </div>
                                <div class="hover-content">
                                    <p>Chandigarh <FontAwesomeIcon icon={faArrowsAltH} className="icon-color"/></p>
                                    <h2>Canada</h2>
                                    <p>Ticket From<b>52$</b></p>
                                </div>
                            </div>
                       </div>
                       </Link>
  </div>
</div>


    </div>
  </div>
</section>
{/* end section */}




<section className='faq_section'> 
  <div className='container'>
    <div className='row'>
      <h3 className='faq_title'>Frequently asked questions</h3>
    </div>

    <div className='row faq_row'>
      <h6 className='faq_heading'>How long does a flight from <b>Delhi</b> to <b> Mumbai ?</b> take?</h6>
      <p className='faq_dec'>An average nonstop flight takes 3h 37m, covering a distance of 1743 miles.</p>
    </div>

    <div className='row faq_row'>
      <h6  className='faq_heading'>How many flights are there between <b>Delhi</b> and<b> Mumbai ?</b></h6>
      <p className='faq_dec'>There are 379 (nonstop) flights between Delhi and Mumbai per week, averaging 54 per day.</p>
    </div>
    
    <div className='row faq_row'>
      <h6  className='faq_heading'>Which airlines provide the cheapest flights from <b>Delhi</b> to <b> Mumbai ?</b></h6>
      <p className='faq_dec'>In the past 3 days, the cheapest one-way tickets were found on Airindia ($15) and Indigo ($19), and the lowest round-trip tickets have been found on Air Asia ($30) and Multiple Airlines ($37).</p>
    </div>
    <div className='row faq_row'>
      <h6  className='faq_heading'>What’s the cheapest day of the week to fly from <b>Delhi</b> to <b> Mumbai ?</b></h6>
      <p className='faq_dec'>From Delhi to Mumbai, Wednesday is the cheapest day to fly on average and Tuesday is the most expensive. Flying from Mumbai back to Delhi , the best deals are generally found on Monday, with Sunday being the most expensive.</p>
    </div>

    <div className='row faq_row'>
      <h6  className='faq_heading'>Which airlines fly most frequently between <b>Delhi</b> and<b> Mumbai ?</b></h6>
      <p className='faq_dec'><b>Air India (19</b> times daily), <b>Vistra (11</b> times daily), <b>Spicejet (8 </b>times daily) are the most frequent flyers on this route.</p>
    </div>

    <div className='row faq_row'>
      <h6  className='faq_heading'>Which airports will I be using when flying from <b>Delhi</b> to <b>Mumbai?</b></h6>
      <p className='faq_dec'>When flying out of Delhi you will be using Indra Gandhi Internation Aiport, often referred to as  Nice Airport. You will be landing at <b>Mumbai Chhatrapati ShivajiMaharaj International Airport,</b> also known as <b>Paris</b> Airport.</p>
    </div>




  </div>
</section>



{/* start six section */}
<section className='cheap_flight_airlinesearch_section pb-3'>
  <div className='container'>
    <div className='row'>
      <div className='col-md-12 pt-5 pb-4'>
        <h2 className='last_minute_flights'>Explore flights and cheap airfare from <b><span className='mum_city'>Mumabi</span></b> ,India to other Populer destnations. </h2>
      </div>
    </div>
    <div className='row '>
        {/* {
            beach_imgs.map((beach_dtl =>
                  <div className='col-lg-3 col-md-6 col-sm-6 col-xs-12 p-0 m-0 chep_img_box'>
                    <div className='beach_detls_imgs'>
                      <img src={beach_dtl.beachimg} alt='' className='plane_beach'/>
                      <div className='bech_text_ups'>
                        <p className='bech_names'>{beach_dtl.beachname}</p>
                        <p className='bech__price'>{beach_dtl.beachprice}</p>
                      </div>
                    </div>
                  </div>
            ))
        } */}

<div class="col-lg-12 cheap-f-row">
  <div class="col-lg-3">
  <Link href="#">
                       <div class="small-image-container">
                        <img
                          src={`${process.env.PUBLIC_URL}/image/france.png`}
                          alt="Example"
                        />
                            <div class="content main12">
                                <div class="main-content">
                                    <h2>France</h2>
                                    <p>Ticket From<b>52$</b></p>
                                </div>
                                <div class="hover-content">
                                    <p>Chandigarh <FontAwesomeIcon icon={faArrowsAltH} className="icon-color"/></p>
                                    <h2>France</h2>
                                    <p>Ticket From<b>52$</b></p>
                                </div>
                            </div>
                       </div>
                       </Link>
  </div>
  <div class="col-lg-3">
  <Link href="#">
                       <div class="small-image-container">
                        <img
                          src={`${process.env.PUBLIC_URL}/image/england.png`}
                          alt="Example"
                        />
                            <div class="content main12">
                                <div class="main-content">
                                    <h2>England</h2>
                                    <p>Ticket From<b>52$</b></p>
                                </div>
                                <div class="hover-content">
                                    <p>Chandigarh <FontAwesomeIcon icon={faArrowsAltH} className="icon-color"/></p>
                                    <h2>England</h2>
                                    <p>Ticket From<b>52$</b></p>
                                </div>
                            </div>
                       </div>
                       </Link>
  </div>
  <div class="col-lg-3">
  <Link href="#">
                       <div class="small-image-container">
                        <img
                          src={`${process.env.PUBLIC_URL}/image/paris.png`}
                          alt="Example"
                        />
                            <div class="content main12">
                                <div class="main-content">
                                    <h2>Paris</h2>
                                    <p>Ticket From<b>52$</b></p>
                                </div>
                                <div class="hover-content">
                                    <p>Chandigarh <FontAwesomeIcon icon={faArrowsAltH} className="icon-color"/></p>
                                    <h2>Paris</h2>
                                    <p>Ticket From<b>52$</b></p>
                                </div>
                            </div>
                       </div>
                       </Link>
  </div>
  <div class="col-lg-3">
  <Link href="#">
                       <div class="small-image-container">
                        <img
                          src={`${process.env.PUBLIC_URL}/image/canada.png`}
                          alt="Example"
                        />
                            <div class="content main12">
                                <div class="main-content">
                                    <h2>Canada</h2>
                                    <p>Ticket From<b>52$</b></p>
                                </div>
                                <div class="hover-content">
                                    <p>Chandigarh <FontAwesomeIcon icon={faArrowsAltH} className="icon-color"/></p>
                                    <h2>Canada</h2>
                                    <p>Ticket From<b>52$</b></p>
                                </div>
                            </div>
                       </div>
                       </Link>
  </div>
</div>
    </div>
  </div>
</section>
{/* end section */}









{/* start seven section */}
<section className='Populer_Routes_section'>
  <div className='container'>
    <div className='row'>
      <div className='col-md-12 pt-5 pb-2'>
        <h2 className='Populer_Routes '>Populer  Routes </h2>
      </div>
    </div>
    <div className='row bg-white'>
                        
          {  
            cheapflight.map(flight => (
              <div className='col-md-6'>
                <Link href="#">
                <div className='flightbox d-flex align-items-center justify-content-between'>
                    <h6 className='from'>{flight.from}</h6>
                    <img src={flight.img} alt=''/>
                    <h6 className='fromto'>{flight.to}</h6>
                </div>
                </Link>
              </div>
              )
            )
          }

    </div>
  </div>
</section>
{/* end section */}



{/* eight section */}
<section className='nine_section'>
  <div className='container'>
    <div className='row'>
      <div className='col-md-12'>
      <div className='faster-booking '>
                    <div className='row'>
                      <div className='col-md-5'>
                        <img src={missoion} alt='' className='w-100 img-fluid'/>
                      </div>

                      <div className='col-md-7 p-3 pl-5 d-flex align-items-center'>
                        <div className='fasstbooking'>
                            <h3 className='signfastbook'>Our  Mission  make sure your travel is carbon negitive  </h3>
                            <p className='travel'>We care about this planet  and we want make our contribtutions  in ensuring .. </p>
                            <button className='fasstbooking_btn'>Sign in</button>
                        </div>
                      </div>
                    </div>
            </div>
      </div>
    </div>
  </div>
</section>
{/* end nine section */}









{/* header */}
<Footer/>
{/* end header  */}

    </>
  )
}
