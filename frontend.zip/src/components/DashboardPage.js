import React from 'react';
import './Common/css/style.css'; 
import Sidebar from './Common/Sidebar';
import DashboardHeader from './Common/DashboardHeader';
import { CChart } from '@coreui/react-chartjs';
import Form from 'react-bootstrap/Form';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEllipsisVertical } from '@fortawesome/free-solid-svg-icons';

export default function DashboardPage() {
  return ( 

    <>
 
<section className="admin-pages pt-o">
    <div className="container-fluid p-0">
        <div className="row p-0 m-0">
            <div className="col-md-2 bg-light">
                <Sidebar/>
            </div>

            <div className="col-md-10">
                <header><DashboardHeader/></header>

                    



<div className='row'>
        <div className='col-md-8'>
            <div className="grph_bar">
                <div className='row'>
                    <div className='col-md-8'>   
                        <h4 className="dash_blogs_title">Visitors</h4>
                    </div>
                    <div className='col-md-3'>
                        <div className='dropdowns_class'>
                        <Form.Select aria-label="Default select example form-control">
                            <option>Weekly</option>
                            <option value="1">Day</option>
                            <option value="2">Weekly</option>
                            <option value="3">Monthly</option>
                        </Form.Select>
                        </div>
                    </div>
                    <div className='col-md-1'>   
                   {/* <!-- Nav Item - User Information --> */}
                   
                        <div className="nav-item dropdown no-arrow">
                                    <div className="nav-link dropdown-toggle" to="/" id="MenuDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <div className="d-flex">
                                                <FontAwesomeIcon icon={ faEllipsisVertical }/> 
                                        </div>
                                    </div>

                                    
                                    {/* <!-- Dropdown - User Information --> */}
                                    <div className="dropdown-menu dropdown-menu-right shadow" aria-labelledby="MenuDropdown">
                                            <div className="dropdown-item" to="/">
                                                   
                                                </div>
                                                <div className="dropdown-item" to="/">
                                               
                                                    Settings 
                                                </div>
                                                <div className="dropdown-item" to="/">
                                                
                                                    Activity Log
                                                </div>
                                                <div className="dropdown-divider"></div>
                                                <div className="dropdown-item" to="/" data-toggle="modal" data-target="#logoutModal">
                                              
                                                    Logout
                                                </div>
                                    </div>
                        </div>
                    
                    </div>
                </div>
           
                <CChart
                    type="bar"
                    data={{
                        labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July'],
                        datasets: [
                           
                            {
                                id: 1,
                                backgroundColor: '#ff8d06',
                                label: 'New Visitors',
                                data: [10, 30, 12, 39, 10, 40, 39, 80, 40],
                              },
                              {
                                id: 2,
                                backgroundColor: '#2864f0',
                                label: 'Repeat Visitors',
                                data: [50, 34, 18, 29, 50, 90, 29, 30, 36],
                              },
                        ],
                    }}
                    labels="months"
                />
            </div>
        </div>

        <div className='col-md-4'>
            <div className="cucle_graph">
                <CChart
                    type="doughnut"
                    data={{
                        labels: ['Total', 'Open', 'Close'],
                        datasets: [
                            {
                                backgroundColor: ['#0daa96', '#ff8d06', '#2864f0'],
                                data: [40, 20, 80, 10],
                        
                            },
                        ],
                    
                    }}
                />

                            <div className="col-md-12">
                                <div className="d-flex ">
                                    <div className="geen_section">
                                        <span className="count">310</span>
                                        <span className="texts">Total's Request</span>
                                    </div>
                                </div>
                            </div>

                            <div className="col-md-12">
                                <div className="d-flex ">
                                    <div className="orang_section">
                                        <span className="count">100</span>
                                        <span className="texts">Today’s closed Request</span>
                                    </div>
                                </div>
                            </div>

                            <div className="col-md-12">
                                <div className="d-flex ">
                                    <div className="blue_section">
                                        <span className="count">210</span>
                                        <span className="texts">Today’s open Request</span>
                                    </div>
                                </div>
                            </div>

            </div>
        </div>
</div>

{/* <!-- Content Row --> */}
<div className="row">

{/* <!-- Blogs Card Example --> */}
            <div className="col-xl-4 col-md-6 mb-4">
                <div className="card h-100 py-2 dash_blogs">
                    <div className="card-body">
                        <div className="row no-gutters align-items-center">
                            <div className="col-md-12">
                                <div className="d-flex justify-content-between">
                                    <h4 className="dash_blogs_title">Blogs</h4>
                                    <div className="dash_blogs_cont">
                                        <span className="totl">Total</span>
                                        <span className="today">Today</span>
                                    </div>
                                </div>
                            </div>
                            <div className="col-md-12">
                                <div className="d-flex ">
                                    <div className="geen_section">
                                        <span className="count">40</span>
                                        <span className="texts">Total number of blog posted</span>
                                    </div>
                                </div>
                            </div>
                            
                            <div className="col-md-12">
                                <div className="row">
                                    <div className="col-md-6">
                                        <div className="blue_section">
                                            <span className="count">16000</span>
                                            <span className="texts">New Reader</span>
                                        </div>
                                    </div>
                                    <div className="col-md-6">
                                        <div className="orang_section">
                                            <span className="count">14000</span>
                                            <span className="texts">Repeat Reader</span>
                                        </div>
                                    </div>
                                </div>
                                <div className="row">
                                    <p className="lastpost"> Last Post: 28-may </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


 {/* <!-- end Blogs Card Example --> */}

{/* <!-- articales Card Example --> */}
    <div className="col-xl-4 col-md-6 mb-4">
                <div className="card h-100 py-2 dash_blogs">
                    <div className="card-body">
                        <div className="row no-gutters align-items-center">
                            <div className="col-md-12">
                                <div className="d-flex justify-content-between">
                                    <h4 className="dash_blogs_title">Articales</h4>
                                    <div className="dash_blogs_cont">
                                        <span className="totl">Total</span>
                                        <span className="today">Today</span>
                                    </div>
                                </div>
                            </div>
                            <div className="col-md-12">
                                <div className="d-flex ">
                                    <div className="geen_section">
                                        <span className="count">40</span>
                                        <span className="texts">Total number of blog posted</span>
                                    </div>
                                </div>
                            </div>
                            
                            <div className="col-md-12">
                                <div className="row">
                                    <div className="col-md-6">
                                        <div className="blue_section">
                                            <span className="count">16000</span>
                                            <span className="texts">New Reader</span>
                                        </div>
                                    </div>
                                    <div className="col-md-6">
                                        <div className="orang_section">
                                            <span className="count">14000</span>
                                            <span className="texts">Repeat Reader</span>
                                        </div>
                                    </div>
                                </div>
                                <div className="row">
                                    <p className="lastpost"> Last Post: 28-may </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
 {/* <!-- end Articales Card Example --> */}
            
            
{/* <!-- Messages Card Example --> */}
           <div className="col-xl-4 col-md-6 mb-4">
                <div className="card h-100 py-2 dash_blogs">
                    <div className="card-body">
                        <div className="row no-gutters align-items-center">
                            <div className="col-md-12">
                                <div className="d-flex justify-content-between">
                                    <h4 className="dash_blogs_title">Messages</h4>
                                    <div className="dash_blogs_cont">
                                        <span className="totl">Total</span>
                                        <span className="today">Today</span>
                                    </div>
                                </div>
                            </div>
                            <div className="col-md-12">
                                <div className="d-flex ">
                                    <div className="geen_section">
                                        <span className="count">300</span>
                                        <span className="texts">Total no. of messages</span>
                                    </div>
                                </div>
                            </div>
                            
                            <div className="col-md-12">
                                <div className="row">
                                    <div className="col-md-6">
                                        <div className="blue_section">
                                            <span className="count">16000</span>
                                            <span className="texts">Open</span>
                                        </div>
                                    </div>
                                    <div className="col-md-6">
                                        <div className="orang_section">
                                            <span className="count">14000</span>
                                            <span className="texts">Close</span>
                                        </div>
                                    </div>
                                </div>
                                <div className="row">
                                    {/* <p className="lastpost"> Last Post: 28-may </p> */}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
 {/* <!-- end Messages Card Example --> */}
        </div>
         {/* <!-- end Content Row --> */}





       {/* <!-- Content Row --> */}
       <div className="row">


{/* <!-- Web Pages Card Example --> */}
            <div className="col-xl-4 col-md-6 mb-4">
                <div className="card h-100 py-2 web_page">
                    <div className="card-body">
                        <div className="row no-gutters align-items-center">
                            <div className="col-md-12">
                                <div className="d-flex justify-content-between">
                                    <h4 className="dash_blogs_title">Web Pages</h4>
                                    <div className="dash_blogs_cont">
                                        <span className="totl">Web Pages</span>
                                        <span className="today">URLs</span>
                                    </div>
                                </div>
                            </div>
                            <div className="col-md-12">
                                <div className="d-flex ">
                                    <div className="geen_section">
                                        <span className="count">40</span>
                                        <span className="texts">Total number of blog posted</span>
                                    </div>
                                </div>
                            </div>
                            
                            <div className="col-md-12">
                                <div className="row">
                                    <div className="col-md-6">
                                        <div className="blue_section">
                                            <span className="count">16000</span>
                                            <span className="texts">Dynamic content</span>
                                        </div>
                                    </div>
                                    <div className="col-md-6">
                                        <div className="orang_section">
                                            <span className="count">14000</span>
                                            <span className="texts">Genric Content</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
 {/* <!-- end Web Pages Card Example --> */}

{/* <!-- Offer Card Example --> */}
    <div className="col-xl-4 col-md-6 mb-4">
                <div className="card h-100 py-2 Offer">
                    <div className="card-body">
                        <div className="row no-gutters align-items-center">
                            <div className="col-md-12">
                                <div className="d-flex justify-content-between">
                                    <h4 className="dash_blogs_title">Offers</h4>
                                </div>
                            </div>
                            
                            <div className="col-md-12">
                                <div className="row">
                                    <div className="col-md-6">
                                        <div className="blue_section">
                                            <span className="count">40</span>
                                            <span className="texts">New Reader</span>
                                            < hr/>
                                            <span className="texts_reching">Reaching Out <span>1600</span></span>
                                        </div>
                                    </div>
                                    <div className="col-md-6">
                                        <div className="orang_section offer">
                                            <span className="count">8</span>
                                            <span className="texts">Active Offer</span>
                                            < hr/>
                                            <span className="texts_reching">Reaching Out <span>1600</span></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
 {/* <!-- end Offer Card Example --> */}
            
            
{/* <!-- Jobs Card Example --> */}
           <div className="col-xl-4 col-md-6 mb-4">
                <div className="card h-100 py-2 Jobs">
                    <div className="card-body">
                        <div className="row no-gutters align-items-center">
                            <div className="col-md-12">
                                <div className="d-flex justify-content-between">
                                    <h4 className="dash_blogs_title">Jobs</h4>
                                </div>
                            </div>
                            
                            <div className="col-md-12">
                                <div className="row">
                                    <div className="col-md-6">
                                        <div className="blue_section">
                                            <span className="count">60</span>
                                            <span className="texts">Total Jobs</span>
                                        </div>
                                    </div>
                                    <div className="col-md-6">
                                        <div className="orang_section">
                                            <span className="count">8</span>
                                            <span className="texts">Active Jobs</span>
                                        </div>
                                    </div>
                                </div>
                                <div className="row">
                                    {/* <p className="lastpost"> Last Post: 28-may </p> */}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
 {/* <!-- end Jobs Card Example --> */}
        </div>
         {/* <!-- end Content Row --> */}




            </div>
        </div>
    </div>
</section> 
    </>
  )
}
