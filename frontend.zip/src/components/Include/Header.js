// import React, { useEffect, useState } from 'react'
import './css/header-footer.css'
import './css/style.css'
import logoImg from '../Assets/logo.svg';
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import mobile_menu from '../Assets/moble-menu.svg'
import { NavLink, Link } from 'react-router-dom';
// import { useParams } from "react-router-dom";
// import { useDispatch, useSelector } from 'react-redux';
// import { setLanguage } from '../../redux/Action'
// import axios from 'axios';
import Loginwith from '../Loginwith';
import SignupPop from '../SignupPopup';
import user from '../Common/img/user.svg'


export default function Header() {

    // const { slug } = useParams()
    // const [langs, setLangs] = useState([]);
    // const dispatch = useDispatch();
    // const landrex = useSelector((state) => state.reducer.language);

    // console.log('landrex ==> ' + JSON.stringify(landrex));






    /* let langs=[
        {
            id: "1",
            title: "English",
            url: "/",

        },
        {
            id: "2",
            title: "Spanish",
            url: "/es/",

        },
       
       
    

    ] */



        // dharampreet hide the language 

    // useEffect(() => {
    //     get_langauages()

    // }, [])

// dharampreet hide the language 



    // const changeURL = async (code) =>{
    //     let langObj = await get_webpage(code)
    //     if(langObj.lang && langObj.slug){
    //         localStorage.setItem('language', langObj.lang);

    //         window.location.href = '/'+langObj.slug;
    //     }else{
    //         localStorage.setItem('language', code);
    //         window.location.reload()
    //     }
    // }




// dharampreet hide the language 


    // const get_webpage = async (code) => {

    //     const currentURL = window.location.href;

    //     const delimiter = "/";

    //     // Split the string into an array using the delimiter
    //     const stringArray = currentURL.split(delimiter);

    //     // Get the last element of the array
    //     const lastElement = stringArray[stringArray.length - 1];

    //     try {
    //         let post_data = {
    //             method: 'POST',
    //             //credentials: 'same-origin',
    //             //mode: 'same-origin',
    //             body: JSON.stringify({ 'slug': lastElement, 'lang': code }),
    //             headers: {
    //                 'Accept': 'application/json',
    //                 'Content-Type': 'application/json',
    //                 //'X-CSRFToken':  cookie.load('csrftoken')
    //             }
    //         }
    //         const response = await fetch(process.env.REACT_APP_API_URL + 'webpages/bylang', post_data)

    //         const data = await response.json();

    //         if (data.length > 0) {
    //             console.log(data)
    //             return data[0];
    //         } else return false;

    //     } catch (e) {
    //         //snotify()
    //     }

    // }

    // const get_langauages = async () => {

    //     try {
    //         await axios.get('https://flight-backend-ro3e.onrender.com/api/languages')
    //             .then(data => {
    //                 console.log(data.data)
    //                 //setOrders(data)
    //                 if (data.data.length > 0) setLangs(data.data)
    //             }, (error) => {
    //                 if (error) {
    //                     console.log(error)
    //                 }
    //             });
    //     } catch (e) {
    //         //snotify()
    //     }
    // }

// dharampreet hide language


    let main_menu = [
        // {
        //     id: "1",
        //     title: "Euro",
        //     url: "/",

        // },
        {
            id: "1",
            title: "My Trips",
            url: "/"
        },
        {
            id: "2",
            title: "How can we help you?",
            url: "/how-can-we-help-you"
        }
    ]
    let logo_menu = [
        {
            id: "1",
            title: "Flights",
            url: "/fligh-deal",

        },
        {
            id: "2",
            title: "Today Deals",
            url: "/Cheap-flight",

        },
        // {
        //     id: "3",
        //     title: "Pages",
        //     url: "/pages",

        // },


    ]





    return (
        <>
            <header>
                <section className='home_page'>
                    <Navbar bg="light" expand="lg">
                        <div className='container-fluid'>
                            <NavLink to="/"> <img src={logoImg} tittle="" alt="" /></NavLink>
                            {logo_menu.map(
                                menus => (
                                    <Link key={menus.id} to={menus.url} className='logo_manu'>{menus.title}</Link>
                                )
                            )}
                            <Navbar.Toggle aria-controls="basic-navbar-nav"> <img src={mobile_menu} tittle="" alt="" /></Navbar.Toggle>
                            <Navbar.Collapse id="basic-navbar-nav" className='main_header justify-content-end'>
                                <SignupPop/>
                                {/* // dharampreet hide the language  */}

                                {/* <select onChange={(e) => dispatch(setLanguage(e.target.value))}>{langs.length > 0 ? langs.map((ke) => (<option value={ke.code} selected={localStorage.getItem('language') == ke.code ? ("selected") : ''}>{ke.name}</option>)) : ''} </select> */}

                                {/* // dharampreet hide the language  */}


                                <Nav className="me-auto ">
                                    {
                                        main_menu.map(

                                            menus => (
                                                <Link key={menus.id} to={menus.url} >{menus.title}</Link>
                                            )
                                        )
                                    }
                                </Nav>
                                {/* <button className='sign_in_btn'>Sign in</button> */}
                                <div className='menu_icon_dp'>
                                <img src={user} width={20} height={20} />
                                <Loginwith/>
                                </div>
                            </Navbar.Collapse>
                        </div>
                    </Navbar>

                </section>
            </header>
        </>
    )
}
