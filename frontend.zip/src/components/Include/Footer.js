import React from 'react'
import { Link } from 'react-router-dom';
import tweeter from '../Assets/029-twitter 2.svg';
import instagram from '../Assets/020-instagram 2.svg';
import linkdin from '../Assets/002-linkedin 2.svg';
import facebook from '../Assets/012-facebook 2.svg';
import secure from '../Assets/020-secure 1.svg';
import teamandcondition from '../Assets/044-invoice 1.svg';
import Media from '../Assets/047-agreement 1.svg';
import Condition from '../Assets/035-contract 1.svg';
import Privacy from '../Assets/008-document 2.svg';
import about from '../Assets/020-couple 1.svg';
import contactimg from '../Assets/035-contract 1.svg';
import helpcenter from '../Assets/014-24-hours-support 1.svg';
import faq from '../Assets/046-question 2.svg';




export default function Footer() {

  const Travel=[
    {
        id: "1",
        title: "City breaks",
        url: "/admin",
    },
    {
      id: "2",
      title: "Last minute flights",
      url: "/admin",
    },
    {
      id: "3",
      title: "Cheap flights",
      url: "/admin",
    },
    {
      id: "4",
      title: "Low cost flights",
      url: "/admin",
    },
    {
      id: "5",
      title: "Flight discount codes",
      url: "/admin",
    },

    ]

    const Airlines=[
      {
          id: "1",
          title: "Iberia Airline",
          url: "/admin",
      },
      {
        id: "2",
        title: "Tap Portgual",
        url: "/admin",
      },
      {
        id: "3",
        title: "Luftansa",
        url: "/admin",
      },
      {
        id: "4",
        title: "Air Europa",
        url: "/admin",
      },
      {
        id: "5",
        title: "Brussel Airline",
        url: "/admin",
      },
      {
        id: "6",
        title: "Turkish Airline",
        url: "/admin",
      },
  
      ]

      const Routes=[
        {
            id: "1",
            title: "Flights from London to Rome",
            url: "/admin",
        },
        {
          id: "2",
          title: "Flights from Delhi to Paris",
          url: "/admin",
        },
        {
          id: "3",
          title: "Flights to Alicante",
          url: "/admin",
        },
        {
          id: "4",
          title: "Flights to Palma",
          url: "/admin",
        },
        {
          id: "5",
          title: "Flights from Oslo to Barcelona",
          url: "/admin",
        },
        {
          id: "6",
          title: "Flights from Neyork to Amsterdam",
          url: "/admin",
        },
      
      ]

     


// footer

      const Company=[
        {
            id: "1",
            title: " Security",
            img_url: secure,
            url: "/security",
        },
        {
          id: "2",
          title: "Terms of Use",
          url: "/Terms-of-use",
          img_url: teamandcondition,
        },
        {
          id: "3",
          title: "Privacy Policy",
          url: "/Privacy-policy",
          img_url: Privacy,
        },
        {
          id: "4",
          title: "Term & Condition",
          url: "/Term-and-conditions",
          img_url: Condition,
        },
        {
          id: "5",
          title: "Story",
          url: "/story",
          img_url: Media,
        },
      
        ]
        
        const Platfrom=[
          {
              id: "1",
              title: "About us",
              url: "/about",
              img_url: about,
          },
          {
            id: "2",
            title: "Contact us",
            url: "/contact-us",
            img_url: contactimg,
          },
          {
            id: "3",
            title: "Job",
            url: "/jobs",
            img_url: helpcenter,
          },
          {
            id: "4",
            title: "Blog",
            url: "/blog",
            img_url: faq,
          },
          ]
          

  return (
    <>
    
    <section className='footer  my-3'>
      <div className='container'>
{/* start footer top menu */}
        <div className='row '>
          <div className='col-md-3'>
            <div className='Travel-links'>
                <h6>Travel links</h6>
                <ul>
                    {
                      Travel.map( 
                        tevls=>(
                          <li key={tevls.id}>
                            <Link to={tevls.url}>{tevls.title}</Link>
                          </li> 
                        )
                      )
                    }
                </ul>
            </div>
          </div>
          <div className='col-md-3'>
            <div className='Top-Airlines'>
                <h6>Top Airlines</h6>
                <ul>
                    {
                      Airlines.map( 
                        tevls=>(
                          <li key={tevls.id} >
                            <Link to={tevls.url}>{tevls.title}</Link>
                          </li> 
                        )
                      )
                    }
               
                </ul>
            </div>
          </div>
          <div className='col-md-3'>
            <div className='Populer-Routes'>
                <h6>Populer Routes </h6>
                <ul>
                    {
                      Routes.map( 
                        tevls=>(
                          <li key={tevls.id}>
                            <Link to={tevls.url}>{tevls.title}</Link>
                          </li> 
                        )
                      )
                    }
                </ul>
            </div>
          </div>
          <div className='col-md-3'></div>
        </div>
        </div>
</section>

{/* end footer top menu */}


{/* start footer bottom menu */}

<section className='footer-bottom'>
    <div className='container'>
        <hr className='footer-divider'/>
        <div className='row'>
          <div className='col-md-3'>
            <div className='Company '>
                <h6>Company</h6>
                <ul>
                    {
                      Company.map( 
                        tevls=>(
                          <li key={tevls.id}>
                            <Link to={tevls.url} ><img  src={tevls.img_url} alt=''/> {tevls.title}</Link>
                          </li> 
                        )
                      )
                    }
                </ul>
            </div>
          </div>
          <div className='col-md-3'>
            <div className='Platfrom'>
                <h6>Platfrom</h6>
                <ul>
                    {
                      Platfrom.map( 
                        tevls=>(
                          <li key={tevls.id}>
                            <Link to={tevls.url} ><img src={tevls.img_url} alt='' />{tevls.title}</Link>
                          </li> 
                        )
                      )
                    }
                </ul>
            </div>
          </div>
          <div className='col-md-3'>
            <div className='Carrier'>
                <h6>Carrier </h6>
                   <Link to="/jobs"> <button className='carrier-btn'  >we Hiring</button></Link>
            </div>
          </div>
          <div className='col-md-3'>
            <div className='Follow'>
                  <h6 className='pl-2'>Follow  us</h6>
                  <div className='share_icon'>
                    <Link className="share-tweeter" to="/">
                      <img src={ tweeter } tittle="" alt="" />
                    </Link>
                    <Link className="share-tweeter" to="/">
                      <img src={ instagram } tittle="" alt="" />
                    </Link>
                    <Link className="share-tweeter" to="/">
                      <img src={ linkdin } tittle="" alt="" />
                    </Link>
                    <Link className="share-tweeter" to="/">
                      <img src={ facebook } tittle="" alt="" />
                    </Link>

                  </div>
            </div>
          </div>
        </div>
{/* end footer bottom menu */}
      </div>
    </section>
    
    </>
  )
}
