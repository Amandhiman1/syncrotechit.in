import { SET_LANGUAGE, IS_ADMIN, COUNTRY_CODE } from './Constants'

const initialState = {
    language: 'en',
    isAdmin: null,
    countryCode: 'IN'
}
export const reducer = (state = initialState, action) => {
    switch (action.type) {
        case SET_LANGUAGE:
            return {
                ...state,
                language: action.payload
            }
        case IS_ADMIN:
            return {
                ...state,
                isAdmin: action.payload
            }
        case COUNTRY_CODE:
            return {
                ...state,
                countryCode: action.payload
            }
        default:
            return state;
    }
}