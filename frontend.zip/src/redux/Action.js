import axios from "axios";
import { SET_LANGUAGE, IS_ADMIN, COUNTRY_CODE } from "./Constants";

export const setLanguage = (lang) => ({
  type: SET_LANGUAGE,
  payload: lang,
});

export const setIsAdmin = (isAdmin) => ({
  type: IS_ADMIN,
  payload: isAdmin,
});

export const setCountryCode = (country_code) => ({
  type: COUNTRY_CODE,
  payload: country_code,
});

// export const checkAdminLogin = () => async (dispatch) => {
//   try {
//     const response = await axios.get("https://flight-backend-ro3e.onrender.com/api/admin/checkLogin", { withCredentials: true });
//     const { isLoggedIn, admin } = response.data;
//     console.log('isLoggedIn', isLoggedIn);
//     if (isLoggedIn) {
//       dispatch({ type: IS_ADMIN, payload: true });
//     } else {
//       dispatch({ type: IS_ADMIN, payload: false });
//     }
//   } catch (error) {
//     dispatch({ type: IS_ADMIN, payload: false });
//   }
// };

export const checkAdminLogin = () => async (dispatch, getState) => {
  const { isAdmin } = getState().reducer; // Get the current isAdmin value from the state
  if (isAdmin !== null) {
    // If isAdmin is already set, don't dispatch the server response
    return;
  }

  try {
    const response = await fetch("https://flight-backend-ro3e.onrender.com/api/admin/checkLogin", {
      method: "GET",
      credentials: "include" // Use 'include' to send cookies along with the request
    });
    
    if (!response.ok) {
      throw new Error("Network response was not ok.");
    }
  
    const data = await response.json();
    const { isLoggedIn, admin } = data;
  
    if (isLoggedIn) {
      dispatch(setIsAdmin(admin));
    } else {
      dispatch(setIsAdmin(false)); // Set isAdmin to false if not logged in
    }
  } catch (error) {
    console.error("Error fetching data:", error);
    dispatch(setIsAdmin(false)); // Handle error, set isAdmin to false
  }

  // try {
  //   const response = await axios.get("https://flight-backend-ro3e.onrender.com/api/admin/checkLogin", { withCredentials: true });
  //   const { isLoggedIn, admin } = response.data;
  //   if (isLoggedIn) {
  //     dispatch(setIsAdmin(admin));
  //   } else {
  //     dispatch(setIsAdmin(false)); // Set isAdmin to false if not logged in
  //   }
  // } catch (error) {
  //   dispatch(setIsAdmin(false)); // Handle error, set isAdmin to false
  // }
};
