export const SET_LANGUAGE='SET_LANGUAGE';
export const IS_ADMIN='IS_ADMIN';
export const COUNTRY_CODE='COUNTRY_CODE';