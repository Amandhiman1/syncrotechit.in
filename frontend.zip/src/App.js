import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import "./components/Dashboard/Common/css/admin-2.min.css";
import "./components/Include/css/responsive.css";
import "./components/Include/css/style.css";
import React from "react";
import "bootstrap/dist/js/bootstrap.js";
import "bootstrap/dist/css/bootstrap.css";
import "bootstrap/dist/js/bootstrap.bundle.js";
import {
  BrowserRouter as Router,
  // Routes,
  Route,
  Switch,
} from "react-router-dom";
import { ToastContainer, Slide } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
// admin
import DashboardPage from "./components/Dashboard/DashboardPage";
import DashboardVisitersPage from "./components/Dashboard/DashboardVisiterspage";
import DashboardPages from "./components/Dashboard/DashboardPages";
import DashboardCategories from "./components/Dashboard/DashboardCategories";
import DashboardcallBackpage from "./components/Dashboard/DashboardcallBackpage";
import DashboardOfferpage from "./components/Dashboard/DashboardOfferpage";
import Dashboardmessagepage from "./components/Dashboard/Dashboardmessagepage";
import DashboardNewsletter from "./components/Dashboard/DashboardNewsletter";
import DashboardMedia from "./components/Dashboard/DashboardMedia";
import DashboardBlog from "./components/Dashboard/DashboardBlog";
import DashboardWeb_page from "./components/Dashboard/DashboardWeb_page";
import DashboardAddWebPage from "./components/Dashboard/DashboardAddWebPage";
import DashboardReportspage from "./components/Dashboard/DashboardReportspage";
import DashboardPeoplespage from "./components/Dashboard/DashboardPeoplespage";
import DashboardLanguagepage from "./components/Dashboard/DashboardLanguagepage";
import DashboardJobspage from "./components/Dashboard/DashboardJobspage";
import DashboardFrequentlypage from "./components/Dashboard/DashboardFrequentlypage";
import DashboardCurrencypage from "./components/Dashboard/DashboardCurrencypage";
import DashboardJobs_viewpage from "./components/Dashboard/DashboardJob_viewpage";
import Login_form from "./components/Dashboard/Common/Login_form";
import DashboardEditPage from "./components/Dashboard/DashboardEditPage";
import DashboardTypeEditPage from "./components/Dashboard/DashboardTypeEditPage";

// end admin

// main page

import Index from "./components/Index";
import About from "./components/About";
import Blog from "./components/Blog";
import Security from "./components/Security";
import Contact from "./components/Contact";
import FlightDeal from "./components/Flight_Deals";
import Jobs from "./components/Jobs";
import TermsOfUse from "./components/TermsOfUse";
import PrivacyPolicy from "./components/PrivacyPolicy";
import TermAndConditions from "./components/TermAndConditions";
import Blog_view from "./components/Blog_view";
import CheapFlight from "./components/CheapFlight";
import JobCareerOportunity from "./components/JobCareerOportunity";
import ContactHelpYou from "./components/ContactHelpYou";
import Story from "./components/Story";
import JobCareerViwe from "./components/JobCareerViwe";
import JobViewDetail from "./components/JobViewDetail";
import Pages from "./components/Pages";
import SinglePage from "./components/SinglePage";
import ThankYou from "./components/ThankYou";
import DashboardCMSPages from "./components/Dashboard/DashboardCMSPages";
import DashboardAddCMSPage from "./components/Dashboard/DashboardAddCMSPage";
import DashboardAddArticlePage from "./components/Dashboard/DashboardAddArticlePage";
import FaqQuestion from "./components/FaqQuestion";
import FaqArticle from "./components/FaqArticle";

import PrivateRoute from "./PrivateRoute";
// import useAuth from "./useAuth";
import DashboardAddBlog from "./components/Dashboard/DashboardAddBlog";
import DashboardEditBlog from "./components/Dashboard/DashboardEditBlogPage";
import DashboardProfilePage from "./components/Dashboard/DashboardProfilePage";
import DashboardAddOffer from "./components/Dashboard/DashboardAddOffer";
import OfferDetails from "./components/OfferDetails";
import DashboardAddJob from "./components/Dashboard/DashboardAddJob";
import DashboardEditJob from "./components/Dashboard/DashboardEditJob";
import DashboardEditOffer from "./components/Dashboard/DashboardEditOffer";
import DashboardTaskAssigning from "./components/Dashboard/DashboardTaskAssigning";


// end main page

function App() {
  // const { isLoggedIn } = //useAuth();
  return (
    <>



      <Router>
        <Switch>
          {/* admin */}
          <PrivateRoute
            exact
            path="/admin/dashboard"
            component={DashboardPage}
          />
          <PrivateRoute
            exact
            path="/admin/visiters"
            component={DashboardVisitersPage}
          />
          <PrivateRoute
            exact
            path="/admin/call-back"
            component={DashboardcallBackpage}
          />
          <PrivateRoute
            exact
            path="/admin/offer"
            component={DashboardOfferpage}
          />
          <PrivateRoute
            exact
            path="/admin/message"
            component={Dashboardmessagepage}
          />
          <PrivateRoute exact path="/admin/blog" component={DashboardBlog} />
          <PrivateRoute
            exact
            path="/admin/news-letter"
            component={DashboardNewsletter}
          />
          <PrivateRoute exact path="/admin/media" component={DashboardMedia} />
          <PrivateRoute
            exact
            path="/admin/web-pages"
            component={DashboardWeb_page}
          />
          <PrivateRoute
            exact
            path="/admin/add-page"
            component={DashboardAddWebPage}
          />
          <PrivateRoute
            exact
            path="/admin/add-cms-page"
            component={DashboardAddCMSPage}
          />
          <PrivateRoute
            exact
            path="/admin/pages/:id"
            component={DashboardPages}
          />
          <PrivateRoute
            exact
            path="/admin/cms-pages"
            component={DashboardCMSPages}
          />
          <PrivateRoute
            exact
            path="/admin/categories"
            component={DashboardCategories}
          />
          <PrivateRoute
            exact
            path="/admin/jobs"
            component={DashboardJobspage}
          />
          <PrivateRoute
            exact
            path="/admin/Jobs-view"
            component={DashboardJobs_viewpage}
          />
          <PrivateRoute
            exact
            path="/admin/frequently-asked"
            component={DashboardFrequentlypage}
          />
          <PrivateRoute
            exact
            path="/admin/peoples"
            component={DashboardPeoplespage}
          />
          <PrivateRoute
            exact
            path="/admin/reports"
            component={DashboardReportspage}
          />
          <PrivateRoute
            exact
            path="/admin/currency"
            component={DashboardCurrencypage}
          />
          <PrivateRoute
            exact
            path="/admin/language"
            component={DashboardLanguagepage}
          />
          <PrivateRoute
            exact
            path="/admin/update-page/:slug"
            component={DashboardEditPage}
          />
          <PrivateRoute
            exact
            path="/admin/update-page-types/:id"
            component={DashboardTypeEditPage}
          />
          <PrivateRoute
            exact
            path="/admin/add-article"
            component={DashboardAddArticlePage}
          />
          <PrivateRoute
            exact
            path="/admin/add-blog"
            component={DashboardAddBlog}
          />
          <PrivateRoute
            exact
            path="/admin/edit-blog/:slug"
            component={DashboardEditBlog}
          />
          <PrivateRoute
            exact
            path="/admin/add-offer"
            component={DashboardAddOffer}
          />
          <PrivateRoute
            exact
            path="/admin/profile"
            component={DashboardProfilePage}
          />
          <PrivateRoute
            exact
            path="/admin/add-job"
            component={DashboardAddJob}
          />
          <PrivateRoute
            exact
            path="/admin/edit-job/:jobSlug"
            component={DashboardEditJob}
          />
          <PrivateRoute
            exact
            path="/admin/edit-offer/:id"
            component={DashboardEditOffer}
          />
          <PrivateRoute
            exact
            path="/admin/task-assigning"
            component={DashboardTaskAssigning}
          />
          <Route exact path="/admin/login" component={Login_form} />
          {/* end admin */}

          {/* main */}
          <Route exact path="/" component={Index} />
          <Route exact path="/about" component={About} />
          <Route exact path="/contact-us" component={Contact} />
          <Route exact path="/how-can-we-help-you" component={ContactHelpYou} />
          <Route exact path="/thank-you" component={ThankYou} />
          <Route exact path="/blog" component={Blog} />
          <Route exact path="/blog/category/:categorySlug" component={Blog} />
          <Route exact path="/blog-view/:blogSlug" component={Blog_view} />
          <Route exact path="/security" component={Security} />
          <Route exact path="/fligh-deal" component={FlightDeal} />
          <Route exact path="/jobs" component={Jobs} />
          <Route exact path="/job-career-view" component={JobCareerViwe} />
          <Route exact path="/offer/:id" component={OfferDetails} />
          <Route
            exact
            path="/job-career-oportunity"
            component={JobCareerOportunity}
          />
          <Route exact path="/Terms-of-use" component={TermsOfUse} />
          <Route exact path="/Privacy-policy" component={PrivacyPolicy} />
          <Route
            exact
            path="/Term-and-conditions"
            component={TermAndConditions}
          />
          <Route exact path="/Cheap-flight" component={CheapFlight} />
          <Route exact path="/story" component={Story} />
          <Route exact path="/job-view-detail/:slug" component={JobViewDetail} />
          <Route exact path="/pages" component={Pages} />
          <Route exact path="/page/:slug" component={SinglePage} />
          <Route exact path="/question/:questionSlug" component={FaqQuestion} />
          <Route exact path="/article/:articleSlug" component={FaqArticle} />
          {/* end main */}
        </Switch>
      </Router>
     
      <ToastContainer
        position="top-right"
        autoClose={5000}
        hideProgressBar={false}
        newestOnTop={false}
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
        theme="light"
        transition={Slide}
      />
      {/* Same as */}
      <ToastContainer />
    </>
  );
}

export default App;
